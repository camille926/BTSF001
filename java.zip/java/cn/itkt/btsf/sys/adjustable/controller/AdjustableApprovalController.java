package cn.itkt.btsf.sys.adjustable.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.itkt.btsf.sys.adjustable.vo.AdjustableVO;
import cn.itkt.btsf.sys.adjustable.vo.ApprovalHistoryVO;

/**
 * 调账单任务处理和办理Controller
 */
@Controller
@RequestMapping("/adjustable/approvaladj")
public class AdjustableApprovalController {
	
	@Resource
	AdjustableApprovalSupport adjustableApprovalSupport;
	/**
	 * 任务审批
	 * @param modelMap
	 * @param eransferbillNo
	 * @return
	 */
	@RequestMapping("/approval")
	public String getAdjustableInfo(ModelMap modelMap, @RequestParam(value="eransferbillNo",required=false,defaultValue="") String eransferbillNo,@RequestParam(value="taskid",required=false,defaultValue="") String taskid){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,taskid);
		adjustableApprovalSupport.doDefauteticket(modelMap, eransferbillNo);//颓废票查询
		return "adjustable/repeatadj/show";
	}
	/**
	 * 任务审批结果处理
	 * @param modelMap
	 * @param approvalHistoryVO
	 * @return
	 */
	@RequestMapping(value="/approvalresult", method = RequestMethod.POST)
	public String doApprovalResult(ModelMap modelMap,@ModelAttribute("approvalHistoryVO") ApprovalHistoryVO approvalHistoryVO){
		adjustableApprovalSupport.doApprovalResult(modelMap,approvalHistoryVO);
		return "baseinfo/area/showMessage";
	}
	
	/**
	 * 跳转退款处理页面
	 * @param modelMap
	 * @param approvalHistoryVO
	 * @return
	 */
	@RequestMapping(value="/toCheckout")
	public String doCheckout(ModelMap modelMap, @RequestParam(value="eransferbillNo",required=false,defaultValue="") String eransferbillNo,@RequestParam(value="taskid",required=false,defaultValue="") String taskid){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,taskid);
		adjustableApprovalSupport.doDefauteticket(modelMap, eransferbillNo);//颓废票查询
		modelMap.addAttribute("action", "checkout");
		return "adjustable/repeatadj/show";
	}
	
	/**
	 * 跳转审核页面
	 * @param modelMap
	 * @param approvalHistoryVO
	 * @return
	 */
	@RequestMapping(value="/toAudit")
	public String toAudit(ModelMap modelMap, @RequestParam(value="eransferbillNo",required=false,defaultValue="") String eransferbillNo,@RequestParam(value="taskid",required=false,defaultValue="") String taskid){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,taskid);
		modelMap.addAttribute("action", "audit");
		adjustableApprovalSupport.doDefauteticket(modelMap, eransferbillNo);//颓废票查询
		return "adjustable/repeatadj/show";
	}
	
	/**
	 * 跳转审核修改页面
	 * @param modelMap
	 * @param approvalHistoryVO
	 * @return
	 */
	@RequestMapping(value="/toAuditUpdate")
	public String toAuditUpdate(ModelMap modelMap, @RequestParam(value="eransferbillNo",required=false,defaultValue="") String eransferbillNo,
			@RequestParam(value="taskid",required=false,defaultValue="") String taskid){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,taskid);
		return "adjustable/repeatadj/info";
	}

	
	/**
	 * 跳转更新调帐单
	 * @param id 调帐单Id
	 * @return
	 */
	@RequestMapping(value="/toUpdateByEransferbillNo")
	public String toUpdateByEransferbillNo(ModelMap modelMap,
			@RequestParam(value="eransferbillNo",required=false,defaultValue="") String eransferbillNo,
			@RequestParam(value="taskid",required=false,defaultValue="") String taskid){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,taskid);
		adjustableApprovalSupport.doDefauteticket(modelMap, eransferbillNo);//颓废票查询
		modelMap.addAttribute("action", "anthorUpdate");
		return "adjustable/repeatadj/info";
	}
	
	/**
	 * 审核修改
	 * @param modelMap
	 * @param vo
	 * @return
	 */
	@RequestMapping(value="/update") 
	public String update(ModelMap modelMap,@ModelAttribute AdjustableVO vo){
		this.adjustableApprovalSupport.update(modelMap, vo);
		modelMap.addAttribute("refundType", vo.getRefundtype());
		adjustableApprovalSupport.doApprovalResult(modelMap,vo.getApprovalHistory());
		return "baseinfo/area/showMessage";
	}
	
	/**
	 * 跳转审批
	 * @param modelMap
	 * @param approvalHistoryVO
	 * @return
	 */
	@RequestMapping(value="/toApproval")
	public String toApproval(ModelMap modelMap, @RequestParam(value="eransferbillNo",required=false,defaultValue="") String eransferbillNo,@RequestParam(value="taskid",required=false,defaultValue="") String taskid){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,taskid);
		adjustableApprovalSupport.doDefauteticket(modelMap, eransferbillNo);//颓废票查询
		modelMap.addAttribute("action", "approval");
		return "adjustable/repeatadj/show";
	}
	/**
	 * 财务结算跳转
	 * @param modelMap
	 * @param eransferbillNo
	 * @param taskid
	 * @return
	 */
	@RequestMapping(value="/toConfim")
	public String toConfim(ModelMap modelMap, @RequestParam(value="eransferbillNo",required=false,defaultValue="") String eransferbillNo,@RequestParam(value="taskid",required=false,defaultValue="") String taskid){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,taskid);
		adjustableApprovalSupport.doDefauteticket(modelMap, eransferbillNo);//颓废票查询
		modelMap.addAttribute("action", "confim");
		return "adjustable/repeatadj/show";
	}
	/**
	 * 调账单打印页面
	 * @param modelMap
	 * @param eransferbillNo
	 * @return
	 */
	@RequestMapping("/doPrint")
	public String getAdjustableInfo(ModelMap modelMap, @RequestParam String eransferbillNo){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,"");
		return "adjustable/repeatadj/print";
	}
	/**
	 * 跳转复议处理页面
	 * @param modelMap
	 * @param approvalHistoryVO
	 * @return
	 */
	@RequestMapping(value="/toReconsideration")
	public String doReconsideration(ModelMap modelMap, @RequestParam(value="eransferbillNo",required=false,defaultValue="") String eransferbillNo){
		adjustableApprovalSupport.getAdjustableInfo(modelMap, eransferbillNo,"");
		modelMap.addAttribute("action", "reconsideration");
		return "adjustable/repeatadj/show";
	}
}
