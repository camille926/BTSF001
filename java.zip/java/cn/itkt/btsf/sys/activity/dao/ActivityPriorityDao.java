package cn.itkt.btsf.sys.activity.dao;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.sys.activity.po.ActivityPO;
import cn.itkt.btsf.sys.activity.vo.ActivityGroupVO;
import cn.itkt.btsf.sys.activity.vo.ActivityVO;

/**
 * 活动信息表 
 * @author codegen 2011-10-13 14:04:30 
 */

public interface ActivityPriorityDao {
	/**
	 * 查询活动组列表
	 * @return
	 */
	public List<ActivityGroupVO> listActivityGroup();
	/**
	 * 设置活动优先级
	 * @param map
	 */
	public void activityPrioritySet(Map<String, Object> map);
	/**
	 * 删除所有活动优先级
	 */
	public void deleteAllPriority();
	/**
	 * 更新活动组的优先级
	 * @param map
	 */
	public void updateGroupPriority(Map<String, Object> map);
	/**
	 * 从活动组中删除某个活动
	 * @param map
	 */
	public void deleteActivityPriority(Map<String, Object> map);
	/**
	 * 删除活动组
	 * @param groupId
	 */
	public void deleteActivityGroup(Long groupId);
	/**
	 * 删除活动组
	 * @param groupId
	 */
	public void deleteActivityGroupPriority(Long groupId);
	/**
	 * 创建指定优先级的活动组
	 * @param group
	 */
	public int createGroup(ActivityGroupVO group);
	/**
	 * 向活动组中添加活动
	 * @param map
	 */
	public void createActivityPriority(HashMap<String, Object> map);
	/**
	 * 查询活动列表
	 * @param map
	 */
	public List<ActivityPO> findAllActivityForPage(Map<Object, Object> map);
	/**
	 * 查询活动列表记录数
	 * @param map
	 */
	public int countFindAllActivityForPage(Map<Object, Object> map);
	


}