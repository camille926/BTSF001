package cn.itkt.btsf.sys.activity.dao;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.sys.activity.po.ActivityPO;

/**
 * 活动信息表 
 * @author xuyh 2012-09-24 14:04:30 
 */

public interface ActivityDao {
	
	/**
	 * 查找所有 --分页
	 * @return List<ActivityPO> 
	 */
	public List<ActivityPO> findAllActivityForPage(Map<String,Object> map);
	/**
	 * 取站内所有数据行
	 * @param po 
	 */
	public int countFindAllActivityForPage(Map<String,Object> map);
	
	/**
	 * 获取所有的活动类型
	 * @return
	 */
	public List<Map<String,Object>> getAllActivityTypes() ;
	/**
	 * 获取活动方式的数据
	 * @return
	 */
	public List<Map<String,Object>> getActivityWay(long activityId) ;

	
	/**
	 * 获取所有的所属条件信息
	 * @return
	 */
	public List<Map<String,Object>> getActivityConditions(long activityType);
	
	
	/**
	 * 获取该活动所有的已经选条件信息
	 * @return
	 */
	public List<Map<String,Object>> getActivityConditionValues(long activityId);
	
	/**
	 * 查找单个 
	 * @param id 
	 * @return Activity 
	 */
	public ActivityPO findActivity(String activityId);
	/**
	 * 创建 
	 * @param po 
	 */
	public void createActivity(ActivityPO po);

	/**
	 * 创建活动方式数据
	 * @param ways
	 */
	public void createActivityWay(Map<String,Object> ways);
	/**
	 * 创建活动条件
	 * @param conds
	 */
	public void createActivityConds(Map<String,Object> conds);

	/**
	 * 修改 
	 * @param po 
	 */
	public void updateActivity(ActivityPO po);
	/**
	 * 删除 
	 * @param activityId 
	 */
	public void deleteActivity(String activityId);
	/**
	 * 根据活动id删除活动组优先级表中记录
	 * @param activityId
	 */
	public void deleteActivityPriority(String activityId);
	/**
	 * 根据活动id删除活动方式表中记录
	 * @param activityId
	 */
	public void deleteActivityWay(long activityId);
	
	/**
	 * 根据活动id删除活动条件表中记录
	 * @param activityId
	 */
	public void deleteActivityConds(long activityId);
	
	
	
}