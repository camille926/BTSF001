package cn.itkt.btsf.sys.activity.dao;
import java.util.List;
import java.util.Map;

/**
 * 活动信息表 
 * @author xuyh 2012-09-24 14:04:30 
 */

public interface ActivityConditionDao {
	/**
	 * 查询所有舱位
	 * @return
	 */
	public List<Map<String, Object>> findAllShippingSpaceList(Map<String,Object> reqs);

	public List<Map<String, Object>> queryAirLine(Map<String, Object> reqs);

	public int countAirLine(Map<String, Object> reqs);

	public List<Map<String, Object>> queryCity(Map<String, Object> reqs);

	public List<Map<String, Object>> queryAllCity(Map<String, Object> reqs);

	public int countCity(Map<String, Object> reqs);
	
	public List<Map<String, Object>> queryProvince(Map<String, Object> reqs);
	
	public List<Map<String, Object>> queryUserChannels(Map<String, Object> reqs);

	public List<Map<String, Object>> queryRecommendPhone(Map<String, Object> reqs);
	
	public int countRecommendPhone(Map<String, Object> reqs);
	
	public List<Map<String, Object>> queryAirCompany(Map<String, Object> reqs);
	
	public int countAirCompany(Map<String, Object> reqs);
	
	
	
}