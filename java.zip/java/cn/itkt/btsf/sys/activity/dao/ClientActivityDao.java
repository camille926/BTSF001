package cn.itkt.btsf.sys.activity.dao;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.sys.activity.po.ClientActivityPO;

/**
 * 客户端活动信息表 
 * @author xuyh 2012-09-24 14:04:30 
 */

public interface ClientActivityDao {
	
	/**
	 * 查找所有 --分页
	 * @return List<ClientActivityPO> 
	 */
	public List<ClientActivityPO> findAllActivityForPage(Map<String,Object> map);
	/**
	 * 获取所有数据行
	 * @param po 
	 */
	public int countFindAllActivityForPage(Map<String,Object> map);
	
	/**
	 * 查找单个 
	 * @param id 
	 * @return Activity 
	 */
	public ClientActivityPO findActivity(String activityId);
	/**
	 * 创建 
	 * @param po 
	 */
	public void createActivity(ClientActivityPO po);
	/**
	 * 修改 
	 * @param po 
	 */
	public void updateActivity(ClientActivityPO po);
	/**
	 * 删除 
	 * @param activityId 
	 */
	public void deleteActivity(String activityId);
	
	/**
	 * 设置
	 * @param activityId 
	 */
	public void updateActivityOrder(Map<String,Object> map);
	
}