package cn.itkt.btsf.sys.activity.po;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 客户端活动表
 * 
 * @author xuyh
 * @date 2012-09-21
 */
public class ClientActivityPO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** 活动主键ID **/
	private long id;

	/** 活动编号 **/
	private String activityId;

	/** 活动名称 **/
	private String activityName;

	/** 活动开始时间 **/
	private Date activityStartDate;

	/** 活动结束时间 **/
	private Date activityEndDate;

	/** 客户端活动状态(01:正常；02:暂停；03:过期)**/
	private String activityStatus;

	/** 活动备注 **/
	private String activityRemark;
	
	/** 活动图片的url **/
	private String activityImage;
	
	/** 活动图片名称(临时用) **/
	private String tempActivityImage;
	
	/** 活动已经开始 **/
	private boolean hasStarted;
	
	/** 活动顺序 **/
	private int activityOrder;

	public int getActivityOrder() {
		return activityOrder;
	}

	public void setActivityOrder(int activityOrder) {
		this.activityOrder = activityOrder;
	}

	public String getTempActivityImage() {
		return tempActivityImage;
	}

	public void setTempActivityImage(String tempActivityImage) {
		this.tempActivityImage = tempActivityImage;
	}

	public String getActivityImage() {
		return activityImage;
	}

	public void setActivityImage(String activityImage) {
		this.activityImage = activityImage;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public Date getActivityStartDate() {
		return activityStartDate;
	}

	public void setActivityStartDate(Date activityStartDate) {
		this.activityStartDate = activityStartDate;
	}

	public Date getActivityEndDate() {
		return activityEndDate;
	}

	public void setActivityEndDate(Date activityEndDate) {
		this.activityEndDate = activityEndDate;
	}

	public String getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}

	public String getActivityRemark() {
		return activityRemark;
	}

	public void setActivityRemark(String activityRemark) {
		this.activityRemark = activityRemark;
	}

	public boolean isHasStarted() {
		this.hasStarted = false;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String today = sdf.format(new Date());
		String start = sdf.format(this.activityStartDate);
		if(today.compareTo(start)>=0){
			this.hasStarted = true;
		}
		return hasStarted;
	}

	public void setHasStarted(boolean hasStarted) {
		System.out.println("============================");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
		String today = sdf.format(new Date());
		String start = sdf.format(this.activityStartDate);
		if(today.compareTo(start)>=0){
			this.hasStarted = true;
		}
		this.hasStarted = hasStarted;
	}


}