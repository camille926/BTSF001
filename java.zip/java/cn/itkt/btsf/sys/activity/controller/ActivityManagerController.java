package cn.itkt.btsf.sys.activity.controller;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.btsf.sys.activity.vo.ActivityVO;
/**
 * 活动管理控制器
 * @author xuyh
 * @date 2012-09-21
 */
@Controller
@RequestMapping("/sys/activity/manager")
public class ActivityManagerController {

	@Resource
	private  ActivityManagerControllerSupport  activityManagerControllerSupport;
	
	/**
	 * 分页--条件查询
	 * @param modelMap
	 * @param startIndex
	 * @param reqs 查询参数
	 * @return
	 */
	@RequestMapping(value="/listActivity")
	public String listActivity(ModelMap modelMap,@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,@RequestParam Map<String, Object> reqs){
		//调用Support处理业务逻辑
		activityManagerControllerSupport.listActivity(modelMap, startIndex, reqs);
		activityManagerControllerSupport.getAllActivityTypes(modelMap);
		return "sys/activity/activityList";		
	}
	
	/**
	 * 添加活动,第一步,活动基本信息
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/addActivityView")
	public String addActivityView(ModelMap modelMap){
		//调用Support处理业务逻辑
		activityManagerControllerSupport.getAllActivityTypes(modelMap);
		Date today = new Date();
 		modelMap.addAttribute("activityStartDate", today);
		modelMap.addAttribute("activityEndDate", today);
		return "sys/activity/activityAdd";		
	}
	
	/**
	 * 添加活动,第二步,活动条件
	 * @param modelMap
	 * @param vo 活动实体信息
	 * @return
	 */
	@RequestMapping(value="/addActivityView2")
	public String addActivityView2(ModelMap modelMap,@ModelAttribute ActivityVO vo,HttpServletRequest request){
		//接收文件
		preSaveActivityImage(vo, request);
		//调用Support处理业务逻辑
		modelMap.addAttribute("activity", vo);
		//获取所有活动类型
		activityManagerControllerSupport.getAllActivityTypes(modelMap);
		//获取所有的所属条件信息
		activityManagerControllerSupport.getActivityConditions(modelMap,vo.getActivityType());
		return "sys/activity/activityConditionAdd";		
	}
	/**
	 * 添加操作,入库
	 * @param modelMap
	 * @param vo
	 * @return
	 */
	@RequestMapping(value="/addActivity", method=RequestMethod.POST)
	public ModelAndView addActivity(ModelMap modelMap,@ModelAttribute ActivityVO vo,@RequestParam Map<String, Object> reqs){
		//调用Support处理业务逻辑
		activityManagerControllerSupport.addActivity(modelMap,vo,reqs);
		return new ModelAndView("jsonView");
	}

	/**
	 * 删除活动
	 * @param modelMap
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/deleteActivity")
	public ModelAndView deleteActivity(ModelMap modelMap,
			@RequestParam(value="activityType" ,required=false, defaultValue="") String activityType,
			@RequestParam(value="activityId" ,required=false, defaultValue="") String activityId){
		//调用Support处理业务逻辑
		activityManagerControllerSupport.deleteActivity(modelMap,activityType,activityId);
		return new ModelAndView("jsonView");
	}
	
	/**
	 * 修改活动状态
	 * @param modelMap
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/updateActivityStatus")
	public ModelAndView updateActivityStatus(ModelMap modelMap,@RequestParam(value="activityType" ,required=false, defaultValue="") String activityType,@RequestParam(value="activityId" ,required=false, defaultValue="") String activityId){
		//调用Support处理业务逻辑
		activityManagerControllerSupport.updateActivityStatus(modelMap,activityType,activityId);
		return new ModelAndView("jsonView");
	}
	
	/**
	 * 修改活动,第一步,修改活动基本信息
	 * @param modelMap
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/updateActivityView")
	public String updateActivityView(ModelMap modelMap,@RequestParam(value="activityType" ,required=false, defaultValue="") String activityType,
			@RequestParam(value="activityId" ,required=false, defaultValue="") String activityId){
		this.activityManagerControllerSupport.findActivityById(modelMap,activityType, activityId);
		activityManagerControllerSupport.getAllActivityTypes(modelMap);
		return "sys/activity/activityUpdate";
	}
	
	/**
	 * 修改活动,第二步,修改活动相关条件信息
	 * @param modelMap
	 * @param vo
	 * @return
	 */
	@RequestMapping(value="/updateActivityView2")
	public String updateActivityView2(ModelMap modelMap,@ModelAttribute ActivityVO vo,HttpServletRequest request){
		//接收文件
		preSaveActivityImage(vo, request);
		//回显活动信息
		modelMap.addAttribute("activity", vo);
		//查询活动类型
		activityManagerControllerSupport.getAllActivityTypes(modelMap);
		//查询活动关联的活动方式数据
		activityManagerControllerSupport.getActivityWay(modelMap,vo.getActivityType()+"",vo.getId());
		//获取该类型所有的所属条件信息
		activityManagerControllerSupport.getActivityConditions(modelMap,vo.getActivityType());
		//获取该活动所有的已经选条件信息
		activityManagerControllerSupport.getActivityConditionValues(modelMap,vo.getActivityType()+"",vo.getId());
		return "sys/activity/activityConditionUpdate";
	}

	/**
	 * 更新操作,入库
	 * @param modelMap
	 * @param activityVO
	 * @return
	 */
	@RequestMapping(value="/updateActivity")
	public ModelAndView updateActivity(ModelMap modelMap,@ModelAttribute ActivityVO vo,@RequestParam Map<String, Object> reqs){
		//调用Support处理业务逻辑
		activityManagerControllerSupport.updateActivity(modelMap,vo,reqs);
		return new ModelAndView("jsonView");
	}
	
	/**
	 * 预览活动页面
	 * @param modelMap
	 * @param startIndex
	 * @param reqs 查询参数
	 * @return
	 */
	@RequestMapping(value="/previewActivity")
	public String previewActivity(ModelMap modelMap,@RequestParam(value="activityType" ,required=false, defaultValue="") String activityType,
			@RequestParam(value="activityId" ,required=false, defaultValue="") String activityId){
		ActivityVO vo = activityManagerControllerSupport.getActivityByActivityId(activityType,activityId);
		//回显活动信息
		modelMap.addAttribute("activity", vo);
		//查询活动类型
		activityManagerControllerSupport.getAllActivityTypes(modelMap);
		//查询活动关联的活动方式数据
		activityManagerControllerSupport.getActivityWay(modelMap,activityType,vo.getId());
		//获取该类型所有的所属条件信息
		activityManagerControllerSupport.getActivityConditions(modelMap,vo.getActivityType());
		//获取该活动所有的已经选条件信息
		activityManagerControllerSupport.getActivityConditionValues(modelMap,activityType,vo.getId());
		return "sys/activity/activityPreview";		
	}
	
	/**
	 * 预览活动图片
	 * @param reqs
	 * @param response
	 */
	@RequestMapping(value="/showActivityImage")
	public void showActivityImage(@RequestParam Map<String, String> reqs,HttpServletResponse response){
		String actImg = reqs.get("actImg");
		String imagePath = cn.itkt.btsf.util.PropertyUtil.getProProperty().getString("activityImagePath");
		File file = new File(imagePath+File.separator+actImg);
		InputStream in = null;
		ServletOutputStream out= null;
		if(file!=null&&file.exists()){
			try {
				out = response.getOutputStream();
				in = new FileInputStream(file);
				int b = -1;
				while((b = in.read())!=-1){
					out.write(b);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}finally{
				try {
					if(in!=null)in.close();
					if(out!=null)out.close();
				} catch (Exception e2) {
				}
			}
		}
	}
	/**
	 * 预存活动图片
	 * @param reqs
	 * @param response
	 */
	private void preSaveActivityImage(ActivityVO vo, HttpServletRequest request) {
		if (request instanceof MultipartHttpServletRequest) {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			MultipartFile multipartFile = multipartRequest.getFile("activityImageFile");
			if (multipartFile!=null&&multipartFile.getSize() != 0) {
				String imagePath = cn.itkt.btsf.util.PropertyUtil.getProProperty().getString("activityImagePath");
				String fileName = multipartFile.getOriginalFilename();
				String ext = fileName.substring(fileName.lastIndexOf("."));
				vo.setTempActivityImage(System.currentTimeMillis() + ext);
				OutputStream out = null;
				try {
					byte[] bytes = multipartFile.getBytes();
					File dir = new File(imagePath);
					if (!dir.exists())
						dir.mkdirs();// 目录不存在则创建目录
					File file = new File(imagePath + File.separator + vo.getTempActivityImage());
					if (!file.exists())
						file.createNewFile();
					out = new FileOutputStream(file);
					out.write(bytes);
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						out.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	/**
	 * 注册指定日期格式的日期属性编辑器
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		formater.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formater, true));
	}

}