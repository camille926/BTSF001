package cn.itkt.btsf.sys.activity.controller;
import java.io.File;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import net.sf.json.JSONArray;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.sys.activity.po.ActivityPO;
import cn.itkt.btsf.sys.activity.service.ActivityConditionService;
import cn.itkt.btsf.sys.activity.service.ActivityService;
import cn.itkt.btsf.sys.activity.service.carwebservice.MapConvertor;
import cn.itkt.btsf.sys.activity.service.carwebservice.Result;
import cn.itkt.btsf.sys.activity.service.impl.ActivityServiceImpl;
import cn.itkt.btsf.sys.activity.util.HotelResult;
import cn.itkt.btsf.sys.activity.util.HttpClientUtil;
import cn.itkt.btsf.sys.activity.util.MapAdapter;
import cn.itkt.btsf.sys.activity.util.WebServiceUtil;
import cn.itkt.btsf.sys.activity.vo.ActivityVO;
import cn.itkt.pagination.Pages;

import com.opensymphony.oscache.util.StringUtil;

@Service
public class ActivityManagerControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(ActivityManagerControllerSupport.class);
	
	@Resource
	private  ActivityService  activityServiceImpl;
	
	@Resource
	private  ActivityConditionService  activityConditionServiceImpl;
	
	//查询
	public void listActivity(ModelMap modelMap, int startIndex,Map<String,Object> reqs) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Pages<ActivityPO> pages = new Pages<ActivityPO>(startIndex,20);
			Map<String, Object> map = new HashMap<String, Object>();
			reqs.put("activityStartDate1", StringUtil.isEmpty((String)reqs.get("activityStartDate1"))?"":sdf.parse(reqs.get("activityStartDate1").toString()));
			reqs.put("activityStartDate2", StringUtil.isEmpty((String)reqs.get("activityStartDate2"))?"":sdf.parse(reqs.get("activityStartDate2").toString()));
			reqs.put("activityEndDate1", StringUtil.isEmpty((String)reqs.get("activityEndDate1"))?"":sdf.parse(reqs.get("activityEndDate1").toString()));
			reqs.put("activityEndDate2", StringUtil.isEmpty((String)reqs.get("activityEndDate2"))?"":sdf.parse(reqs.get("activityEndDate2").toString()));
			reqs.put("activityId", StringUtil.isEmpty((String)reqs.get("activityId"))?"":reqs.get("activityId").toString().trim());
			reqs.put("activityName", StringUtil.isEmpty((String)reqs.get("activityName"))?"":reqs.get("activityName").toString().trim());
			map.putAll(reqs);
			map.put("startIndex", startIndex);
			map.put("pageSize", 20);
			//业务查询
			Object at = reqs.get("activityType");
			if("4".equals(at)){//酒店活动
				HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"findAllActivityForPage", map, HotelResult.class);
				List<ActivityPO> listAct = result.getListActivities();
				for(ActivityPO p:listAct){
					String param = "activityId="+p.getId();
					HotelResult result2 = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"getActivityWay", param, HotelResult.class);
					List<Map<String, Object>> activityWay = result2.getListMaps();
					p.setActivityWay(activityWay);
					System.out.println(p.isHasStarted());
				}
				pages.setItems(listAct);
				pages.setTotalCount(result.getPageTotalCount());
				modelMap.addAttribute("page", pages);
			}else if("5".equals(at)){//租车活动
				Result result = WebServiceUtil.instanceCarActWS().findAllActivityForPage(new MapAdapter().marshal(map));
				List<cn.itkt.btsf.sys.activity.service.carwebservice.ActivityPO> listAct = result.getListActivities();
				List<ActivityPO> list = new ArrayList<ActivityPO>();
				for(cn.itkt.btsf.sys.activity.service.carwebservice.ActivityPO act:listAct){
					ActivityPO po = ActivityServiceImpl.wsAct2Act(act);
					list.add(po);
				}
				for(ActivityPO p:list){
					Result result2 = WebServiceUtil.instanceCarActWS().getActivityWay(p.getId());
					List<MapConvertor> listMaps = result2.getListMaps();
					List<Map<String, Object>> activityWay = new ArrayList<Map<String,Object>>();
					for(MapConvertor m :listMaps){
						activityWay.add(new MapAdapter().unmarshal(m));
					}
					p.setActivityWay(activityWay);
					System.out.println(p.isHasStarted());
				}
				pages.setItems(list);
				pages.setTotalCount(result.getPageTotalCount());
				modelMap.addAttribute("page", pages);
			}else {
				if(at==null){//默认是机票活动
					reqs.put("activityType", "1");
				}
				List<ActivityPO> list = this.activityServiceImpl.findAllActivityForPage(map);
				for(ActivityPO p:list){
					List<Map<String, Object>> activityWay = this.activityServiceImpl.getActivityWay(p.getId());;
					p.setActivityWay(activityWay);
					System.out.println(p.isHasStarted());
				}
				pages.setItems(list);
				pages.setTotalCount(activityServiceImpl.countFindAllActivityForPage(map));
				modelMap.addAttribute("page", pages);
			}
			//数据回显
			modelMap.addAllAttributes(reqs);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
	}
	//查询
	public ActivityVO getActivityByActivityId(String activityType,String activityId) {
		ActivityVO vo = null;
		if("4".equals(activityType)){
			String param = "activityId="+activityId;
			HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"findActivity", param, HotelResult.class);
			if(result.getResultCode()==0){
				ActivityPO po = result.getListActivities().get(0);
				vo = this.activityServiceImpl.poToVo(po);
			}
		}else if("5".equals(activityType)){
			Result result = WebServiceUtil.instanceCarActWS().findActivity(activityId);
			if(result.getResultCode()==0){
				ActivityPO po = ActivityServiceImpl.wsAct2Act(result.getListActivities().get(0));
				vo = this.activityServiceImpl.poToVo(po);
			}
		}else {
			try {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("activityId", activityId);
				map.put("startIndex", 0);
				map.put("pageSize", 10);
				List<ActivityPO> list = this.activityServiceImpl.findAllActivityForPage(map);
				vo = this.activityServiceImpl.poToVo(list.get(0));
			} catch (Exception e) {
				e.printStackTrace();
				log.error(e.getMessage());
			}
		}
		return vo;
	}
	//获取所有活动类型信息
	public void getAllActivityTypes(ModelMap modelMap){
		try {
			List<Map<String,Object>> types = this.activityServiceImpl.getAllActivityTypes();
			modelMap.addAttribute("types", types);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//获取活动方式
	public void getActivityWay(ModelMap modelMap,String activityType,long activityId){
		if("4".equals(activityType)){
			String param = "activityId="+activityId;
			HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"getActivityWay", param, HotelResult.class);
			if(result.getResultCode()==0){
				List<Map<String,Object>> activityWay = result.getListMaps();
				modelMap.addAttribute("activityWay", activityWay);
			}
		}else if("5".equals(activityType)){
			try {
				Result result = WebServiceUtil.instanceCarActWS().getActivityWay(activityId);
				if(result.getResultCode()==0){
					List<MapConvertor> activityWays = result.getListMaps();
					List<Map<String,Object>> activityWay =new ArrayList<Map<String,Object>>();
					for(MapConvertor actW:activityWays){
						activityWay.add(new MapAdapter().unmarshal(actW));
					}
					modelMap.addAttribute("activityWay", activityWay);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else {
			try {
				List<Map<String,Object>> activityWay = this.activityServiceImpl.getActivityWay(activityId);
				modelMap.addAttribute("activityWay", activityWay);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	
	
	//获取活动条件
	public void getActivityConditions(ModelMap modelMap,long activityType){
		try {
			List<Map<String,Object>> conditions = this.activityServiceImpl.getActivityConditions(activityType);
			modelMap.addAttribute("conditions", conditions);
			//在map中添加上handleCond项,作用与CONDITION_TYPE,只是便于识别
			List<Map<String,Object>> conds = handleConditions(conditions);
			String jsonConds = JSONArray.fromObject(conds).toString().replaceAll("\"", "\'");
			modelMap.addAttribute("jsonConds", jsonConds);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//获取活动条件值
	public void getActivityConditionValues(ModelMap modelMap,String activityType,long activityId){
		List<Map<String,Object>> condsValues =null;
		if("4".equals(activityType)){
			String param = "activityId="+activityId;
			HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"getActivityConditionValues", param, HotelResult.class);
			if(result.getResultCode()==0){
				condsValues = result.getListMaps();
			}
		}else if("5".equals(activityType)){
			try {
				Result result = WebServiceUtil.instanceCarActWS().getActivityConditionValues(activityId);
				if(result.getResultCode()==0){
					List<MapConvertor> listMaps = result.getListMaps();
					condsValues = new ArrayList<Map<String,Object>>();
					for(MapConvertor mapc:listMaps){
						condsValues.add(new MapAdapter().unmarshal(mapc));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}else{
			try {
				condsValues = this.activityServiceImpl.getActivityConditionValues(activityId);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		modelMap.addAttribute("condsValues", condsValues);
		condsValues = handleConditionValues(condsValues);
		String jsonCondsValues = JSONArray.fromObject(condsValues).toString().replaceAll("\"", "\'");
		modelMap.addAttribute("jsonCondsValues", jsonCondsValues);
		
	}
	/**
	 * 处理条件
	 * @param conditions
	 */
	private List<Map<String,Object>> handleConditions(List<Map<String,Object>> conditions){
		final String KEY = "handleCond";//该值与页面紧密关联,用以辅助最终条件页面的显示
		final String VALUE = "handleCondValue";//该值与页面紧密关联,用以辅助最终条件页面的显示
		List<Map<String,Object>> conds = new ArrayList<Map<String,Object>>();
		for(Map<String,Object> cond:conditions){
			if("01".equals(cond.get("CONDITION_TYPE"))){//01:日期类
				cond.put(KEY, "DATE");
			}else if("02".equals(cond.get("CONDITION_TYPE"))){//02:固定值,可以将值都在后台匹配好，这样在前台直接展现
				cond.put(KEY, "FIXED");
				long id = ((BigDecimal)cond.get("ID")).longValue();
				Map<String, Object> fixedValue = genFixedValue(id);
				if(fixedValue.isEmpty()){
					cond.put(VALUE, "");
				}else{
					cond.put(VALUE, fixedValue);
				}
			}else if("03".equals(cond.get("CONDITION_TYPE"))){//03:输入框类
				cond.put(KEY, "INPUT");
				long id = ((BigDecimal)cond.get("ID")).longValue();
				cond.put(VALUE, genInputRules(id));//输入规则
			}else if("04".equals(cond.get("CONDITION_TYPE"))){//04:基于数据库查询
				cond.put(KEY, "DATA");
				long id = ((BigDecimal)cond.get("ID")).longValue();
				cond.put(VALUE, genDataSource(id));//数据来源
			}
			conds.add(cond);
		}
		return conds;
	}
	
	/**
	 * 处理条件
	 * @param conditions
	 */
	private List<Map<String,Object>> handleConditionValues(List<Map<String,Object>> conditions){
		List<Map<String,Object>> condvs = new ArrayList<Map<String,Object>>();
		if(conditions==null||conditions.isEmpty()){//如果是空,不做任何处理
			condvs = conditions;
		}else{
			for(int i=0;i<conditions.size();i++){
				Map<String,Object> cond = conditions.get(i);
				int id = Integer.parseInt(cond.get("ID").toString());
				String[] values ;
				Map<String, Object> keyValue ;
				switch (id) {
				case 2://归属渠道
				case 3://推荐号码
					condvs.add(cond);
					values = cond.get("CONDITION_VALUE").toString().split(",");
					keyValue = new HashMap<String, Object>();
					for(String value :values){
						keyValue.put(value, value);//值与显示相同
					}
					cond.put("CONDITION_VALUE", keyValue);
					break;
				case 4://手机归属省份
					condvs.add(cond);
					//CONDITION_VALUE=440000,450000,520000,460000,根据省份代码查找出省份名称
					values = cond.get("CONDITION_VALUE").toString().split(",");
					keyValue = new HashMap<String, Object>();
					for(String value :values){
						Map<String,Object> reqs = new HashMap<String, Object>();
						reqs.put("startIndex", 0);
						reqs.put("pageSize", 10);
						reqs.put("provinceCode", value);
						Map<String, Object> province = activityConditionServiceImpl.queryProvince(reqs).getItems().get(0);
						keyValue.put(value, province.get("PROVINCE_CNNAME"));
					}
					cond.put("CONDITION_VALUE", keyValue);
					break;
				case 5://手机归属地市
					//CONDITION_VALUE=SJW,SYM,SZV,SZX,根据地市代码查找出地市名称
					condvs.add(cond);
					values = cond.get("CONDITION_VALUE").toString().split(",");//
					keyValue = new HashMap<String, Object>();
					for(String value :values){
						Map<String,Object> reqs = new HashMap<String, Object>();
						reqs.put("startIndex", 0);
						reqs.put("pageSize", 10);
						reqs.put("cityCode", value);
						Map<String, Object> city = activityConditionServiceImpl.queryCity(reqs).getItems().get(0);
						keyValue.put(value, city.get("CITY_CNNAME"));
					}
					cond.put("CONDITION_VALUE", keyValue);
					break;
				case 13://航线
					//CONDITION_VALUE=AAT~URC,AAT~YIN,ACX~CKG,ACX~KMG//根据地市代码查找出地市名称
					condvs.add(cond);
					values = cond.get("CONDITION_VALUE").toString().split(",");//
					keyValue = new HashMap<String, Object>();
					for(String value :values){
						Map<String,Object> reqs = new HashMap<String, Object>();
						reqs.put("startIndex", 0);
						reqs.put("pageSize", 10);
						reqs.put("cityCode", value.split("~")[0]);
						Map<String, Object> cityFrom =new HashMap<String,Object>();
						if(!"0".equals(value.split("~")[0])){
							cityFrom = activityConditionServiceImpl.queryCity(reqs).getItems().get(0);
						}else{
							cityFrom.put("CITY_CNNAME", "任意");
						}
						reqs.put("cityCode", value.split("~")[1]);
						Map<String, Object> cityTo = new HashMap<String,Object>();
						if(!"0".equals(value.split("~")[1])){
							cityTo = activityConditionServiceImpl.queryCity(reqs).getItems().get(0);
						}else{
							cityTo.put("CITY_CNNAME", "任意");
						}
						keyValue.put(value, cityFrom.get("CITY_CNNAME")+"~"+cityTo.get("CITY_CNNAME"));
					}
					cond.put("CONDITION_VALUE", keyValue);
					break;
				case 10://航空公司-航班&舱位
					//JD[BG1234|SD1232/A|B|C],HO[/F|H|K],NN[],HU[/D|H|I|K]//根据航空公司id查找航空公司名称,根据舱位代码查出舱位名称
					condvs.add(cond);
					values = cond.get("CONDITION_VALUE").toString().split(",");
					keyValue = new HashMap<String, Object>();
					//GS[A|B|C]
					for(int j=0;j<values.length;j++){
						String airlinesCode = values[j].substring(0, values[j].indexOf('[')).toString();
						Map<String,Object> companyCond = new HashMap<String, Object>();
						companyCond.put("airlinesCode", airlinesCode);
						companyCond.put("startIndex", 0);
						companyCond.put("pageSize", 10);
						Pages<Map<String,Object>> companyName = activityConditionServiceImpl.queryAirCompany(companyCond);
						if(companyName==null||companyName.getItems().isEmpty()||companyName.getItems().get(0).get("AIRLINES_CNNAME")==null){
							log.error("代码为"+companyCond+"的航空公司不存在!");
							keyValue.put(airlinesCode, "");
						}else{
							keyValue.put(airlinesCode, companyName.getItems().get(0).get("AIRLINES_CNNAME").toString());//保存航空公司id及名称
						}
						String temp = values[j].substring(values[j].indexOf('[')+1, values[j].indexOf(']')).trim();
						String[] flights = temp.substring(0, temp.indexOf('/')).split("\\|");
						for(int k=0;k<flights.length;k++){
							String flight = flights[k];
							if(flight==null||"".equals(flight))continue;
							Map<String,Object> flightCond = new HashMap<String,Object>();
							flightCond.put("flight", flight);
							keyValue.put("com_"+airlinesCode+"__"+flight, flight);
						}
						if(temp.indexOf('/')<temp.length()){//过滤舱位和航班号都为空的情况
							String[] cabinNums = temp.substring(temp.indexOf('/')+1, temp.length()).split("\\|");
							for(int k=0;k<cabinNums.length;k++){
								String cabinNum = cabinNums[k];
								if(cabinNum==null||"".equals(cabinNum))continue;
								Map<String,Object> cabinCond = new HashMap<String,Object>();
								cabinCond.put("spaceCode", cabinNum);
								String cabinName = activityConditionServiceImpl.findAllShippingSpaceList(cabinCond).get(0).get("SPACE_NAME").toString();
								keyValue.put("com_"+airlinesCode+"_"+cabinNum, cabinName);
							}
						}
						cond.put("CONDITION_VALUE", keyValue);
					}
					break;
				default://其他的活动不做处理
					condvs.add(cond);
					break;
				}
				
			}
		}
		return condvs;
	}
	/**
	 * 添加活动
	 * @param modelMap
	 * @param vo
	 * @param reqs
	 */
	public void addActivity(ModelMap modelMap,ActivityVO vo,Map<String, Object> reqs){
		modelMap.clear();
		//验证vo的数据
		try {
			/* 添加活动 与 活动条件 */
			vo.setActivityName(vo.getActivityName().trim());
			vo.setActivityRemark(vo.getActivityRemark().trim());
			//生成活动id
			String activityId = genId();
			vo.setActivityId(activityId);
			if(!StringUtil.isEmpty(vo.getTempActivityImage())&&vo.getTempActivityImage().indexOf(".")!=-1){//非空
				vo.setActivityImage(activityId+vo.getTempActivityImage().substring(vo.getTempActivityImage().lastIndexOf(".")));
			}
			//验证成功后添加
			ActivityPO po = this.activityServiceImpl.voToPo(vo);
			if(!StringUtil.isEmpty(vo.getActivityImage())){
				po.setActivityImage("/sys/activity/manager/showActivityImage?actImg="+vo.getActivityImage());
			}
			/* 分析活动方式 */
			List<Map<String,Object>> ways = new ArrayList<Map<String,Object>>();
			//目前只有两种方式：反赠和直降
			for(int i=1;i<=2;i++){
				String _way = "0"+i;
				if(reqs.get("calculateWay_"+_way)!=null){//后缀表示活动方式
					Map<String,Object> way = new HashMap<String, Object>();
					way.put("activityWay", _way);//获取活动方式
					way.put("calculateWay", reqs.get("calculateWay_"+_way));//获取计算方式
					way.put("calculateValue", Float.parseFloat(reqs.get("calculateValue_"+_way).toString()));//获取计算值
					ways.add(way);
				}
			}
			/* 分析活动条件*/
			List<Map<String,Object>> conds = new ArrayList<Map<String,Object>>();
			for(Entry<String,Object> cond : reqs.entrySet() ){
				String key = cond.getKey(); 
				if(key.startsWith("conValue_")){//过滤出条件的字段,_后面即为条件id,=后的值即为条件值
					Map<String,Object> map = new HashMap<String,Object>();
					map.put("conditionId", Long.parseLong(key.substring(key.indexOf('_')+1)));
					map.put("conditionValue", cond.getValue());
					conds.add(map);
				}
			}
			this.activityServiceImpl.createActivity(po,ways,conds);
			modelMap.addAttribute("message", "保存成功!");
			modelMap.addAttribute("status", true);
		}catch (SQLException e) {
			modelMap.addAttribute("message", "保存失败,数据库异常!");
			modelMap.addAttribute("status", false);
		}catch (RuntimeException e) {
			e.printStackTrace();
			modelMap.addAttribute("message", "保存失败,运行时异常!");
			modelMap.addAttribute("status", false);
		}catch (Exception e) {
			e.printStackTrace();
			if(e.getCause() instanceof SQLException){
				modelMap.addAttribute("message", "保存失败,数据库异常!");
				modelMap.addAttribute("status", false);
			}else{
				modelMap.addAttribute("message", "保存失败!");
				modelMap.addAttribute("status", false);
			}
		}
	}
	
	/**
	 * 查询活动
	 */
	public void findActivityById(ModelMap modelMap,String activityType,String activityId){
		if("4".equals(activityType)){
			String param = "activityId="+activityId;
			HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"findActivity", param, HotelResult.class);
			modelMap.addAttribute("activity", this.activityServiceImpl.poToVo(result.getListActivities().get(0)));
		}else if("5".equals(activityType)){
			Result result = WebServiceUtil.instanceCarActWS().findActivity(activityId);
			ActivityPO po=ActivityServiceImpl.wsAct2Act(result.getListActivities().get(0));
			modelMap.addAttribute("activity", this.activityServiceImpl.poToVo(po));
		}else{
			try {
				ActivityPO po=this.activityServiceImpl.findActivity(activityId);
				modelMap.addAttribute("activity", this.activityServiceImpl.poToVo(po));
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		
	}
	/**
	 * 修改活动状态
	 * @param modelMap
	 * @param activityId
	 */
	public void updateActivityStatus(ModelMap modelMap,String activityType,String activityId){
		if("4".equals(activityType)){//酒店活动
			String param = "activityId="+activityId;
			HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"findActivity", param, HotelResult.class);
			int resultCode = result.getResultCode();
			if(resultCode==0){
				ActivityPO act = result.getListActivities().get(0);
				if( act != null ){
					String status = act.getActivityStatus();
					if(status.equals("01")){
						act.setActivityStatus("02");
					}else if(status.equals("02")){
						act.setActivityStatus("01");
					}
				}
				HotelResult result2 = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"updateActivity", act, HotelResult.class);;
				if(result2.getResultCode()!=0){
					throw new RuntimeException("更新状态出错. ");
				}
			}
		}else if("5".equals(activityType)){//租车活动
			Result result = WebServiceUtil.instanceCarActWS().findActivity(activityId);
			int resultCode = result.getResultCode();
			if(resultCode==0){
				ActivityPO act = ActivityServiceImpl.wsAct2Act(result.getListActivities().get(0));
				if( act != null ){
					String status = act.getActivityStatus();
					if(status.equals("01")){
						act.setActivityStatus("02");
					}else if(status.equals("02")){
						act.setActivityStatus("01");
					}
				}
				Result result2 = WebServiceUtil.instanceCarActWS().updateActivity(ActivityServiceImpl.act2WSAct(act));
				if(result2.getResultCode()!=0){
					throw new RuntimeException("更新状态出错. ");
				}
			}
		}else {
			try {
				this.activityServiceImpl.updateActivityStatus(modelMap,activityId);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * 更新活动
	 * @param modelMap
	 * @param activityVO
	 */
	public void updateActivity(ModelMap modelMap,ActivityVO vo,Map<String, Object> reqs){
		try {
			long actId = vo.getId(); 
			if(!StringUtil.isEmpty(vo.getTempActivityImage())&&vo.getTempActivityImage().indexOf(".")!=-1){//非空
				vo.setActivityImage("/sys/activity/manager/showActivityImage?actImg="+vo.getActivityId()+vo.getTempActivityImage().substring(vo.getTempActivityImage().lastIndexOf(".")));
			}
			/* 分析活动方式 */
			List<Map<String,Object>> ways = new ArrayList<Map<String,Object>>();
			//目前只有两种方式：反赠和直降
			for(int i=1;i<=2;i++){
				String _way = "0"+i;
				if(reqs.get("calculateWay_"+_way)!=null){//后缀表示活动方式
					Map<String,Object> way = new HashMap<String, Object>();
					way.put("activityWay", _way);//获取活动方式
					way.put("calculateWay", reqs.get("calculateWay_"+_way));//获取计算方式
					way.put("calculateValue", Float.parseFloat(reqs.get("calculateValue_"+_way).toString()));//获取计算值
					way.put("activityId", actId);
					ways.add(way);
				}
			}
			/* 分析活动条件*/
			List<Map<String,Object>> conds = new ArrayList<Map<String,Object>>();
			for(Entry<String,Object> cond : reqs.entrySet() ){
				String key = cond.getKey(); 
				if(key.startsWith("conValue_")){//过滤出条件的字段,_后面即为条件id,=后的值即为条件值
					Map<String,Object> map = new HashMap<String,Object>();
					map.put("activityId", actId);
					map.put("conditionId", Long.parseLong(key.substring(key.indexOf('_')+1)));
					map.put("conditionValue", cond.getValue());
					conds.add(map);
				}
			}
			
			ActivityPO po = this.activityServiceImpl.voToPo(vo);
			this.activityServiceImpl.updateActivity(po,ways,conds);
			modelMap.clear();
			modelMap.addAttribute("message", "保存成功");
			modelMap.addAttribute("status", true);
		} catch (Exception e) {
			log.error(e.getMessage());
			modelMap.addAttribute("message", "保存失败【"+e.getMessage()+"】");
			modelMap.addAttribute("status", false);
		}

	}
	
	/**
	 * 删除活动
	 * @param modelMap
	 * @param teamInfoId 班组Id
	 */
	public void deleteActivity(ModelMap modelMap,String activityType,String activityId){
		try {
			ActivityPO activityPO = null;
			if("4".equals(activityType)){
				String param = "activityId="+activityId;
				HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"findActivity", param, HotelResult.class);
				activityPO = result.getListActivities().get(0);
			}else if("5".equals(activityType)){
				activityPO = ActivityServiceImpl.wsAct2Act(WebServiceUtil.instanceCarActWS().findActivity(activityId).getListActivities().get(0));
			}else{
				activityPO = this.activityServiceImpl.findActivity(activityId);	
			}
			
			this.activityServiceImpl.deleteActivity(activityType,activityId);
			//删除文件
			String image = activityPO.getActivityImage();
			if(image!=null&&!"".equals(image)&&image.indexOf("=")!=-1){
				String fileName = image.substring(image.lastIndexOf('=')+1, image.length());
				String imagePath = cn.itkt.btsf.util.PropertyUtil.getProProperty().getString("activityImagePath");
				File file = new File(imagePath+File.separator+fileName);
				if(file!=null&&file.exists()){
					file.delete();
				}
			}
			modelMap.clear();
			modelMap.addAttribute("message", "删除成功");
			modelMap.addAttribute("status", true);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			modelMap.addAttribute("message", "删除失败【"+e.getMessage()+"】");
			modelMap.addAttribute("status", false);
		}
		
	}
	/**
	 * 生成固定值的选项信息
	 * @param condId
	 * @return
	 */
	private Map<String,Object> genFixedValue(long condId){
		Map<String,Object> conds = new LinkedHashMap<String,Object>();
		conds.put("type", "checkbox");
		switch((int)condId){
			case 6://运营商[李旭需求：运营商------移动：1 联通：2 电信：3]
				conds.put("1", "中国移动");
				conds.put("2", "中国联通");
				conds.put("3", "中国电信");
			break;
			case 7://会员注册渠道
				conds.put("0", "Android");
				conds.put("1", "Mobile");
				conds.put("2", "B2C网站");
				conds.put("3", "呼叫中心");
				break;
			case 9://这是星期类型
				conds.put("1", "周一");
				conds.put("2", "周二");
				conds.put("3", "周三");
				conds.put("4", "周四");
				conds.put("5", "周五");
				conds.put("6", "周六");
				conds.put("7", "周日");
				break;
			case 15://往返机票
			case 20://是否需要行程单
			case 21://购买保险
			case 23://推荐好友注册
			case 24://完善用户信息
			case 25://体验功能
				conds.put("type", "radio");
				conds.put("1", "是");
				conds.put("0", "否");
				break;
			case 14://预订渠道[李旭需求：预订渠道-----手机：1、网站：2、呼叫中心：3、终端：4]
				conds.put("1", "手机");
				conds.put("2", "网站");
				conds.put("3", "呼叫中心");
				conds.put("4", "终端");
				break;
			case 16://会员级别
				conds.put("1", "普通会员");
				conds.put("2", "普通vip");
				conds.put("3", "高级vip");
				break;
			case 22://支付方式
				conds.put("KQ", "快钱信用卡接口支付");
				conds.put("HF", "汇付");
				conds.put("TRUST", "授信支付");
				conds.put("OFLINE", "关联支付单");
				conds.put("KQCOIN", "快钱和畅达币");
				conds.put("HFCOIN", "汇付和畅达币");
				conds.put("UNPAY", "银联刷卡");
				conds.put("KQRMB", "快钱人民币网关支付");
				conds.put("COIN", "畅达币支付");
				conds.put("ALIPAY", "手机支付宝");
				conds.put("ALIPAYCOIN", "手机支付宝和畅达币");
				conds.put("UNGPAYCOIN", "银联网关支付和畅达币"); 
//				conds.put("UnionPay", ""); 
//				conds.put("ZFB", ""); 
//				conds.put("KQHFCOIN", ""); 
//				conds.put("UNGPAY", ""); 
				break;
			default:break;
		}
		return conds;
	}
	/**
	 * 生成输入值的规则信息
	 * @param condId
	 * @return
	 */
	private String genInputRules(long condId){
		String rules = "";
		switch ((int)condId){
		case 11://航班号
			rules = "required flightNum";//必填,
			break;
		case 18://单个订单金额
			rules = "required myPositiveNum";//必填,正数
			break;
		case 19://单个订单票数
			rules = "required myPositiveInt";//必填,正整数
			break;
			default:break;
		}
		return rules;
	}
	/**
	 * 生成基于数据库查询的选项信息
	 * @param condId
	 * @return
	 */
	private String genDataSource(long condId){
		String url = "sys/activity/conditions/";
		switch ((int)condId){
		case 2://会员归属渠道
			url += "chooseUserChannels";
			break;
		case 3://注册推荐号码
			url += "chooseRecommendPhone";
			break;
		case 4://会员手机归属省份
			url += "chooseProvince";
			break;
		case 5://会员手机归属地市
			url += "chooseCity";
			break;
		case 10://航空公司
			url += "queryAirCompany";
			break;
//		case 12://舱位		//舱位作为航空公司的下层条件归属到航空公司中了
//			url += "";
//			break;
		case 13://航线
			url += "queryAirLine";
			break;
		default:break;
		}
		return url;
	}
	/**
	 * 该方法生成一个id,生成过程依赖于系统时间,即在系统时间正常的情况下才能正常运行
	 * 028708883[0:当前年份-2012;287:今天在一年中的天数;08883:当前秒数在当天中]
	 * @return 
	 */
	static String genId(){
		String year = (Calendar.getInstance().get(Calendar.YEAR)-2012)+"";
		String day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)+"";
		String second = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)*60*60
		+Calendar.getInstance().get(Calendar.MINUTE)*60
		+Calendar.getInstance().get(Calendar.SECOND)+"";
		
		while(second.length()<5){
			second= "0"+second;
		}
		return year+day+second;
	}

}