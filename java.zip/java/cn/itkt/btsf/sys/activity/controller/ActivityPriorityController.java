package cn.itkt.btsf.sys.activity.controller;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
/**
 * 活动管理控制器
 * @author lixu
 * @date 2012-09-21
 */
@Controller
@RequestMapping("/sys/activity/priority")
public class ActivityPriorityController {

	@Resource
	private  ActivityPriorityControllerSupport  activityPriorityControllerSupport;
	@Resource
	private ActivityManagerControllerSupport activityManagerControllerSupport;
	/**
	 * 分页--条件查询
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/priorityList")
	public String list(ModelMap modelMap){
		//调用Support处理业务逻辑
		activityPriorityControllerSupport.listActivityGroup(modelMap);
		return "sys/activity/priorityList";		
	}
	/**
	 * 设置活动优先级
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/activityPrioritySet")
	public ModelAndView  activityPrioritySet(ModelMap modelMap,HttpServletRequest request,
			@RequestParam(value="groupNumber",required=false,defaultValue="0") int groupNumber){
		try {
			List<Map<String,Object>> activityPriorityList=new ArrayList<Map<String,Object>>();
			List<Map<String,Object>> groupPriorityList= new ArrayList<Map<String,Object>>();
			for(int i=1;i<=groupNumber;i++){
				int activityNum=Integer.parseInt(request.getParameter(("groupActivitiesNum"+i)));
				Long groupId=Long.parseLong(request.getParameter("group"+i));
				int groupPrioirty=Integer.parseInt(request.getParameter("groupPriority"+i));
				Map<String,Object> groupMap=new HashMap<String,Object>();
				groupMap.put("groupId", groupId);
				groupMap.put("groupPriority", groupPrioirty);
				groupPriorityList.add(groupMap);
				for(int j=1;j<=activityNum;j++){
					Map<String,Object> priorityMap=new HashMap<String,Object>();
					Long activityId=Long.parseLong(request.getParameter("activityId"+i+"_"+j));
					int activityPriority=Integer.parseInt(request.getParameter("activityPriority"+i+"_"+j));
					priorityMap.put("groupId", groupId);
					priorityMap.put("activityId", activityId);
					priorityMap.put("activityPriority", activityPriority);
					activityPriorityList.add(priorityMap);
				}
			}
			activityPriorityControllerSupport.activityPrioritySet(modelMap,activityPriorityList,groupPriorityList);
		} catch (Exception e) {
			modelMap.addAttribute("msg","保存失败！");
			modelMap.addAttribute("result","1");
			e.printStackTrace();
		}
		modelMap.addAttribute("msg","保存成功！");
		modelMap.addAttribute("result","0");
		return new ModelAndView("jsonView");
	}
	/**
	 * 删除活动组中的某个活动
	 * @param model
	 * @param groupId
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/deleteActivityPriority")
	public ModelAndView deleteActivityPriority(ModelMap model,
			@RequestParam(value="groupId",required=true) Long groupId,
			@RequestParam(value="activityId",required=true) Long activityId){
		activityPriorityControllerSupport.deleteActivityPriority(groupId,activityId);
		model.addAttribute("msg","删除成功！");
		model.addAttribute("result","0");
		return new ModelAndView("jsonView");
	}
	/**
	 * 删除活动组
	 * @param model
	 * @param groupId
	 * @return
	 */
	@RequestMapping(value="/deleteActivityGroup")
	public ModelAndView deleteActivityGroup(ModelMap model,
			@RequestParam(value="groupId",required=true) Long groupId){
		activityPriorityControllerSupport.deleteActivityGroup(groupId);
		model.addAttribute("msg","删除成功！");
		model.addAttribute("result","0");
		return new ModelAndView("jsonView");
	}
	/**
	 * 去到选择活动页
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/activityChoose")
	public String activityChoose(ModelMap modelMap,
			@RequestParam(value="startIndex",required=false, defaultValue="0") int startIndex,
			@RequestParam Map<String, Object> reqs,
			@RequestParam(value="groupId",required=false) Long groupId ){
		if(groupId!=null){
			modelMap.put("groupId", groupId);
		}
		//调用Support处理业务逻辑
		activityManagerControllerSupport.getAllActivityTypes(modelMap);
		return "sys/activity/chooseActivity";		
	}
	/**
	 * 查询活动列表
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/activityList")
	public String listActivity(ModelMap modelMap,
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,
			@RequestParam Map<String, Object> reqs){
		//调用Support处理业务逻辑
		try {
			activityPriorityControllerSupport.listActivity(modelMap, startIndex, reqs);
			activityManagerControllerSupport.getAllActivityTypes(modelMap);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return "sys/activity/chooseActivityList";		
	}
	/**
	 * 创建活动组
	 * @param modelMap
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/groupCreate")
	public ModelAndView createGroup(ModelMap modelMap,@RequestParam(value="activityChoosed",required=false,defaultValue="") String activityIds){
		activityPriorityControllerSupport.createGroup(modelMap,activityIds);
		modelMap.addAttribute("msg","新增成功！");
		modelMap.addAttribute("result","0");
		return new ModelAndView("jsonView");
	}
	/**
	 * 向活动组添加活动
	 * @param modelMap
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/addActivityToGroup")
	public ModelAndView addActivityToGroup(ModelMap modelMap,@RequestParam(value="activityChoosed",required=true) String activityId,@RequestParam(value="groupId",required=true) String groupId){
		activityPriorityControllerSupport.addActivityToGroup(modelMap,activityId,groupId);
		modelMap.addAttribute("msg","添加成功！");
		modelMap.addAttribute("result","0");
		return new ModelAndView("jsonView");
	}
}