package cn.itkt.btsf.sys.activity.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.cxf.binding.corba.wsdl.Array;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.sys.activity.service.ActivityConditionService;
import cn.itkt.pagination.Pages;
@Service
public class ActivityConditionControllerSupport {
	@Resource
	private ActivityConditionService activityConditionService;
	
	public void queryAirCompany(ModelMap model,int startIndex, Map<String, Object> reqs) {
		reqs.put("airlinesCode", reqs.get("airlinesCode")==null?"":reqs.get("airlinesCode").toString().toUpperCase());
		reqs.put("startIndex", startIndex);
		reqs.put("pageSize", 10);
		Pages<Map<String, Object>> voPages = activityConditionService.queryAirCompany(reqs);
		model.addAttribute("page", voPages);
	}
	
	
	public void findAllShippingSpace(ModelMap modelMap,Map<String,Object> reqs) {
		modelMap.put("spaceList", activityConditionService.findAllShippingSpaceList(reqs));
	}

	/**
	 * 查询航线
	 * @param modelMap
	 * @param startIndex
	 * @param vo
	 */
	public void queryAirLine(ModelMap modelMap, int startIndex,Map<String, Object> reqs ) {
		reqs.put("startIndex", startIndex);
		reqs.put("pageSize", 10);
		Pages<Map<String,Object>> airLinePage= activityConditionService.queryAirLine(reqs);
		modelMap.put("page", airLinePage);
	}


	public void queryCity(ModelMap modelMap, int startIndex,
			Map<String, Object> reqs) {
		reqs.put("startIndex", startIndex);
		reqs.put("pageSize", 10);
		Pages<Map<String,Object>> cityPage= activityConditionService.queryCity(reqs);
		modelMap.put("page", cityPage);
	}
	public void queryAllCity(ModelMap modelMap, Map<String, Object> reqs) {
		//查询所有未添加过的出发城市
		reqs.put("flag0", "not in");
		reqs.put("flag1", "from");
		List<Map<String,Object>> allUnFromCities=new ArrayList<Map<String,Object>>();
		if(reqs.get("fromCities")==null||"".equals(reqs.get("fromCities"))||reqs.get("fromCities").toString().indexOf("'0'")==-1){
			Map<String,Object> map = new HashMap<String, Object>();
			map.put("CITY_CODE","0");
			map.put("CITY_CNNAME","任意");
			allUnFromCities.add(map);
		}
		allUnFromCities.addAll(activityConditionService.queryAllCity(reqs));
		modelMap.put("allUnFromCities", allUnFromCities);

		//查询所有添加过的出发城市
		if(!"".equals(reqs.get("fromCities"))){
			List<Map<String,Object>> allFromCities = new ArrayList<Map<String,Object>>();
			reqs.put("flag0", "in");
			reqs.put("flag1", "from");
			if(reqs.get("fromCities").toString().indexOf("'0'")!=-1){
				Map<String,Object> map = new HashMap<String, Object>();
				map.put("CITY_CODE","0");
				map.put("CITY_CNNAME","任意");
				allFromCities.add(map);
			}
			allFromCities.addAll(activityConditionService.queryAllCity(reqs));
			modelMap.put("allFromCities", allFromCities);
		}
		//查询所有未添加过的到达城市
		reqs.put("flag0", "not in");
		reqs.put("flag1", "to");
		List<Map<String,Object>> allUnToCities= new ArrayList<Map<String,Object>>();
		if(reqs.get("toCities")==null||"".equals(reqs.get("toCities"))||reqs.get("toCities").toString().indexOf("'0'")==-1){
			Map<String,Object> map = new HashMap<String, Object>();
			map.put("CITY_CODE","0");
			map.put("CITY_CNNAME","任意");
			allUnToCities.add(map);
		}
		allUnToCities.addAll(activityConditionService.queryAllCity(reqs));
		modelMap.put("allUnToCities", allUnToCities);
		//查询所有添加过的到达城市
		if(!"".equals(reqs.get("toCities"))){
			reqs.put("flag0", "in");
			reqs.put("flag1", "to");
			List<Map<String,Object>> allToCities= new ArrayList<Map<String,Object>>();
			if(reqs.get("toCities").toString().indexOf("'0'")!=-1){
				Map<String,Object> map = new HashMap<String, Object>();
				map.put("CITY_CODE","0");
				map.put("CITY_CNNAME","任意");
				allToCities.add(map);
			}
			allToCities.addAll(activityConditionService.queryAllCity(reqs));
			modelMap.put("allToCities", allToCities);
		}
		
	}
	
	public void queryProvince(ModelMap modelMap,Map<String, Object> reqs) {
		reqs.put("pageSize", 100);
		Pages<Map<String,Object>> cityPage= activityConditionService.queryProvince(reqs);
		modelMap.put("page", cityPage);
	}

	/**
	 * 查询会员归属渠道
	 * @param modelMap
	 * @param startIndex
	 * @param reqs
	 */
	public void queryUserChannels(ModelMap modelMap, int startIndex,
			Map<String, Object> reqs) {
		Pages<Map<String,Object>> cityPage= activityConditionService.queryUserChannels(reqs);
		modelMap.put("page", cityPage);
	}
	/**
	 * 查询推荐人手机号
	 * @param modelMap
	 * @param startIndex
	 * @param reqs
	 */
	public void queryRecommendPhone(ModelMap modelMap, int startIndex,
			Map<String, Object> reqs) {
		reqs.put("startIndex", startIndex);
		reqs.put("pageSize", 10);
		Pages<Map<String,Object>> cityPage= activityConditionService.queryRecommendPhone(reqs);
		modelMap.put("page", cityPage);
	}
}