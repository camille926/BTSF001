package cn.itkt.btsf.sys.activity.controller;
import java.io.File;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.sys.activity.po.ClientActivityPO;
import cn.itkt.btsf.sys.activity.service.ClientActivityService;
import cn.itkt.btsf.sys.activity.vo.ClientActivityVO;
import cn.itkt.pagination.Pages;

import com.opensymphony.oscache.util.StringUtil;

@Service
public class ClientActivityControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(ClientActivityControllerSupport.class);
	
	@Resource
	private  ClientActivityService  clientActivityServiceImpl;
	
	//查询
	public void listActivity(ModelMap modelMap, int startIndex,Map<String,Object> reqs) {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Pages<ClientActivityPO> pages = new Pages<ClientActivityPO>(startIndex,20);
			Map<String, Object> map = new HashMap<String, Object>();
			reqs.put("activityStartDate1", StringUtil.isEmpty((String)reqs.get("activityStartDate1"))?"":sdf.parse(reqs.get("activityStartDate1").toString()));
			reqs.put("activityStartDate2", StringUtil.isEmpty((String)reqs.get("activityStartDate2"))?"":sdf.parse(reqs.get("activityStartDate2").toString()));
			reqs.put("activityEndDate1", StringUtil.isEmpty((String)reqs.get("activityEndDate1"))?"":sdf.parse(reqs.get("activityEndDate1").toString()));
			reqs.put("activityEndDate2", StringUtil.isEmpty((String)reqs.get("activityEndDate2"))?"":sdf.parse(reqs.get("activityEndDate2").toString()));
			reqs.put("activityId", StringUtil.isEmpty((String)reqs.get("activityId"))?"":reqs.get("activityId").toString().trim());
			reqs.put("activityName", StringUtil.isEmpty((String)reqs.get("activityName"))?"":reqs.get("activityName").toString().trim());
			map.putAll(reqs);
			map.put("startIndex", startIndex);
			map.put("pageSize", 20);
			List<ClientActivityPO> list = this.clientActivityServiceImpl.findAllActivityForPage(map);
			pages.setItems(list);
			pages.setTotalCount(clientActivityServiceImpl.countFindAllActivityForPage(map));
			modelMap.addAttribute("page", pages);
			modelMap.addAllAttributes(reqs);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
	}
	//查询
	public ClientActivityVO getActivityByActivityId(String activityId) {
		ClientActivityVO vo = null;
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("activityId", activityId);
			map.put("startIndex", 0);
			map.put("pageSize", 10);
			List<ClientActivityPO> list = this.clientActivityServiceImpl.findAllActivityForPage(map);
			vo = this.clientActivityServiceImpl.poToVo(list.get(0));
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
		return vo;
	}
	
	/**
	 * 添加活动
	 * @param modelMap
	 * @param vo
	 * @param reqs
	 */
	public void addActivity(ModelMap modelMap,ClientActivityVO vo,Map<String, Object> reqs){
		modelMap.clear();
		//验证vo的数据
		try {
			/* 添加活动 */
			vo.setActivityName(vo.getActivityName().trim());
			vo.setActivityRemark(vo.getActivityRemark().trim());
			//生成活动id
			String activityId = genId();
			vo.setActivityId(activityId);
			if(!StringUtil.isEmpty(vo.getTempActivityImage())&&vo.getTempActivityImage().indexOf(".")!=-1){//非空
				vo.setActivityImage(activityId+vo.getTempActivityImage().substring(vo.getTempActivityImage().lastIndexOf(".")));
			}
			//验证成功后添加
			ClientActivityPO po = this.clientActivityServiceImpl.voToPo(vo);
			if(!StringUtil.isEmpty(vo.getActivityImage())){
				po.setActivityImage("/sys/activity/clientActivity/showActivityImage?actImg="+vo.getActivityImage());
			}
			this.clientActivityServiceImpl.createActivity(po);
			modelMap.addAttribute("message", "保存成功!");
			modelMap.addAttribute("status", true);
		}catch (SQLException e) {
			modelMap.addAttribute("message", "保存失败,数据库异常!");
			modelMap.addAttribute("status", false);
		}catch (RuntimeException e) {
			e.printStackTrace();
			modelMap.addAttribute("message", "保存失败,运行时异常!");
			modelMap.addAttribute("status", false);
		}catch (Exception e) {
			e.printStackTrace();
			if(e.getCause() instanceof SQLException){
				modelMap.addAttribute("message", "保存失败,数据库异常!");
				modelMap.addAttribute("status", false);
			}else{
				modelMap.addAttribute("message", "保存失败!");
				modelMap.addAttribute("status", false);
			}
		}
	}
	
	/**
	 * 查询活动
	 */
	public void findActivityById(ModelMap modelMap,String activityId){
		try {
			ClientActivityPO po=this.clientActivityServiceImpl.findActivity(activityId);
			modelMap.addAttribute("activity", this.clientActivityServiceImpl.poToVo(po));
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}
	/**
	 * 修改活动状态
	 * @param modelMap
	 * @param activityId
	 */
	public void updateActivityStatus(ModelMap modelMap,String activityId){
		try {
			this.clientActivityServiceImpl.updateActivityStatus(modelMap,activityId);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 更新活动
	 * @param modelMap
	 * @param ClientActivityVO
	 */
	public void updateActivity(ModelMap modelMap,ClientActivityVO vo,Map<String, Object> reqs){
		try {
			if(!StringUtil.isEmpty(vo.getTempActivityImage())&&vo.getTempActivityImage().indexOf(".")!=-1){//非空
				vo.setActivityImage("/sys/activity/manager/showActivityImage?actImg="+vo.getActivityId()+vo.getTempActivityImage().substring(vo.getTempActivityImage().lastIndexOf(".")));
			}
			ClientActivityPO po = this.clientActivityServiceImpl.voToPo(vo);
			this.clientActivityServiceImpl.updateActivity(po);
			modelMap.clear();
			modelMap.addAttribute("message", "保存成功");
			modelMap.addAttribute("status", true);
		} catch (Exception e) {
			log.error(e.getMessage());
			modelMap.addAttribute("message", "保存失败【"+e.getMessage()+"】");
			modelMap.addAttribute("status", false);
		}

	}
	
	/**
	 * 删除活动
	 * @param modelMap
	 * @param teamInfoId 班组Id
	 */
	public void deleteActivity(ModelMap modelMap,String activityId){
		try {
			ClientActivityPO ClientActivityPO = this.clientActivityServiceImpl.findActivity(activityId);
			this.clientActivityServiceImpl.deleteActivity(activityId);
			//删除文件
			String image = ClientActivityPO.getActivityImage();
			if(image!=null&&!"".equals(image)&&image.indexOf("=")!=-1){
				String fileName = image.substring(image.lastIndexOf('=')+1, image.length());
				String imagePath = cn.itkt.btsf.util.PropertyUtil.getProProperty().getString("activityImagePath");
				File file = new File(imagePath+File.separator+fileName);
				if(file!=null&&file.exists()){
					file.delete();
				}
			}
			modelMap.clear();
			modelMap.addAttribute("message", "删除成功");
			modelMap.addAttribute("status", true);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			modelMap.addAttribute("message", "删除失败【"+e.getMessage()+"】");
			modelMap.addAttribute("status", false);
		}
		
	}
	
	public void findAllActivity(ModelMap modelMap){
		try {
			Map<String,Object> map = new HashMap<String, Object>();
			map.put("startIndex", 0);
			map.put("pageSize", 100000);
			map.put("activityStatus", "01");//正常
			List<ClientActivityPO> list = this.clientActivityServiceImpl.findAllActivityForPage(map);
			modelMap.put("activityList", list);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void updateActivityOrder(ModelMap modelMap,Map<String,Object> reqs){
		//data=1-11651741,2-11541028
		String data = reqs.get("data").toString();
		String[] dataArr = data.split(",");
		for(String acor :dataArr ){
			Map<String,Object> map = new HashMap<String, Object>();
			map.put("activityOrder", acor.substring(0, acor.indexOf("-")));
			map.put("activityId", acor.substring(acor.indexOf("-")+1));
			this.clientActivityServiceImpl.updateActivityOrder(map);
		}
	}
	/**
	 * 该方法生成一个id,生成过程依赖于系统时间,即在系统时间正常的情况下才能正常运行
	 * 028708883[0:当前年份-2012;287:今天在一年中的天数;08883:当前秒数在当天中]
	 * @return 
	 */
	static String genId(){
		String year = (Calendar.getInstance().get(Calendar.YEAR)-2012)+"";
		String day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)+"";
		String second = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)*60*60
		+Calendar.getInstance().get(Calendar.MINUTE)*60
		+Calendar.getInstance().get(Calendar.SECOND)+"";
		
		while(second.length()<5){
			second= "0"+second;
		}
		return year+day+second;
	}

}