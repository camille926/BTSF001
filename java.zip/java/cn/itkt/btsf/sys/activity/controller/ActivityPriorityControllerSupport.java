package cn.itkt.btsf.sys.activity.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.opensymphony.oscache.util.StringUtil;

import cn.itkt.btsf.sys.activity.po.ActivityPO;
import cn.itkt.btsf.sys.activity.service.ActivityPriorityService;
import cn.itkt.btsf.sys.activity.service.ActivityService;
import cn.itkt.btsf.sys.activity.vo.ActivityGroupVO;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;
@Service
public class ActivityPriorityControllerSupport {
	/**活动组默认优先级**/
	public static final int GROUP_DEFAULT_PRIORITY=4;
	/**活动默认优先级**/
	public static final int ACTIVITY_DEFAULT_PRIORITY=4;
	private static final Logger log = LoggerFactory.getLogger(ActivityPriorityControllerSupport.class);
	
	@Resource
	private  ActivityPriorityService  activityPriorityService;
	@Resource
	private  ActivityService  activityServiceImpl;
	/**
	 * 查询活动组列表
	 * @param modelMap
	 */
	public void listActivityGroup(ModelMap modelMap) {
		List<ActivityGroupVO> groupList=activityPriorityService.listActivityGroup();
		modelMap.addAttribute("groupList",groupList);
		modelMap.addAttribute("groupListSize",groupList.size());
	}
	/**
	 * 设置活动优先级
	 * @param modelMap
	 * @param priorityList
	 */
	@Transactional(rollbackFor = Exception.class)
	public void activityPrioritySet(ModelMap modelMap, List<Map<String,Object>> priorityList,List<Map<String,Object>> groupPriorityList) {
		for(Map<String,Object> map:groupPriorityList){
			activityPriorityService.updateGroupPriority(map);
		}
		//activityPriorityService.deleteAllPriority();
		for(Map<String,Object> map:priorityList){
			activityPriorityService.activityPrioritySet(map);
		}
	}
	/**
	 * 从活动组中删除某个活动
	 * @param groupId
	 * @param activityId
	 */
	@Transactional(rollbackFor = Exception.class)
	public void deleteActivityPriority(Long groupId, Long activityId) {
		
		activityPriorityService.deleteActivityPriority(groupId,activityId);
	}
	/**
	 * 删除活动组
	 * @param groupId
	 */
	@Transactional(rollbackFor = Exception.class)
	public void deleteActivityGroup(Long groupId) {
		activityPriorityService.deleteActivityGroupPriority(groupId);
		activityPriorityService.deleteActivityGroup(groupId);
	}
	/**
	 * 新增活动组
	 * @param modelMap
	 * @param activityId
	 */
	@Transactional(rollbackFor = Exception.class)
	public void createGroup(ModelMap modelMap, String activityId) {
		ActivityGroupVO group=new ActivityGroupVO();
		group.setGroupPriority(GROUP_DEFAULT_PRIORITY);
		group.setGroupName("");
		group.setGroupRemark("");
		activityPriorityService.createGroup(group);
		String[] activityIds=activityId.split(",");
		for(String activity:activityIds){
			if(SysUtil.isEmpty(activity)) continue;
			HashMap<String,Object> map=new HashMap<String,Object>();
			map.put("groupId", group.getId());
			map.put("activityId", Long.parseLong(activity));
			map.put("activityPriority", ACTIVITY_DEFAULT_PRIORITY);
			activityPriorityService.createActivityPriority(map);
		}
		
	}
	/**
	 * 查询活动列表
	 * @param modelMap
	 * @param startIndex
	 * @param reqs
	 * @throws ParseException
	 */
	@Transactional(rollbackFor = Exception.class)
	public void listActivity(ModelMap modelMap, int startIndex,Map<String, Object> reqs) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Pages<ActivityPO> pages = new Pages<ActivityPO>(startIndex);
		Map<Object, Object> map = new HashMap<Object, Object>();
		map.put("startIndex", startIndex);
		map.put("pageSize", 10);
		reqs.put("activityStartDate1", StringUtil.isEmpty((String)reqs.get("activityStartDate1"))?"":sdf.parse(reqs.get("activityStartDate1").toString()));
		reqs.put("activityStartDate2", StringUtil.isEmpty((String)reqs.get("activityStartDate2"))?"":sdf.parse(reqs.get("activityStartDate2").toString()));
		reqs.put("activityEndDate1", StringUtil.isEmpty((String)reqs.get("activityEndDate1"))?"":sdf.parse(reqs.get("activityEndDate1").toString()));
		reqs.put("activityEndDate2", StringUtil.isEmpty((String)reqs.get("activityEndDate2"))?"":sdf.parse(reqs.get("activityEndDate2").toString()));
		reqs.put("activityId", StringUtil.isEmpty((String)reqs.get("activityId"))?"":reqs.get("activityId").toString().trim());
		reqs.put("activityName", StringUtil.isEmpty((String)reqs.get("activityName"))?"":reqs.get("activityName").toString().trim());
		reqs.put("group", StringUtil.isEmpty((String)reqs.get("group"))?"":reqs.get("group").toString().trim());
		map.putAll(reqs);
		List<ActivityPO> list = this.activityPriorityService.findAllActivityForPage(map);
		pages.setItems(list);
		pages.setTotalCount(activityPriorityService.countFindAllActivityForPage(map));
		modelMap.addAttribute("page", pages);
		modelMap.addAllAttributes(reqs);
		
	}
	/**
	 * 向活动组添加活动
	 * @param modelMap
	 * @param activityId
	 * @param groupId
	 */
	public void addActivityToGroup(ModelMap modelMap, String activityId,
			String groupId) {
		String[] activityIds=activityId.split(",");
		for(String activity:activityIds){
			HashMap<String,Object> map=new HashMap<String,Object>();
			map.put("groupId", groupId);
			map.put("activityId", Long.parseLong(activity));
			map.put("activityPriority", ACTIVITY_DEFAULT_PRIORITY);
			activityPriorityService.createActivityPriority(map);
		}
		
	}
}