package cn.itkt.btsf.sys.activity.controller;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.btsf.sys.activity.vo.ClientActivityVO;
/**
 * 终端活动管理控制器
 * @author xuyh
 * @date 2013-01-14
 */
@Controller
@RequestMapping("/sys/activity/clientActivity")
public class ClientActivityController {

	@Resource
	private  ClientActivityControllerSupport  clientActivityControllerSupport;
	
	/**
	 * 分页--条件查询
	 * @param modelMap
	 * @param startIndex
	 * @param reqs 查询参数
	 * @return
	 */
	@RequestMapping(value="/listActivity")
	public String listActivity(ModelMap modelMap,@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,@RequestParam Map<String, Object> reqs){
		//调用Support处理业务逻辑
		clientActivityControllerSupport.listActivity(modelMap, startIndex, reqs);
		return "sys/activity/client/activityList";		
	}
	
	/**
	 * 添加活动页面
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/addActivityView")
	public String addActivityView(ModelMap modelMap){
		Date today = new Date();
 		modelMap.addAttribute("activityStartDate", today);
		modelMap.addAttribute("activityEndDate", today);
		return "sys/activity/client/activityAdd";		
	}
	
	/**
	 * 添加操作,入库
	 * @param modelMap
	 * @param vo
	 * @return
	 */
	@RequestMapping(value="/addActivity", method=RequestMethod.POST)
	public ModelAndView addActivity(ModelMap modelMap,@ModelAttribute ClientActivityVO vo,HttpServletRequest request,@RequestParam Map<String, Object> reqs){
		//接收文件
		int res = preSaveActivityImage(vo, request);
		if(res==1){
			modelMap.addAttribute("message", "图片不得大于50K");
			modelMap.addAttribute("status", 1);
			return new ModelAndView("redirect:/sys/activity/clientActivity/addActivityView");
		}else{
			//调用Support处理业务逻辑
			clientActivityControllerSupport.addActivity(modelMap,vo,reqs);
			return new ModelAndView("redirect:/sys/activity/clientActivity/listActivity");
		}
	}

	/**
	 * 删除活动
	 * @param modelMap
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/deleteActivity")
	public ModelAndView deleteActivity(ModelMap modelMap,@RequestParam(value="activityId" ,required=false, defaultValue="") String activityId){
		//调用Support处理业务逻辑
		clientActivityControllerSupport.deleteActivity(modelMap,activityId);
		return new ModelAndView("jsonView");
	}
	
	/**
	 * 修改活动状态
	 * @param modelMap
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/updateActivityStatus")
	public ModelAndView updateActivityStatus(ModelMap modelMap,@RequestParam(value="activityId" ,required=false, defaultValue="") String activityId){
		//调用Support处理业务逻辑
		clientActivityControllerSupport.updateActivityStatus(modelMap,activityId);
		return new ModelAndView("jsonView");
	}
	
	/**
	 * 修改活动页面
	 * @param modelMap
	 * @param activityId
	 * @return
	 */
	@RequestMapping(value="/updateActivityView")
	public String updateActivityView(ModelMap modelMap,
			@RequestParam(value="activityId" ,required=false, defaultValue="") String activityId){
		this.clientActivityControllerSupport.findActivityById(modelMap, activityId);
		return "sys/activity/client/activityUpdate";
	}
	
	/**
	 * 更新操作,入库
	 * @param modelMap
	 * @param ClientActivityVO
	 * @return
	 */
	@RequestMapping(value="/updateActivity")
	public ModelAndView updateActivity(ModelMap modelMap,@ModelAttribute ClientActivityVO vo,HttpServletRequest request,@RequestParam Map<String, Object> reqs){
		//接收文件
		int res = preSaveActivityImage(vo, request);
		if(res==1){
			modelMap.addAttribute("message", "图片不得大于50K");
			modelMap.addAttribute("status", 1);
			modelMap.addAttribute("activityId", vo.getActivityId());
			return new ModelAndView("redirect:/sys/activity/clientActivity/updateActivityView",modelMap);
		}else{
			//调用Support处理业务逻辑
			clientActivityControllerSupport.updateActivity(modelMap,vo,reqs);
			return new ModelAndView("redirect:/sys/activity/clientActivity/listActivity");
		}
	}
	
	/**
	 * 预览活动页面
	 * @param modelMap
	 * @param startIndex
	 * @param reqs 查询参数
	 * @return
	 */
	@RequestMapping(value="/previewActivity")
	public String previewActivity(ModelMap modelMap,@RequestParam(value="activityId" ,required=false, defaultValue="") String activityId){
		Map<String, Object> reqs = new HashMap<String, Object>();
		reqs.put("activityId", activityId);
		ClientActivityVO vo = clientActivityControllerSupport.getActivityByActivityId(activityId);
		//回显活动信息
		modelMap.addAttribute("activity", vo);
		return "sys/activity/client/activityPreview";		
	}
	
	/**
	 * 活动顺序设置页面
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/activityOrderSetView")
	public String activityOrderSetView(ModelMap modelMap){
		//查询所有的客户端活动信息
		this.clientActivityControllerSupport.findAllActivity(modelMap);
		return "sys/activity/client/activityOrderSet";		
	}
	/**
	 * 活动顺序设置
	 * @param modelMap
	 * @param reqs 查询参数
	 * @return
	 */
	@RequestMapping(value="/activityOrderSet",method=RequestMethod.POST)
	public ModelAndView activityOrderSet(ModelMap modelMap,@RequestParam Map<String, Object> reqs){
		//查询所有的客户端活动信息
		//data=1-11651741,2-11541028
		this.clientActivityControllerSupport.updateActivityOrder(modelMap,reqs);
		return new ModelAndView("jsonView");	
	}
	
	/**
	 * 预览活动图片
	 * @param reqs
	 * @param response
	 */
	@RequestMapping(value="/showActivityImage")
	public void showActivityImage(@RequestParam Map<String, String> reqs,HttpServletResponse response){
		String actImg = reqs.get("actImg");
		String imagePath = cn.itkt.btsf.util.PropertyUtil.getProProperty().getString("activityImagePath");
		File file = new File(imagePath+File.separator+actImg);
		InputStream in = null;
		ServletOutputStream out= null;
		if(file!=null&&file.exists()){
			try {
				out = response.getOutputStream();
				in = new FileInputStream(file);
				int b = -1;
				while((b = in.read())!=-1){
					out.write(b);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}finally{
				try {
					if(in!=null)in.close();
					if(out!=null)out.close();
				} catch (Exception e2) {
				}
			}
		}
	}
	/**
	 * 预存活动图片
	 * @param reqs
	 * @param response
	 */
	private int preSaveActivityImage(ClientActivityVO vo, HttpServletRequest request) {
		if (request instanceof MultipartHttpServletRequest) {
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			MultipartFile multipartFile = multipartRequest.getFile("activityImageFile");
			if (multipartFile!=null&&multipartFile.getSize()/1024 > 50) {//活动图片不能大于50K
				return 1;
			}
			if (multipartFile!=null&&multipartFile.getSize() != 0&&multipartFile.getSize()/1024 <= 50) {
				String imagePath = cn.itkt.btsf.util.PropertyUtil.getProProperty().getString("activityImagePath");
				String fileName = multipartFile.getOriginalFilename();
				String ext = fileName.substring(fileName.lastIndexOf("."));
				vo.setTempActivityImage(System.currentTimeMillis() + ext);
				OutputStream out = null;
				try {
					byte[] bytes = multipartFile.getBytes();
					File dir = new File(imagePath);
					if (!dir.exists())
						dir.mkdirs();// 目录不存在则创建目录
					File file = new File(imagePath + File.separator + vo.getTempActivityImage());
					if (!file.exists())
						file.createNewFile();
					out = new FileOutputStream(file);
					out.write(bytes);
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						if(out!=null)out.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		return 0;
	}
	
	/**
	 * 注册指定日期格式的日期属性编辑器
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		formater.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formater, true));
	}

}