package cn.itkt.btsf.sys.activity.controller;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
/**
 * 活动管理控制器
 * @author lixu
 * @date 2012-09-21
 */
@Controller
@RequestMapping("/sys/activity/conditions")
public class ActivityConditionController {
	@Resource
	private ActivityConditionControllerSupport activityConditionControllerSupport;
	
	/**
	 * 查询航空公司
	 * @param model
	 * @param startIndex
	 * @param reqs
	 * @return
	 */
	@RequestMapping(value="/queryAirCompany")
	public String queryAirCompany(ModelMap modelMap,
			@RequestParam(value="startIndex",required=false,defaultValue="0") int startIndex,
			@RequestParam Map<String, Object> reqs ){
		String airlinesCode = reqs.get("airlinesCode")==null?"":reqs.get("airlinesCode").toString().toUpperCase().trim();
		String airlinesName = reqs.get("airlinesName")==null?"":reqs.get("airlinesName").toString().trim();
		reqs.put("airlinesCode", airlinesCode);
		reqs.put("airlinesName", airlinesName);
		activityConditionControllerSupport.queryAirCompany(modelMap,startIndex,reqs);
		modelMap.put("airlinesCode", airlinesCode);
		modelMap.put("airlinesName", airlinesName);
		return "sys/activity/conditions/chooseAirCompany";	
	}
	/**
	 * 查询航线
	 * @param modelMap
	 * @param startIndex
	 * @param vo
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/queryAirLine")
	public String queryAirLine(ModelMap modelMap,@RequestParam(value="startIndex",defaultValue = "0",required=false) int startIndex,
			@RequestParam Map<String, Object> reqs){
		Set<String> fromCities = new HashSet<String>();
		Set<String> toCities = new HashSet<String>();
		if(reqs.get("keys")!=null&&!"".equals(reqs.get("keys"))){
			String keys = reqs.get("keys").toString();
			String[] ks = keys.split(",");
			for(String k:ks){
				fromCities.add("'"+k.split("~")[0]+"'");
				toCities.add("'"+k.split("~")[1]+"'");
			}
		}
		reqs.put("fromCities", fromCities.size()==0?"":fromCities.toString().replace("[", "").replace("]", ""));
		reqs.put("toCities", toCities.size()==0?"":toCities.toString().replace("[", "").replace("]", ""));
		activityConditionControllerSupport.queryAllCity(modelMap,reqs);
		return "sys/activity/conditions/chooseAirLine";	
	}
	/**
	 * 查询航线中城市
	 * @param modelMap
	 * @param startIndex
	 * @param vo
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/queryAirLine_city")
	public String queryAirLine_city(ModelMap modelMap,@RequestParam(value="startIndex",defaultValue = "0",required=false) int startIndex,
			@RequestParam Map<String, Object> reqs){
		String cityName = reqs.get("cityName")==null?"":reqs.get("cityName").toString().trim();
		String cityCode = reqs.get("cityCode")==null?"":reqs.get("cityCode").toString().toUpperCase().trim();
		String provinceName = reqs.get("provinceName")==null?"":reqs.get("provinceName").toString().trim();
		reqs.put("cityName", cityName);
		reqs.put("cityCode", cityCode);
		reqs.put("provinceName", provinceName);
		activityConditionControllerSupport.queryCity(modelMap,startIndex,reqs);
		modelMap.put("cityName", cityName);
		modelMap.put("cityCode", cityCode);
		modelMap.put("provinceName", provinceName);
		
		return "sys/activity/conditions/chooseAirLine_city";	
	}
	/**
	 * 会员手机归属地市
	 * @param modelMap
	 * @param startIndex
	 * @param reqs
	 * @return
	 */
	@RequestMapping(value="/chooseCity")
	public String queryCity(ModelMap modelMap,@RequestParam(value="startIndex",defaultValue = "0",required=false) int startIndex,
			@RequestParam Map<String, Object> reqs){
		String cityName = reqs.get("cityName")==null?"":reqs.get("cityName").toString().trim();
		String cityCode = reqs.get("cityCode")==null?"":reqs.get("cityCode").toString().toUpperCase().trim();
		String provinceName = reqs.get("provinceName")==null?"":reqs.get("provinceName").toString().trim();
		reqs.put("cityName", cityName);
		reqs.put("cityCode", cityCode);
		reqs.put("provinceName", provinceName);
		activityConditionControllerSupport.queryCity(modelMap,startIndex,reqs);
		modelMap.put("cityName", cityName);
		modelMap.put("cityCode", cityCode);
		modelMap.put("provinceName", provinceName);
		return "sys/activity/conditions/chooseCity";
	}
	/**
	 * 会员手机归属省份
	 * @param modelMap
	 * @param startIndex
	 * @param reqs
	 * @return
	 */
	@RequestMapping(value="/chooseProvince")
	public String queryProvince(ModelMap modelMap,@RequestParam Map<String, Object> reqs){
		activityConditionControllerSupport.queryProvince(modelMap,reqs);
		return "sys/activity/conditions/chooseProvince";
	}
	/**
	 * 查询舱位
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/findCabin",method=RequestMethod.POST)
	public ModelAndView findAllShippingSpace(ModelMap modelMap,@RequestParam(value="aillinesCode" ,required=false, defaultValue="") String aillinesCode,
			@RequestParam Map<String, Object> reqs){
		activityConditionControllerSupport.findAllShippingSpace(modelMap,reqs);
		return new ModelAndView("jsonView");
	}
	/**
	 * 会员归属渠道
	 * @param modelMap
	 * @param startIndex
	 * @param reqs
	 * @return
	 */
	@RequestMapping(value="/chooseUserChannels")
	public String queryUserChannels(ModelMap modelMap,@RequestParam(value="startIndex",defaultValue = "0",required=false) int startIndex,
			@RequestParam Map<String, Object> reqs){
		String channelId = reqs.get("channelId")==null?"":reqs.get("channelId").toString().trim();
		reqs.put("channelId", channelId);
		activityConditionControllerSupport.queryUserChannels(modelMap,startIndex,reqs);
		modelMap.put("channelId", channelId);
		return "sys/activity/conditions/chooseUserChannels";
	}
	/**
	 * 推荐人手机号
	 * @param modelMap
	 * @param startIndex
	 * @param reqs
	 * @return
	 */
	@RequestMapping(value="/chooseRecommendPhone")
	public String queryRecommendPhone(ModelMap modelMap,@RequestParam(value="startIndex",defaultValue = "0",required=false) int startIndex,
			@RequestParam Map<String, Object> reqs){
		String recommendPhone = reqs.get("recommendPhone")==null?"":reqs.get("recommendPhone").toString().trim();
		reqs.put("recommendPhone", recommendPhone);
		activityConditionControllerSupport.queryRecommendPhone(modelMap,startIndex,reqs);
		modelMap.put("recommendPhone", recommendPhone);
		return "sys/activity/conditions/chooseRecommendPhone";
	}
	
}