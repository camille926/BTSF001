package cn.itkt.btsf.sys.activity.vo;

import java.util.List;

public class ActivityGroupVO {
	private Long id;
	private String groupName;
	private String groupRemark;
	private int groupPriority;
	private List<ActivityVO> activityList;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getGroupRemark() {
		return groupRemark;
	}
	public void setGroupRemark(String groupRemark) {
		this.groupRemark = groupRemark;
	}
	public List<ActivityVO> getActivityList() {
		return activityList;
	}
	public void setActivityList(List<ActivityVO> activityList) {
		this.activityList = activityList;
	}
	public int getGroupPriority() {
		return groupPriority;
	}
	public void setGroupPriority(int groupPriority) {
		this.groupPriority = groupPriority;
	}
	
	
}
