package cn.itkt.btsf.sys.activity.vo;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 活动实体类
 * 
 * @author xuyh
 * @date 2012-09-21
 */
public class ActivityVO {

	/** 活动主键ID **/
	private long id;

	/** 活动编号 **/
	private String activityId;

	/** 活动名称 **/
	private String activityName;

	/** 活动类型id **/
	private long activityType;

	/** 活动开始时间 **/
	private Date activityStartDate;

	/** 活动结束时间 **/
	private Date activityEndDate;

	/** 活动状态 **/
	private String activityStatus;

	/** 活动备注 **/
	private String activityRemark;
	
	/** 全部或任一（01:全部；02:任一） **/
	private String allOrAny;
	/**活动在活动组中的优先级**/
	private int activityPriority;
	
	/** 活动图片的url **/
	private String activityImage;
	
	/** 活动图片名称(临时用) **/
	private String tempActivityImage;
	
	/** 活动方式数据 **/
	private List<Map<String,Object>> activityWay;
	
	public List<Map<String, Object>> getActivityWay() {
		return activityWay;
	}

	public void setActivityWay(List<Map<String, Object>> activityWay) {
		this.activityWay = activityWay;
	}

	public String getTempActivityImage() {
		return tempActivityImage;
	}

	public void setTempActivityImage(String tempActivityImage) {
		this.tempActivityImage = tempActivityImage;
	}

	public String getActivityImage() {
		return activityImage;
	}

	public void setActivityImage(String activityImage) {
		this.activityImage = activityImage;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getActivityName() {
		return activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public long getActivityType() {
		return activityType;
	}

	public void setActivityType(long activityType) {
		this.activityType = activityType;
	}

	public Date getActivityStartDate() {
		return activityStartDate;
	}

	public void setActivityStartDate(Date activityStartDate) {
		this.activityStartDate = activityStartDate;
	}

	public Date getActivityEndDate() {
		return activityEndDate;
	}

	public void setActivityEndDate(Date activityEndDate) {
		this.activityEndDate = activityEndDate;
	}


	public String getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}

	public String getActivityRemark() {
		return activityRemark;
	}

	public void setActivityRemark(String activityRemark) {
		this.activityRemark = activityRemark;
	}

	public String getAllOrAny() {
		return allOrAny;
	}

	public void setAllOrAny(String allOrAny) {
		this.allOrAny = allOrAny;
	}

	public int getActivityPriority() {
		return activityPriority;
	}

	public void setActivityPriority(int activityPriority) {
		this.activityPriority = activityPriority;
	}

}