package cn.itkt.btsf.sys.activity.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.itkt.btsf.sys.activity.dao.ActivityPriorityDao;
import cn.itkt.btsf.sys.activity.po.ActivityPO;
import cn.itkt.btsf.sys.activity.service.ActivityPriorityService;
import cn.itkt.btsf.sys.activity.vo.ActivityGroupVO;
import cn.itkt.btsf.sys.activity.vo.ActivityVO;
@Service
public class ActivityPriorityServiceImpl implements ActivityPriorityService {
	@Resource
	private ActivityPriorityDao activityPriorityDao;
	/**
	 * 查询活动组列表
	 * @return
	 */
	public List<ActivityGroupVO> listActivityGroup(){
		return activityPriorityDao.listActivityGroup();
	}
	/**
	 * 设置活动优先级
	 * @param map
	 */
	public void activityPrioritySet(Map<String, Object> map){
		activityPriorityDao.activityPrioritySet(map);
	}
	/**
	 * 删除所有活动优先级
	 */
	public void deleteAllPriority(){
		activityPriorityDao.deleteAllPriority();
	}
	/**
	 * 更新活动组优先级
	 * @param map
	 */
	public void updateGroupPriority(Map<String, Object> map){
		activityPriorityDao.updateGroupPriority(map);
	}
	/**
	 * 从活动组中删除某个活动
	 * @param groupId
	 * @param activityId
	 */
	public void deleteActivityPriority(Long groupId, Long activityId){
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("groupId", groupId);
		map.put("activityId", activityId);
		activityPriorityDao.deleteActivityPriority(map);
	}
	/**
	 * 根据活动组删除活动优先级
	 * @param groupId
	 */
	public void deleteActivityGroupPriority(Long groupId){
		activityPriorityDao.deleteActivityGroupPriority(groupId);
	}
	/**
	 * 删除活动组
	 * @param groupId
	 */
	public void deleteActivityGroup(Long groupId){
		activityPriorityDao.deleteActivityGroup(groupId);
	}
	/**
	 * 创建指定优先级的活动组
	 * @param defaultPriority
	 */
	public void createGroup(ActivityGroupVO group){
		activityPriorityDao.createGroup(group);
	}
	/**
	 * 向活动组中添加活动
	 * @param map
	 */
	public void createActivityPriority(HashMap<String, Object> map){
		activityPriorityDao.createActivityPriority(map);
	}
	/**
	 * 查询活动列表
	 * @param map
	 * @return
	 */
	public List<ActivityPO> findAllActivityForPage(Map<Object, Object> map){
		return activityPriorityDao.findAllActivityForPage(map);
	}
	/**
	 * 查询活动列表记录数
	 * @param map
	 * @return
	 */
	public int countFindAllActivityForPage(Map<Object, Object> map){
		return activityPriorityDao.countFindAllActivityForPage(map);
	}
}
