package cn.itkt.btsf.sys.activity.service;

import java.util.List;
import java.util.Map;

import org.springframework.ui.ModelMap;

import cn.itkt.btsf.sys.activity.po.ClientActivityPO;
import cn.itkt.btsf.sys.activity.vo.ClientActivityVO;
import cn.itkt.pagination.Pages;

public interface ClientActivityService {
	
	/**
	 * 查找所有 --分页
	 * @return List<PhoneClientActivityPO> 
	 */
	public List<ClientActivityPO> findAllActivityForPage(Map<String,Object> map)throws Exception;
	
	public int countFindAllActivityForPage(Map<String, Object> map)throws Exception;
	/**
	 * 创建 
	 * @param po
	 */
	public void createActivity(ClientActivityPO po) throws Exception;

	/**
	 * 删除 
	 * @param id 
	 */
	public void deleteActivity(String activityId)throws Exception;
	
	
	/**
	 * 查找单个 
	 * @param activityId
	 * @return
	 */
	public ClientActivityPO findActivity(String activityId)throws Exception;

	/**
	 * 修改 活动状态
	 * @param po 
	 */
	public void updateActivityStatus(ModelMap modelMap,String activityId) throws Exception;
	/**
	 * 修改 
	 * @param po 
	 */
	public void updateActivity(ClientActivityPO po) throws Exception;
	/**
	 * po与vo转换
	 * @param po
	 * @return vo
	 */
	ClientActivityVO poToVo(ClientActivityPO po);
	
	/**
	 * vo与po转换
	 * @param po
	 * @return vo
	 */
	ClientActivityPO voToPo(ClientActivityVO vo);
	
	
	/**
	 * po列表与vo列表转换
	 * @param poList
	 * @return voList
	 */
	List<ClientActivityVO> poListToVoList(List<ClientActivityPO> poList);

	/**
	 * 重新活动序号
	 * @param reqs
	 */
	public void updateActivityOrder(Map<String, Object> reqs);
	
}