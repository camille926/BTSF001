package cn.itkt.btsf.sys.activity.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.sys.activity.po.ActivityPO;
import cn.itkt.btsf.sys.activity.vo.ActivityGroupVO;


public interface ActivityPriorityService {
	/**
	 * 查询活动组列表
	 * @return
	 */
	public List<ActivityGroupVO> listActivityGroup();
	/**
	 * 设置活动优先级
	 * @param map
	 */
	public void activityPrioritySet(Map<String, Object> map);
	/**
	 * 删除所有活动优先级
	 */
	public void deleteAllPriority();
	/**
	 * 更新活动组优先级
	 * @param map
	 */
	public void updateGroupPriority(Map<String, Object> map);
	/**
	 * 从活动组中删除某个活动
	 * @param groupId
	 * @param activityId
	 */
	public void deleteActivityPriority(Long groupId, Long activityId);
	/**
	 * 根据活动组删除活动优先级
	 * @param groupId
	 */
	public void deleteActivityGroupPriority(Long groupId);
	/**
	 * 删除活动组
	 * @param groupId
	 */
	public void deleteActivityGroup(Long groupId);
	/**
	 * 创建指定优先级的活动组
	 * @param group
	 */
	public void createGroup(ActivityGroupVO group);
	/**
	 * 向活动组中添加活动
	 * @param map
	 */
	public void createActivityPriority(HashMap<String, Object> map);
	/**
	 * 查询活动列表
	 * @param map
	 * @return
	 */
	public List<ActivityPO> findAllActivityForPage(Map<Object, Object> map);
	/**
	 * 查询活动列表记录数
	 * @param map
	 * @return
	 */
	public int countFindAllActivityForPage(Map<Object, Object> map);
	
	

}