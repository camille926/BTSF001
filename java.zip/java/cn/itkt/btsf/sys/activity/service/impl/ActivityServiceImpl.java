package cn.itkt.btsf.sys.activity.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.sys.activity.dao.ActivityDao;
import cn.itkt.btsf.sys.activity.po.ActivityPO;
import cn.itkt.btsf.sys.activity.service.ActivityService;
import cn.itkt.btsf.sys.activity.service.carwebservice.Result;
import cn.itkt.btsf.sys.activity.util.HotelResult;
import cn.itkt.btsf.sys.activity.util.HttpClientUtil;
import cn.itkt.btsf.sys.activity.util.MapAdapter;
import cn.itkt.btsf.sys.activity.util.WebServiceUtil;
import cn.itkt.btsf.sys.activity.vo.ActivityVO;
import cn.itkt.exception.AppException;

import com.opensymphony.oscache.util.StringUtil;

@Service
public class ActivityServiceImpl implements ActivityService {

	private static final Logger log = LoggerFactory.getLogger(ActivityServiceImpl.class);
	
	@Resource
	private  ActivityDao  activityDao;
	
	@Override
	public List<ActivityPO> findAllActivityForPage(Map<String, Object> map) {
		String activityType = (String) map.get("activityType");
		if(activityType==null){
			map.put("activityType", "1");
		}
		return activityDao.findAllActivityForPage(map);
	}

	
	/**
	 * 查找单个 
	 * @param activityId 
	 * @return Activity 
	 */
	public ActivityPO findActivity(String activityId){
		return activityDao.findActivity(activityId);	
	}


	/**
	 * 删除 
	 * @param id 
	 */
	@Transactional(rollbackFor=Exception.class)
	public void deleteActivity(String activityType,String activityId){
		if("4".equals(activityType)){
			String param = "activityId="+activityId;
			HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"findActivity", param, HotelResult.class);
			ActivityPO po = result.getListActivities().get(0);
			HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"deleteActivity", param, HotelResult.class);
			//解除与组的关系
//			activityDao.deleteActivityPriority(activityId);
			//解除与活动方式信息间的关系
			String param2 = "activityId="+po.getId();
			HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"deleteActivityWay", param2, HotelResult.class);
			//解除与活动条件信息间的关系
			HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"deleteActivityConds", param2, HotelResult.class);
		}else if("5".equals(activityType)){
			Result result = WebServiceUtil.instanceCarActWS().findActivity(activityId);
			ActivityPO po = wsAct2Act(result.getListActivities().get(0));
			WebServiceUtil.instanceCarActWS().deleteActivity(activityId);
			//解除与组的关系
//			activityDao.deleteActivityPriority(activityId);
			//解除与活动方式信息间的关系
			WebServiceUtil.instanceCarActWS().deleteActivityWay(po.getId());
			//解除与活动条件信息间的关系
			WebServiceUtil.instanceCarActWS().deleteActivityConds(po.getId());
		}else{
			ActivityPO po = activityDao.findActivity(activityId);
			activityDao.deleteActivity(activityId);
			//解除与组的关系
			activityDao.deleteActivityPriority(activityId);
			//解除与活动方式信息间的关系
			activityDao.deleteActivityWay(po.getId());
			//解除与活动条件信息间的关系
			activityDao.deleteActivityConds(po.getId());
		}
	}

	@Transactional(rollbackFor=Exception.class)
	public void createActivity(ActivityPO po,List<Map<String,Object>> ways,List<Map<String,Object>> conds) throws Exception {
		if(po.getActivityType()==4){
			HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"saveActivity", po, HotelResult.class);
			String param = "activityId="+po.getActivityId();
			HotelResult result = HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"findActivity", param, HotelResult.class);
			long actId = result.getListActivities().get(0).getId();
			//添加活动方式信息,如直降200
			for(Map<String,Object> way:ways){
				way.put("activityId", actId);
				HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"saveActivityWay", way, HotelResult.class);
			}
			//添加活动条件信息,如注册日期,2012-09-01至2012-09-02
			for(Map<String,Object> cond :conds){
				cond.put("activityId", actId);
				HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"saveActivityConds", cond, HotelResult.class);
			}
		}else if(po.getActivityType()==5){
			WebServiceUtil.instanceCarActWS().saveActivity(act2WSAct(po));
			Result result = WebServiceUtil.instanceCarActWS().findActivity(po.getActivityId());
			long actId = result.getListActivities().get(0).getId();
			//添加活动方式信息,如直降200
			for(Map<String,Object> way:ways){
				way.put("activityId", actId);
				WebServiceUtil.instanceCarActWS().saveActivityWay(new MapAdapter().marshal(way));
			}
			//添加活动条件信息,如注册日期,2012-09-01至2012-09-02
			for(Map<String,Object> cond :conds){
				cond.put("activityId", actId);
				WebServiceUtil.instanceCarActWS().saveActivityConds(new MapAdapter().marshal(cond));
			}
		}else{
			this.activityDao.createActivity(po);//添加活动
			long actId = this.activityDao.findActivity(po.getActivityId()).getId();
			//添加活动方式信息,如直降200
			for(Map<String,Object> way:ways){
				way.put("activityId", actId);
				this.activityDao.createActivityWay(way);
			}
			//添加活动条件信息,如注册日期,2012-09-01至2012-09-02
			for(Map<String,Object> cond :conds){
				cond.put("activityId", actId);
				this.activityDao.createActivityConds(cond);
			}
		}
		//保存文件
		saveImage(po);
	}

	public void updateActivityStatus(ModelMap modelMap,String activityId) throws Exception{
		ActivityPO po = activityDao.findActivity(activityId);
		po.setActivityImage(po.getActivityImage()==null?"":po.getActivityImage());
		po.setActivityRemark(po.getActivityRemark()==null?"":po.getActivityRemark());
		if( po != null ){
			String status = po.getActivityStatus();
			if(status.equals("01")){
				po.setActivityStatus("02");
			}else if(status.equals("02")){
				po.setActivityStatus("01");
			}
			activityDao.updateActivity(po);
		}
	}
	
	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void updateActivity(ActivityPO po,List<Map<String,Object>> ways,List<Map<String,Object>> conds) throws Exception {
		try{
			if(po.getActivityType()==4){
				HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"updateActivity", po, HotelResult.class);
				//删除活动方式信息,根据活动id
				String param = "activityId="+po.getId();
				HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"deleteActivityWay", param, HotelResult.class);
				//添加活动方式信息,如直降200
				for(Map<String,Object> way:ways){
					HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"saveActivityWay", way, HotelResult.class);
				}
				//删除活动条件信息
				HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"deleteActivityConds", param, HotelResult.class);
				//添加活动条件信息,如注册日期,2012-09-01至2012-09-02
				for(Map<String,Object> cond:conds){
					HttpClientUtil.doFormPost(WebServiceUtil.getHotelBaseUrl()+"saveActivityConds", cond, HotelResult.class);
				}
			}else if(po.getActivityType()==5){
				WebServiceUtil.instanceCarActWS().updateActivity(act2WSAct(po));
				//删除活动方式信息,根据活动id
				WebServiceUtil.instanceCarActWS().deleteActivityWay(po.getId());
				//添加活动方式信息,如直降200
				for(Map<String,Object> way:ways){
					WebServiceUtil.instanceCarActWS().saveActivityWay(new MapAdapter().marshal(way));
				}
				//删除活动条件信息
				WebServiceUtil.instanceCarActWS().deleteActivityConds(po.getId());
				//添加活动条件信息,如注册日期,2012-09-01至2012-09-02
				for(Map<String,Object> cond:conds){
					WebServiceUtil.instanceCarActWS().saveActivityConds(new MapAdapter().marshal(cond));
				}
			}else{
				if( po != null )
					 activityDao.updateActivity(po);
				//删除活动方式信息,根据活动id
				this.activityDao.deleteActivityWay(po.getId());
				//添加活动方式信息,如直降200
				for(Map<String,Object> way:ways){
					this.activityDao.createActivityWay(way);
				}
				//删除活动条件信息
				this.activityDao.deleteActivityConds(po.getId());
				//添加活动条件信息,如注册日期,2012-09-01至2012-09-02
				for(Map<String,Object> cond:conds){
					this.activityDao.createActivityConds(cond);
				}
			}
			//保存图片
			saveImage(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("update error!");
		}	
	}

	@Override
	public List<Map<String,Object>> getAllActivityTypes() {
		return activityDao.getAllActivityTypes();
	}

	@Override
	public List<Map<String,Object>> getActivityWay(long activityId) {
		return activityDao.getActivityWay(activityId);
	}
	
	@Override
	public List<Map<String,Object>> getActivityConditions(long activityType) {
		return activityDao.getActivityConditions(activityType);
	}
	
	@Override
	public List<Map<String,Object>> getActivityConditionValues(long activityId) {
		return activityDao.getActivityConditionValues(activityId);
	}


	@Override
	public int countFindAllActivityForPage(Map<String, Object> map) {
		return activityDao.countFindAllActivityForPage(map);
	}

	private void saveImage(ActivityPO po){
		//保存文件
		String activityId = po.getActivityId();
		String tempActivityImage = po.getTempActivityImage();
		if (!StringUtil.isEmpty(activityId)&&!StringUtil.isEmpty(tempActivityImage)&&tempActivityImage.indexOf(".")!=-1) {
			String imagePath = cn.itkt.btsf.util.PropertyUtil.getProProperty().getString("activityImagePath");
			String fileName = po.getTempActivityImage();
			File file = new File(imagePath + File.separator + fileName);
			String activityImage = activityId+tempActivityImage.substring(tempActivityImage.lastIndexOf("."), tempActivityImage.length());
			file.renameTo(new File(imagePath + File.separator + activityImage));
		}
	}
	
	@Override
	public List<ActivityVO> poListToVoList(List<ActivityPO> poList) {
		List<ActivityVO> voList = new ArrayList<ActivityVO>();
		for (ActivityPO po : poList) {
			voList.add(this.poToVo(po));
		}
		return voList;
	}

	@Override
	public ActivityVO poToVo(ActivityPO po) {
		ActivityVO vo = new ActivityVO();
		try {
			PropertyUtils.copyProperties(vo, po);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vo;
	}

	@Override
	public ActivityPO voToPo(ActivityVO vo) {
		ActivityPO po = new ActivityPO();
		try {
			PropertyUtils.copyProperties(po, vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return po;
	}
	public static XMLGregorianCalendar date2XMLGregorianCalendar(Date date) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.setTime(date);
		XMLGregorianCalendar gc = null;
		try {
			gc = DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
		}
		return gc;
	}
	
	public static Date xMLGregorianCalendar2Date(XMLGregorianCalendar xmlDate) {
		GregorianCalendar cal = xmlDate.toGregorianCalendar();
		return new Date(cal.getTime().getTime());
	}
	
	public static ActivityPO wsAct2Act(cn.itkt.btsf.sys.activity.service.carwebservice.ActivityPO wsAct) {
		ActivityPO po = new ActivityPO();
		po.setId(wsAct.getId());
		po.setActivityId(wsAct.getActivityId());
		po.setActivityName(wsAct.getActivityName());
		po.setActivityType(wsAct.getActivityType());
		po.setActivityStartDate(xMLGregorianCalendar2Date(wsAct.getActivityStartDate()));
		po.setActivityEndDate(xMLGregorianCalendar2Date(wsAct.getActivityEndDate()));
		po.setActivityStatus(wsAct.getActivityStatus());
		po.setActivityRemark(wsAct.getActivityRemark());
		po.setAllOrAny(wsAct.getAllOrAny());
		po.setActivityImage(wsAct.getActivityImage());
		return po;
	}
	public static cn.itkt.btsf.sys.activity.service.carwebservice.ActivityPO act2WSAct(ActivityPO act) {
		cn.itkt.btsf.sys.activity.service.carwebservice.ActivityPO po = new cn.itkt.btsf.sys.activity.service.carwebservice.ActivityPO();
		po.setId(act.getId());
		po.setActivityId(act.getActivityId());
		po.setActivityName(act.getActivityName());
		po.setActivityType(act.getActivityType());
		po.setActivityStartDate(date2XMLGregorianCalendar(act.getActivityStartDate()));
		po.setActivityEndDate(date2XMLGregorianCalendar(act.getActivityEndDate()));
		po.setActivityStatus(act.getActivityStatus());
		po.setActivityRemark(act.getActivityRemark());
		po.setAllOrAny(act.getAllOrAny());
		po.setActivityImage(act.getActivityImage());
		return po;
	}
}