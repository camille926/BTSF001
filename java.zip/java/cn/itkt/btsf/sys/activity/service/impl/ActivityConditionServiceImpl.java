package cn.itkt.btsf.sys.activity.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.sys.activity.dao.ActivityConditionDao;
import cn.itkt.btsf.sys.activity.service.ActivityConditionService;
import cn.itkt.pagination.Pages;

@Service
public class ActivityConditionServiceImpl implements ActivityConditionService {

	private static final Logger log = LoggerFactory.getLogger(ActivityConditionServiceImpl.class);
	
	@Resource
	private  ActivityConditionDao  activityConditionDao;
	/**
	 * 查询所有舱位
	 * @return
	 */
	public List<Map<String, Object>> findAllShippingSpaceList(Map<String,Object> reqs){
		return activityConditionDao.findAllShippingSpaceList(reqs);
	}

	@Override
	public Pages<Map<String, Object>> queryAirLine(Map<String, Object> reqs) {
		Pages<Map<String,Object>> airLinePage=new Pages<Map<String,Object>>(Integer.parseInt(reqs.get("startIndex").toString()),
				Integer.parseInt(reqs.get("pageSize").toString()));
		airLinePage.setItems(activityConditionDao.queryAirLine(reqs));
		airLinePage.setTotalCount(activityConditionDao.countAirLine(reqs));
		return airLinePage;
	}

	@Override
	public Pages<Map<String, Object>> queryCity(Map<String, Object> reqs) {
		Pages<Map<String,Object>> cityPage=new Pages<Map<String,Object>>(Integer.parseInt(reqs.get("startIndex").toString()),
				Integer.parseInt(reqs.get("pageSize").toString()));
		cityPage.setItems(activityConditionDao.queryCity(reqs));
		cityPage.setTotalCount(activityConditionDao.countCity(reqs));
		return cityPage;
	}
	@Override
	public List<Map<String, Object>> queryAllCity(Map<String, Object> reqs) {
		List<Map<String,Object>> allCity = activityConditionDao.queryAllCity(reqs);
		for(Map<String,Object> city:allCity){
			StringBuffer cityEnName = new StringBuffer(city.get("CITY_ENNAME").toString());
			int count = 20 - cityEnName.length();
			for(int i=0;i<count;i++){
				cityEnName.append("&nbsp;");
			}
			city.put("CITY_ENNAME", cityEnName.toString());
		}
		return allCity;
	}
	@Override
	public Pages<Map<String, Object>> queryProvince(Map<String, Object> reqs) {
		Pages<Map<String,Object>> cityPage=new Pages<Map<String,Object>>(0);
		cityPage.setItems(activityConditionDao.queryProvince(reqs));
		return cityPage;
	}

	@Override
	public Pages<Map<String, Object>> queryUserChannels(Map<String, Object> reqs) {
		Pages<Map<String,Object>> userChannelsPage=new Pages<Map<String,Object>>(0);
		userChannelsPage.setItems(activityConditionDao.queryUserChannels(reqs));
		return userChannelsPage;
	}
	@Override
	public Pages<Map<String, Object>> queryRecommendPhone(Map<String, Object> reqs) {
		Pages<Map<String,Object>> recommendPhonePage=new Pages<Map<String,Object>>(Integer.parseInt(reqs.get("startIndex").toString()),
				Integer.parseInt(reqs.get("pageSize").toString()));
		recommendPhonePage.setItems(activityConditionDao.queryRecommendPhone(reqs));
		recommendPhonePage.setTotalCount(activityConditionDao.countRecommendPhone(reqs));
		return recommendPhonePage;
	}

	@Override
	public Pages<Map<String, Object>> queryAirCompany(Map<String, Object> reqs) {
		Pages<Map<String,Object>> airCompanyPage=new Pages<Map<String,Object>>(Integer.parseInt(reqs.get("startIndex").toString()));
		airCompanyPage.setItems(activityConditionDao.queryAirCompany(reqs));
		airCompanyPage.setTotalCount(activityConditionDao.countAirCompany(reqs));
		return airCompanyPage;
	}
	
	
	
}