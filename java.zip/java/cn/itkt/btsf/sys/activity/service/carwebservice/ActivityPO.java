
package cn.itkt.btsf.sys.activity.service.carwebservice;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>activityPO complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="activityPO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="activityEndDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="activityId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="activityImage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="activityName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="activityRemark" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="activityStartDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="activityStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="activityType" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="activityWay" type="{http://web.controller.car.itkt.cn/}hashMap" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="allOrAny" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hasStarted" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="tempActivityImage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "activityPO", propOrder = {
    "activityEndDate",
    "activityId",
    "activityImage",
    "activityName",
    "activityRemark",
    "activityStartDate",
    "activityStatus",
    "activityType",
    "activityWay",
    "allOrAny",
    "hasStarted",
    "id",
    "tempActivityImage"
})
public class ActivityPO {

    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar activityEndDate;
    protected String activityId;
    protected String activityImage;
    protected String activityName;
    protected String activityRemark;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar activityStartDate;
    protected String activityStatus;
    protected long activityType;
    @XmlElement(nillable = true)
    protected List<HashMap> activityWay;
    protected String allOrAny;
    protected boolean hasStarted;
    protected long id;
    protected String tempActivityImage;

    /**
     * ��ȡactivityEndDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getActivityEndDate() {
        return activityEndDate;
    }

    /**
     * ����activityEndDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setActivityEndDate(XMLGregorianCalendar value) {
        this.activityEndDate = value;
    }

    /**
     * ��ȡactivityId���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivityId() {
        return activityId;
    }

    /**
     * ����activityId���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivityId(String value) {
        this.activityId = value;
    }

    /**
     * ��ȡactivityImage���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivityImage() {
        return activityImage;
    }

    /**
     * ����activityImage���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivityImage(String value) {
        this.activityImage = value;
    }

    /**
     * ��ȡactivityName���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivityName() {
        return activityName;
    }

    /**
     * ����activityName���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivityName(String value) {
        this.activityName = value;
    }

    /**
     * ��ȡactivityRemark���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivityRemark() {
        return activityRemark;
    }

    /**
     * ����activityRemark���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivityRemark(String value) {
        this.activityRemark = value;
    }

    /**
     * ��ȡactivityStartDate���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getActivityStartDate() {
        return activityStartDate;
    }

    /**
     * ����activityStartDate���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setActivityStartDate(XMLGregorianCalendar value) {
        this.activityStartDate = value;
    }

    /**
     * ��ȡactivityStatus���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActivityStatus() {
        return activityStatus;
    }

    /**
     * ����activityStatus���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActivityStatus(String value) {
        this.activityStatus = value;
    }

    /**
     * ��ȡactivityType���Ե�ֵ��
     * 
     */
    public long getActivityType() {
        return activityType;
    }

    /**
     * ����activityType���Ե�ֵ��
     * 
     */
    public void setActivityType(long value) {
        this.activityType = value;
    }

    /**
     * Gets the value of the activityWay property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the activityWay property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActivityWay().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HashMap }
     * 
     * 
     */
    public List<HashMap> getActivityWay() {
        if (activityWay == null) {
            activityWay = new ArrayList<HashMap>();
        }
        return this.activityWay;
    }

    /**
     * ��ȡallOrAny���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAllOrAny() {
        return allOrAny;
    }

    /**
     * ����allOrAny���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAllOrAny(String value) {
        this.allOrAny = value;
    }

    /**
     * ��ȡhasStarted���Ե�ֵ��
     * 
     */
    public boolean isHasStarted() {
        return hasStarted;
    }

    /**
     * ����hasStarted���Ե�ֵ��
     * 
     */
    public void setHasStarted(boolean value) {
        this.hasStarted = value;
    }

    /**
     * ��ȡid���Ե�ֵ��
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * ����id���Ե�ֵ��
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

    /**
     * ��ȡtempActivityImage���Ե�ֵ��
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTempActivityImage() {
        return tempActivityImage;
    }

    /**
     * ����tempActivityImage���Ե�ֵ��
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTempActivityImage(String value) {
        this.tempActivityImage = value;
    }

}
