package cn.itkt.btsf.sys.activity.service.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.sys.activity.dao.ClientActivityDao;
import cn.itkt.btsf.sys.activity.po.ClientActivityPO;
import cn.itkt.btsf.sys.activity.service.ClientActivityService;
import cn.itkt.btsf.sys.activity.vo.ClientActivityVO;
import cn.itkt.exception.AppException;

import com.opensymphony.oscache.util.StringUtil;

@Service
public class ClientActivityServiceImpl implements ClientActivityService {

	private static final Logger log = LoggerFactory.getLogger(ClientActivityServiceImpl.class);
	
	@Resource
	private  ClientActivityDao  clientActivityDao;
	
	@Override
	public List<ClientActivityPO> findAllActivityForPage(Map<String, Object> map) {
		this.autoOrder();
		return clientActivityDao.findAllActivityForPage(map);
	}

	@Override
	public int countFindAllActivityForPage(Map<String, Object> map) {
		return clientActivityDao.countFindAllActivityForPage(map);
	}
	
	/**
	 * 查找单个 
	 * @param activityId 
	 * @return Activity 
	 */
	public ClientActivityPO findActivity(String activityId){
		return clientActivityDao.findActivity(activityId);	
	}


	/**
	 * 删除 
	 * @param id 
	 */
	@Transactional(rollbackFor=Exception.class)
	public void deleteActivity(String activityId){
		clientActivityDao.deleteActivity(activityId);
	}

	@Transactional(rollbackFor=Exception.class)
	public void createActivity(ClientActivityPO po) throws Exception {
		po.setActivityOrder(Integer.MAX_VALUE);//设置序号为最大，以保证其总会排在最后
		this.clientActivityDao.createActivity(po);//添加活动
		this.clientActivityDao.findActivity(po.getActivityId()).getId();
		//保存文件
		saveImage(po);
	}

	public void updateActivityStatus(ModelMap modelMap,String activityId) throws Exception{
		ClientActivityPO po = clientActivityDao.findActivity(activityId);
		po.setActivityImage(po.getActivityImage()==null?"":po.getActivityImage());
		po.setActivityRemark(po.getActivityRemark()==null?"":po.getActivityRemark());
		if( po != null ){
			String status = po.getActivityStatus();
			if(status.equals("01")){
				po.setActivityStatus("02");
			}else if(status.equals("02")){
				po.setActivityStatus("01");
			}
			clientActivityDao.updateActivity(po);
		}
	}
	
	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void updateActivity(ClientActivityPO po) throws Exception {
		try{
			if( po != null )
				 clientActivityDao.updateActivity(po);
			//保存图片
			saveImage(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("update error!");
		}	
	}

	//自动排序
	private void autoOrder(){
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startIndex", 0);
		map.put("pageSize", Integer.MAX_VALUE);
		//先按正常、暂停、过期排序；再按序号排序
		//然后重新设置序号
		List<ClientActivityPO> list = this.clientActivityDao.findAllActivityForPage(map);
		int i=1;
		for(ClientActivityPO po:list){
			if(po.getActivityOrder()!=i){
				po.setActivityOrder(i);
				Map<String, Object> cond = new HashMap<String, Object>();
				cond.put("activityId", po.getActivityId());
				cond.put("activityOrder", po.getActivityOrder());
				this.clientActivityDao.updateActivityOrder(cond);
			}
			i++;
		}
	}
	
	@Override
	//手工排序 只对正常的排序
	public void updateActivityOrder(Map<String, Object> cond) {
		this.clientActivityDao.updateActivityOrder(cond);
		
	}

	private void saveImage(ClientActivityPO po){
		//保存文件
		String activityId = po.getActivityId();
		String tempActivityImage = po.getTempActivityImage();
		if (!StringUtil.isEmpty(activityId)&&!StringUtil.isEmpty(tempActivityImage)&&tempActivityImage.indexOf(".")!=-1) {
			String imagePath = cn.itkt.btsf.util.PropertyUtil.getProProperty().getString("activityImagePath");
			String fileName = po.getTempActivityImage();
			File file = new File(imagePath + File.separator + fileName);
			String activityImage = activityId+tempActivityImage.substring(tempActivityImage.lastIndexOf("."), tempActivityImage.length());
			file.renameTo(new File(imagePath + File.separator + activityImage));
		}
	}
	
	@Override
	public List<ClientActivityVO> poListToVoList(List<ClientActivityPO> poList) {
		List<ClientActivityVO> voList = new ArrayList<ClientActivityVO>();
		for (ClientActivityPO po : poList) {
			voList.add(this.poToVo(po));
		}
		return voList;
	}

	@Override
	public ClientActivityVO poToVo(ClientActivityPO po) {
		ClientActivityVO vo = new ClientActivityVO();
		try {
			PropertyUtils.copyProperties(vo, po);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return vo;
	}

	@Override
	public ClientActivityPO voToPo(ClientActivityVO vo) {
		ClientActivityPO po = new ClientActivityPO();
		try {
			PropertyUtils.copyProperties(po, vo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return po;
	}

}