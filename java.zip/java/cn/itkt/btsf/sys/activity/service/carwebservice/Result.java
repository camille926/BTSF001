
package cn.itkt.btsf.sys.activity.service.carwebservice;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Result complex type�� Java �ࡣ
 * 
 * <p>����ģʽƬ��ָ�������ڴ����е�Ԥ�����ݡ�
 * 
 * <pre>
 * &lt;complexType name="Result">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="resultCode" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="listActivities" type="{http://web.controller.car.itkt.cn/}activityPO" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="listMaps" type="{http://web.controller.car.itkt.cn/}MapConvertor" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="pageTotalCount" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Result", propOrder = {
    "resultCode",
    "listActivities",
    "listMaps",
    "pageTotalCount"
})
public class Result {

    protected int resultCode;
    @XmlElement(nillable = true)
    protected List<ActivityPO> listActivities;
    @XmlElement(nillable = true)
    protected List<MapConvertor> listMaps;
    protected int pageTotalCount;

    /**
     * ��ȡresultCode���Ե�ֵ��
     * 
     */
    public int getResultCode() {
        return resultCode;
    }

    /**
     * ����resultCode���Ե�ֵ��
     * 
     */
    public void setResultCode(int value) {
        this.resultCode = value;
    }

    /**
     * Gets the value of the listActivities property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the listActivities property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getListActivities().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActivityPO }
     * 
     * 
     */
    public List<ActivityPO> getListActivities() {
        if (listActivities == null) {
            listActivities = new ArrayList<ActivityPO>();
        }
        return this.listActivities;
    }

    /**
     * Gets the value of the listMaps property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the listMaps property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getListMaps().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MapConvertor }
     * 
     * 
     */
    public List<MapConvertor> getListMaps() {
        if (listMaps == null) {
            listMaps = new ArrayList<MapConvertor>();
        }
        return this.listMaps;
    }

    /**
     * ��ȡpageTotalCount���Ե�ֵ��
     * 
     */
    public int getPageTotalCount() {
        return pageTotalCount;
    }

    /**
     * ����pageTotalCount���Ե�ֵ��
     * 
     */
    public void setPageTotalCount(int value) {
        this.pageTotalCount = value;
    }

}
