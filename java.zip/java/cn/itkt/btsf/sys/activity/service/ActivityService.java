package cn.itkt.btsf.sys.activity.service;

import java.util.List;
import java.util.Map;

import org.springframework.ui.ModelMap;

import cn.itkt.btsf.sys.activity.po.ActivityPO;
import cn.itkt.btsf.sys.activity.vo.ActivityVO;

public interface ActivityService {
	
	/**
	 * 查找所有 --分页
	 * @return List<PhoneActivityPO> 
	 */
	public List<ActivityPO> findAllActivityForPage(Map<String,Object> map)throws Exception;
	/**
	 * 取站内所有数据行
	 * @param po 
	 */
	public int countFindAllActivityForPage(Map<String,Object> map)throws Exception;
	/**
	 * 获取所有的活动类型
	 * @return
	 */
	public List<Map<String,Object>> getAllActivityTypes()throws Exception;
	
	/**
	 * 获取所有的所属条件信息
	 * @return
	 */
	public List<Map<String,Object>> getActivityConditions(long activityType)throws Exception;
	/**
	 * 获取该活动所选条件信息
	 * @return
	 */
	public List<Map<String,Object>> getActivityConditionValues(long activityId)throws Exception;
	
	/**
	 * 创建 
	 * @param po
	 */
	public void createActivity(ActivityPO po,List<Map<String,Object>> ways,List<Map<String,Object>> conds) throws Exception;

	/**
	 * 删除 
	 * @param id 
	 */
	public void deleteActivity(String activityType,String activityId)throws Exception;
	
	
	/**
	 * 查找单个 
	 * @param activityId
	 * @return
	 */
	public ActivityPO findActivity(String activityId)throws Exception;

	/**
	 * 修改 活动状态
	 * @param po 
	 */
	public void updateActivityStatus(ModelMap modelMap,String activityId) throws Exception;
	/**
	 * 修改 
	 * @param po 
	 */
	public void updateActivity(ActivityPO po,List<Map<String,Object>> ways,List<Map<String,Object>> conds) throws Exception;
	/**
	 * po与vo转换
	 * @param po
	 * @return vo
	 */
	ActivityVO poToVo(ActivityPO po);
	
	/**
	 * vo与po转换
	 * @param po
	 * @return vo
	 */
	ActivityPO voToPo(ActivityVO vo);
	
	
	/**
	 * po列表与vo列表转换
	 * @param poList
	 * @return voList
	 */
	List<ActivityVO> poListToVoList(List<ActivityPO> poList);
	
	/**
	 * 查询活动方式
	 * @param poList
	 * @return voList
	 */
	List<Map<String,Object>> getActivityWay(long activityId);

}