package cn.itkt.btsf.sys.activity.service;

import java.util.List;
import java.util.Map;

import cn.itkt.pagination.Pages;

public interface ActivityConditionService {
	/**
	 * 查询所有舱位
	 * @return
	 */
	public List<Map<String, Object>> findAllShippingSpaceList(Map<String,Object> reqs);

	public Pages<Map<String, Object>> queryAirLine(Map<String, Object> reqs);

	public List<Map<String, Object>> queryAllCity(Map<String, Object> reqs);
	
	public Pages<Map<String, Object>> queryCity(Map<String, Object> reqs);
	public Pages<Map<String, Object>> queryProvince(Map<String, Object> reqs);
	/**
	 * 查询会员归属渠道
	 * @param reqs
	 * @return
	 */
	public Pages<Map<String, Object>> queryUserChannels(Map<String, Object> reqs);
	/**
	 * 查询会员归属渠道
	 * @param reqs
	 * @return
	 */
	public Pages<Map<String, Object>> queryRecommendPhone(Map<String, Object> reqs);
	
	/**
	 * 查询航空公司
	 * @param reqs
	 * @return
	 */
	public Pages<Map<String, Object>> queryAirCompany(Map<String, Object> reqs);
}