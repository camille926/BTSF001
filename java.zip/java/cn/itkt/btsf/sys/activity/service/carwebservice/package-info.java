@javax.xml.bind.annotation.XmlSchema(namespace = "http://web.controller.car.itkt.cn/")
package cn.itkt.btsf.sys.activity.service.carwebservice;
