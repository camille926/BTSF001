
package cn.itkt.btsf.sys.activity.service.carwebservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the cn.itkt.btsf.sys.activity.service.carwebservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DeleteActivityCondsResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "deleteActivityCondsResponse");
    private final static QName _GetPreferenceActivityResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getPreferenceActivityResponse");
    private final static QName _OrderListQuery_QNAME = new QName("http://web.controller.car.itkt.cn/", "orderListQuery");
    private final static QName _FindAllActivityForPageResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "findAllActivityForPageResponse");
    private final static QName _SynOrderInfoResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "synOrderInfoResponse");
    private final static QName _SaveOrderChangeResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveOrderChangeResponse");
    private final static QName _SaveContact_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveContact");
    private final static QName _UpdateActivityResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateActivityResponse");
    private final static QName _UpdateContactResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateContactResponse");
    private final static QName _SaveActivityCondsResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveActivityCondsResponse");
    private final static QName _CitySpaceFeeResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "citySpaceFeeResponse");
    private final static QName _CheckUserInfo_QNAME = new QName("http://web.controller.car.itkt.cn/", "checkUserInfo");
    private final static QName _DeleteActivityResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "deleteActivityResponse");
    private final static QName _GetModeLeveListResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getModeLeveListResponse");
    private final static QName _SaveActivityConds_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveActivityConds");
    private final static QName _UpdateOrderInfo_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateOrderInfo");
    private final static QName _SaveActivityWayResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveActivityWayResponse");
    private final static QName _AddSelfDriveOrder_QNAME = new QName("http://web.controller.car.itkt.cn/", "addSelfDriveOrder");
    private final static QName _AddSelfDriveOrderResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "addSelfDriveOrderResponse");
    private final static QName _GetActivityWay_QNAME = new QName("http://web.controller.car.itkt.cn/", "getActivityWay");
    private final static QName _UpdateOrderInfoCommonsResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateOrderInfoCommonsResponse");
    private final static QName _CancelSelfDriveOrder_QNAME = new QName("http://web.controller.car.itkt.cn/", "cancelSelfDriveOrder");
    private final static QName _DeleteActivityWay_QNAME = new QName("http://web.controller.car.itkt.cn/", "deleteActivityWay");
    private final static QName _CalcCarOrderPriceResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "calcCarOrderPriceResponse");
    private final static QName _GetPriceIntervalList_QNAME = new QName("http://web.controller.car.itkt.cn/", "getPriceIntervalList");
    private final static QName _SynOrderInfo_QNAME = new QName("http://web.controller.car.itkt.cn/", "synOrderInfo");
    private final static QName _CheckUserInfoResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "checkUserInfoResponse");
    private final static QName _GetCityInfoResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getCityInfoResponse");
    private final static QName _DeleteActivityWayResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "deleteActivityWayResponse");
    private final static QName _FindActivityResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "findActivityResponse");
    private final static QName _UpdateOrderChangeResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateOrderChangeResponse");
    private final static QName _QueryOrderListResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryOrderListResponse");
    private final static QName _GetAdditionalServices_QNAME = new QName("http://web.controller.car.itkt.cn/", "getAdditionalServices");
    private final static QName _QueryServiceExtResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryServiceExtResponse");
    private final static QName _GetDistrict_QNAME = new QName("http://web.controller.car.itkt.cn/", "getDistrict");
    private final static QName _GetBrandListResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getBrandListResponse");
    private final static QName _QueryCoinByUserNoResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryCoinByUserNoResponse");
    private final static QName _UpdateServiceExtResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateServiceExtResponse");
    private final static QName _FindAllActivityForPage_QNAME = new QName("http://web.controller.car.itkt.cn/", "findAllActivityForPage");
    private final static QName _DeleteOrderChange_QNAME = new QName("http://web.controller.car.itkt.cn/", "deleteOrderChange");
    private final static QName _QueryOrderList_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryOrderList");
    private final static QName _QueryAllContactsByIdResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryAllContactsByIdResponse");
    private final static QName _GetActivityConditionValues_QNAME = new QName("http://web.controller.car.itkt.cn/", "getActivityConditionValues");
    private final static QName _CancelSelfDriveOrderResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "cancelSelfDriveOrderResponse");
    private final static QName _UpdateActivity_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateActivity");
    private final static QName _QueryStoreByCityCodeResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryStoreByCityCodeResponse");
    private final static QName _UpdateOrderInfoResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateOrderInfoResponse");
    private final static QName _QueryOrderChang_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryOrderChang");
    private final static QName _GetActivityConditionValuesResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getActivityConditionValuesResponse");
    private final static QName _UpdateOrderChange_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateOrderChange");
    private final static QName _QueryAllContactsById_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryAllContactsById");
    private final static QName _GetStoreByDistrictCodeResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getStoreByDistrictCodeResponse");
    private final static QName _QueryOrderInfoByOrderNoResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryOrderInfoByOrderNoResponse");
    private final static QName _QueryCarDataVersionResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryCarDataVersionResponse");
    private final static QName _GetSelfDriveCarTypes_QNAME = new QName("http://web.controller.car.itkt.cn/", "getSelfDriveCarTypes");
    private final static QName _RecommendCarResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "recommendCarResponse");
    private final static QName _GetModeLeveList_QNAME = new QName("http://web.controller.car.itkt.cn/", "getModeLeveList");
    private final static QName _CalcCarOrderPrice_QNAME = new QName("http://web.controller.car.itkt.cn/", "calcCarOrderPrice");
    private final static QName _GetDistrictResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getDistrictResponse");
    private final static QName _DeleteActivityConds_QNAME = new QName("http://web.controller.car.itkt.cn/", "deleteActivityConds");
    private final static QName _OrderListQueryResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "orderListQueryResponse");
    private final static QName _QueryServiceExt_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryServiceExt");
    private final static QName _GetPriceIntervalListResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getPriceIntervalListResponse");
    private final static QName _FindActivity_QNAME = new QName("http://web.controller.car.itkt.cn/", "findActivity");
    private final static QName _SaveContactResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveContactResponse");
    private final static QName _DeleteActivity_QNAME = new QName("http://web.controller.car.itkt.cn/", "deleteActivity");
    private final static QName _QueryCoinByUserNo_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryCoinByUserNo");
    private final static QName _GetBrandList_QNAME = new QName("http://web.controller.car.itkt.cn/", "getBrandList");
    private final static QName _UpdateContact_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateContact");
    private final static QName _GetSelfDriveCarTypesResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getSelfDriveCarTypesResponse");
    private final static QName _GetCityInfo_QNAME = new QName("http://web.controller.car.itkt.cn/", "getCityInfo");
    private final static QName _SaveActivity_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveActivity");
    private final static QName _SaveActivityResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveActivityResponse");
    private final static QName _GetActivityWayResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getActivityWayResponse");
    private final static QName _QueryStoreByCityCode_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryStoreByCityCode");
    private final static QName _UpdateServiceExt_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateServiceExt");
    private final static QName _DeleteOrderChangeResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "deleteOrderChangeResponse");
    private final static QName _GetPreferenceActivity_QNAME = new QName("http://web.controller.car.itkt.cn/", "getPreferenceActivity");
    private final static QName _RecommendCar_QNAME = new QName("http://web.controller.car.itkt.cn/", "recommendCar");
    private final static QName _CitySpaceFee_QNAME = new QName("http://web.controller.car.itkt.cn/", "citySpaceFee");
    private final static QName _QueryCarDataVersion_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryCarDataVersion");
    private final static QName _SaveActivityWay_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveActivityWay");
    private final static QName _UpdateOrderInfoCommons_QNAME = new QName("http://web.controller.car.itkt.cn/", "updateOrderInfoCommons");
    private final static QName _GetAdditionalServicesResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "getAdditionalServicesResponse");
    private final static QName _SaveOrderChange_QNAME = new QName("http://web.controller.car.itkt.cn/", "saveOrderChange");
    private final static QName _QueryOrderChangResponse_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryOrderChangResponse");
    private final static QName _QueryOrderInfoByOrderNo_QNAME = new QName("http://web.controller.car.itkt.cn/", "queryOrderInfoByOrderNo");
    private final static QName _GetStoreByDistrictCode_QNAME = new QName("http://web.controller.car.itkt.cn/", "getStoreByDistrictCode");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: cn.itkt.btsf.sys.activity.service.carwebservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link StringArray }
     * 
     */
    public StringArray createStringArray() {
        return new StringArray();
    }

    /**
     * Create an instance of {@link GetAdditionalServicesResponse }
     * 
     */
    public GetAdditionalServicesResponse createGetAdditionalServicesResponse() {
        return new GetAdditionalServicesResponse();
    }

    /**
     * Create an instance of {@link SaveOrderChange }
     * 
     */
    public SaveOrderChange createSaveOrderChange() {
        return new SaveOrderChange();
    }

    /**
     * Create an instance of {@link QueryOrderChangResponse }
     * 
     */
    public QueryOrderChangResponse createQueryOrderChangResponse() {
        return new QueryOrderChangResponse();
    }

    /**
     * Create an instance of {@link QueryOrderInfoByOrderNo }
     * 
     */
    public QueryOrderInfoByOrderNo createQueryOrderInfoByOrderNo() {
        return new QueryOrderInfoByOrderNo();
    }

    /**
     * Create an instance of {@link GetStoreByDistrictCode }
     * 
     */
    public GetStoreByDistrictCode createGetStoreByDistrictCode() {
        return new GetStoreByDistrictCode();
    }

    /**
     * Create an instance of {@link UpdateServiceExt }
     * 
     */
    public UpdateServiceExt createUpdateServiceExt() {
        return new UpdateServiceExt();
    }

    /**
     * Create an instance of {@link DeleteOrderChangeResponse }
     * 
     */
    public DeleteOrderChangeResponse createDeleteOrderChangeResponse() {
        return new DeleteOrderChangeResponse();
    }

    /**
     * Create an instance of {@link GetPreferenceActivity }
     * 
     */
    public GetPreferenceActivity createGetPreferenceActivity() {
        return new GetPreferenceActivity();
    }

    /**
     * Create an instance of {@link RecommendCar }
     * 
     */
    public RecommendCar createRecommendCar() {
        return new RecommendCar();
    }

    /**
     * Create an instance of {@link CitySpaceFee }
     * 
     */
    public CitySpaceFee createCitySpaceFee() {
        return new CitySpaceFee();
    }

    /**
     * Create an instance of {@link QueryCarDataVersion }
     * 
     */
    public QueryCarDataVersion createQueryCarDataVersion() {
        return new QueryCarDataVersion();
    }

    /**
     * Create an instance of {@link SaveActivityWay }
     * 
     */
    public SaveActivityWay createSaveActivityWay() {
        return new SaveActivityWay();
    }

    /**
     * Create an instance of {@link UpdateOrderInfoCommons }
     * 
     */
    public UpdateOrderInfoCommons createUpdateOrderInfoCommons() {
        return new UpdateOrderInfoCommons();
    }

    /**
     * Create an instance of {@link QueryCoinByUserNo }
     * 
     */
    public QueryCoinByUserNo createQueryCoinByUserNo() {
        return new QueryCoinByUserNo();
    }

    /**
     * Create an instance of {@link GetBrandList }
     * 
     */
    public GetBrandList createGetBrandList() {
        return new GetBrandList();
    }

    /**
     * Create an instance of {@link UpdateContact }
     * 
     */
    public UpdateContact createUpdateContact() {
        return new UpdateContact();
    }

    /**
     * Create an instance of {@link SaveActivity }
     * 
     */
    public SaveActivity createSaveActivity() {
        return new SaveActivity();
    }

    /**
     * Create an instance of {@link GetCityInfo }
     * 
     */
    public GetCityInfo createGetCityInfo() {
        return new GetCityInfo();
    }

    /**
     * Create an instance of {@link GetSelfDriveCarTypesResponse }
     * 
     */
    public GetSelfDriveCarTypesResponse createGetSelfDriveCarTypesResponse() {
        return new GetSelfDriveCarTypesResponse();
    }

    /**
     * Create an instance of {@link SaveActivityResponse }
     * 
     */
    public SaveActivityResponse createSaveActivityResponse() {
        return new SaveActivityResponse();
    }

    /**
     * Create an instance of {@link QueryStoreByCityCode }
     * 
     */
    public QueryStoreByCityCode createQueryStoreByCityCode() {
        return new QueryStoreByCityCode();
    }

    /**
     * Create an instance of {@link GetActivityWayResponse }
     * 
     */
    public GetActivityWayResponse createGetActivityWayResponse() {
        return new GetActivityWayResponse();
    }

    /**
     * Create an instance of {@link QueryServiceExt }
     * 
     */
    public QueryServiceExt createQueryServiceExt() {
        return new QueryServiceExt();
    }

    /**
     * Create an instance of {@link GetPriceIntervalListResponse }
     * 
     */
    public GetPriceIntervalListResponse createGetPriceIntervalListResponse() {
        return new GetPriceIntervalListResponse();
    }

    /**
     * Create an instance of {@link FindActivity }
     * 
     */
    public FindActivity createFindActivity() {
        return new FindActivity();
    }

    /**
     * Create an instance of {@link SaveContactResponse }
     * 
     */
    public SaveContactResponse createSaveContactResponse() {
        return new SaveContactResponse();
    }

    /**
     * Create an instance of {@link DeleteActivity }
     * 
     */
    public DeleteActivity createDeleteActivity() {
        return new DeleteActivity();
    }

    /**
     * Create an instance of {@link QueryOrderInfoByOrderNoResponse }
     * 
     */
    public QueryOrderInfoByOrderNoResponse createQueryOrderInfoByOrderNoResponse() {
        return new QueryOrderInfoByOrderNoResponse();
    }

    /**
     * Create an instance of {@link QueryCarDataVersionResponse }
     * 
     */
    public QueryCarDataVersionResponse createQueryCarDataVersionResponse() {
        return new QueryCarDataVersionResponse();
    }

    /**
     * Create an instance of {@link GetSelfDriveCarTypes }
     * 
     */
    public GetSelfDriveCarTypes createGetSelfDriveCarTypes() {
        return new GetSelfDriveCarTypes();
    }

    /**
     * Create an instance of {@link RecommendCarResponse }
     * 
     */
    public RecommendCarResponse createRecommendCarResponse() {
        return new RecommendCarResponse();
    }

    /**
     * Create an instance of {@link GetModeLeveList }
     * 
     */
    public GetModeLeveList createGetModeLeveList() {
        return new GetModeLeveList();
    }

    /**
     * Create an instance of {@link CalcCarOrderPrice }
     * 
     */
    public CalcCarOrderPrice createCalcCarOrderPrice() {
        return new CalcCarOrderPrice();
    }

    /**
     * Create an instance of {@link GetDistrictResponse }
     * 
     */
    public GetDistrictResponse createGetDistrictResponse() {
        return new GetDistrictResponse();
    }

    /**
     * Create an instance of {@link DeleteActivityConds }
     * 
     */
    public DeleteActivityConds createDeleteActivityConds() {
        return new DeleteActivityConds();
    }

    /**
     * Create an instance of {@link OrderListQueryResponse }
     * 
     */
    public OrderListQueryResponse createOrderListQueryResponse() {
        return new OrderListQueryResponse();
    }

    /**
     * Create an instance of {@link QueryOrderChang }
     * 
     */
    public QueryOrderChang createQueryOrderChang() {
        return new QueryOrderChang();
    }

    /**
     * Create an instance of {@link GetActivityConditionValuesResponse }
     * 
     */
    public GetActivityConditionValuesResponse createGetActivityConditionValuesResponse() {
        return new GetActivityConditionValuesResponse();
    }

    /**
     * Create an instance of {@link UpdateOrderChange }
     * 
     */
    public UpdateOrderChange createUpdateOrderChange() {
        return new UpdateOrderChange();
    }

    /**
     * Create an instance of {@link QueryAllContactsById }
     * 
     */
    public QueryAllContactsById createQueryAllContactsById() {
        return new QueryAllContactsById();
    }

    /**
     * Create an instance of {@link GetStoreByDistrictCodeResponse }
     * 
     */
    public GetStoreByDistrictCodeResponse createGetStoreByDistrictCodeResponse() {
        return new GetStoreByDistrictCodeResponse();
    }

    /**
     * Create an instance of {@link FindAllActivityForPage }
     * 
     */
    public FindAllActivityForPage createFindAllActivityForPage() {
        return new FindAllActivityForPage();
    }

    /**
     * Create an instance of {@link DeleteOrderChange }
     * 
     */
    public DeleteOrderChange createDeleteOrderChange() {
        return new DeleteOrderChange();
    }

    /**
     * Create an instance of {@link QueryOrderList }
     * 
     */
    public QueryOrderList createQueryOrderList() {
        return new QueryOrderList();
    }

    /**
     * Create an instance of {@link QueryAllContactsByIdResponse }
     * 
     */
    public QueryAllContactsByIdResponse createQueryAllContactsByIdResponse() {
        return new QueryAllContactsByIdResponse();
    }

    /**
     * Create an instance of {@link GetActivityConditionValues }
     * 
     */
    public GetActivityConditionValues createGetActivityConditionValues() {
        return new GetActivityConditionValues();
    }

    /**
     * Create an instance of {@link CancelSelfDriveOrderResponse }
     * 
     */
    public CancelSelfDriveOrderResponse createCancelSelfDriveOrderResponse() {
        return new CancelSelfDriveOrderResponse();
    }

    /**
     * Create an instance of {@link UpdateActivity }
     * 
     */
    public UpdateActivity createUpdateActivity() {
        return new UpdateActivity();
    }

    /**
     * Create an instance of {@link QueryStoreByCityCodeResponse }
     * 
     */
    public QueryStoreByCityCodeResponse createQueryStoreByCityCodeResponse() {
        return new QueryStoreByCityCodeResponse();
    }

    /**
     * Create an instance of {@link UpdateOrderInfoResponse }
     * 
     */
    public UpdateOrderInfoResponse createUpdateOrderInfoResponse() {
        return new UpdateOrderInfoResponse();
    }

    /**
     * Create an instance of {@link UpdateOrderChangeResponse }
     * 
     */
    public UpdateOrderChangeResponse createUpdateOrderChangeResponse() {
        return new UpdateOrderChangeResponse();
    }

    /**
     * Create an instance of {@link FindActivityResponse }
     * 
     */
    public FindActivityResponse createFindActivityResponse() {
        return new FindActivityResponse();
    }

    /**
     * Create an instance of {@link DeleteActivityWayResponse }
     * 
     */
    public DeleteActivityWayResponse createDeleteActivityWayResponse() {
        return new DeleteActivityWayResponse();
    }

    /**
     * Create an instance of {@link QueryOrderListResponse }
     * 
     */
    public QueryOrderListResponse createQueryOrderListResponse() {
        return new QueryOrderListResponse();
    }

    /**
     * Create an instance of {@link QueryServiceExtResponse }
     * 
     */
    public QueryServiceExtResponse createQueryServiceExtResponse() {
        return new QueryServiceExtResponse();
    }

    /**
     * Create an instance of {@link GetAdditionalServices }
     * 
     */
    public GetAdditionalServices createGetAdditionalServices() {
        return new GetAdditionalServices();
    }

    /**
     * Create an instance of {@link GetDistrict }
     * 
     */
    public GetDistrict createGetDistrict() {
        return new GetDistrict();
    }

    /**
     * Create an instance of {@link GetBrandListResponse }
     * 
     */
    public GetBrandListResponse createGetBrandListResponse() {
        return new GetBrandListResponse();
    }

    /**
     * Create an instance of {@link UpdateServiceExtResponse }
     * 
     */
    public UpdateServiceExtResponse createUpdateServiceExtResponse() {
        return new UpdateServiceExtResponse();
    }

    /**
     * Create an instance of {@link QueryCoinByUserNoResponse }
     * 
     */
    public QueryCoinByUserNoResponse createQueryCoinByUserNoResponse() {
        return new QueryCoinByUserNoResponse();
    }

    /**
     * Create an instance of {@link GetPriceIntervalList }
     * 
     */
    public GetPriceIntervalList createGetPriceIntervalList() {
        return new GetPriceIntervalList();
    }

    /**
     * Create an instance of {@link SynOrderInfo }
     * 
     */
    public SynOrderInfo createSynOrderInfo() {
        return new SynOrderInfo();
    }

    /**
     * Create an instance of {@link CheckUserInfoResponse }
     * 
     */
    public CheckUserInfoResponse createCheckUserInfoResponse() {
        return new CheckUserInfoResponse();
    }

    /**
     * Create an instance of {@link GetCityInfoResponse }
     * 
     */
    public GetCityInfoResponse createGetCityInfoResponse() {
        return new GetCityInfoResponse();
    }

    /**
     * Create an instance of {@link UpdateOrderInfoCommonsResponse }
     * 
     */
    public UpdateOrderInfoCommonsResponse createUpdateOrderInfoCommonsResponse() {
        return new UpdateOrderInfoCommonsResponse();
    }

    /**
     * Create an instance of {@link GetActivityWay }
     * 
     */
    public GetActivityWay createGetActivityWay() {
        return new GetActivityWay();
    }

    /**
     * Create an instance of {@link AddSelfDriveOrderResponse }
     * 
     */
    public AddSelfDriveOrderResponse createAddSelfDriveOrderResponse() {
        return new AddSelfDriveOrderResponse();
    }

    /**
     * Create an instance of {@link CancelSelfDriveOrder }
     * 
     */
    public CancelSelfDriveOrder createCancelSelfDriveOrder() {
        return new CancelSelfDriveOrder();
    }

    /**
     * Create an instance of {@link DeleteActivityWay }
     * 
     */
    public DeleteActivityWay createDeleteActivityWay() {
        return new DeleteActivityWay();
    }

    /**
     * Create an instance of {@link CalcCarOrderPriceResponse }
     * 
     */
    public CalcCarOrderPriceResponse createCalcCarOrderPriceResponse() {
        return new CalcCarOrderPriceResponse();
    }

    /**
     * Create an instance of {@link SaveActivityWayResponse }
     * 
     */
    public SaveActivityWayResponse createSaveActivityWayResponse() {
        return new SaveActivityWayResponse();
    }

    /**
     * Create an instance of {@link AddSelfDriveOrder }
     * 
     */
    public AddSelfDriveOrder createAddSelfDriveOrder() {
        return new AddSelfDriveOrder();
    }

    /**
     * Create an instance of {@link CitySpaceFeeResponse }
     * 
     */
    public CitySpaceFeeResponse createCitySpaceFeeResponse() {
        return new CitySpaceFeeResponse();
    }

    /**
     * Create an instance of {@link DeleteActivityResponse }
     * 
     */
    public DeleteActivityResponse createDeleteActivityResponse() {
        return new DeleteActivityResponse();
    }

    /**
     * Create an instance of {@link CheckUserInfo }
     * 
     */
    public CheckUserInfo createCheckUserInfo() {
        return new CheckUserInfo();
    }

    /**
     * Create an instance of {@link SaveActivityConds }
     * 
     */
    public SaveActivityConds createSaveActivityConds() {
        return new SaveActivityConds();
    }

    /**
     * Create an instance of {@link GetModeLeveListResponse }
     * 
     */
    public GetModeLeveListResponse createGetModeLeveListResponse() {
        return new GetModeLeveListResponse();
    }

    /**
     * Create an instance of {@link UpdateOrderInfo }
     * 
     */
    public UpdateOrderInfo createUpdateOrderInfo() {
        return new UpdateOrderInfo();
    }

    /**
     * Create an instance of {@link UpdateContactResponse }
     * 
     */
    public UpdateContactResponse createUpdateContactResponse() {
        return new UpdateContactResponse();
    }

    /**
     * Create an instance of {@link UpdateActivityResponse }
     * 
     */
    public UpdateActivityResponse createUpdateActivityResponse() {
        return new UpdateActivityResponse();
    }

    /**
     * Create an instance of {@link SaveActivityCondsResponse }
     * 
     */
    public SaveActivityCondsResponse createSaveActivityCondsResponse() {
        return new SaveActivityCondsResponse();
    }

    /**
     * Create an instance of {@link SaveContact }
     * 
     */
    public SaveContact createSaveContact() {
        return new SaveContact();
    }

    /**
     * Create an instance of {@link SaveOrderChangeResponse }
     * 
     */
    public SaveOrderChangeResponse createSaveOrderChangeResponse() {
        return new SaveOrderChangeResponse();
    }

    /**
     * Create an instance of {@link DeleteActivityCondsResponse }
     * 
     */
    public DeleteActivityCondsResponse createDeleteActivityCondsResponse() {
        return new DeleteActivityCondsResponse();
    }

    /**
     * Create an instance of {@link GetPreferenceActivityResponse }
     * 
     */
    public GetPreferenceActivityResponse createGetPreferenceActivityResponse() {
        return new GetPreferenceActivityResponse();
    }

    /**
     * Create an instance of {@link OrderListQuery }
     * 
     */
    public OrderListQuery createOrderListQuery() {
        return new OrderListQuery();
    }

    /**
     * Create an instance of {@link FindAllActivityForPageResponse }
     * 
     */
    public FindAllActivityForPageResponse createFindAllActivityForPageResponse() {
        return new FindAllActivityForPageResponse();
    }

    /**
     * Create an instance of {@link SynOrderInfoResponse }
     * 
     */
    public SynOrderInfoResponse createSynOrderInfoResponse() {
        return new SynOrderInfoResponse();
    }

    /**
     * Create an instance of {@link HashMap }
     * 
     */
    public HashMap createHashMap() {
        return new HashMap();
    }

    /**
     * Create an instance of {@link Result }
     * 
     */
    public Result createResult() {
        return new Result();
    }

    /**
     * Create an instance of {@link ActivityPO }
     * 
     */
    public ActivityPO createActivityPO() {
        return new ActivityPO();
    }

    /**
     * Create an instance of {@link MapEntry }
     * 
     */
    public MapEntry createMapEntry() {
        return new MapEntry();
    }

    /**
     * Create an instance of {@link MapConvertor }
     * 
     */
    public MapConvertor createMapConvertor() {
        return new MapConvertor();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteActivityCondsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "deleteActivityCondsResponse")
    public JAXBElement<DeleteActivityCondsResponse> createDeleteActivityCondsResponse(DeleteActivityCondsResponse value) {
        return new JAXBElement<DeleteActivityCondsResponse>(_DeleteActivityCondsResponse_QNAME, DeleteActivityCondsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPreferenceActivityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getPreferenceActivityResponse")
    public JAXBElement<GetPreferenceActivityResponse> createGetPreferenceActivityResponse(GetPreferenceActivityResponse value) {
        return new JAXBElement<GetPreferenceActivityResponse>(_GetPreferenceActivityResponse_QNAME, GetPreferenceActivityResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderListQuery }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "orderListQuery")
    public JAXBElement<OrderListQuery> createOrderListQuery(OrderListQuery value) {
        return new JAXBElement<OrderListQuery>(_OrderListQuery_QNAME, OrderListQuery.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindAllActivityForPageResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "findAllActivityForPageResponse")
    public JAXBElement<FindAllActivityForPageResponse> createFindAllActivityForPageResponse(FindAllActivityForPageResponse value) {
        return new JAXBElement<FindAllActivityForPageResponse>(_FindAllActivityForPageResponse_QNAME, FindAllActivityForPageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynOrderInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "synOrderInfoResponse")
    public JAXBElement<SynOrderInfoResponse> createSynOrderInfoResponse(SynOrderInfoResponse value) {
        return new JAXBElement<SynOrderInfoResponse>(_SynOrderInfoResponse_QNAME, SynOrderInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveOrderChangeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveOrderChangeResponse")
    public JAXBElement<SaveOrderChangeResponse> createSaveOrderChangeResponse(SaveOrderChangeResponse value) {
        return new JAXBElement<SaveOrderChangeResponse>(_SaveOrderChangeResponse_QNAME, SaveOrderChangeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveContact }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveContact")
    public JAXBElement<SaveContact> createSaveContact(SaveContact value) {
        return new JAXBElement<SaveContact>(_SaveContact_QNAME, SaveContact.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateActivityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateActivityResponse")
    public JAXBElement<UpdateActivityResponse> createUpdateActivityResponse(UpdateActivityResponse value) {
        return new JAXBElement<UpdateActivityResponse>(_UpdateActivityResponse_QNAME, UpdateActivityResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateContactResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateContactResponse")
    public JAXBElement<UpdateContactResponse> createUpdateContactResponse(UpdateContactResponse value) {
        return new JAXBElement<UpdateContactResponse>(_UpdateContactResponse_QNAME, UpdateContactResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveActivityCondsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveActivityCondsResponse")
    public JAXBElement<SaveActivityCondsResponse> createSaveActivityCondsResponse(SaveActivityCondsResponse value) {
        return new JAXBElement<SaveActivityCondsResponse>(_SaveActivityCondsResponse_QNAME, SaveActivityCondsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CitySpaceFeeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "citySpaceFeeResponse")
    public JAXBElement<CitySpaceFeeResponse> createCitySpaceFeeResponse(CitySpaceFeeResponse value) {
        return new JAXBElement<CitySpaceFeeResponse>(_CitySpaceFeeResponse_QNAME, CitySpaceFeeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CheckUserInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "checkUserInfo")
    public JAXBElement<CheckUserInfo> createCheckUserInfo(CheckUserInfo value) {
        return new JAXBElement<CheckUserInfo>(_CheckUserInfo_QNAME, CheckUserInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteActivityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "deleteActivityResponse")
    public JAXBElement<DeleteActivityResponse> createDeleteActivityResponse(DeleteActivityResponse value) {
        return new JAXBElement<DeleteActivityResponse>(_DeleteActivityResponse_QNAME, DeleteActivityResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetModeLeveListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getModeLeveListResponse")
    public JAXBElement<GetModeLeveListResponse> createGetModeLeveListResponse(GetModeLeveListResponse value) {
        return new JAXBElement<GetModeLeveListResponse>(_GetModeLeveListResponse_QNAME, GetModeLeveListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveActivityConds }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveActivityConds")
    public JAXBElement<SaveActivityConds> createSaveActivityConds(SaveActivityConds value) {
        return new JAXBElement<SaveActivityConds>(_SaveActivityConds_QNAME, SaveActivityConds.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateOrderInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateOrderInfo")
    public JAXBElement<UpdateOrderInfo> createUpdateOrderInfo(UpdateOrderInfo value) {
        return new JAXBElement<UpdateOrderInfo>(_UpdateOrderInfo_QNAME, UpdateOrderInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveActivityWayResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveActivityWayResponse")
    public JAXBElement<SaveActivityWayResponse> createSaveActivityWayResponse(SaveActivityWayResponse value) {
        return new JAXBElement<SaveActivityWayResponse>(_SaveActivityWayResponse_QNAME, SaveActivityWayResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddSelfDriveOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "addSelfDriveOrder")
    public JAXBElement<AddSelfDriveOrder> createAddSelfDriveOrder(AddSelfDriveOrder value) {
        return new JAXBElement<AddSelfDriveOrder>(_AddSelfDriveOrder_QNAME, AddSelfDriveOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddSelfDriveOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "addSelfDriveOrderResponse")
    public JAXBElement<AddSelfDriveOrderResponse> createAddSelfDriveOrderResponse(AddSelfDriveOrderResponse value) {
        return new JAXBElement<AddSelfDriveOrderResponse>(_AddSelfDriveOrderResponse_QNAME, AddSelfDriveOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetActivityWay }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getActivityWay")
    public JAXBElement<GetActivityWay> createGetActivityWay(GetActivityWay value) {
        return new JAXBElement<GetActivityWay>(_GetActivityWay_QNAME, GetActivityWay.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateOrderInfoCommonsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateOrderInfoCommonsResponse")
    public JAXBElement<UpdateOrderInfoCommonsResponse> createUpdateOrderInfoCommonsResponse(UpdateOrderInfoCommonsResponse value) {
        return new JAXBElement<UpdateOrderInfoCommonsResponse>(_UpdateOrderInfoCommonsResponse_QNAME, UpdateOrderInfoCommonsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancelSelfDriveOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "cancelSelfDriveOrder")
    public JAXBElement<CancelSelfDriveOrder> createCancelSelfDriveOrder(CancelSelfDriveOrder value) {
        return new JAXBElement<CancelSelfDriveOrder>(_CancelSelfDriveOrder_QNAME, CancelSelfDriveOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteActivityWay }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "deleteActivityWay")
    public JAXBElement<DeleteActivityWay> createDeleteActivityWay(DeleteActivityWay value) {
        return new JAXBElement<DeleteActivityWay>(_DeleteActivityWay_QNAME, DeleteActivityWay.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalcCarOrderPriceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "calcCarOrderPriceResponse")
    public JAXBElement<CalcCarOrderPriceResponse> createCalcCarOrderPriceResponse(CalcCarOrderPriceResponse value) {
        return new JAXBElement<CalcCarOrderPriceResponse>(_CalcCarOrderPriceResponse_QNAME, CalcCarOrderPriceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPriceIntervalList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getPriceIntervalList")
    public JAXBElement<GetPriceIntervalList> createGetPriceIntervalList(GetPriceIntervalList value) {
        return new JAXBElement<GetPriceIntervalList>(_GetPriceIntervalList_QNAME, GetPriceIntervalList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SynOrderInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "synOrderInfo")
    public JAXBElement<SynOrderInfo> createSynOrderInfo(SynOrderInfo value) {
        return new JAXBElement<SynOrderInfo>(_SynOrderInfo_QNAME, SynOrderInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CheckUserInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "checkUserInfoResponse")
    public JAXBElement<CheckUserInfoResponse> createCheckUserInfoResponse(CheckUserInfoResponse value) {
        return new JAXBElement<CheckUserInfoResponse>(_CheckUserInfoResponse_QNAME, CheckUserInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCityInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getCityInfoResponse")
    public JAXBElement<GetCityInfoResponse> createGetCityInfoResponse(GetCityInfoResponse value) {
        return new JAXBElement<GetCityInfoResponse>(_GetCityInfoResponse_QNAME, GetCityInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteActivityWayResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "deleteActivityWayResponse")
    public JAXBElement<DeleteActivityWayResponse> createDeleteActivityWayResponse(DeleteActivityWayResponse value) {
        return new JAXBElement<DeleteActivityWayResponse>(_DeleteActivityWayResponse_QNAME, DeleteActivityWayResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindActivityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "findActivityResponse")
    public JAXBElement<FindActivityResponse> createFindActivityResponse(FindActivityResponse value) {
        return new JAXBElement<FindActivityResponse>(_FindActivityResponse_QNAME, FindActivityResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateOrderChangeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateOrderChangeResponse")
    public JAXBElement<UpdateOrderChangeResponse> createUpdateOrderChangeResponse(UpdateOrderChangeResponse value) {
        return new JAXBElement<UpdateOrderChangeResponse>(_UpdateOrderChangeResponse_QNAME, UpdateOrderChangeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryOrderListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryOrderListResponse")
    public JAXBElement<QueryOrderListResponse> createQueryOrderListResponse(QueryOrderListResponse value) {
        return new JAXBElement<QueryOrderListResponse>(_QueryOrderListResponse_QNAME, QueryOrderListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAdditionalServices }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getAdditionalServices")
    public JAXBElement<GetAdditionalServices> createGetAdditionalServices(GetAdditionalServices value) {
        return new JAXBElement<GetAdditionalServices>(_GetAdditionalServices_QNAME, GetAdditionalServices.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryServiceExtResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryServiceExtResponse")
    public JAXBElement<QueryServiceExtResponse> createQueryServiceExtResponse(QueryServiceExtResponse value) {
        return new JAXBElement<QueryServiceExtResponse>(_QueryServiceExtResponse_QNAME, QueryServiceExtResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDistrict }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getDistrict")
    public JAXBElement<GetDistrict> createGetDistrict(GetDistrict value) {
        return new JAXBElement<GetDistrict>(_GetDistrict_QNAME, GetDistrict.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBrandListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getBrandListResponse")
    public JAXBElement<GetBrandListResponse> createGetBrandListResponse(GetBrandListResponse value) {
        return new JAXBElement<GetBrandListResponse>(_GetBrandListResponse_QNAME, GetBrandListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryCoinByUserNoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryCoinByUserNoResponse")
    public JAXBElement<QueryCoinByUserNoResponse> createQueryCoinByUserNoResponse(QueryCoinByUserNoResponse value) {
        return new JAXBElement<QueryCoinByUserNoResponse>(_QueryCoinByUserNoResponse_QNAME, QueryCoinByUserNoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateServiceExtResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateServiceExtResponse")
    public JAXBElement<UpdateServiceExtResponse> createUpdateServiceExtResponse(UpdateServiceExtResponse value) {
        return new JAXBElement<UpdateServiceExtResponse>(_UpdateServiceExtResponse_QNAME, UpdateServiceExtResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindAllActivityForPage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "findAllActivityForPage")
    public JAXBElement<FindAllActivityForPage> createFindAllActivityForPage(FindAllActivityForPage value) {
        return new JAXBElement<FindAllActivityForPage>(_FindAllActivityForPage_QNAME, FindAllActivityForPage.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteOrderChange }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "deleteOrderChange")
    public JAXBElement<DeleteOrderChange> createDeleteOrderChange(DeleteOrderChange value) {
        return new JAXBElement<DeleteOrderChange>(_DeleteOrderChange_QNAME, DeleteOrderChange.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryOrderList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryOrderList")
    public JAXBElement<QueryOrderList> createQueryOrderList(QueryOrderList value) {
        return new JAXBElement<QueryOrderList>(_QueryOrderList_QNAME, QueryOrderList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryAllContactsByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryAllContactsByIdResponse")
    public JAXBElement<QueryAllContactsByIdResponse> createQueryAllContactsByIdResponse(QueryAllContactsByIdResponse value) {
        return new JAXBElement<QueryAllContactsByIdResponse>(_QueryAllContactsByIdResponse_QNAME, QueryAllContactsByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetActivityConditionValues }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getActivityConditionValues")
    public JAXBElement<GetActivityConditionValues> createGetActivityConditionValues(GetActivityConditionValues value) {
        return new JAXBElement<GetActivityConditionValues>(_GetActivityConditionValues_QNAME, GetActivityConditionValues.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancelSelfDriveOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "cancelSelfDriveOrderResponse")
    public JAXBElement<CancelSelfDriveOrderResponse> createCancelSelfDriveOrderResponse(CancelSelfDriveOrderResponse value) {
        return new JAXBElement<CancelSelfDriveOrderResponse>(_CancelSelfDriveOrderResponse_QNAME, CancelSelfDriveOrderResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateActivity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateActivity")
    public JAXBElement<UpdateActivity> createUpdateActivity(UpdateActivity value) {
        return new JAXBElement<UpdateActivity>(_UpdateActivity_QNAME, UpdateActivity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryStoreByCityCodeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryStoreByCityCodeResponse")
    public JAXBElement<QueryStoreByCityCodeResponse> createQueryStoreByCityCodeResponse(QueryStoreByCityCodeResponse value) {
        return new JAXBElement<QueryStoreByCityCodeResponse>(_QueryStoreByCityCodeResponse_QNAME, QueryStoreByCityCodeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateOrderInfoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateOrderInfoResponse")
    public JAXBElement<UpdateOrderInfoResponse> createUpdateOrderInfoResponse(UpdateOrderInfoResponse value) {
        return new JAXBElement<UpdateOrderInfoResponse>(_UpdateOrderInfoResponse_QNAME, UpdateOrderInfoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryOrderChang }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryOrderChang")
    public JAXBElement<QueryOrderChang> createQueryOrderChang(QueryOrderChang value) {
        return new JAXBElement<QueryOrderChang>(_QueryOrderChang_QNAME, QueryOrderChang.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetActivityConditionValuesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getActivityConditionValuesResponse")
    public JAXBElement<GetActivityConditionValuesResponse> createGetActivityConditionValuesResponse(GetActivityConditionValuesResponse value) {
        return new JAXBElement<GetActivityConditionValuesResponse>(_GetActivityConditionValuesResponse_QNAME, GetActivityConditionValuesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateOrderChange }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateOrderChange")
    public JAXBElement<UpdateOrderChange> createUpdateOrderChange(UpdateOrderChange value) {
        return new JAXBElement<UpdateOrderChange>(_UpdateOrderChange_QNAME, UpdateOrderChange.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryAllContactsById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryAllContactsById")
    public JAXBElement<QueryAllContactsById> createQueryAllContactsById(QueryAllContactsById value) {
        return new JAXBElement<QueryAllContactsById>(_QueryAllContactsById_QNAME, QueryAllContactsById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStoreByDistrictCodeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getStoreByDistrictCodeResponse")
    public JAXBElement<GetStoreByDistrictCodeResponse> createGetStoreByDistrictCodeResponse(GetStoreByDistrictCodeResponse value) {
        return new JAXBElement<GetStoreByDistrictCodeResponse>(_GetStoreByDistrictCodeResponse_QNAME, GetStoreByDistrictCodeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryOrderInfoByOrderNoResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryOrderInfoByOrderNoResponse")
    public JAXBElement<QueryOrderInfoByOrderNoResponse> createQueryOrderInfoByOrderNoResponse(QueryOrderInfoByOrderNoResponse value) {
        return new JAXBElement<QueryOrderInfoByOrderNoResponse>(_QueryOrderInfoByOrderNoResponse_QNAME, QueryOrderInfoByOrderNoResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryCarDataVersionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryCarDataVersionResponse")
    public JAXBElement<QueryCarDataVersionResponse> createQueryCarDataVersionResponse(QueryCarDataVersionResponse value) {
        return new JAXBElement<QueryCarDataVersionResponse>(_QueryCarDataVersionResponse_QNAME, QueryCarDataVersionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSelfDriveCarTypes }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getSelfDriveCarTypes")
    public JAXBElement<GetSelfDriveCarTypes> createGetSelfDriveCarTypes(GetSelfDriveCarTypes value) {
        return new JAXBElement<GetSelfDriveCarTypes>(_GetSelfDriveCarTypes_QNAME, GetSelfDriveCarTypes.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecommendCarResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "recommendCarResponse")
    public JAXBElement<RecommendCarResponse> createRecommendCarResponse(RecommendCarResponse value) {
        return new JAXBElement<RecommendCarResponse>(_RecommendCarResponse_QNAME, RecommendCarResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetModeLeveList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getModeLeveList")
    public JAXBElement<GetModeLeveList> createGetModeLeveList(GetModeLeveList value) {
        return new JAXBElement<GetModeLeveList>(_GetModeLeveList_QNAME, GetModeLeveList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalcCarOrderPrice }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "calcCarOrderPrice")
    public JAXBElement<CalcCarOrderPrice> createCalcCarOrderPrice(CalcCarOrderPrice value) {
        return new JAXBElement<CalcCarOrderPrice>(_CalcCarOrderPrice_QNAME, CalcCarOrderPrice.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDistrictResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getDistrictResponse")
    public JAXBElement<GetDistrictResponse> createGetDistrictResponse(GetDistrictResponse value) {
        return new JAXBElement<GetDistrictResponse>(_GetDistrictResponse_QNAME, GetDistrictResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteActivityConds }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "deleteActivityConds")
    public JAXBElement<DeleteActivityConds> createDeleteActivityConds(DeleteActivityConds value) {
        return new JAXBElement<DeleteActivityConds>(_DeleteActivityConds_QNAME, DeleteActivityConds.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderListQueryResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "orderListQueryResponse")
    public JAXBElement<OrderListQueryResponse> createOrderListQueryResponse(OrderListQueryResponse value) {
        return new JAXBElement<OrderListQueryResponse>(_OrderListQueryResponse_QNAME, OrderListQueryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryServiceExt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryServiceExt")
    public JAXBElement<QueryServiceExt> createQueryServiceExt(QueryServiceExt value) {
        return new JAXBElement<QueryServiceExt>(_QueryServiceExt_QNAME, QueryServiceExt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPriceIntervalListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getPriceIntervalListResponse")
    public JAXBElement<GetPriceIntervalListResponse> createGetPriceIntervalListResponse(GetPriceIntervalListResponse value) {
        return new JAXBElement<GetPriceIntervalListResponse>(_GetPriceIntervalListResponse_QNAME, GetPriceIntervalListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FindActivity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "findActivity")
    public JAXBElement<FindActivity> createFindActivity(FindActivity value) {
        return new JAXBElement<FindActivity>(_FindActivity_QNAME, FindActivity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveContactResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveContactResponse")
    public JAXBElement<SaveContactResponse> createSaveContactResponse(SaveContactResponse value) {
        return new JAXBElement<SaveContactResponse>(_SaveContactResponse_QNAME, SaveContactResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteActivity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "deleteActivity")
    public JAXBElement<DeleteActivity> createDeleteActivity(DeleteActivity value) {
        return new JAXBElement<DeleteActivity>(_DeleteActivity_QNAME, DeleteActivity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryCoinByUserNo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryCoinByUserNo")
    public JAXBElement<QueryCoinByUserNo> createQueryCoinByUserNo(QueryCoinByUserNo value) {
        return new JAXBElement<QueryCoinByUserNo>(_QueryCoinByUserNo_QNAME, QueryCoinByUserNo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetBrandList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getBrandList")
    public JAXBElement<GetBrandList> createGetBrandList(GetBrandList value) {
        return new JAXBElement<GetBrandList>(_GetBrandList_QNAME, GetBrandList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateContact }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateContact")
    public JAXBElement<UpdateContact> createUpdateContact(UpdateContact value) {
        return new JAXBElement<UpdateContact>(_UpdateContact_QNAME, UpdateContact.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSelfDriveCarTypesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getSelfDriveCarTypesResponse")
    public JAXBElement<GetSelfDriveCarTypesResponse> createGetSelfDriveCarTypesResponse(GetSelfDriveCarTypesResponse value) {
        return new JAXBElement<GetSelfDriveCarTypesResponse>(_GetSelfDriveCarTypesResponse_QNAME, GetSelfDriveCarTypesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCityInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getCityInfo")
    public JAXBElement<GetCityInfo> createGetCityInfo(GetCityInfo value) {
        return new JAXBElement<GetCityInfo>(_GetCityInfo_QNAME, GetCityInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveActivity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveActivity")
    public JAXBElement<SaveActivity> createSaveActivity(SaveActivity value) {
        return new JAXBElement<SaveActivity>(_SaveActivity_QNAME, SaveActivity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveActivityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveActivityResponse")
    public JAXBElement<SaveActivityResponse> createSaveActivityResponse(SaveActivityResponse value) {
        return new JAXBElement<SaveActivityResponse>(_SaveActivityResponse_QNAME, SaveActivityResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetActivityWayResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getActivityWayResponse")
    public JAXBElement<GetActivityWayResponse> createGetActivityWayResponse(GetActivityWayResponse value) {
        return new JAXBElement<GetActivityWayResponse>(_GetActivityWayResponse_QNAME, GetActivityWayResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryStoreByCityCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryStoreByCityCode")
    public JAXBElement<QueryStoreByCityCode> createQueryStoreByCityCode(QueryStoreByCityCode value) {
        return new JAXBElement<QueryStoreByCityCode>(_QueryStoreByCityCode_QNAME, QueryStoreByCityCode.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateServiceExt }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateServiceExt")
    public JAXBElement<UpdateServiceExt> createUpdateServiceExt(UpdateServiceExt value) {
        return new JAXBElement<UpdateServiceExt>(_UpdateServiceExt_QNAME, UpdateServiceExt.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteOrderChangeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "deleteOrderChangeResponse")
    public JAXBElement<DeleteOrderChangeResponse> createDeleteOrderChangeResponse(DeleteOrderChangeResponse value) {
        return new JAXBElement<DeleteOrderChangeResponse>(_DeleteOrderChangeResponse_QNAME, DeleteOrderChangeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetPreferenceActivity }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getPreferenceActivity")
    public JAXBElement<GetPreferenceActivity> createGetPreferenceActivity(GetPreferenceActivity value) {
        return new JAXBElement<GetPreferenceActivity>(_GetPreferenceActivity_QNAME, GetPreferenceActivity.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RecommendCar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "recommendCar")
    public JAXBElement<RecommendCar> createRecommendCar(RecommendCar value) {
        return new JAXBElement<RecommendCar>(_RecommendCar_QNAME, RecommendCar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CitySpaceFee }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "citySpaceFee")
    public JAXBElement<CitySpaceFee> createCitySpaceFee(CitySpaceFee value) {
        return new JAXBElement<CitySpaceFee>(_CitySpaceFee_QNAME, CitySpaceFee.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryCarDataVersion }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryCarDataVersion")
    public JAXBElement<QueryCarDataVersion> createQueryCarDataVersion(QueryCarDataVersion value) {
        return new JAXBElement<QueryCarDataVersion>(_QueryCarDataVersion_QNAME, QueryCarDataVersion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveActivityWay }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveActivityWay")
    public JAXBElement<SaveActivityWay> createSaveActivityWay(SaveActivityWay value) {
        return new JAXBElement<SaveActivityWay>(_SaveActivityWay_QNAME, SaveActivityWay.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateOrderInfoCommons }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "updateOrderInfoCommons")
    public JAXBElement<UpdateOrderInfoCommons> createUpdateOrderInfoCommons(UpdateOrderInfoCommons value) {
        return new JAXBElement<UpdateOrderInfoCommons>(_UpdateOrderInfoCommons_QNAME, UpdateOrderInfoCommons.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAdditionalServicesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getAdditionalServicesResponse")
    public JAXBElement<GetAdditionalServicesResponse> createGetAdditionalServicesResponse(GetAdditionalServicesResponse value) {
        return new JAXBElement<GetAdditionalServicesResponse>(_GetAdditionalServicesResponse_QNAME, GetAdditionalServicesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SaveOrderChange }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "saveOrderChange")
    public JAXBElement<SaveOrderChange> createSaveOrderChange(SaveOrderChange value) {
        return new JAXBElement<SaveOrderChange>(_SaveOrderChange_QNAME, SaveOrderChange.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryOrderChangResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryOrderChangResponse")
    public JAXBElement<QueryOrderChangResponse> createQueryOrderChangResponse(QueryOrderChangResponse value) {
        return new JAXBElement<QueryOrderChangResponse>(_QueryOrderChangResponse_QNAME, QueryOrderChangResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link QueryOrderInfoByOrderNo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "queryOrderInfoByOrderNo")
    public JAXBElement<QueryOrderInfoByOrderNo> createQueryOrderInfoByOrderNo(QueryOrderInfoByOrderNo value) {
        return new JAXBElement<QueryOrderInfoByOrderNo>(_QueryOrderInfoByOrderNo_QNAME, QueryOrderInfoByOrderNo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStoreByDistrictCode }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://web.controller.car.itkt.cn/", name = "getStoreByDistrictCode")
    public JAXBElement<GetStoreByDistrictCode> createGetStoreByDistrictCode(GetStoreByDistrictCode value) {
        return new JAXBElement<GetStoreByDistrictCode>(_GetStoreByDistrictCode_QNAME, GetStoreByDistrictCode.class, null, value);
    }

}
