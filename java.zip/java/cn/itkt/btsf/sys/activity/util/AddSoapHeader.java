package cn.itkt.btsf.sys.activity.util;

import java.util.List;

import javax.xml.namespace.QName;

import org.apache.cxf.binding.soap.SoapHeader;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.headers.Header;
import org.apache.cxf.helpers.DOMUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class AddSoapHeader extends AbstractSoapInterceptor{
	private static String nameURI="http://tempuri.org/";
	public AddSoapHeader(){
		super(Phase.WRITE);
	}
	public void handleMessage(SoapMessage message) throws Fault {
		
		QName qname=new QName(nameURI, "CheckSoap");
		Document doc=DOMUtils.createDocument();
		Element spId=doc.createElement("Account");
		spId.setTextContent("lcdnet");
		Element spPass=doc.createElement("Password");
		spPass.setTextContent("lcdkj001");
		Element root=doc.createElementNS(nameURI, "CheckSoap");
		root.appendChild(spId);
		root.appendChild(spPass);
		SoapHeader head=new SoapHeader(qname,root);
		List<Header> headers=message.getHeaders();
		headers.add(head);
	}
	
	
}
