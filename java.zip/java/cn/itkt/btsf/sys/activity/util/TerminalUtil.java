package cn.itkt.btsf.sys.activity.util;

public class TerminalUtil {
	public static String getTerminalId() {
		String ICCID       = "internet;internet";
		String equString   = "internet";
		String md5Password = getMD5Message(ICCID + equString).toUpperCase();
		String terminalId  = ICCID + ":" + md5Password;
		
		return terminalId.trim();
	}
	
	public static String getMD5Message(String ms)
	{
		try { 
		     java.security.MessageDigest alg=java.security.MessageDigest.getInstance("MD5"); 
		     alg.update(ms.getBytes()); 
		     byte[] digesta=alg.digest(); 
		     return bytesToHexString(digesta);
		   } 
		   catch (java.security.NoSuchAlgorithmException ex) { 
		     return null;
		   } 
	}
	public static String bytesToHexString(byte[] in) {
		StringBuffer sb = new StringBuffer();
		String temp = null;
		for (int i = 0; i < in.length; i++) {
			sb.append(byteToHexString(in[i]));
		}
		return sb.toString();
	}
	
	public static String byteToHexString(byte b) {
		StringBuffer result = new StringBuffer(2);
		String temp = Integer.toHexString(b >= 0 ? b : (b + 256));
		if (temp.length() == 1) {
			result.append("0");
		}
		result.append(temp);
		return result.toString();
	}
}
