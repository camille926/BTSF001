package cn.itkt.btsf.sys.activity.util;

import java.util.List;

import javax.xml.namespace.QName;

import org.apache.cxf.binding.soap.SoapHeader;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.headers.Header;
import org.apache.cxf.helpers.DOMUtils;
import org.apache.cxf.helpers.XMLUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;



public class AuthHeader extends AbstractSoapInterceptor {

	public static final String xml_namespaceUR_att = "http://www.itkt.cn/";  
    public static final String xml_header_el = "Header";  
    public static final String xml_authentication_el = "authentication";  
    public static final String xml_systemID_el = "systemID";  
  
	public AuthHeader(){
		super(Phase.WRITE);
	}
	
	public void handleMessage(SoapMessage message) throws Fault {
        String sysId = TerminalUtil.getTerminalId();  
        QName qname = new QName("RequestSOAPHeader");//这个值暂时不清楚具体做什么用，可以随便写  
  
        Document doc = (Document) DOMUtils.createDocument();  
        Element root = doc.createElement(xml_header_el);  
        Element eSysId = doc.createElement(xml_systemID_el);  
        eSysId.setTextContent(sysId);  
        Element child = doc.createElementNS(xml_namespaceUR_att,  
                xml_authentication_el);  
        child.appendChild(eSysId);  
        root.appendChild(child);  
        XMLUtils.printDOM(root);// 只是打印xml内容到控制台,可删除  
        SoapHeader head = new SoapHeader(qname, root);  
        List<Header> headers = message.getHeaders();  
        headers.add(head);  
          
	}

}
