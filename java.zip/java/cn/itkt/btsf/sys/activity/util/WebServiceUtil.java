package cn.itkt.btsf.sys.activity.util;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.common.gzip.GZIPInInterceptor;
import org.apache.cxf.transport.common.gzip.GZIPOutInterceptor;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

import cn.itkt.btsf.sys.activity.service.carwebservice.WebCarController;
import cn.itkt.btsf.sys.common.constant.WebServiceConstant;

public class WebServiceUtil {
	private static WebCarController carWebService;
	private static String hotelBaseUrl;
	private static final int CXF_CLIENT_TIME_OUT = 6000;
	static {
		String carWSUrl = WebServiceConstant.getRentCarActPoint();
		carWebService = initCarWS(carWSUrl);
		
		hotelBaseUrl = WebServiceConstant.getHotelActPoint();
	}

	public static WebCarController instanceCarActWS() {
		return carWebService;
	}

	public static WebCarController initCarWS(String carWSUrl) {
		JaxWsProxyFactoryBean bean = new JaxWsProxyFactoryBean();
		LoggingInInterceptor in = new LoggingInInterceptor();
		in.setPrettyLogging(true);
		bean.getInInterceptors().add(in);
		LoggingOutInterceptor out = new LoggingOutInterceptor();
		out.setPrettyLogging(true);
		bean.getOutInterceptors().add(out);
		bean.getOutInterceptors().add(new AuthHeader());
		bean.getInInterceptors().add(new GZIPInInterceptor());
		bean.getOutInterceptors().add(new GZIPOutInterceptor());
		bean.setAddress(carWSUrl);
		bean.setServiceClass(WebCarController.class);
		WebCarController zuChe = (WebCarController) bean.create();
		Client proxy = ClientProxy.getClient(zuChe);

		Endpoint endpoint = proxy.getEndpoint();
		endpoint.getInInterceptors().add(new GZIPInInterceptor());
		endpoint.getOutInterceptors().add(new GZIPOutInterceptor());

		HTTPConduit conduit = (HTTPConduit) proxy.getConduit();
		HTTPClientPolicy policy = new HTTPClientPolicy();
		policy.setConnectionTimeout(CXF_CLIENT_TIME_OUT);
		policy.setReceiveTimeout(CXF_CLIENT_TIME_OUT);

		conduit.setClient(policy);
		return zuChe;
	}

	public static String getHotelBaseUrl() {
		return hotelBaseUrl;
	}

}
