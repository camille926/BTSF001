package cn.itkt.btsf.sys.activity.util;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import cn.itkt.btsf.sys.activity.service.carwebservice.MapConvertor;
import cn.itkt.btsf.sys.activity.service.carwebservice.MapEntry;

public class MapAdapter extends XmlAdapter<MapConvertor, Map<String,Object>> {

	@Override
	public MapConvertor marshal(Map<String, Object> v) throws Exception {
		// Convert a bound type to a value type.
		MapConvertor map=new MapConvertor();
		for(Map.Entry<String, Object> e:v.entrySet()){
			MapEntry e2 = new MapEntry();
			e2.setKey(e.getKey());
			e2.setValue(e.getValue());
			map.getEntries().add(e2);
		}
		return map;

	}

	@Override
	public Map<String, Object> unmarshal(MapConvertor v) throws Exception {
		// Convert a value type to a bound type.
		Map<String, Object> map = new HashMap<String, Object>();
		for (MapEntry e : v.getEntries()){
            map.put(e.getKey(), e.getValue());
        }
        return map;

	}
	
}
