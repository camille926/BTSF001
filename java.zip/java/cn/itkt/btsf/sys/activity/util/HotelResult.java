package cn.itkt.btsf.sys.activity.util;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.sys.activity.po.ActivityPO;

public class HotelResult implements Serializable {
	/**
		 * 
		 */
	private static final long serialVersionUID = -8751476903794773125L;
	private int resultCode;
	private List<ActivityPO> listActivities;
	private List<Map<String, Object>> listMaps;
	private int pageTotalCount;

	public int getResultCode() {
		return resultCode;
	}

	public void setResultCode(int resultCode) {
		this.resultCode = resultCode;
	}

	public List<ActivityPO> getListActivities() {
		return listActivities;
	}

	public void setListActivities(List<ActivityPO> listActivities) {
		this.listActivities = listActivities;
	}

	public int getPageTotalCount() {
		return pageTotalCount;
	}

	public void setPageTotalCount(int pageTotalCount) {
		this.pageTotalCount = pageTotalCount;
	}

	public List<Map<String, Object>> getListMaps() {
		return listMaps;
	}

	public void setListMaps(List<Map<String, Object>> listMaps) {
		this.listMaps = listMaps;
	}

}
