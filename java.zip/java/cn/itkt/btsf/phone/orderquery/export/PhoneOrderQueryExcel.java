package cn.itkt.btsf.phone.orderquery.export;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;

import cn.itkt.btsf.phone.orderquery.po.PhoneOrderQueryPO;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

/**
 * 促销活动导出excel
 * @author Administrator
 *
 */
public class PhoneOrderQueryExcel extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> arg0,
			HSSFWorkbook Workbook, HttpServletRequest arg2, HttpServletResponse arg3)
			throws Exception {
		String filename = "";
		
		HSSFSheet sheet = Workbook.createSheet("订单查询");
		sheet.setDefaultColumnWidth(20);
		setText(getCell(sheet,0,0),"订单号");
		setText(getCell(sheet,0,1),"航班号");
		setText(getCell(sheet,0,2),"会员电话");
		setText(getCell(sheet,0,3),"乘机人");
		setText(getCell(sheet,0,4),"起飞城市");
		
		setText(getCell(sheet,0,5),"目的城市");
		setText(getCell(sheet,0,6),"订单日期");
		setText(getCell(sheet,0,7),"乘机日期");
		setText(getCell(sheet,0,8),"支付状态");
		setText(getCell(sheet,0,9),"票面价");
		setText(getCell(sheet,0,10),"机票总额");
		setText(getCell(sheet,0,11),"订单总额");
		
		setText(getCell(sheet,0,12),"省份");
		setText(getCell(sheet,0,13),"地市");
		setText(getCell(sheet,0,14),"客票状态");
		setText(getCell(sheet,0,15),"渠道号");
		
		Pages page = (Pages)arg0.get("page");
		List list = page.getItems();
		for (int i =0;i<list.size();i++) {
			PhoneOrderQueryPO  phoneOrderQueryPO = (PhoneOrderQueryPO)list.get(i);
			setText(getCell(sheet,(i+1),0),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getOrderNo())));
			setText(getCell(sheet,(i+1),1),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getAirteamnum())));
			setText(getCell(sheet,(i+1),2),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getTelephone())));
			setText(getCell(sheet,(i+1),3),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getPassengerName())));
			setText(getCell(sheet,(i+1),4),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getTakeoffCity())));
			setText(getCell(sheet,(i+1),5),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getArriveCity())));
			setText(getCell(sheet,(i+1),6),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getOrderDate())));
			setText(getCell(sheet,(i+1),7),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getFlyDate())));
			
			String paystatus = phoneOrderQueryPO.getPayStatus()==null?"":phoneOrderQueryPO.getPayStatus();
			String pay = "";
			if(paystatus.equals("00") || paystatus =="00"){
				pay = "未支付";
			}else if(paystatus.equals("01") || paystatus =="01"){
				pay = "部分支付";
			}else if(paystatus.equals("02") || paystatus =="02"){
				pay = "支付成功";
			}else if(paystatus.equals("03") || paystatus =="03"){
				pay = "支付失败";
			}else if(paystatus.equals("04") || paystatus =="04"){
				pay = "支付中";
			}
			
			setText(getCell(sheet,(i+1),8),String.valueOf(pay));
			
			setText(getCell(sheet,(i+1),9),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getAmountFare())));
			setText(getCell(sheet,(i+1),10),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getTicketTotalAmount())));
			setText(getCell(sheet,(i+1),11),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getAmount())));
			setText(getCell(sheet,(i+1),12),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getProvince())));
			setText(getCell(sheet,(i+1),13),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getCity())));
			
			String ticketstatus = phoneOrderQueryPO.getTicketStatus()==null?"":phoneOrderQueryPO.getTicketStatus();
			String msg = "";
			if(ticketstatus.equals("02") || ticketstatus =="02"){
				msg = "已出票";
			}else if(ticketstatus.equals("03") || ticketstatus =="03"){
				msg = "航班变动中";
			}else if(ticketstatus.equals("04") || ticketstatus =="04"){
				msg = "自愿退票中";
			}else if(ticketstatus.equals("05") || ticketstatus =="05"){
				msg = "非自愿退票中";
			}else if(ticketstatus.equals("06") || ticketstatus =="06"){
				msg = "升舱退票中";
			}else if(ticketstatus.equals("07") || ticketstatus =="07"){
				msg = "退票完成";
			}else if(ticketstatus.equals("08") || ticketstatus =="08"){
				msg = "废票处理中";
			}else if(ticketstatus.equals("09") || ticketstatus =="09"){
				msg = "废票完成";
			}else if(ticketstatus.equals("10") || ticketstatus =="10"){
				msg = "退款完成";
			}else if(ticketstatus.equals("11") || ticketstatus =="11"){
				msg = "改期处理中";
			}else if(ticketstatus.equals("12") || ticketstatus =="12"){
				msg = "改期完成";
			}else if(ticketstatus.equals("14") || ticketstatus =="14"){
				msg = "升舱完成";
			}else if(ticketstatus.equals("15") || ticketstatus =="15"){
				msg = "废款完成";
			}else if(ticketstatus.equals("16") || ticketstatus =="16"){
				msg = "已核销";
			}else{
				
			}
			setText(getCell(sheet,(i+1),14),String.valueOf(SysUtil.ifNull(msg)));
			setText(getCell(sheet,(i+1),15),String.valueOf(SysUtil.ifNull(phoneOrderQueryPO.getChannel())));
		}
		//设置下载时客户端Excel的名称
	/*	if(arg0.get("startDate") == null && arg0.get("endDate") != null){
			filename = "促销活动 业务发展日起"+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";  
		}else if(arg0.get("endDate") == null && arg0.get("startDate") != null){
			filename = "促销活动"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-至今"+".xls"; 
		}else if(arg0.get("endDate") == null && arg0.get("startDate") == null){
			filename = "促销活动 业务发展日起-至今.xls";
		}else{
			filename = "促销活动"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";
		}*/
		filename = "订单查询"+".xls";;
		filename = this.encodeFilename(filename, arg2);//处理中文文件名   
		arg3.setContentType("application/vnd.ms-excel");      
		arg3.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = arg3.getOutputStream();      
		Workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close();      
	}
	/**   
	     * 设置下载文件中文件的名称   
	     *    
	     * @param filename   
	     * @param request   
	     * @return   
	     */     
	    public static String encodeFilename(String filename, HttpServletRequest request) {     
	      /**   
	       * 获取客户端浏览器和操作系统信息   
	      * 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)   
	       * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6   
	       */     
	      String agent = request.getHeader("USER-AGENT");     
	      try {     
	        if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {     
	          String newFileName = URLEncoder.encode(filename, "UTF-8");     
	          newFileName = newFileName.replace("+", "%20");     
	          if (newFileName.length() > 150) {     
	            newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");     
	            newFileName = newFileName.replace("+", "%20");     
	          }     
	          return newFileName;     
	        }     
	        if ((agent != null) && (-1 != agent.indexOf("Mozilla")))     
	          return MimeUtility.encodeText(filename, "UTF-8", "B");     
	       
	        return filename;     
	      } catch (Exception ex) {     
	        return filename;     
	      }     
	    }  
}
