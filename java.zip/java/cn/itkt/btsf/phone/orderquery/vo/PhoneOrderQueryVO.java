package cn.itkt.btsf.phone.orderquery.vo;

public class PhoneOrderQueryVO {
	
	private String orderStartTime;   //订单开始时间
	
	private String orderEndTime;     //订单结束时间
	
	private String payStatus;        //支付状态
	
	private String ticketStatus;     //客票状态
	
	private String orderStatus;      //订单状态
	
	private String flyStartTime;     //乘机开始时间
	
	private String flyEndTime;       //乘机结束时间

	public String getOrderStartTime() {
		return orderStartTime;
	}

	public void setOrderStartTime(String orderStartTime) {
		this.orderStartTime = orderStartTime;
	}

	public String getOrderEndTime() {
		return orderEndTime;
	}

	public void setOrderEndTime(String orderEndTime) {
		this.orderEndTime = orderEndTime;
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}

	public String getTicketStatus() {
		return ticketStatus;
	}

	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getFlyStartTime() {
		return flyStartTime;
	}

	public void setFlyStartTime(String flyStartTime) {
		this.flyStartTime = flyStartTime;
	}

	public String getFlyEndTime() {
		return flyEndTime;
	}

	public void setFlyEndTime(String flyEndTime) {
		this.flyEndTime = flyEndTime;
	}
	
}
