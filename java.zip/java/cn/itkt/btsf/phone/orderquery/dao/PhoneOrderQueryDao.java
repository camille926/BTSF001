package cn.itkt.btsf.phone.orderquery.dao;

import java.util.List;
import java.util.Map;

/**
 * 移动商旅订单查询dao
 * 新增的功能
 * @author liuxw
 * 2012年7月9日
 */
public interface PhoneOrderQueryDao {
	
	public List getOrderList(Map<String,Object> map);
	
	public int getOrderCount(Map<String,Object> map);
	
	//获取订单的状态
	public List getOrderStatus();
	
	//查询未支付的订单
	public List getOrderListNotPay(Map<String,Object> map);
	
	//查询未支付的订单
	public int getOrderCountNotPay(Map<String,Object> map);

}
