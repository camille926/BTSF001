package cn.itkt.btsf.phone.orderquery.po;

import java.io.UnsupportedEncodingException;

public class PhoneOrderQueryPO {
	
	private String id;
	
	private String orderStartTime;   //订单开始时间
	
	private String orderEndTime;     //订单结束时间
	
	private String payStatus;        //支付状态
	
	private String ticketStatus;     //客票状态
	
	private String orderStatus;      //订单状态
	
	private String flyStartTime;     //乘机开始时间
	
	private String flyEndTime;       //乘机结束时间
	
	//数据库返回的数据字段
	private String orderNo;          //订单号
	
	private String airteamnum;       //航班号
	
	private String telephone;        //会员电话
	
	private String passengerName;    //乘机人
	
	private String takeoffCity;      //起飞城市
	
	private String arriveCity;       //目的城市
	
	private String orderDate;        //订单日期
	
	private String flyDate;          //起飞日期
	
	private String amountFare;       //票面价   
	
	private String ticketTotalAmount; //机票总额
	
	private String amount;            //订单总额
	
	private String province;          //省份
	
	private String city;              //地市
	
	//private String ticketstate;       //票状态
	
	private String channel;           //渠道号
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrderStartTime() {
		return orderStartTime;
	}

	public void setOrderStartTime(String orderStartTime) {
		this.orderStartTime = orderStartTime;
	}

	public String getOrderEndTime() {
		return orderEndTime;
	}

	public void setOrderEndTime(String orderEndTime) {
		this.orderEndTime = orderEndTime;
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) throws UnsupportedEncodingException {
		this.payStatus = payStatus;
	}

	public String getTicketStatus() {
		return ticketStatus;
	}

	public void setTicketStatus(String ticketStatus) {
		this.ticketStatus = ticketStatus;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getFlyStartTime() {
		return flyStartTime;
	}

	public void setFlyStartTime(String flyStartTime) {
		this.flyStartTime = flyStartTime;
	}

	public String getFlyEndTime() {
		return flyEndTime;
	}

	public void setFlyEndTime(String flyEndTime) {
		this.flyEndTime = flyEndTime;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getAirteamnum() {
		return airteamnum;
	}

	public void setAirteamnum(String airteamnum) {
		this.airteamnum = airteamnum;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getTakeoffCity() {
		return takeoffCity;
	}

	public void setTakeoffCity(String takeoffCity) {
		this.takeoffCity = takeoffCity;
	}

	public String getArriveCity() {
		return arriveCity;
	}

	public void setArriveCity(String arriveCity) {
		this.arriveCity = arriveCity;
	}

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getFlyDate() {
		return flyDate;
	}

	public void setFlyDate(String flyDate) {
		this.flyDate = flyDate;
	}

	public String getAmountFare() {
		return amountFare;
	}

	public void setAmountFare(String amountFare) {
		this.amountFare = amountFare;
	}

	public String getTicketTotalAmount() {
		return ticketTotalAmount;
	}

	public void setTicketTotalAmount(String ticketTotalAmount) {
		this.ticketTotalAmount = ticketTotalAmount;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}
	
}
