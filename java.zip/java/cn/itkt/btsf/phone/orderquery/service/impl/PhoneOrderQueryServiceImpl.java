package cn.itkt.btsf.phone.orderquery.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.itkt.btsf.phone.orderquery.dao.PhoneOrderQueryDao;
import cn.itkt.btsf.phone.orderquery.service.PhoneOrderQueryService;

@Service
public class PhoneOrderQueryServiceImpl implements PhoneOrderQueryService {

	@Resource
	private PhoneOrderQueryDao phoneOrderQueryDao;
	
	
	@Override
	public int getOrderCount(Map<String, Object> map) {
		return phoneOrderQueryDao.getOrderCount(map);
	}

	@Override
	public List getOrderList(Map<String, Object> map) {
		return phoneOrderQueryDao.getOrderList(map);
	}

	@Override
	public List getOrderStatus() {
		return phoneOrderQueryDao.getOrderStatus();
	}

	//查询未支付的订单
	@Override
	public int getOrderCountNotPay(Map<String, Object> map) {
		return phoneOrderQueryDao.getOrderCountNotPay(map);
	}

	//查询未支付的订单
	@Override
	public List getOrderListNotPay(Map<String, Object> map) {
		return phoneOrderQueryDao.getOrderListNotPay(map);
	}

}
