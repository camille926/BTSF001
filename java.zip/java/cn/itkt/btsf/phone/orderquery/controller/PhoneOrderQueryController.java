package cn.itkt.btsf.phone.orderquery.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.itkt.btsf.phone.orderquery.vo.PhoneOrderQueryVO;

/**
 * 移动商旅订单查询controller
 * 新增的功能
 * @author liuxw
 * 2012年7月9日
 *
 */
@Controller
@RequestMapping("/phone/orderQuery")
public class PhoneOrderQueryController {
	
	 @Resource
	 private PhoneOrderQueryControllerSupport phoneOrderQueryControllerSupport;
	
	@RequestMapping("/list")
	public String list(@RequestParam(value="startIndex", required=false, defaultValue="0")int startIndex,
					   @ModelAttribute PhoneOrderQueryVO phoneOrderQueryVO,ModelMap modelMap){
		
		phoneOrderQueryControllerSupport.list(startIndex, phoneOrderQueryVO, modelMap);
		
		return "phone/orderquery/list";
	}
	
	/**
	 * 获取订单的状态值
	 * @return
	 */
	@RequestMapping("/getOrderStatus")
	public @ResponseBody List getOrderStatus(){
		List list = phoneOrderQueryControllerSupport.getOrderStatus(); 
		return list;
	}

	/**
	 * 导出订单查询报表
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value="/exportOrderQuery")
	public String exportOrderQuery(@RequestParam(value="startIndex", required=false, defaultValue="0")int startIndex,
			   @ModelAttribute PhoneOrderQueryVO phoneOrderQueryVO,ModelMap modelMap){
		phoneOrderQueryControllerSupport.exportOrderQuery(startIndex, phoneOrderQueryVO, modelMap);
		return "exportOrderQueryExcel";
	}
}
