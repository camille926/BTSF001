package cn.itkt.btsf.phone.orderquery.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import cn.itkt.btsf.phone.orderquery.po.PhoneOrderQueryPO;
import cn.itkt.btsf.phone.orderquery.service.PhoneOrderQueryService;
import cn.itkt.btsf.phone.orderquery.vo.PhoneOrderQueryVO;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

/**
 * 移动商旅订单查询support
 * 新增的功能
 * @author liuxw
 * 2012年7月9日
 */
@Service
public class PhoneOrderQueryControllerSupport {
	
	@Resource
	private PhoneOrderQueryService phoneOrderQueryService;
	
	@SuppressWarnings("unchecked")
	public void list(int startIndex,PhoneOrderQueryVO phoneOrderQueryVO,ModelMap modelMap){
		
		PhoneOrderQueryPO  phoneOrderQueryPO = new PhoneOrderQueryPO();
		SysUtil.cloneObject(phoneOrderQueryVO, phoneOrderQueryPO);
		
		Pages page = new Pages(startIndex);
		Map map = new HashMap();
		map.put("page", page);
		map.put("phoneOrderQueryPO", phoneOrderQueryPO);
		
		int resultcount = 0;
		List list = null;
		//先判断是否是查询未支付的订单
		String payStatus = phoneOrderQueryVO.getPayStatus();
		
		if(payStatus == "00" || "00".equals(payStatus)){  //00表示查询未支付的订单
			resultcount = phoneOrderQueryService.getOrderCountNotPay(map);
			list = phoneOrderQueryService.getOrderListNotPay(map);
		}else{
			resultcount = phoneOrderQueryService.getOrderCount(map);
			list = phoneOrderQueryService.getOrderList(map);
		}
		
		page.setItems(list);
		page.setTotalCount(resultcount);
		modelMap.addAttribute("page", page);
		modelMap.addAttribute("phoneOrderQueryPO", phoneOrderQueryPO);
		
	}
	
	public List getOrderStatus(){
		return phoneOrderQueryService.getOrderStatus();
	}
	
	@SuppressWarnings("unchecked")
	public void exportOrderQuery(int startIndex,PhoneOrderQueryVO phoneOrderQueryVO,ModelMap modelMap){
		PhoneOrderQueryPO  phoneOrderQueryPO = new PhoneOrderQueryPO();
		SysUtil.cloneObject(phoneOrderQueryVO, phoneOrderQueryPO);
		
		Pages page = new Pages(startIndex);
		page.setPageSize(999999999);
		Map map = new HashMap();
		map.put("page", page);
		map.put("phoneOrderQueryPO", phoneOrderQueryPO);
		
		//int resultcount = 0;
		List list = null;
		//先判断是否是查询未支付的订单
		String payStatus = phoneOrderQueryVO.getPayStatus();
		
		if(payStatus == "00" || "00".equals(payStatus)){  //00表示查询未支付的订单
			
			//System.out.println(payStatus);
			//resultcount = phoneOrderQueryService.getOrderCountNotPay(map);
			list = phoneOrderQueryService.getOrderListNotPay(map);
		}else{
			//resultcount = phoneOrderQueryService.getOrderCount(map);
			list = phoneOrderQueryService.getOrderList(map);
		}
		
		page.setItems(list);
		//page.setTotalCount(resultcount);
		modelMap.addAttribute("page", page);
		modelMap.addAttribute("phoneOrderQueryPO", phoneOrderQueryPO);//phoneOrderQueryControllerSupport.list(startIndex, phoneOrderQueryVO, modelMap);
	}

}
