package cn.itkt.btsf.phone.users.export;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.context.ApplicationContext;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import cn.itkt.btsf.phone.export.BissnessExcel;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.phone.users.vo.PhoneUsersMailVO;
import cn.itkt.btsf.sys.pay.vo.QryPayJournalVO;

/**
 * 会员信息以Excel形式导出
 * 
 * @author xuyh
 * @Date 2012-08-17 下午13:34:49
 * @version
 */
public class UsersPhoneExcelView extends AbstractExcelView{
	private int pageSize = 500; //设置每次取出多少行记录
	
	private PhoneUsersService phoneUsersService;

	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		if(phoneUsersService == null){
			ApplicationContext ctx = getApplicationContext();
			phoneUsersService = (PhoneUsersService)ctx.getBean("phoneUsersServiceImpl");
		}

		HSSFSheet sheet = workbook.createSheet();
		workbook.setSheetName(0, "会员信息");
		sheet.setDefaultColumnWidth(20);
		setTableHeader(sheet);
		

		int startIndex = 0;
		int rowNum = 0;
		int sheetNum = 1;

		Map<Object, Object> params = new HashMap<Object, Object>();
		params.put("pageSize", pageSize);
		params.put("startIndex", startIndex);
		PhoneUsersMailVO vo = (PhoneUsersMailVO)model.get("phoneUsersMailVO");
		if(vo.getUname() != null && !"".equals(vo.getUname())){
			params.put("activityname", vo.getUname()==null?"":vo.getUname().trim());
		}
		if(vo.getTelephone() != null && !"".equals(vo.getTelephone())){
			params.put("telephone", vo.getTelephone()==null?"":vo.getTelephone().trim());
		}
		if(vo.getRecommendPhone() != null && !"".equals(vo.getRecommendPhone())){
			params.put("recommendPhone",  vo.getRecommendPhone()==null?"":vo.getRecommendPhone().trim());
		}
		//PayHelper.buildQryPayJournalParamMap(params, qryPayVO);
		
		List<PhoneUsersMailVO> phoneUsersList = null;
		PhoneUsersMailVO phoneUsers = null;
		do {
			phoneUsersList = phoneUsersService.findPhoneUser(params);
			if(rowNum >= 10000){//当一个Sheet的数据行数超过10000时，创建一个新的sheet
				sheet = workbook.createSheet();
				workbook.setSheetName(sheetNum, "会员信息"+sheetNum);
				sheet.setDefaultColumnWidth(20);
				setTableHeader(sheet);
				rowNum = 0;
				sheetNum++;
			}
			if (phoneUsersList != null) {
				for (int i = 0, size = phoneUsersList.size(); i < size; i++) {
					phoneUsers = phoneUsersList.get(i);
					setText(getCell(sheet, (rowNum + i + 1), 0), String.valueOf(rowNum + i + 1));
					setText(getCell(sheet, (rowNum + i + 1), 1), phoneUsers.getTelephone());
					setText(getCell(sheet, (rowNum + i + 1), 2), phoneUsers.getRecommendPhone());
					setText(getCell(sheet, (rowNum + i + 1), 3), phoneUsers.getProvince());
					setText(getCell(sheet, (rowNum + i + 1), 4), phoneUsers.getCity());
					setText(getCell(sheet, (rowNum + i + 1), 5), phoneUsers.getChaneel());
					setText(getCell(sheet, (rowNum + i + 1), 6), phoneUsers.getVersion());
					setText(getCell(sheet, (rowNum + i + 1), 7), new SimpleDateFormat("yyyy-MM-dd").format(phoneUsers.getAdddate()));
					setText(getCell(sheet, (rowNum + i + 1), 8), getSourceType(phoneUsers.getSource()));
					setText(getCell(sheet, (rowNum + i + 1), 9), phoneUsers.getLcdcoin());
					setText(getCell(sheet, (rowNum + i + 1), 10), phoneUsers.getReceiptscoin());
					setText(getCell(sheet, (rowNum + i + 1), 11), phoneUsers.getAmount());
				}
				startIndex +=  phoneUsersList.size(); 
				rowNum +=  phoneUsersList.size(); 
				params.put("startIndex", startIndex);
			}
		} while (phoneUsersList != null && phoneUsersList.size() > 0);
		
		
		String filename = "会员信息查询.xls";  
		filename = BissnessExcel.encodeFilename(filename, request);//处理中文文件名   
		response.setContentType("application/vnd.ms-excel");      
		response.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = response.getOutputStream();      
		workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close(); 
	}
	
	/**
	 * 设置一个sheet的表头
	 * 
	 * @param sheet
	 */
	private void setTableHeader(HSSFSheet sheet){
		setText(getCell(sheet, 0, 0), "序号");
		setText(getCell(sheet, 0, 1), "会员手机号");
		setText(getCell(sheet, 0, 2), "推荐人号码");
		setText(getCell(sheet, 0, 3), "省份");
		setText(getCell(sheet, 0, 4), "地市");
		setText(getCell(sheet, 0, 5), "渠道号");
		setText(getCell(sheet, 0, 6), "版本号");
		setText(getCell(sheet, 0, 7), "注册时间");
		setText(getCell(sheet, 0, 8), "来源");
		setText(getCell(sheet, 0, 9), "畅达币金额");
		setText(getCell(sheet, 0, 10), "获赠畅达币总额");
		setText(getCell(sheet, 0, 11), "消费总额");
		sheet.createFreezePane(0, 1, 1, 1);
	}

	/**
	 * 来源名称
	 * @param sourceType
	 * @return
	 */
	private String getSourceType(String sourceType) {
		String sourceTypeStr;
		if (sourceType == null) {
			sourceTypeStr = "";
		} else if (sourceType.equals("0")) {
			sourceTypeStr = "Android";
		} else if (sourceType.equals("1")) {
			sourceTypeStr = "Mobile";
		} else if (sourceType.equals("2")) {
			sourceTypeStr = "网站";
		} else {
			sourceTypeStr = "";
		}
		return sourceTypeStr;
	}

}
