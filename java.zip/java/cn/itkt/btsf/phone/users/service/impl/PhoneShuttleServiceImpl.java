package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.users.dao.PhoneShuttleDao;
import cn.itkt.btsf.phone.users.po.PhoneShuttlePO;
import cn.itkt.btsf.phone.users.service.PhoneShuttleService;
import cn.itkt.btsf.phone.users.vo.PhoneShowAirportShuttleVO;
import cn.itkt.exception.AppException;

@Service
public class PhoneShuttleServiceImpl implements PhoneShuttleService {

	private static final Logger log = LoggerFactory.getLogger(PhoneShuttleServiceImpl.class);
	
	@Resource
	private  PhoneShuttleDao  phoneShuttleDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneShuttle 
	 */
	public PhoneShuttlePO find(Serializable id){
		return phoneShuttleDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PhoneShuttlePO> 
	 */
	public List<PhoneShuttlePO> findAll(){
		return phoneShuttleDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PhoneShuttlePO po) throws AppException{
		try{
			if( po != null )
				 phoneShuttleDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(PhoneShuttlePO po) throws AppException {
		try{
			if( po != null )
				 phoneShuttleDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(String[] id){
		 phoneShuttleDao.delete(id);
	}

	@Override
	public int countFindAllShow(Map<Object, Object> map) {
		return phoneShuttleDao.countFindAllShow(map);
	}

	@Override
	public List<PhoneShowAirportShuttleVO> findAllShow(Map<Object, Object> map) {
		return phoneShuttleDao.findAllShow(map);
	}

	@Override
	@Transactional(rollbackFor={Exception.class})
	public void batchCreate(List<PhoneShuttlePO> list) throws AppException {
		if(list != null){
			for(PhoneShuttlePO po  : list){
				this.create(po);
			}
		}else{
			log.error("解析EXCEL表格失败，检查EXCEL是否有数据");
			throw new AppException("parse.excel.exception");
		}
	
		
	}



}