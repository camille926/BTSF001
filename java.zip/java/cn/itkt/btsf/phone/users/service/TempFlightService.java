package cn.itkt.btsf.phone.users.service;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.TempFlightPO;

public interface TempFlightService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return TempFlight 
	 */
	public List<TempFlightPO> find(Serializable btsfTempTerminaldoId);

	/**
	 * 查找所有 
	 * @return List<TempFlightPO> 
	 */
	public List<TempFlightPO> findAll();



}