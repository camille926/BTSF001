package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.users.dao.PhoneOrderDao;
import cn.itkt.btsf.phone.users.dao.PhoneOrderExtDao;
import cn.itkt.btsf.phone.users.po.PhoneOrderExtPO;
import cn.itkt.btsf.phone.users.po.PhoneOrderPO;
import cn.itkt.btsf.phone.users.service.PhoneOrderService;
import cn.itkt.btsf.phone.users.vo.PhoneOrderShowVO;
import cn.itkt.exception.AppException;

@Service
public class PhoneOrderServiceImpl implements PhoneOrderService {

	

	private static final Logger log = LoggerFactory.getLogger(PhoneOrderServiceImpl.class);
	
	@Resource
	private  PhoneOrderDao  phoneOrderDao;
	
	@Resource
	private  PhoneOrderExtDao  phoneOrderExtDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneOrder 
	 */
	public PhoneOrderPO find(Serializable id){
		return phoneOrderDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PhoneOrderPO> 
	 */
	public List<PhoneOrderPO> findAll(){
		return phoneOrderDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PhoneOrderPO po) throws AppException{
		try{
			if( po != null )
				 phoneOrderDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	@Override
	public Boolean create(PhoneOrderExtPO po) {
		Boolean result = false;
		try{
			if( po != null ){
				phoneOrderExtDao.create(po);
				result = true;
			}
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
		return result;
	}
	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(PhoneOrderPO po) throws AppException {
		try{
			if( po != null )
				 phoneOrderDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 phoneOrderDao.delete(id);
	}

	@Override
	public int countFindAllShow(Map<Object, Object> map) {
		
		return phoneOrderDao.countFindAllShow(map);
	}

	@Override
	public List<PhoneOrderShowVO> findAllShow(Map<Object, Object> map) {

		return phoneOrderDao.findAllShow(map);
	}

	@Override
	public PhoneOrderPO findByOrderId(String orderId) {
		
		return phoneOrderDao.findByOrderId(orderId);
	}
	
	/**
	 * 更改移动商旅订单扩展表的移动商旅客户信息。
	 * 比如把订单扩展表的A客户改成B客户
	 * 
	 * @param po
	 * @return
	 */
	@Override
	public int updateUserForOrder(PhoneOrderExtPO po){
		return phoneOrderExtDao.updateUserForOrder(po);
	}
}