package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.users.dao.PhoneCoinDetailsDao;
import cn.itkt.btsf.phone.users.po.PhoneCoinDetailsPO;
import cn.itkt.btsf.phone.users.service.PhoneCoinDetailsService;
import cn.itkt.exception.AppException;

@Service
public class PhoneCoinDetailsServiceImpl implements PhoneCoinDetailsService {

	private static final Logger log = LoggerFactory.getLogger(PhoneCoinDetailsServiceImpl.class);
	
	@Resource
	private  PhoneCoinDetailsDao  phoneCoinDetailsDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneCoinDetails 
	 */
	public PhoneCoinDetailsPO find(Serializable id){
		return phoneCoinDetailsDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PhoneCoinDetailsPO> 
	 */
	public List<PhoneCoinDetailsPO> findAll(){
		return phoneCoinDetailsDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PhoneCoinDetailsPO po) throws AppException{
		try{
			if( po != null )
				 phoneCoinDetailsDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(PhoneCoinDetailsPO po) throws AppException {
		try{
			if( po != null )
				 phoneCoinDetailsDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 phoneCoinDetailsDao.delete(id);
	}

	@Override
	public List<PhoneCoinDetailsPO> findByUserId(Map map) {
	
		return phoneCoinDetailsDao.findByUserId(map);
	}
	
	@Override
	public List<Map> findByUserId1(Map map) {
		try {
			map.put("orderStatus", "已取消");
			return phoneCoinDetailsDao.findByUserId1(map);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}

	@Override
	public int countFindAllForPage(Map map) {
		return phoneCoinDetailsDao.countFindAllForPage(map);
	}
	
	@Override
	public int countFindAllForPage1(Map map) {
		map.put("orderStatus", "已取消");
		return phoneCoinDetailsDao.countFindAllForPage1(map);
	}

	@Override
	public List<PhoneCoinDetailsPO> findByUserIdAndTicketId(Map<String, Object> params) {
		return phoneCoinDetailsDao.findByUserIdAndTicketId(params);
	}
	public List findByUpdateDetails(Map<String, Object> params){
		return phoneCoinDetailsDao.findByUpdateDetails(params);
	}



}