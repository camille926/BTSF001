package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.users.dao.PhoneAirportShuttleDao;
import cn.itkt.btsf.phone.users.po.PhoneAirportShuttlePO;
import cn.itkt.btsf.phone.users.service.PhoneAirportShuttleService;
import cn.itkt.exception.AppException;

@Service
public class PhoneAirportShuttleServiceImpl implements PhoneAirportShuttleService {

	private static final Logger log = LoggerFactory.getLogger(PhoneAirportShuttleServiceImpl.class);
	
	@Resource
	private  PhoneAirportShuttleDao  phoneAirportShuttleDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneAirportShuttle 
	 */
	public PhoneAirportShuttlePO find(Serializable id){
		return phoneAirportShuttleDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PhoneAirportShuttlePO> 
	 */
	public List<PhoneAirportShuttlePO> findAll(){
		return phoneAirportShuttleDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PhoneAirportShuttlePO po) throws AppException{
		try{
			if( po != null )
				 phoneAirportShuttleDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(PhoneAirportShuttlePO po) throws AppException {
		try{
			if( po != null )
				 phoneAirportShuttleDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 phoneAirportShuttleDao.delete(id);
	}



}