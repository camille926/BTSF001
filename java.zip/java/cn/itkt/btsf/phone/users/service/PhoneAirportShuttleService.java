package cn.itkt.btsf.phone.users.service;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.PhoneAirportShuttlePO;
import cn.itkt.exception.AppException;

public interface PhoneAirportShuttleService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneAirportShuttle 
	 */
	public PhoneAirportShuttlePO find(Serializable id);
	
	

	/**
	 * 查找所有 
	 * @return List<PhoneAirportShuttlePO> 
	 */
	public List<PhoneAirportShuttlePO> findAll();

	/**
	 * 创建 
	 * @param po
	 */
	public void create(PhoneAirportShuttlePO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneAirportShuttlePO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);



}