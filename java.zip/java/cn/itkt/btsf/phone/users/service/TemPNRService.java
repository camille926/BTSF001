package cn.itkt.btsf.phone.users.service;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.TemPNRPO;

public interface TemPNRService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return TemPNR 
	 */
	public List<TemPNRPO> find(Serializable btsfTempTerminaldoId);

	/**
	 * 查找所有 
	 * @return List<TemPNRPO> 
	 */
	public List<TemPNRPO> findAll();

	



}