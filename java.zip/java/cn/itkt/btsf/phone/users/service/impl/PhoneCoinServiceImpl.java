package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.users.dao.PhoneCoinDao;
import cn.itkt.btsf.phone.users.po.PhoneCoinDetailsPO;
import cn.itkt.btsf.phone.users.po.PhoneCoinPO;
import cn.itkt.btsf.phone.users.service.PhoneCoinDetailsService;
import cn.itkt.btsf.phone.users.service.PhoneCoinService;
import cn.itkt.exception.AppException;
import cn.itkt.util.SysUtil;

@Service
public class PhoneCoinServiceImpl implements PhoneCoinService {

	private static final Logger log = LoggerFactory.getLogger(PhoneCoinServiceImpl.class);
	
	@Resource
	private  PhoneCoinDao  phoneCoinDao;
	@Resource
	private PhoneCoinDetailsService phoneCoinDetailsService;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneCoin 
	 */
	public PhoneCoinPO find(Serializable id){
		return phoneCoinDao.find(id);	
	}
	
	/**
	 * 查找所有 
	 * @return List<PhoneCoinPO> 
	 */
	public List<PhoneCoinPO> findAll(){
		return phoneCoinDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PhoneCoinPO po) throws AppException{
		try{
			if( po != null )
				 phoneCoinDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(PhoneCoinPO po) throws AppException {
		try{
			if( po != null )
				 phoneCoinDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 phoneCoinDao.delete(id);
	}

	@Override
	public PhoneCoinPO findByUserId(String userid) {
		return phoneCoinDao.findByUserId(userid);
	}

	@Override
	public boolean refundLcdCoin(String userId,String lcdCoin,Long ticketId,String exchangetype) {
		boolean flag = false;
		try {
			//退剩余的畅达币给客户
			PhoneCoinPO findByUserId = this.findByUserId(userId);//该用户的畅达币信息
			if(findByUserId != null){
				Map<String, Object> params = new HashMap<String, Object>();
				params.put("ticketId", ticketId);
				params.put("coinaccountid", findByUserId.getId());
				params.put("exchangetype", exchangetype);
				List<PhoneCoinDetailsPO> lists = phoneCoinDetailsService.findByUserIdAndTicketId(params);
				if(lists.size()<=0){
					int usedLcdcoin = SysUtil.changeDecimal(Double.parseDouble(findByUserId.getLcdcoin()));//可用畅达币
					int allLcdcoin = SysUtil.changeDecimal(Double.parseDouble(findByUserId.getAlllcdcoin()));//累积畅达币
					findByUserId.setLcdcoin(usedLcdcoin+Integer.parseInt(lcdCoin)+"");//可用畅达币(原畅达币数量+返的畅达币数量)
					findByUserId.setAlllcdcoin(allLcdcoin+Integer.valueOf(lcdCoin)+"");//累积畅达币(原畅达币数量+返的畅达币数量)
					this.update(findByUserId);//更新畅达币信息
					
					//记录畅达币交易明细
					PhoneCoinDetailsPO phoneCoinDetailsPO = new PhoneCoinDetailsPO();
					phoneCoinDetailsPO.setCoinaccountid(findByUserId.getId());
					phoneCoinDetailsPO.setPaycoin(0);
					phoneCoinDetailsPO.setReceiptscoin(Integer.valueOf(lcdCoin));
					phoneCoinDetailsPO.setExchangetype(exchangetype);
					phoneCoinDetailsPO.setExchangetime(new Date());
					phoneCoinDetailsPO.setTicketId(ticketId);
					phoneCoinDetailsService.create(phoneCoinDetailsPO);
				}
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@Override
	public boolean addCoinByEransferbillNo(String userId,String lcdCoin,String eransferbillNo,String exchangetype,String operator) {
		boolean flag = false;
		try {
					PhoneCoinPO findByUserId = this.findByUserId(userId);//该用户的畅达币信息
					int usedLcdcoin = SysUtil.changeDecimal(Double.parseDouble(findByUserId.getLcdcoin()));//可用畅达币
					int allLcdcoin = SysUtil.changeDecimal(Double.parseDouble(findByUserId.getAlllcdcoin()));//累积畅达币
					
					if (exchangetype.equals("0")) {
						findByUserId.setLcdcoin(usedLcdcoin-Integer.parseInt(lcdCoin)+"");//可用畅达币(原畅达币数量+返的畅达币数量)
					}else {
						findByUserId.setLcdcoin(usedLcdcoin+Integer.parseInt(lcdCoin)+"");//可用畅达币(原畅达币数量+返的畅达币数量)
					}
					
					findByUserId.setAlllcdcoin(allLcdcoin+Integer.valueOf(lcdCoin)+"");//累积畅达币(原畅达币数量+返的畅达币数量)
					this.update(findByUserId);//更新畅达币信息
					
					//记录畅达币交易明细
					PhoneCoinDetailsPO phoneCoinDetailsPO = new PhoneCoinDetailsPO();
					phoneCoinDetailsPO.setCoinaccountid(findByUserId.getId());
					if (exchangetype.equals("0")) {
						phoneCoinDetailsPO.setPaycoin(Integer.valueOf(lcdCoin));
					}else {
						phoneCoinDetailsPO.setReceiptscoin(Integer.valueOf(lcdCoin));
					}
					
					phoneCoinDetailsPO.setExchangetype("18");
					phoneCoinDetailsPO.setExchangetime(new Date());
					phoneCoinDetailsPO.setEransferbillNo(eransferbillNo);
					phoneCoinDetailsPO.setOperator(operator);
					phoneCoinDetailsService.create(phoneCoinDetailsPO);
				flag = true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return flag;
	}




}