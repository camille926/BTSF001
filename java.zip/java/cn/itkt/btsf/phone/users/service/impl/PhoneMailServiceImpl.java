package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.users.dao.PhoneMailDao;
import cn.itkt.btsf.phone.users.po.PhoneMailPO;
import cn.itkt.btsf.phone.users.service.PhoneMailService;
import cn.itkt.exception.AppException;

@Service
public class PhoneMailServiceImpl implements PhoneMailService {

	private static final Logger log = LoggerFactory.getLogger(PhoneMailServiceImpl.class);
	
	@Resource
	private  PhoneMailDao  phoneMailDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneMail 
	 */
	public PhoneMailPO find(Serializable id){
		return phoneMailDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PhoneMailPO> 
	 */
	public List<PhoneMailPO> findAll(){
		return phoneMailDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PhoneMailPO po) throws AppException{
		try{
			if( po != null )
				 phoneMailDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(PhoneMailPO po) throws AppException {
		try{
			if( po != null )
				 phoneMailDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 phoneMailDao.delete(id);
	}



}