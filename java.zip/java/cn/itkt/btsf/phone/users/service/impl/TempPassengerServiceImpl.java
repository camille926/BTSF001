package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.phone.users.dao.TempPassengerDao;
import cn.itkt.btsf.phone.users.po.TempPassengerPO;
import cn.itkt.btsf.phone.users.service.TempPassengerService;

@Service
public class TempPassengerServiceImpl implements TempPassengerService {

	private static final Logger log = LoggerFactory.getLogger(TempPassengerServiceImpl.class);
	
	@Resource
	private  TempPassengerDao  tempPassengerDao;

	@Override
	public List<TempPassengerPO> find(Serializable btsfTempTerminaldoId) {
		
		return tempPassengerDao.find(btsfTempTerminaldoId);
	}

	@Override
	public List<TempPassengerPO> findAll() {
		
		return null;
	}
	

	



}