package cn.itkt.btsf.phone.users.service;

import java.util.HashMap;
import java.util.Map;

import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;
/**
 * 查询移动商旅会员畅达币信息
 * @author Administrator
 *
 */
public class LcdCoinInfosHandler extends AbstractWebserviceInvoker{

	@Override
	public Object[] buildArgument(Object args) throws Exception {
		return (Object[])args;
	}

	@Override
	public Object buildResult(Object result) {
		Map<String,Object> map = new HashMap<String,Object>();
		String phoneCoin = (String)result;
		String[] split = phoneCoin.split("\"");
		if("0".equals(split[1])){
			map.put("result", split[1]);//结果
			map.put("Error", split[3]);//错误信息
			map.put("accountlatedLcdCoin", split[5]);//累积畅达币
			map.put("usedLcdCoin", split[7]);//已消费畅达币
			map.put("usingLcdCoin", split[9]);//可使用畅达币
			map.put("noGetLcdCoin", split[11]);//未到账畅达币
		}else{
			map.put("accountlatedLcdCoin", 0);//累积畅达币
			map.put("usedLcdCoin", 0);//已消费畅达币
			map.put("usingLcdCoin", 0);//可使用畅达币
			map.put("noGetLcdCoin", 0);//未到账畅达币
		}
		return map;
	}

}
