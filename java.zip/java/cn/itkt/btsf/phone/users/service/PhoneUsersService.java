package cn.itkt.btsf.phone.users.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.phone.users.vo.PhoneUsersMailVO;
import cn.itkt.btsf.phone.users.vo.PhoneUsersVO;
import cn.itkt.exception.AppException;

public interface PhoneUsersService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneUsers 
	 */
	public PhoneUsersPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneUsersPO> 
	 */
//public List<PhoneUsersPO> findAll();

	/**
	 * 创建 
	 * @param po
	 */
	public void create(PhoneUsersPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneUsersPO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 查找所有--分页  
	 * @return List<PhoneUsersPO> 
	 */
	public List<PhoneUsersMailVO> findAllShow(Map<Object,Object> map);
	
	/**
	 * 取站内所有数据行
	 * @param po 
	 */
	public int countFindAllShow(Map<Object,Object> map);
	
	/**
	 * po与vo转换
	 * @param po
	 * @return vo
	 */
	PhoneUsersVO poToVo(PhoneUsersPO po);
	
	/**
	 * vo与po转换
	 * @param po
	 * @return vo
	 */
	PhoneUsersPO voToPo(PhoneUsersVO vo);
	
	
	/**
	 * po列表与vo列表转换
	 * @param poList
	 * @return voList
	 */
	List<PhoneUsersVO> poListToVoList(List<PhoneUsersPO> poList);
	
	/**
	 * 查找分页数据
	 * @param map
	 * @return
	 */
	public List<PhoneUsersMailVO> findPhoneUser(Map<Object,Object> map);
	/**
	 * 统计
	 * @return
	 */
	public int count(Map<Object,Object> map);
	/**
	 * 根据退款申请单id（BTSF_CC_TKT_REFUNDINFO_EXT 表）获得移动商旅会员id
	 * @param ticketId
	 * @return
	 */
	public PhoneUsersPO findUserByExtId(long id);
	/**
	 * 查找用户的行程单邮寄地址信息
	 * @param userid
	 * @return
	 */
	public int findMailCount(String userid);
	
	/**
	 * 根据手机号判断
	 * @param userPhone 手机号
	 * @return
	 */
	public int countsByUserPhone(String userPhone);
	/**
	 * /**
	 * 掌上航旅用户账户转移
	 * 1.转移的手机号不是掌上航旅会员，直接将转移的手机号替换原手机号
	 * 2.转移的手机号是掌上航旅会员，则删除该会员信息，将转移的手机号替换原手机号
	 * @param newUserPhone转移的手机号
	 * @param flag=1转移手机号是掌上航旅会员，=0不是
	 * @param oldUserId 原会员id
	 */
	public void replaceUser1(String newUserPhone, String flag, String oldUserId,String oldUserPhone);

	public PhoneUsersPO findByPhone(String phone);
	
	/**
	 * 会员信息维护查询
	 * @param userid
	 * @return
	 */
	public PhoneUsersMailVO manageFindById(Map<Object,Object> map);
	/**
	 * 修改会员备注
	 * @param po 
	 */
	public void updateRemark(PhoneUsersMailVO po);
}