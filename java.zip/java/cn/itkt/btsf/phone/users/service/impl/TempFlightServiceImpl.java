package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.phone.users.dao.TempFlightDao;
import cn.itkt.btsf.phone.users.po.TempFlightPO;
import cn.itkt.btsf.phone.users.service.TempFlightService;

@Service
public class TempFlightServiceImpl implements TempFlightService {

	private static final Logger log = LoggerFactory.getLogger(TempFlightServiceImpl.class);
	
	@Resource
	private  TempFlightDao  tempFlightDao;

	@Override
	public List<TempFlightPO> find(Serializable btsfTempTerminaldoId) {
	
		return tempFlightDao.find(btsfTempTerminaldoId);
	}

	@Override
	public List<TempFlightPO> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	
	



}