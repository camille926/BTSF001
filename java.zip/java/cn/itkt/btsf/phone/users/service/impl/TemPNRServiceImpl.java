package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.phone.users.dao.TemPNRDao;
import cn.itkt.btsf.phone.users.po.TemPNRPO;
import cn.itkt.btsf.phone.users.service.TemPNRService;

@Service
public class TemPNRServiceImpl implements TemPNRService {

	private static final Logger log = LoggerFactory.getLogger(TemPNRServiceImpl.class);
	
	@Resource
	private  TemPNRDao  temPNRDao;

	@Override
	public List<TemPNRPO> find(Serializable btsfTempTerminaldoId) {
		
		return temPNRDao.find(btsfTempTerminaldoId);
	}

	@Override
	public List<TemPNRPO> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	



}