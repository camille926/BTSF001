package cn.itkt.btsf.phone.users.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.users.dao.PhoneUsersDao;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.phone.users.vo.PhoneUsersMailVO;
import cn.itkt.btsf.phone.users.vo.PhoneUsersVO;
import cn.itkt.btsf.util.CopyUtil;
import cn.itkt.exception.AppException;

@Service
public class PhoneUsersServiceImpl implements PhoneUsersService {

	private static final Logger log = LoggerFactory.getLogger(PhoneUsersServiceImpl.class);
	
	@Resource
	private  PhoneUsersDao  phoneUsersDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneUsers 
	 */
	public PhoneUsersPO find(Serializable id){
		return phoneUsersDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PhoneUsersPO> 
	 */
	/*public List<PhoneUsersPO> findAll(){
		return phoneUsersDao.findAll();	
	}*/

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PhoneUsersPO po) throws AppException{
		try{
			if( po != null )
				 phoneUsersDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(PhoneUsersPO po) throws AppException {
		try{
			if( po != null )
				 phoneUsersDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 phoneUsersDao.delete(id);
	}

	@Override
	public int countFindAllShow(Map<Object, Object> map) {
	
		return phoneUsersDao.countFindAllShow(map);
	}

	@Override
	public List<PhoneUsersMailVO> findAllShow(Map<Object, Object> map) {
		 List<PhoneUsersMailVO> findAllShow = phoneUsersDao.findAllShow(map);
		 for (PhoneUsersMailVO phoneUsersMailVO : findAllShow) {
			 phoneUsersMailVO.setMailpoList(phoneUsersMailVO.getMailpo().size());
		 }
		 return findAllShow;
	}
	@Override
	public List<PhoneUsersVO> poListToVoList(List<PhoneUsersPO> poList) {
		List<PhoneUsersVO> voList = new ArrayList<PhoneUsersVO>();
		for (PhoneUsersPO po : poList) {
			voList.add(this.poToVo(po));
		}
		return voList;
	}

	@Override
	public PhoneUsersVO poToVo(PhoneUsersPO po) {
		PhoneUsersVO vo = new PhoneUsersVO();
		try {
			PropertyUtils.copyProperties(vo, po);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vo;
	}

	@Override
	public PhoneUsersPO voToPo(PhoneUsersVO vo) {
		PhoneUsersPO po = new PhoneUsersPO();
		try {
			PropertyUtils.copyProperties(po, vo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return po;
	}

	@Override
	public List<PhoneUsersMailVO> findPhoneUser(Map<Object, Object> map) {
		List<PhoneUsersMailVO> findAllShow = phoneUsersDao.findPhoneUser(map);
		 for (PhoneUsersMailVO phoneUsersMailVO : findAllShow) {
			 phoneUsersMailVO.setMailpoList(phoneUsersMailVO.getMailpo().size());
		 }
		 return findAllShow;
	}

	@Override
	public int count(Map<Object,Object> map) {
		return phoneUsersDao.count(map);
	}

	@Override
	public PhoneUsersPO findUserByExtId(long id) {
		return phoneUsersDao.findUserByExtId(id);
	}

	@Override
	public int findMailCount(String userid) {
		return phoneUsersDao.findMailCount(userid);
	}

	@Override
	public int countsByUserPhone(String userPhone) {
		return phoneUsersDao.countsByUserPhone(userPhone);
	}

	@Override
	public void replaceUser1(String newUserPhone, String flag, String oldUserId,String oldUserPhone) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("newUserPhone", newUserPhone);
		map.put("oldUserId", Integer.parseInt(oldUserId));
		if("1".equals(flag)){
			//转移的手机号是掌上航旅会员，则删除该会员信息，将转移的手机号替换原手机号
			phoneUsersDao.deleteByPhone1(newUserPhone);
			phoneUsersDao.updateByPhone(map);
			
			//更新弹屏手机号会员类型汇总表[BTSF_SYS_POPUPMBRPHONE]
			int newCount = phoneUsersDao.findPopupmbrphoneByPhone(newUserPhone);
			log.info("新手机号为:"+newUserPhone+"的数量为:"+newCount);
			if(newCount>0){
				//先删除新手机号打赌记录
				phoneUsersDao.deletePopupmbrphone(newUserPhone);
				log.info("删除手机号为["+newUserPhone+"]的用户");
				//再把旧新机号代表的会员更新为新手机号
				int count = phoneUsersDao.findPopupmbrphoneByPhone(oldUserPhone);
				log.info("手机号为:"+oldUserPhone+"的数量为:"+count);
				if(count>0){
					//如果该手机号会员存在的话，将其手机号进行更新
					Map<String,Object> map1 = new HashMap<String,Object>();
					map1.put("newUserPhone", newUserPhone);
					map1.put("oldUserPhone", oldUserPhone);
					phoneUsersDao.updatePopupmbrphone(map1);
				}
			}
		}else{
			//转移的手机号不是掌上航旅会员，直接将转移的手机号替换原手机号
			phoneUsersDao.updateByPhone(map);
			//直接更新弹屏手机号会员类型汇总表[BTSF_SYS_POPUPMBRPHONE]
			int count = phoneUsersDao.findPopupmbrphoneByPhone(oldUserPhone);
			log.info("手机号为:"+oldUserPhone+"的数量为:"+count+",执行更新...");
			if(count>0){
				//如果该手机号会员存在的话，将其手机号进行更新
				Map<String,Object> map1 = new HashMap<String,Object>();
				map1.put("newUserPhone", newUserPhone);
				map1.put("oldUserPhone", oldUserPhone);
				phoneUsersDao.updatePopupmbrphone(map1);
			}
		}
	}

	@Override
	public PhoneUsersPO findByPhone(String phone) {
		return phoneUsersDao.findByPhone(phone);
	}
	/**
	 * 会员信息维护查询
	 * @param userid
	 * @return
	 */
	public PhoneUsersMailVO manageFindById(Map<Object,Object> map)
	{
		return phoneUsersDao.manageFindById(map);
	}
	/**
	 * 修改会员备注
	 * @param po 
	 */
	public void updateRemark(PhoneUsersMailVO po)
	{
		phoneUsersDao.updateRemark(po);
	}
}