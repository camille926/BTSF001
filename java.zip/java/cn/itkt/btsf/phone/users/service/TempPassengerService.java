package cn.itkt.btsf.phone.users.service;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.TempPassengerPO;

public interface TempPassengerService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return TempPassenger 
	 */
	public List<TempPassengerPO> find(Serializable btsfTempTerminaldoId);

	/**
	 * 查找所有 
	 * @return List<TempPassengerPO> 
	 */
	public List<TempPassengerPO> findAll();

	


}