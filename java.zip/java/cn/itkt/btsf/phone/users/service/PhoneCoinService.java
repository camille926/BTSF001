package cn.itkt.btsf.phone.users.service;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.PhoneCoinPO;
import cn.itkt.exception.AppException;

public interface PhoneCoinService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneCoin 
	 */
	public PhoneCoinPO find(Serializable id);
	
	/**
	 * 根据用户id查询
	 * @param userid
	 * @return
	 */
	public PhoneCoinPO findByUserId(String userid);


	/**
	 * 查找所有 
	 * @return List<PhoneCoinPO> 
	 */
	public List<PhoneCoinPO> findAll();

	/**
	 * 创建 
	 * @param po
	 */
	public void create(PhoneCoinPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneCoinPO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	/**
	 * 退畅达币到账户
	 * userId 会员id
	 * lcdCoin 退畅达币的数量
	 * ticketId 票id
	 * exchangetype 交易类型:00：注册， 01：低价推送，02：正常票返2%畅达币，03：活动，04：兑换，05：退票，06：购票，07：其他
	 * @return
	 */
	public boolean refundLcdCoin(String userId,String lcdCoin,Long ticketId,String exchangetype);

	public boolean addCoinByEransferbillNo(String userId,String lcdCoin,String eransferbillNo,String exchangetype,String operator);
}