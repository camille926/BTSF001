package cn.itkt.btsf.phone.users.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.users.po.PhoneShuttlePO;
import cn.itkt.btsf.phone.users.service.PhoneShuttleService;
import cn.itkt.btsf.phone.users.vo.PhoneShowAirportShuttleVO;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

@Service
public class PhoneShuttleControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(PhoneShuttleControllerSupport.class);
	
	@Resource
	private  PhoneShuttleService  phoneShuttleService;
	

	/**
	 * 跳转列表
	 * 
	 * @param modelMap
	 */
	public void list(ModelMap modelMap,int startIndex){
	  try {
		  Pages<PhoneShowAirportShuttleVO> pages=new Pages<PhoneShowAirportShuttleVO>(startIndex);
		  Map<Object,Object> map=new HashMap<Object,Object>();
		  map.put("startIndex", startIndex);
		  map.put("pageSize", 10);
		  List<PhoneShowAirportShuttleVO> temList=this.phoneShuttleService.findAllShow(map);
		  pages.setItems(temList);
		  pages.setTotalCount(phoneShuttleService.countFindAllShow(map));
		  modelMap.addAttribute("page",pages);
	} catch (Exception e) {
		e.printStackTrace();
		log.error(e.getMessage());
	}		
	}
	//查询
	public void listForFind(ModelMap modelMap, int startIndex,PhoneShowAirportShuttleVO vo) {
		try {
			Pages<PhoneShowAirportShuttleVO> pages = new Pages<PhoneShowAirportShuttleVO>(startIndex);
			Map<Object, Object> map = new HashMap<Object, Object>();
		if (vo.getAirportName()!="") {
			map.put("airportName", vo.getAirportName());
			modelMap.addAttribute("airportName", vo.getAirportName());
		}
		if (vo.getStartstation()!="") {
			map.put("startstation", vo.getStartstation());
			modelMap.addAttribute("startstation", vo.getStartstation());
		}
		if (vo.getEndstation()!="") {
			map.put("endstation", vo.getEndstation());
			modelMap.addAttribute("endstation", vo.getEndstation());
		}
		if (vo.getCityname()!="") {
			map.put("cityname", vo.getCityname());
			modelMap.addAttribute("cityname", vo.getCityname());
		}
			//map.put("sendType", "2");
			map.put("startIndex", startIndex);
			map.put("pageSize", 10);
			List<PhoneShowAirportShuttleVO> list = this.phoneShuttleService.findAllShow(map);
			//List<MsgSendVO> mList = this.msgSendService.poListToVoList(list);
			pages.setItems(list);
			pages.setTotalCount(phoneShuttleService.countFindAllShow(map));
			modelMap.addAttribute("page", pages);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}

	}
	
	 /** 根据ID查询
	 * @param modelMap
	 * @param teamInfoId 班组ID
	 */
	public void findById(ModelMap modelMap,String id){
		

		try {
			PhoneShuttlePO po=this.phoneShuttleService.find(id);
			
			modelMap.addAttribute("shuttle",po);
			
		} catch (Exception e) {
			
			log.error(e.getMessage());
		}
	}
	
	/**
	 * 更新
	 * @param modelMap
	 * @param userVO 角色信息
	 */
	public void update(ModelMap modelMap,PhoneShuttlePO phoneShuttlePO){
		try {
		
			this.phoneShuttleService.update(phoneShuttlePO);
			modelMap.clear();
			modelMap.addAttribute("message", "保存成功");
			modelMap.addAttribute("status", true);
		} catch (AppException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage());
			modelMap.addAttribute("message", "保存失败");
			modelMap.addAttribute("status", false);
		}

	}
	
	/**
	 * 删除
	 * @param modelMap
	 * @param teamInfoId 班组Id
	 */
	public void delete(ModelMap modelMap,String Id){
		try {
			this.phoneShuttleService.delete(Id.split(","));
			modelMap.clear();
			modelMap.addAttribute("message", "删除成功");
			modelMap.addAttribute("status", true);
		} catch (Exception e) {
			log.error(e.getMessage());
			modelMap.addAttribute("message", "删除失败");
			modelMap.addAttribute("status", false);
		}
		
	}
	
	
	
	


}