package cn.itkt.btsf.phone.users.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.btsf.phone.users.po.PhoneShuttlePO;
import cn.itkt.btsf.phone.users.vo.PhoneShowAirportShuttleVO;


@Controller
@RequestMapping("/phone/users/phoneshuttle")
public class PhoneShuttleController {

	@Resource
	private  PhoneShuttleControllerSupport  phoneShuttleControllerSupport;

	/**
	 * 分页
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/list")
	public String list(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex){
		//调用Support处理业务逻辑
		phoneShuttleControllerSupport.list(modelMap, startIndex);
		return "phone/bus/view";		
		
	}
	/**
	 * 分页--条件查询
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	@RequestMapping(value="/listForfind")
	public String list1(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,PhoneShowAirportShuttleVO vo){
		//调用Support处理业务逻辑
		phoneShuttleControllerSupport.listForFind(modelMap, startIndex, vo);
		return "phone/bus/view";		
	}
	
	/**
	 * 跳转修改信息
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toUpdate")
	public String templatevUpdate(ModelMap modelMap,
			@RequestParam(value="Id" ,required=false, defaultValue="") String Id){
		
		this.phoneShuttleControllerSupport.findById(modelMap, Id);
		
		return "phone/bus/edit";
	}	
	
	/**
	 * 更新
	 * @param modelMap
	 * @param 
	 * @return
	 */
	@RequestMapping(value="/update")
	public ModelAndView update(ModelMap modelMap,@ModelAttribute("PhoneShuttlePO") PhoneShuttlePO po){
		this.phoneShuttleControllerSupport.update(modelMap, po);
		return new ModelAndView("jsonView");
	}
	
	/**
	 * 删除
	 * @param modelMap
	 * @param roleVO 用户信息
	 * @return
	 */
	@RequestMapping(value="/delete")
	public ModelAndView delete(ModelMap modelMap,
			@RequestParam(value="Id" ,required=false, defaultValue="") String Id){
		this.phoneShuttleControllerSupport.delete(modelMap, Id);
		return new ModelAndView("jsonView");
	}

	


}