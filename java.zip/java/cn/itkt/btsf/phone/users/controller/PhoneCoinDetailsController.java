package cn.itkt.btsf.phone.users.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.itkt.btsf.phone.users.service.PhoneCoinDetailsService;
import cn.itkt.btsf.phone.users.service.PhoneCoinService;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.phone.users.vo.PhoneShowAirportShuttleVO;
import cn.itkt.btsf.phone.users.vo.PhoneUsersMailVO;
import cn.itkt.btsf.sys.adjustable.controller.AdjustableKeepSupport;
import cn.itkt.util.SysUtil;


@Controller
@RequestMapping("/phone/users/phonecoindetails")
public class PhoneCoinDetailsController {
	
	@Resource
	private AdjustableKeepSupport adjustableKeepSupport;
	
	@Resource
	private PhoneCoinService phoneCoinService;
	
	@Resource
	private PhoneCoinDetailsService phoneCoinDetailsService;
	
	@Resource
	private  PhoneUsersService  phoneUsersService;
	
	@RequestMapping(value="/view")
	public String list1(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,PhoneShowAirportShuttleVO vo){
		return "/phone/coin/updateCoin";		
	}

	
	@RequestMapping(value="/list") 
	public String list(ModelMap modelMap,HttpServletRequest request,String query){
		Map<String, Object> parameterMap = request.getParameterMap();
		adjustableKeepSupport.findListByCompany(modelMap, parameterMap);
		modelMap.addAttribute("query", query);
		return "/phone/coin/adjustlist";
	}
	@RequestMapping(value="/add") 
	public String add(ModelMap modelMap,HttpServletRequest request,String query){
		String eransferbillNo = request.getParameter("eransferbillNo");
		String puserTel = request.getParameter("puserTel").replaceAll(" ", "");
		
		String userid = request.getParameter("userid").replaceAll(" ", "");
		String paytype = request.getParameter("paytype");
		String amount = request.getParameter("amount").replaceAll(" ", "");
		String operator = SysUtil.getUsername();
		
		Map map = new HashMap<Object, Object>();
		map .put("telephone", puserTel);
		map.put("startIndex", 0);
		map.put("pageSize", 10);
		List<PhoneUsersMailVO> list = this.phoneUsersService.findAllShow(map);
		if (null!=list&&list.size()>0) {
			userid = Long.toString(((PhoneUsersMailVO)list.get(0)).getUserid());
		}
		
		boolean result = true;
		if (userid!=null&&!userid.equals("")) {
			result = phoneCoinService.addCoinByEransferbillNo(userid, amount, eransferbillNo, paytype,operator);
		}else {
			modelMap.put("addResult", "操作失败！");
			return "/phone/coin/updateCoin";
		}
		
		
		if (result) {
			modelMap.put("addResult", "操作成功！");
		}else {
			modelMap.put("addResult", "操作失败！");
		}
		
		
		return "/phone/coin/updateCoin";
	}
	
	@RequestMapping(value="/updateList") 
	public String updateList(ModelMap modelMap,HttpServletRequest request,String query){
		String telephone = request.getParameter("telephone");
		String operator = request.getParameter("operator");
		String beginDate = request.getParameter("beginDate");
		String endDate = request.getParameter("endDate");
		String eransferbillno = request.getParameter("eransferbillno");
		
		modelMap.put("telephone",telephone);
		modelMap.put("operator", operator);
		modelMap.put("beginDate", beginDate);
		modelMap.put("endDate",endDate );
		modelMap.put("eransferbillno",eransferbillno );

		
		List list = phoneCoinDetailsService.findByUpdateDetails(modelMap);
		
		modelMap.put("list", list);
		return "/phone/coin/updateCoinHistory";
	}



}