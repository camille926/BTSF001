package cn.itkt.btsf.phone.users.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;

import cn.itkt.btsf.phone.users.dao.PhoneAirportShuttleDao;
import cn.itkt.btsf.phone.users.po.PhoneAirportShuttlePO;
import cn.itkt.btsf.phone.users.po.PhoneShuttlePO;
import cn.itkt.btsf.phone.users.service.PhoneAirportShuttleService;
import cn.itkt.btsf.phone.users.service.PhoneShuttleService;
import cn.itkt.btsf.sys.baseinfo.dao.AirportDao;
import cn.itkt.btsf.sys.baseinfo.po.AirportPO;
import cn.itkt.btsf.util.ExcelImport;
import cn.itkt.exception.AppException;
import cn.itkt.util.SysUtil;

@Service
public class PhoneAirportShuttleControllerSupport {

	private static final Logger log = LoggerFactory
			.getLogger(PhoneAirportShuttleControllerSupport.class);

	@Resource
	private PhoneAirportShuttleService phoneAirportShuttleService;
	@Resource
	private PhoneShuttleService phoneShuttleService;
	@Resource
	private AirportDao<AirportPO> airportDao;
	@Resource
	private PhoneAirportShuttleDao phoneAirportShuttleDao;

	public void toUpload(ModelMap modelMap) {

		try {
			List<PhoneAirportShuttlePO> airportList = this.phoneAirportShuttleService.findAll();

			modelMap.addAttribute("shuttle", airportList);

		} catch (Exception e) {

			log.error(e.getMessage());
		}
	}
	private List<PhoneShuttlePO> parseMap(List<Map<String, String>> phoneShuttleMapList,String fid){
		List<PhoneShuttlePO> phoneShuttleList = new ArrayList<PhoneShuttlePO>();
		Map<String, String>  map;
		//第一行是表头，所以跳过第一行
		for(int i=1, size=phoneShuttleMapList.size(); i<size; i++){
			map = phoneShuttleMapList.get(i);
			PhoneShuttlePO po = new PhoneShuttlePO();
			//线路名称
			po.setName(map.get("key0"));
			//起点
			po.setStartstation(map.get("key1"));
			//终点
			po.setEndstation(map.get("key2"));
			//行驶线路 停靠车站
			po.setPassstation(map.get("key3"));
			//运营时间
			po.setOperationstime(map.get("key4"));
			//间隔时间
			po.setIntervaltime(map.get("key5"));
			//票价
			po.setFare(map.get("key6"));
			//巴士热线	
			po.setHotline(map.get("key7"));
			//区间
		   po.setDriection(map.get("key8"));
			//城市名称
		   po.setCityname(map.get("key9"));
		   
		   po.setAirportid(Long.valueOf(fid));

			phoneShuttleList.add(po);
		}
		return phoneShuttleList;
	}
	
	
	/**
	 * 导入写在EXCEL表格里的个人会员信息
	 * 
	 * @param modelMap
	 * @return
	 * @throws AppException 
	 */
	public boolean importExcel(Set<MultipartFile> mfs,String fid,String name) throws IOException, AppException{
		if(mfs != null){
			Iterator<MultipartFile> ite = mfs.iterator();
			MultipartFile multipartFile = null;
			while(ite.hasNext()){
				multipartFile = ite.next();
				break; //只有一个文件，所以直接跳出
			}
			InputStream excelToLoad = null;
			try {
				if(multipartFile != null){
					excelToLoad = multipartFile.getInputStream();
					ExcelImport excelImport = new ExcelImport();
					List<Map<String, String>> phoneShuttleMapList = excelImport.getXlsList(excelToLoad);
					if(phoneShuttleMapList != null){
						if (null==name || "".equals(name)) {
							List<PhoneShuttlePO> phoneShuttleList = parseMap(phoneShuttleMapList,fid);
							phoneShuttleService.batchCreate(phoneShuttleList);
							return true;
							
						}else{
							//创建机场
			/*				Long sLong=phoneAirportShuttleDao.getSeqId();
							PhoneAirportShuttlePO po=new PhoneAirportShuttlePO();
							po.setId(sLong);
							po.setName(name);
							phoneAirportShuttleService.create(po);*/
							AirportPO airportPO = new AirportPO();
							airportPO.setAirportName(name);
							airportPO.setCreateUser(Long.parseLong(SysUtil.getUser().getId()));
							airportPO.setCreationDate(new Date());
							airportDao.create(airportPO);
//							System.out.println(airportPO.getId());
							List<PhoneShuttlePO> phoneShuttleList = parseMap(phoneShuttleMapList,String.valueOf(airportPO.getId()));
							phoneShuttleService.batchCreate(phoneShuttleList);
							return true;
							
						}
						
					}
				}
			} catch (RuntimeException e) {
				e.printStackTrace();
			} finally {
				try {
					if(excelToLoad != null){
						excelToLoad.close();
					}
				} catch (RuntimeException e) {
					e.printStackTrace();
				}
			}
			
			return false;
		}else{
			throw new AppException("parse.excel.exception");
		}
		
	}

}