package cn.itkt.btsf.phone.users.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/phone/users/temppassenger")
public class TempPassengerController {

	@Resource
	private  TempPassengerControllerSupport  tempPassengerControllerSupport;




}