package cn.itkt.btsf.phone.users.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.itkt.btsf.phone.channelmanage.po.ChannelManagePO;
import cn.itkt.btsf.phone.users.vo.PhoneUsersMailVO;


@Controller
@RequestMapping("/phone/users/phoneusers")
public class PhoneUsersController {

	@Resource
	private  PhoneUsersControllerSupport  phoneUsersControllerSupport;
	
	
	/**
	 * 分页
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @param type pop:表示来自弹屏的请求
	 * @param type  type=manager  掌上航旅会员维护
	 * @return
	 */
	
	@RequestMapping(value="/list")
	public String list(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,
			@RequestParam(value="from" ,required=false, defaultValue="") String from,
			@RequestParam(value="type" ,required=false, defaultValue="") String type,
			@ModelAttribute PhoneUsersMailVO vo){
		//调用Support处理业务逻辑
		phoneUsersControllerSupport.list(modelMap, startIndex,vo);
//		if(vo.getUname() != null && !"".equals(vo.getUname())){
//			modelMap.put("activityname", vo.getUname()==null?"":vo.getUname().trim());
//		}
		if(vo.getTelephone() != null && !"".equals(vo.getTelephone())){
			modelMap.put("telephone", vo.getTelephone()==null?"":vo.getTelephone().trim());
		}
		if(vo.getRecommendPhone() != null && !"".equals(vo.getRecommendPhone())){
			modelMap.put("recommendPhone",  vo.getRecommendPhone()==null?"":vo.getRecommendPhone().trim());
		}
		if(vo.getUname() != null && !"".equals(vo.getUname())){
			modelMap.put("uname",  vo.getUname()==null?"":vo.getUname().trim());
		}
		if(!"pop".equals(from)&&"".equals(type)){
			return "phone/user/view";	
		}else if(!"pop".equals(from)&&"manage".equals(type))
		{
			return "phone/user/manage";
		}
		else{
			return "sys/cc/popscreen/phoneUserList";	
		}
			
		
	}
	
	
	
	/**
	 * 分页--条件查询
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/listForfind")
	public String list1(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,
			@RequestParam(value="from" ,required=false, defaultValue="") String from,
			@ModelAttribute("param") PhoneUsersMailVO vo){
		//调用Support处理业务逻辑
		phoneUsersControllerSupport.listForFind(modelMap, startIndex, vo);
		if(!"pop".equals(from)){
			return "phone/user/view";	
		}else{
			return "sys/cc/popscreen/phoneUserList";	
		}
			
	}
	/**
	 * 注册指定日期格式的日期属性编辑器
	 * 
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		formater.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formater, true));
	}
	
	
	/**
	 * 跳转畅达币信息
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toCoin")
	public String toCoin(ModelMap modelMap,@RequestParam(value="Id" ,required=false, defaultValue="") String Id,
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,HttpServletRequest request){
		phoneUsersControllerSupport.toCoin(modelMap, Id,startIndex,request);
		return "phone/user/coinList";
	}
	
	/**
	 * 跳转移动商旅会员信息
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/usermail")
	public String usermail(ModelMap modelMap,@RequestParam(value="Id" ,required=false, defaultValue="") String Id,
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,@RequestParam(value="reloadFlag" ,required=false, defaultValue="0") int reloadFlag){
		phoneUsersControllerSupport.usermail(modelMap, Id,startIndex);
		modelMap.put("reloadFlag", reloadFlag);
		return "phone/user/memberInfo";
	}
	
	/**
	 * 掌上航旅用户账户转移
	 * 新填功能
	 * 1.转移的手机号不是掌上航旅会员，直接将转移的手机号替换原手机号
	 * 2.转移的手机号是掌上航旅会员，则删除该会员信息，将转移的手机号替换原手机号
	 * 返回值=1表示成功    =0表示失败
	 * @return
	 */
	@RequestMapping(value="/replaceUser")
	public @ResponseBody String replaceUser(HttpServletRequest request){
		String newUserPhone = request.getParameter("newUserPhone");
		//String newUserName = request.getParameter("newUserName");
		//String newUserNo = request.getParameter("newUserNo");
		
		String flag = request.getParameter("flag");  //flag=1转移手机号是掌上航旅会员，=0不是
		String oldUserId = request.getParameter("userId");
		String oldUserPhone = request.getParameter("oldUserPhone");
		return phoneUsersControllerSupport.replaceUser(newUserPhone,flag,oldUserId,oldUserPhone);
	}
	
	/**
	 * 判断手机号码是否是掌上航旅会员
	 * 返回1表示是，返回0表示不是，其他情况返回-1
	 * @return
	 */
	@RequestMapping(value="/isPhoneUser")
	public @ResponseBody String isPhoneUser(HttpServletRequest request){
		String newUserPhone = request.getParameter("newUserPhone");
		return phoneUsersControllerSupport.isPhoneUser(newUserPhone);
	}
	
	/**
	 * 查询会员信息导出报表
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @param type pop:表示来自弹屏的请求
	 * @return
	 */
	
	@RequestMapping(value="/export")
	public String exportExcel(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,
			@RequestParam(value="from" ,required=false, defaultValue="") String from,
			@ModelAttribute PhoneUsersMailVO vo){
		//调用Support处理业务逻辑
//		phoneUsersControllerSupport.list(modelMap, startIndex,vo);
		if(vo.getUname() != null && !"".equals(vo.getUname())){
			modelMap.put("activityname", vo.getUname()==null?"":vo.getUname().trim());
		}
		if(vo.getTelephone() != null && !"".equals(vo.getTelephone())){
			modelMap.put("telephone", vo.getTelephone()==null?"":vo.getTelephone().trim());
		}
		if(vo.getRecommendPhone() != null && !"".equals(vo.getRecommendPhone())){
			modelMap.put("recommendPhone",  vo.getRecommendPhone()==null?"":vo.getRecommendPhone().trim());
		}
		return "usersPhoneExcel";	
			
		
	}
	/**
	 * 跳转修改信息
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toUpdate")
	public String templatevUpdate(ModelMap modelMap,
			@RequestParam(value="Id" ,required=false, defaultValue="") String userid,
			@RequestParam(value="version" ,required=false, defaultValue="") String version
			){
		this.phoneUsersControllerSupport.manageFindById(modelMap, userid,version);
		return "phone/user/manageEdit";
	}
	/**
	 * 更新会员信息备注特殊要求
	 * @param modelMap
	 * @param 
	 * @return
	 */
	@RequestMapping(value="/update")
	public @ResponseBody String update(ModelMap modelMap,HttpServletRequest request){
		PhoneUsersMailVO po = new PhoneUsersMailVO();
		String id = request.getParameter("id");
		if(id!=null&&!"".equals(id)){
			po.setUserid(Integer.parseInt(id));
		}
		String remark = request.getParameter("remark").trim();
		po.setRemark(remark);
		String result = this.phoneUsersControllerSupport.updateRemark(po);
		return result;
	}
}