package cn.itkt.btsf.phone.users.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.users.dao.TemPNRDao;
import cn.itkt.btsf.phone.users.dao.TempFlightDao;
import cn.itkt.btsf.phone.users.dao.TempPassengerDao;
import cn.itkt.btsf.phone.users.po.PhoneOrderPO;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.phone.users.po.TemPNRPO;
import cn.itkt.btsf.phone.users.po.TempFlightPO;
import cn.itkt.btsf.phone.users.po.TempPassengerPO;
import cn.itkt.btsf.phone.users.service.PhoneOrderService;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.phone.users.vo.PhoneOrderShowVO;
import cn.itkt.btsf.sys.cc.national.controller.OrderManageControllerSupport;
import cn.itkt.btsf.sys.cc.national.po.OrderInfoPO;
import cn.itkt.btsf.sys.cc.national.po.OrderMsgExtPO;
import cn.itkt.btsf.sys.cc.national.service.OrderManageService;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

@Service
public class PhoneOrderControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(PhoneOrderControllerSupport.class);
	
	@Resource
	private  PhoneOrderService  phoneOrderService;
	
	@Resource
	private OrderManageService orderManageService;
	@Resource
	private TempFlightDao tempFlightDao;
	@Resource
	private TempPassengerDao tempPassengerDao;
	@Resource
	private TemPNRDao temPNRDao;
	@Resource
	private OrderManageControllerSupport orderManageControllerSupport;
	@Resource
	private PhoneUsersService phoneUsersService;
	
	
	/**
	 * 跳转列表
	 * 
	 * @param modelMap
	 */
	public void list(ModelMap modelMap,int startIndex){
	  try {
		  Pages<PhoneOrderShowVO> pages=new Pages<PhoneOrderShowVO>(startIndex);
		  Map<Object,Object> map=new HashMap<Object,Object>();
		  map.put("startIndex", startIndex);
		  map.put("pageSize", 10);
		  List<PhoneOrderShowVO> temList=this.phoneOrderService.findAllShow(map);
		  pages.setItems(temList);
		  pages.setTotalCount(phoneOrderService.countFindAllShow(map));
		  modelMap.addAttribute("page",pages);
	} catch (Exception e) {
		e.printStackTrace();
		log.error(e.getMessage());
	}		
	}
	//查询
	public void listForFind(ModelMap modelMap, int startIndex,long userId) {
		try {
			//查询会员信息
			PhoneUsersPO phoneUserpo = phoneUsersService.find(userId);
			modelMap.addAttribute("phoneUserpo", phoneUserpo);
			
			//查询订单信息
			Pages<PhoneOrderShowVO> pages = new Pages<PhoneOrderShowVO>(startIndex);
			Map<Object, Object> map = new HashMap<Object, Object>();
			map.put("userId", userId);
			map.put("startIndex", startIndex);
			map.put("pageSize", 10);
			List<PhoneOrderShowVO> list = this.phoneOrderService.findAllShow(map);
			pages.setItems(list);
			pages.setTotalCount(phoneOrderService.countFindAllShow(map));
			modelMap.addAttribute("page", pages);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}

	}
	//查询
	public void getWay(ModelMap modelMap,String id,String getitinerary) {
		try {
			//利用id查询 找出记录
			PhoneOrderPO po=phoneOrderService.find(id);
			po.setGetitinerary(getitinerary);
			phoneOrderService.update(po);
			modelMap.clear();
			modelMap.addAttribute("message", "更新成功");
			modelMap.addAttribute("status", true);
		} catch (AppException e) {
			modelMap.addAttribute("message", "更新失败");
			modelMap.addAttribute("status", false);
			e.printStackTrace();
		}

		
	}
	public void toPost(ModelMap modelMap,String orderNo) {
		//查看这条记录是否存在
		//OrderMsgExtPO po=orderManageService.findOrderMsgExtByOrderNo(orderNo);
		/*if (po!=null) {
			modelMap.addAttribute("orderMsgExtPO", po);
		}*/
		modelMap.addAttribute("orderNo", orderNo);
	}
	/**
	 * 更新
	 * @param modelMap
	 * @param userVO 角色信息
	 */
	public void addOrupdate(ModelMap modelMap,OrderMsgExtPO orderMsgExtPO){
		/*try {
			//查看这条记录是否存在
			OrderMsgExtPO po=orderManageService.findOrderMsgExtByOrderNo(orderMsgExtPO.getOrderNo());
			if (po==null) {
				orderMsgExtPO.setReceiptGetType("1");
				orderMsgExtPO.setSendSms("0");
				orderManageService.createOrderMsgExt(orderMsgExtPO);
			}else{
				po.setAddress(orderMsgExtPO.getAddress());
				po.setOrderNo(orderMsgExtPO.getOrderNo());
				po.setPostCode(orderMsgExtPO.getPostCode());
				po.setRecipient(orderMsgExtPO.getRecipient());
				po.setReceiptGetType("1");
				orderManageService.updateMsgExt(po);
			}
			modelMap.clear();
			modelMap.addAttribute("message", "保存成功");
			modelMap.addAttribute("status", true);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage());
			modelMap.addAttribute("message", "保存失败");
			modelMap.addAttribute("status", false);
		}*/

	}
	
	public void validationOrderNo(ModelMap modelMap,String orderId){
		OrderInfoPO order=orderManageService.findOrderByOrderNo(orderId);
		if (order==null) {
			modelMap.clear();
			modelMap.addAttribute("message", "此订单未与订单表相关联，不能查看");
			modelMap.addAttribute("status", true);
		}else {
			modelMap.clear();
			modelMap.addAttribute("message", "删除成功");
			modelMap.addAttribute("status", false);
		}
		
		
		
	}
	
	/*public Boolean seeAll(ModelMap modelMap,String orderId) throws AppException{
		//查看订单情况  是否为已出票
		PhoneOrderPO phoneOrderPO  =  phoneOrderService.findByOrderId(orderId);
		OrderMsgExtPO orderMsgExtPO=orderManageService.findMsgByOrderId(Long.valueOf(orderId));
		//已出票的情况
		if (phoneOrderPO.getState().equals("2")&&orderMsgExtPO!=null) {
			orderManageControllerSupport.findOrderDetail(orderId, modelMap,"output");
		   return false;
		}else {
			//获取订单航段信息
			List<TempFlightPO> flightList=tempFlightDao.find(orderId);
			modelMap.addAttribute("flightList", flightList);
			//获取旅客信息
			List<TempPassengerPO> tempPassengerList=tempPassengerDao.find(orderId);
			modelMap.addAttribute("tempPassengerList", tempPassengerList);
			//获取pnr信息
			List<TemPNRPO> pnrList=temPNRDao.find(orderId);
			modelMap.addAttribute("pnrList", pnrList);
		  return true;
		}
	 
		
		
		
	}*/

}