package cn.itkt.btsf.phone.users.controller;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.phone.users.service.PhoneMailService;

@Service
public class PhoneMailControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(PhoneMailControllerSupport.class);
	
	@Resource
	private  PhoneMailService  phoneMailService;
	



}