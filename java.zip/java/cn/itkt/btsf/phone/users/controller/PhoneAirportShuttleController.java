package cn.itkt.btsf.phone.users.controller;

import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger; 
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import cn.itkt.btsf.sys.member.controller.MemberIndividualController;
import cn.itkt.btsf.util.UploadController;
import cn.itkt.util.SysUtil;


@Controller
@RequestMapping("/phone/users/phoneairportshuttle")
public class PhoneAirportShuttleController {
	Logger logger = LoggerFactory.getLogger(MemberIndividualController.class);
	@Resource
	private  PhoneAirportShuttleControllerSupport  phoneAirportShuttleControllerSupport;
	
	private UploadController uploader = new UploadController();
	/**
	 * 大巴信息导入页面
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toUpload")
	public String templatevUpdate(ModelMap modelMap){
		
		this.phoneAirportShuttleControllerSupport.toUpload(modelMap);
		
		return "phone/bus/add";
	}
	
	/**
	 * 导入写在EXCEL表格里的个人会员信息
	 * 
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/importExcel")
	public void importExcel(HttpServletRequest request, HttpServletResponse response,@RequestParam(value="Id" ,required=false, defaultValue="") String Id,@RequestParam(value="Name" ,required=false, defaultValue="") String Name){
		Set<MultipartFile> mfs = uploader.getFileSet(request);
		String result = "0";
		try {
			 Name = new String(Name.getBytes("ISO-8859-1"), "UTF-8");// 解决乱码问题
			 result = phoneAirportShuttleControllerSupport.importExcel(mfs,Id,Name) ? "1" : "0";
			 SysUtil.render(response, result);
		} catch (Exception e) {
			logger.error(e.getMessage());
			e.printStackTrace();
			SysUtil.render(response, "0");
		}
	}
	
	




}