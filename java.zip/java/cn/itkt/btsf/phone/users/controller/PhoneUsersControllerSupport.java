package cn.itkt.btsf.phone.users.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.circum.vo.PhoneActivityVO;
import cn.itkt.btsf.phone.users.po.PhoneCoinDetailsPO;
import cn.itkt.btsf.phone.users.po.PhoneCoinPO;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.phone.users.service.LcdCoinInfosHandler;
import cn.itkt.btsf.phone.users.service.PhoneCoinDetailsService;
import cn.itkt.btsf.phone.users.service.PhoneCoinService;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.phone.users.vo.PhoneUsersMailVO;
import cn.itkt.btsf.sys.cc.national.service.FlightQueryService;
import cn.itkt.btsf.sys.cc.national.service.impl.FlightQueryServiceImpl;
import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;
import cn.itkt.btsf.sys.common.constant.WebServiceConstant;
import cn.itkt.btsf.util.IdcardUtils;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

@Service
public class PhoneUsersControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(PhoneUsersControllerSupport.class);
	
	@Resource
	private  PhoneUsersService  phoneUsersService;
	@Resource
	private  PhoneCoinService phoneCoinService;
	@Resource
	private PhoneCoinDetailsService phoneCoinDetailsService;
	@Resource
	private FlightQueryService flightQueryService;
	
	/**
	 * 跳转列表
	 * 
	 * @param modelMap
	 */
	public void list(ModelMap modelMap,int startIndex,PhoneUsersMailVO vo){
	  try {
		  Pages<PhoneUsersMailVO> pages=new Pages<PhoneUsersMailVO>(startIndex);
		  Map<Object,Object> map=new HashMap<Object,Object>();
		  map.put("startIndex", startIndex);
		  map.put("pageSize", 10);
		  if(vo!=null){
			  map.put("telephone", vo.getTelephone()==null?"":vo.getTelephone().trim());
			  map.put("recommendPhone", vo.getRecommendPhone()==null?"":vo.getRecommendPhone().trim());
			  map.put("uname", vo.getUname()==null?"":vo.getUname().trim());
		  }
		  List<PhoneUsersMailVO> temList=this.phoneUsersService.findPhoneUser(map);
		  pages.setItems(temList);
		  pages.setTotalCount(phoneUsersService.count(map));
		  modelMap.addAttribute("page",pages);
		  modelMap.addAttribute("list","list");
	} catch (Exception e) {
		e.printStackTrace();
		log.error(e.getMessage());
	}		
	}
	//查询
	public void listForFind(ModelMap modelMap, int startIndex,PhoneUsersMailVO vo) {
		try {
			Pages<PhoneUsersMailVO> pages = new Pages<PhoneUsersMailVO>(startIndex);
			Map<Object, Object> map = new HashMap<Object, Object>();
		if (vo.getUname()!="") {
			map.put("uname", vo.getUname());
			modelMap.addAttribute("uname", vo.getUname());
		}
		if (vo.getTelephone()!="") {
			map.put("telephone", vo.getTelephone());
			modelMap.addAttribute("telephone", vo.getTelephone());
		}
			//map.put("sendType", "2");
			map.put("startIndex", startIndex);
			map.put("pageSize", 10);
			List<PhoneUsersMailVO> list = this.phoneUsersService.findAllShow(map);
			//List<MsgSendVO> mList = this.msgSendService.poListToVoList(list);
			pages.setItems(list);
			pages.setTotalCount(phoneUsersService.countFindAllShow(map));
			modelMap.addAttribute("page", pages);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}

	}
	//显示详细畅达币
	public void toCoin(ModelMap modelMap, String Id,int startIndex ,HttpServletRequest request) {
		//根据手机号获取会员id
		
		String phone = request.getParameter("phone");
		//Id = "";
		if(!("".equals(phone)||phone =="") && (Id =="" || "".equals(Id))){
			PhoneUsersPO po = phoneUsersService.findByPhone(phone);
			if(po == null){
				Id = "0";
				modelMap.addAttribute("flag", "-1");
			}else{
				Id = po.getUserid()+"";
			}
		}
		//查询会员信息
		PhoneUsersPO phoneUserpo = phoneUsersService.find(Id);
		modelMap.addAttribute("phoneUserpo", phoneUserpo);
		
		//查询畅达币信息
		AbstractWebserviceInvoker webserviceInvoker = new LcdCoinInfosHandler();
		Map<String,Object> phoneCoinInfo = (Map<String,Object>)webserviceInvoker.invoke(WebServiceConstant.getTicketNewPoint(), 
				"getMLcdCoinInfos",WebServiceConstant.getQname(),new Object[] {Id});
		modelMap.addAttribute("phoneCoinPO", phoneCoinInfo);
		
		// 获取会员畅达币明细
		Pages page = new Pages(startIndex);
		Map<Object, Object> map = new HashMap<Object, Object>();
		//map.put("startIndex", startIndex);
		map.put("userid", Id);
		
		String coinstutas = request.getParameter("coinstutas");
		String startDate = request.getParameter("startDate");
		String endDate = request.getParameter("endDate");
		String details=request.getParameter("coinDetails");
		
		String coinDetails=details==null?details:details.trim();
		map.put("coinstutas", coinstutas);
		map.put("startDate", startDate);
		map.put("endDate", endDate);
		map.put("coinDetails", coinDetails);
		
		//map.put("pageSize", 10);
		map.put("page", page);
		
		List<Map> temList = phoneCoinDetailsService.findByUserId1(map);
		page.setItems(temList);
		page.setTotalCount(phoneCoinDetailsService.countFindAllForPage1(map));
		modelMap.addAttribute("page", page);
		if("'00','TJ','02','03'".equals(coinstutas)){
			coinstutas = "00";
		}else if(!"".equals(coinstutas) && coinstutas !=null){
			coinstutas = coinstutas.replaceAll("'", "");
		}
		modelMap.addAttribute("coinstutas", coinstutas);
		modelMap.addAttribute("startDate", startDate);
		modelMap.addAttribute("endDate", endDate);
		modelMap.addAttribute("coinDetails", coinDetails);
		//modelMap.addAttribute("flag", "0");
	}
	
	//显示会员信息
	public void usermail(ModelMap modelMap, String Id,int startIndex) {
		//获取会员常用邮寄地址
		 Pages<PhoneUsersMailVO> pages=new Pages<PhoneUsersMailVO>(startIndex);
		  Map<Object,Object> map=new HashMap<Object,Object>();
		  map.put("startIndex", startIndex);
		  map.put("userid", Id);
		  map.put("pageSize", 10);
		  List<PhoneUsersMailVO> findAllShow = phoneUsersService.findAllShow(map);
		 pages.setItems(findAllShow);
		  pages.setTotalCount(phoneUsersService.findMailCount(Id));
		modelMap.addAttribute("page", pages);

	}
	
	/**
	 * 判断手机号码是否是掌上航旅会员
	 *  返回1表示是，返回0表示不是，其他情况返回-1
	 * @return
	 */
	public String isPhoneUser(String userPhone){
 		String  result = "0";
		try {
			int tt = phoneUsersService.countsByUserPhone(userPhone);
			if(tt>0){
				result = "1";
			}
		} catch (Exception e) {
			result = "-1";
		}
		return result;
	}
	
	/**
	 * 掌上航旅用户账户转移
	 * 1.转移的手机号不是掌上航旅会员，直接将转移的手机号替换原手机号
	 * 2.转移的手机号是掌上航旅会员，则删除该会员信息，将转移的手机号替换原手机号
	 * @param newUserPhone转移的手机号
	 * @param flag=1转移手机号是掌上航旅会员，=0不是
	 * @param oldUserId 原会员id
	 * @return 返回值=1表示成功    =0表示失败
	 */
	public String replaceUser(String newUserPhone,String flag,String oldUserId,String oldUserPhone){
		String  result = "1";
		try {
//			if("1".equals(flag) || flag=="1"){
//				//转移的手机号是掌上航旅会员，则删除该会员信息，将转移的手机号替换原手机号
//			}else{
//				//转移的手机号不是掌上航旅会员，直接将转移的手机号替换原手机号
//			}
			phoneUsersService.replaceUser1(newUserPhone,flag,oldUserId,oldUserPhone);
		} catch (Exception e) {
			e.printStackTrace();
			result = "0";
		}
		return result;
	}
	/**
	 * 会员信息维护查询
	 * @param userid
	 * @return
	 */
	public void  manageFindById(ModelMap modelMap,String userid,String version)
	{
		 Map<Object,Object> map=new HashMap<Object,Object>();
		  map.put("userid", userid);
		  map.put("version", version);
		PhoneUsersMailVO bean=phoneUsersService.manageFindById(map);
		/*if("1".equals(bean.getCardtype())&&bean.getCardno()!=null)
		{
		bean.setBirthday(IdcardUtils.getBirthByIdCard(bean.getCardno()));
		bean.setSex("M".equals(IdcardUtils.getGenderByIdCard(bean.getCardno()))? "男":"女");
		}*/
		modelMap.addAttribute("bean", bean);
	}
	/**
	 * 修改会员备注
	 * @param po 
	 */
	public String updateRemark(PhoneUsersMailVO po)
	{
		String result = "success";
		try {
			phoneUsersService.updateRemark(po);
		} catch (AppException e) {
			result = "failed";
		}
		return result;
	}

}