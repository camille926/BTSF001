package cn.itkt.btsf.phone.users.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/phone/users/tempflight")
public class TempFlightController {

	@Resource
	private  TempFlightControllerSupport  tempFlightControllerSupport;




}