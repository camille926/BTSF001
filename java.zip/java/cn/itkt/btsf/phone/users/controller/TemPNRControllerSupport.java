package cn.itkt.btsf.phone.users.controller;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.phone.users.service.TemPNRService;

@Service
public class TemPNRControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(TemPNRControllerSupport.class);
	
	@Resource
	private  TemPNRService  temPNRService;
	



}