package cn.itkt.btsf.phone.users.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.btsf.phone.users.vo.PhoneOrderShowVO;
import cn.itkt.btsf.sys.cc.national.po.OrderMsgExtPO;
import cn.itkt.exception.AppException;


@Controller
@RequestMapping("/phone/users/phoneorder")
public class PhoneOrderController {

	@Resource
	private  PhoneOrderControllerSupport  phoneOrderControllerSupport;
	
	/**
	 * 分页
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/list")
	public String list(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex){
		//调用Support处理业务逻辑
		phoneOrderControllerSupport.list(modelMap, startIndex);
		modelMap.addAttribute("list", "list");
		return "phone/order/view";		
		
	}
	
	/**
	 * 改变行程单方式
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/getWay")
	public ModelAndView getWay(ModelMap modelMap,	
			@RequestParam(value="Id" ,required=false, defaultValue="0") String Id,
			@RequestParam(value="getitinerary" ,required=false, defaultValue="0") String getitinerary){
		//调用Support处理业务逻辑
		phoneOrderControllerSupport.getWay(modelMap, Id,getitinerary);
	
		return new ModelAndView("jsonView");	
		
	}
	
	/**
	 * 分页--条件查询
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/listForfind")
	public String list1(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,long userId){
		//调用Support处理业务逻辑
		phoneOrderControllerSupport.listForFind(modelMap, startIndex, userId);
		return "phone/user/orderInfo";		
	}
	
	
	/**
	 * 跳转修改行程单邮寄
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toPost")
	public String toPost(ModelMap modelMap,
			@RequestParam(value="Id" ,required=false, defaultValue="") String Id){
		
		this.phoneOrderControllerSupport.toPost(modelMap, Id);
		
		return "phone/order/post";
	}
	
	/**
	 * 新增或更新
	 * @param modelMap
	 * @param 
	 * @return
	 */
	@RequestMapping(value="/addOrUpdate")
	public ModelAndView addOrUpdate(ModelMap modelMap,@ModelAttribute("OrderMsgExtPO") OrderMsgExtPO orderMsgExtPO){
		this.phoneOrderControllerSupport.addOrupdate(modelMap, orderMsgExtPO);
		return new ModelAndView("jsonView");
	}
	
	/**
	 * 注册指定日期格式的日期属性编辑器
	 * 
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		formater.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formater, true));
	}
	
	/**
	 * 待用方法（未用）
	 * @param modelMap
	 * @param orderId
	 * @return
	 */
	@RequestMapping(value="/validationOrderNo")
	public ModelAndView validationOrderNo(ModelMap modelMap,@RequestParam(value="orderId",required=false,defaultValue="") String orderId){
		 this.phoneOrderControllerSupport.validationOrderNo(modelMap,orderId);
		 return new ModelAndView("jsonView");
	}

	/*@RequestMapping(value="/seeAll")
	public String seeAll(ModelMap modelMap,
			@RequestParam(value="Id" ,required=false, defaultValue="") String Id) throws AppException{
		Boolean flag=this.phoneOrderControllerSupport.seeAll(modelMap,Id);
		if (flag==false) {
			return "/sys/cc/orderManage/outPutTicketDetail";
		}else {
			return "phone/order/show";
		}
		
	}*/



}