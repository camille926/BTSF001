package cn.itkt.btsf.phone.users.po;

import java.io.Serializable;


/**
 * 移动商旅_班车机场信息 
 * @author codegen 2011-10-15 16:55:58 
 */
public class PhoneAirportShuttlePO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
	/** ���   �� **/ 
	private long id;
	
    /** ���� **/ 
	private String name;
	

	/**
	 * 构造 
	 */
	public PhoneAirportShuttlePO() {
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}