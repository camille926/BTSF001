package cn.itkt.btsf.phone.users.po;



import java.io.Serializable;


/**
 * 临时表_旅客信息 
 * @author codegen 2011-11-17 16:34:51 
 */
public class TempPassengerPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** �� **/ 
	private long id;
	
    /** 旅客姓名�ÿ����� **/ 
	private String passengerName;
	
    /** 旅客类型0成人1儿童2婴儿�� **/ 
	private String passengerType;
	
    /**旅客证件号码 �ÿ�֤������ **/ 
	private String passengerIdno;
	
    /** 旅客证件类型�ÿ�֤������ **/ 
	private String passengerIdtype;
	
    /**旅客出生年月 �ÿͳ������� **/ 
	private String passengerBirthday;
	
    /**旅客联系电话**/ 
	private String passengerTelephone;
	
    /**旅客的常旅客卡 **/ 
	private String passengerMileagecard;
	
    /**旅客的航空公司卡 **/ 
	private String passengerAirlinemileagecard;
	
    /** 旅客的订票全票价 **/ 
	private double passengerFullprice;
	
    /** 机票的燃油税��Ʊ��ȼ��˰ **/ 
	private double passengerFueltax;
	
    /** 机票的机场建设费��Ʊ�Ļ���� **/ 
	private double passengerAirporttax;
	
    /**外键 ��� **/ 
	private long btsfTempTerminaldoId;
	
    /** 保险的份数 **/ 
	private double insurancecount;
	
    /** 保险的总金额���յ��ܽ� **/ 
	private double insurancemoney;
	
    /**返程全票价 ����ȫƱ�� **/ 
	private double passengerFullpriceReturn;
	
    /** 返程燃油税����ȼ��˰ **/ 
	private double passengerFueltaxReturn;
	
    /** 返程机建费���̻�� **/ 
	private double passengerAirporttaxReturn;
	
    /** ��������所属部门 **/ 
	private String deptName;
	
    /** 操作人���� **/ 
	private String operName;
	
    /**成本中心 �ɱ����� **/ 
	private String costCenter;
	

	/**
	 * 构造 
	 */
	public TempPassengerPO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getPassengerType() {
		return passengerType;
	}

	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public String getPassengerIdno() {
		return passengerIdno;
	}

	public void setPassengerIdno(String passengerIdno) {
		this.passengerIdno = passengerIdno;
	}
	public String getPassengerIdtype() {
		return passengerIdtype;
	}

	public void setPassengerIdtype(String passengerIdtype) {
		this.passengerIdtype = passengerIdtype;
	}
	public String getPassengerBirthday() {
		return passengerBirthday;
	}

	public void setPassengerBirthday(String passengerBirthday) {
		this.passengerBirthday = passengerBirthday;
	}
	public String getPassengerTelephone() {
		return passengerTelephone;
	}

	public void setPassengerTelephone(String passengerTelephone) {
		this.passengerTelephone = passengerTelephone;
	}
	public String getPassengerMileagecard() {
		return passengerMileagecard;
	}

	public void setPassengerMileagecard(String passengerMileagecard) {
		this.passengerMileagecard = passengerMileagecard;
	}
	public String getPassengerAirlinemileagecard() {
		return passengerAirlinemileagecard;
	}

	public void setPassengerAirlinemileagecard(String passengerAirlinemileagecard) {
		this.passengerAirlinemileagecard = passengerAirlinemileagecard;
	}
	public double getPassengerFullprice() {
		return passengerFullprice;
	}

	public void setPassengerFullprice(double passengerFullprice) {
		this.passengerFullprice = passengerFullprice;
	}
	public double getPassengerFueltax() {
		return passengerFueltax;
	}

	public void setPassengerFueltax(double passengerFueltax) {
		this.passengerFueltax = passengerFueltax;
	}
	public double getPassengerAirporttax() {
		return passengerAirporttax;
	}

	public void setPassengerAirporttax(double passengerAirporttax) {
		this.passengerAirporttax = passengerAirporttax;
	}
	public long getBtsfTempTerminaldoId() {
		return btsfTempTerminaldoId;
	}

	public void setBtsfTempTerminaldoId(long btsfTempTerminaldoId) {
		this.btsfTempTerminaldoId = btsfTempTerminaldoId;
	}
	public double getInsurancecount() {
		return insurancecount;
	}

	public void setInsurancecount(double insurancecount) {
		this.insurancecount = insurancecount;
	}
	public double getInsurancemoney() {
		return insurancemoney;
	}

	public void setInsurancemoney(double insurancemoney) {
		this.insurancemoney = insurancemoney;
	}
	public double getPassengerFullpriceReturn() {
		return passengerFullpriceReturn;
	}

	public void setPassengerFullpriceReturn(double passengerFullpriceReturn) {
		this.passengerFullpriceReturn = passengerFullpriceReturn;
	}
	public double getPassengerFueltaxReturn() {
		return passengerFueltaxReturn;
	}

	public void setPassengerFueltaxReturn(double passengerFueltaxReturn) {
		this.passengerFueltaxReturn = passengerFueltaxReturn;
	}
	public double getPassengerAirporttaxReturn() {
		return passengerAirporttaxReturn;
	}

	public void setPassengerAirporttaxReturn(double passengerAirporttaxReturn) {
		this.passengerAirporttaxReturn = passengerAirporttaxReturn;
	}
	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getOperName() {
		return operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}
	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

}