package cn.itkt.btsf.phone.users.po;



import java.io.Serializable;


/**
 * 临时表_航班信息 
 * @author codegen 2011-11-17 19:51:16 
 */
public class TempFlightPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** �� **/ 
	private long id;
	
    /**出发机场 ������ **/ 
	private String flightStartcity;
	
    /** 到达机场����� **/ 
	private String flightArrivalcity;
	
    /** 出发时间����ʱ�� **/ 
	private String flightStartdate;
	
    /** 舱位 **/ 
	private String flightCabin;
	
    /** 基础舱位 **/ 
	private String flightBasecabin;
	
    /** 航空公司���չ�˾ **/ 
	private String flightAirline;
	
    /** 航班号����� **/ 
	private String flightFlightno;
	
    /**外键 ��� **/ 
	private long btsfTempTerminaldoId;
	
    /** 特价航班编号�ؼۺ����� **/ 
	private String specialflightNum;
	
    /** 到达时间����ʱ�� **/ 
	private String flightArrivaldate;
	
    /**定票OFFICENO ��ƱOFFICENO **/ 
	private String officeno;
	
    /** 返点z值����zֵ **/ 
	private long zvalue;
	
    /** RULESUMMARY 退改签规定摘要**/ 
	private String rulesummary;
	
    /**退改签规定内容**/ 
	private String eicoment;
	
    /** 票价级别 **/ 
	private String pricetype;
	
    /** 票价折扣 **/ 
	private String pricediscount;
	
    /**出票时限 ��Ʊʱ�� **/ 
	private String outtimelimit;
	
    /** 舱位的折扣率**/ 
	private String cabindiscount;
	
    /** ���ȥ�̻�����PNR区分去程还是往返PNR **/ 
	private String flightsite;
	
    /** 航段类型（单程01往返02） **/ 
	private String flighttype;
	
    /**是否为特价往返0为是，1为不是**/ 
	private String isspecialflightreturn;
	
    /** �� 机型**/ 
	private String planetype;
	
    /** bjs724返点 **/ 
	private double basevalue;
	

	/**
	 * 构造 
	 */
	public TempFlightPO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getFlightStartcity() {
		return flightStartcity;
	}

	public void setFlightStartcity(String flightStartcity) {
		this.flightStartcity = flightStartcity;
	}
	public String getFlightArrivalcity() {
		return flightArrivalcity;
	}

	public void setFlightArrivalcity(String flightArrivalcity) {
		this.flightArrivalcity = flightArrivalcity;
	}
	public String getFlightStartdate() {
		return flightStartdate;
	}

	public void setFlightStartdate(String flightStartdate) {
		this.flightStartdate = flightStartdate;
	}
	public String getFlightCabin() {
		return flightCabin;
	}

	public void setFlightCabin(String flightCabin) {
		this.flightCabin = flightCabin;
	}
	public String getFlightBasecabin() {
		return flightBasecabin;
	}

	public void setFlightBasecabin(String flightBasecabin) {
		this.flightBasecabin = flightBasecabin;
	}
	public String getFlightAirline() {
		return flightAirline;
	}

	public void setFlightAirline(String flightAirline) {
		this.flightAirline = flightAirline;
	}
	public String getFlightFlightno() {
		return flightFlightno;
	}

	public void setFlightFlightno(String flightFlightno) {
		this.flightFlightno = flightFlightno;
	}
	public long getBtsfTempTerminaldoId() {
		return btsfTempTerminaldoId;
	}

	public void setBtsfTempTerminaldoId(long btsfTempTerminaldoId) {
		this.btsfTempTerminaldoId = btsfTempTerminaldoId;
	}
	public String getSpecialflightNum() {
		return specialflightNum;
	}

	public void setSpecialflightNum(String specialflightNum) {
		this.specialflightNum = specialflightNum;
	}
	public String getFlightArrivaldate() {
		return flightArrivaldate;
	}

	public void setFlightArrivaldate(String flightArrivaldate) {
		this.flightArrivaldate = flightArrivaldate;
	}
	public String getOfficeno() {
		return officeno;
	}

	public void setOfficeno(String officeno) {
		this.officeno = officeno;
	}
	public long getZvalue() {
		return zvalue;
	}

	public void setZvalue(long zvalue) {
		this.zvalue = zvalue;
	}
	public String getRulesummary() {
		return rulesummary;
	}

	public void setRulesummary(String rulesummary) {
		this.rulesummary = rulesummary;
	}
	public String getEicoment() {
		return eicoment;
	}

	public void setEicoment(String eicoment) {
		this.eicoment = eicoment;
	}
	public String getPricetype() {
		return pricetype;
	}

	public void setPricetype(String pricetype) {
		this.pricetype = pricetype;
	}
	public String getPricediscount() {
		return pricediscount;
	}

	public void setPricediscount(String pricediscount) {
		this.pricediscount = pricediscount;
	}
	public String getOuttimelimit() {
		return outtimelimit;
	}

	public void setOuttimelimit(String outtimelimit) {
		this.outtimelimit = outtimelimit;
	}
	public String getCabindiscount() {
		return cabindiscount;
	}

	public void setCabindiscount(String cabindiscount) {
		this.cabindiscount = cabindiscount;
	}
	public String getFlightsite() {
		return flightsite;
	}

	public void setFlightsite(String flightsite) {
		this.flightsite = flightsite;
	}
	public String getFlighttype() {
		return flighttype;
	}

	public void setFlighttype(String flighttype) {
		this.flighttype = flighttype;
	}
	public String getIsspecialflightreturn() {
		return isspecialflightreturn;
	}

	public void setIsspecialflightreturn(String isspecialflightreturn) {
		this.isspecialflightreturn = isspecialflightreturn;
	}
	public String getPlanetype() {
		return planetype;
	}

	public void setPlanetype(String planetype) {
		this.planetype = planetype;
	}
	public double getBasevalue() {
		return basevalue;
	}

	public void setBasevalue(double basevalue) {
		this.basevalue = basevalue;
	}

}