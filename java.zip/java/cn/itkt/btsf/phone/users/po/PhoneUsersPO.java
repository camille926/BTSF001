package cn.itkt.btsf.phone.users.po;

import java.io.Serializable;
import java.util.Date;
import java.util.List;


/**
 * 移动商旅_会员表 
 * @author codegen 2011-10-14 15:06:10 
 */
public class PhoneUsersPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	/**pu.userid, pu.remark, coin.lcdcoin**/
	/** ��ţ���ԱID�� **/ 
	private long userid;
	
    /** ��Ա�ֻ� **/ 
	private String telephone;
	
    /** ��Ա���� **/ 
	private String password;
	
    /** ��Ա�� **/ 
	private String name;
	
    /** ��Ա���� **/ 
	private String email;
	
    /** ע��ʱ�� **/ 
	private Date adddate;
	
	/**扩展字段 详细地址**/
	private List<String> address;
	
    /** ��Դ   ��0�� Android
	��1�� Mobile **/ 
	private String source;
	
	private String recommendPhone;
	
	private String remark;
	
	private String lcdcoin;

	/**
	 * 构造 
	 */
	public PhoneUsersPO() {
	}
	
	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public Date getAdddate() {
		return adddate;
	}

	public void setAdddate(Date adddate) {
		this.adddate = adddate;
	}
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getRecommendPhone() {
		return recommendPhone;
	}

	public void setRecommendPhone(String recommendPhone) {
		this.recommendPhone = recommendPhone;
	}

	public List<String> getAddress() {
		return address;
	}

	public void setAddress(List<String> address) {
		this.address = address;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getLcdcoin() {
		return lcdcoin;
	}

	public void setLcdcoin(String lcdcoin) {
		this.lcdcoin = lcdcoin;
	}


}