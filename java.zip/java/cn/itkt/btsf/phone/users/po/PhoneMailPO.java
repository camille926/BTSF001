package cn.itkt.btsf.phone.users.po;

import java.io.Serializable;


/**
 * 移动商旅_行程单邮寄地址表 
 * @author codegen 2011-10-14 16:12:17 
 */
public class PhoneMailPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
	/** ��ţ��ʼĵ�ַID�� **/ 
	private long addressid;
	
    /** ��ԱID **/ 
	private long userid;
	
    /** �ռ������� **/ 
	private String name;
	
    /** �������� **/ 
	private String postcode;
	
    /** �ʼĵ�ַ **/ 
	private String postaladdress;
	

	/**
	 * 构造 
	 */
	public PhoneMailPO() {
	}
	
	public long getAddressid() {
		return addressid;
	}

	public void setAddressid(long addressid) {
		this.addressid = addressid;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getPostaladdress() {
		return postaladdress;
	}

	public void setPostaladdress(String postaladdress) {
		this.postaladdress = postaladdress;
	}

}