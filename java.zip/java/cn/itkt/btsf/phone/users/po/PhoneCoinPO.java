package cn.itkt.btsf.phone.users.po;

import java.io.Serializable;


/**
 * 移动商旅_会员畅达币表 
 * @author codegen 2011-10-14 16:22:02 
 */
public class PhoneCoinPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
	/** ���� 主键  编号 ��� **/ 
	private long id;
	
    /** ��ԱID **/ 
	private long userid;
	
    /** 可用畅达币���ó���� **/ 
	private String lcdcoin;
	
    /** 累计畅达币 **/ 
	private String alllcdcoin;
	
    /** 畅达币账号������˺� **/ 
	private String accountnumber;
	

	/**
	 * 构造 
	 */
	public PhoneCoinPO() {
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getLcdcoin() {
		return lcdcoin;
	}

	public void setLcdcoin(String lcdcoin) {
		this.lcdcoin = lcdcoin;
	}
	public String getAlllcdcoin() {
		return alllcdcoin;
	}

	public void setAlllcdcoin(String alllcdcoin) {
		this.alllcdcoin = alllcdcoin;
	}
	public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

}