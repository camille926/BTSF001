package cn.itkt.btsf.phone.users.po;



import java.io.Serializable;


/**
 * PNR信息表  
 * @author codegen 2011-11-17 16:36:46 
 */
public class TemPNRPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** �� **/ 
	private long id;
	
    /** PNR号**/ 
	private String pnrNo;
	
    /** PNR ID **/ 
	private String pnrId;
	
    /** 旅客类型：0成人，1儿童，2婴儿 **/ 
	private String passengerType;
	
    /** 外键��� **/ 
	private long btsfTempTerminaldoId;
	
    /**区分去程还是往返PNR ���ȥ�̻�����PNR **/ 
	private String flightsite;
	
    /** 山东航空公司提供的大客户编码 **/ 
	private String scJgkh;
	
    /**来源51book：51BOOK；隆畅达：“”，linkosky **/ 
	private String source;
	
    /**51bookID **/ 
	private String policyid;
	

	/**
	 * 构造 
	 */
	public TemPNRPO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}
	public String getPnrId() {
		return pnrId;
	}

	public void setPnrId(String pnrId) {
		this.pnrId = pnrId;
	}
	public String getPassengerType() {
		return passengerType;
	}

	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public long getBtsfTempTerminaldoId() {
		return btsfTempTerminaldoId;
	}

	public void setBtsfTempTerminaldoId(long btsfTempTerminaldoId) {
		this.btsfTempTerminaldoId = btsfTempTerminaldoId;
	}
	public String getFlightsite() {
		return flightsite;
	}

	public void setFlightsite(String flightsite) {
		this.flightsite = flightsite;
	}
	public String getScJgkh() {
		return scJgkh;
	}

	public void setScJgkh(String scJgkh) {
		this.scJgkh = scJgkh;
	}
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
	public String getPolicyid() {
		return policyid;
	}

	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}

}