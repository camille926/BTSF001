package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.PhoneAirportShuttlePO;

/**
 * 移动商旅_班车机场信息 
 * @author codegen 2011-10-15 16:55:58 
 */
public interface PhoneAirportShuttleDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneAirportShuttle 
	 */
	public PhoneAirportShuttlePO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneAirportShuttlePO> 
	 */
	public List<PhoneAirportShuttlePO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneAirportShuttlePO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneAirportShuttlePO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 获取主键序列
	 * @return
	 */
	public Long getSeqId();

}