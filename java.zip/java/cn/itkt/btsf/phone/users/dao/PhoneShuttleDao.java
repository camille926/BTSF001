package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.users.po.PhoneShuttlePO;
import cn.itkt.btsf.phone.users.vo.PhoneShowAirportShuttleVO;

/**
 * 班车信息 
 * @author codegen 2011-10-15 17:00:55 
 */
public interface PhoneShuttleDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneShuttle 
	 */
	public PhoneShuttlePO find(Serializable id);
	
	
	/**
	 * 查找所有--分页  
	 * @return List<PhoneUsersPO> 
	 */
	public List<PhoneShowAirportShuttleVO> findAllShow(Map<Object,Object> map);
	
	
	/**
	 * 取站内所有数据行
	 * @param po 
	 */
	public int countFindAllShow(Map<Object,Object> map);

	/**
	 * 查找所有 
	 * @return List<PhoneShuttlePO> 
	 */
	public List<PhoneShuttlePO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneShuttlePO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneShuttlePO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(String[] id);

}