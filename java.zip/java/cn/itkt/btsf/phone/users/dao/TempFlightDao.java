package cn.itkt.btsf.phone.users.dao;



import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.TempFlightPO;





/**
 * 临时表_航班信息 
 * @author codegen 2011-11-17 19:51:16 
 */
public interface TempFlightDao {

	/**
	 * 查找单个 --根据外键
	 * @param id 
	 * @return TempFlight 
	 */
	public List<TempFlightPO> find(Serializable btsfTempTerminaldoId);

	/**
	 * 查找所有 
	 * @return List<TempFlightPO> 
	 */
	public List<TempFlightPO> findAll();

}