package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.PhoneMailPO;

/**
 * 移动商旅_行程单邮寄地址表 
 * @author codegen 2011-10-14 16:12:17 
 */
public interface PhoneMailDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneMail 
	 */
	public PhoneMailPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneMailPO> 
	 */
	public List<PhoneMailPO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneMailPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneMailPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);

}