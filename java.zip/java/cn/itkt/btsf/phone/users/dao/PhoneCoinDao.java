package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.PhoneCoinPO;

/**
 * 移动商旅_会员畅达币表 
 * @author codegen 2011-10-14 16:22:02 
 */
public interface PhoneCoinDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneCoin 
	 */
	public PhoneCoinPO find(Serializable id);
	/**
	 * 根据用户id查询
	 * @param userid
	 * @return
	 */
	public PhoneCoinPO findByUserId(String userid);

	/**
	 * 查找所有 
	 * @return List<PhoneCoinPO> 
	 */
	public List<PhoneCoinPO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneCoinPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneCoinPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);

}