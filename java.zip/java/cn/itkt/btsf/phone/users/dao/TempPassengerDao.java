package cn.itkt.btsf.phone.users.dao;



import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.TempPassengerPO;





/**
 * 临时表_旅客信息 
 * @author codegen 2011-11-17 16:34:51 
 */
public interface TempPassengerDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return TempPassenger 
	 */
	public List<TempPassengerPO> find(Serializable btsfTempTerminaldoId);

	/**
	 * 查找所有 
	 * @return List<TempPassengerPO> 
	 */
	public List<TempPassengerPO> findAll();



}