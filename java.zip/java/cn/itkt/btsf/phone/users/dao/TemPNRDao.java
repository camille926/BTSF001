package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.users.po.TemPNRPO;

/**
 * PNR信息表  
 * @author codegen 2011-11-17 16:36:46 
 */
public interface TemPNRDao {

	/**
	 * 查找单个 --根据外键
	 * @param id 
	 * @return TemPNR 
	 */
	public List<TemPNRPO> find(Serializable btsfTempTerminaldoId);

	/**
	 * 查找所有 
	 * @return List<TemPNRPO> 
	 */
	public List<TemPNRPO> findAll();


}