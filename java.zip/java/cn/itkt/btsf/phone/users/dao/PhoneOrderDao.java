package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.users.po.PhoneOrderPO;
import cn.itkt.btsf.phone.users.vo.PhoneOrderShowVO;

/**
 * 移动商旅_订单表 
 * @author codegen 2011-10-18 17:02:39 
 */
public interface PhoneOrderDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneOrder 
	 */
	public PhoneOrderPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneOrderPO> 
	 */
	public List<PhoneOrderPO> findAll();
	
	
	/**
	 * 查找所有--分页  
	 * @return List<PhoneUsersPO> 
	 */
	public List<PhoneOrderShowVO> findAllShow(Map<Object,Object> map);
	
	/**
	 * 取站内所有数据行
	 * @param po 
	 */
	public int countFindAllShow(Map<Object,Object> map);
	

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneOrderPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneOrderPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 根据订单id茶隼
	 * @param orderId
	 * @return
	 */
	public PhoneOrderPO findByOrderId (String orderId);
	
	/**
	 * 查询移动商旅订单扩展信息
	 * 
	 * @param orderId
	 * @return
	 */
	public PhoneOrderShowVO findPhoneOrderExt(Long orderId);

}