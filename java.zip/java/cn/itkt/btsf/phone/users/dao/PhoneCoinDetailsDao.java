package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.users.po.PhoneCoinDetailsPO;

/**
 * 移动商旅_畅达币明细表 
 * @author codegen 2011-10-14 16:26:31 
 */
public interface PhoneCoinDetailsDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneCoinDetails 
	 */
	public PhoneCoinDetailsPO find(Serializable id);
	
	/**
	 * 根据用户id查询
	 * @param userid
	 * @return
	 */
	public List<PhoneCoinDetailsPO> findByUserId(Map map);
	
	public List<Map> findByUserId1(Map map);
	/**
	 * 根据用户id查询
	 * @param userid
	 * @return
	 */
	public int countFindAllForPage(Map map);
	
	public int countFindAllForPage1(Map map);

	/**
	 * 查找所有 
	 * @return List<PhoneCoinDetailsPO> 
	 */
	public List<PhoneCoinDetailsPO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneCoinDetailsPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneCoinDetailsPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	/****
	 * 根据用户ID, 客票ID, 交易类型,查询 移动商旅_畅达币明细表 
	 * @param userId 用户ID
	 * @param ticketId 客票ID
	 * @param exchangeType  交易类型
	 * @return
	 */
	public List<PhoneCoinDetailsPO> findByUserIdAndTicketId(Map<String, Object> params);
	
	public List findByUpdateDetails(Map<String, Object> params);

}