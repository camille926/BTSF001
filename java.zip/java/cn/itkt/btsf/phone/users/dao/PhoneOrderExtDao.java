package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Date;

import cn.itkt.btsf.phone.users.po.PhoneOrderExtPO;

/**
 * 移动商旅_订单扩展表 
 * @author codegen 2012-04-09 14:11:07 
 */
public interface PhoneOrderExtDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneOrderExt 
	 */
	public PhoneOrderExtPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneOrderExtPO> 
	 */
	public List<PhoneOrderExtPO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneOrderExtPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneOrderExtPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	/**
	 * 更改移动商旅订单扩展表的移动商旅客户信息。
	 * 比如把订单扩展表的A客户改成B客户
	 * 
	 * @param po
	 * @return
	 */
	public int updateUserForOrder(PhoneOrderExtPO po);
	/**
	 * 根据订单id查找订单扩展信息
	 * @param orderId
	 * @return
	 */
	public PhoneOrderExtPO findByOrderId(Long orderId);

}