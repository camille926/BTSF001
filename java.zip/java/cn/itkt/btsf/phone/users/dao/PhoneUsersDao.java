package cn.itkt.btsf.phone.users.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.phone.users.vo.PhoneUsersMailVO;

/**
 * 移动商旅_会员表 
 * @author codegen 2011-10-14 15:06:10 
 */
public interface PhoneUsersDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneUsers 
	 */
	public PhoneUsersPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneUsersPO> 
	 */
	public List<PhoneUsersPO> findAll(Map<String,Object> map);
	
	/**
	 * 查找所有--分页  
	 * @return List<PhoneUsersPO> 
	 */
	public List<PhoneUsersMailVO> findAllShow(Map<Object,Object> map);
	
	/**
	 * 取站内所有数据行
	 * @param po 
	 */
	public int countFindAllShow(Map<Object,Object> map);
	
	

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneUsersPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneUsersPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	/**
	 * 查找分页数据
	 * @param map
	 * @return
	 */
	public List<PhoneUsersMailVO> findPhoneUser(Map<Object,Object> map);
	/**
	 * 统计
	 * @return
	 */
	public int count(Map<Object,Object> map);
	
	public PhoneUsersPO findUserByExtId(long id);
	/**
	 * 查找用户的行程单邮寄地址信息
	 * @param userid
	 * @return
	 */
	public int findMailCount(String userid);

	/**
	 * 根据用户的手机号查询是否是掌上航旅会员
	 * @param userPhone
	 * @return
	 */
	public int countsByUserPhone(String userPhone);
	/**
	 * 将新的原手机号更新为新手机号
	 * @return
	 */
	public int updateByPhone(Map<String,Object> map);
	/**
	 * 将该手机号指定的用户删除
	 * @param newUserPhone
	 */
	public void deleteByPhone1(String newUserPhone);
	
	public PhoneUsersPO findByPhone(String phone);
	/**
	 * 根据手机号查询btsf_sys_popupmbrphone有没有记录
	 * @param phoneno
	 * @return
	 */
	public int findPopupmbrphoneByPhone(String oldUserPhone);
	/**
	 * 删除该手机号代表的那条记录
	 * @param map
	 * @return
	 */
	public void deletePopupmbrphone(String newUserPhone);
	/**
	 * 更新btsf_sys_popupmbrphone
	 * @param map
	 * @return
	 */
	public void updatePopupmbrphone(Map<String,Object> map);
	/**
	 * 会员信息维护查询
	 * @param userid
	 * @return
	 */
	public PhoneUsersMailVO manageFindById(Map<Object,Object> map);
	/**
	 * 修改会员备注
	 * @param po 
	 */
	public void updateRemark(PhoneUsersMailVO po);
}