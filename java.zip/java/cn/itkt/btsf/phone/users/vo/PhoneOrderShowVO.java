package cn.itkt.btsf.phone.users.vo;

import java.util.Date;

public class PhoneOrderShowVO {

	//订单表主键
	private long oid;
	
	private long userid;
	
	//移动商旅会员姓名
	private String userName;
	
    //订单ID 
	private String orderid;

	//订单状态
	private String state;
	
	//手机号码 关联会员表里的手机号码
	private String telNo;
	
	//行程单获取方式 
	private String getitinerary;
	
	//订单产生时间 
	private Date addtime;
	
	//订单产生时间 查询开始时间
	private String addtimeS;
	
	//订单产生时间 查询结束时间
	private String addtimeE;
	
	private String coinstate;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCoinstate() {
		return coinstate;
	}

	public void setCoinstate(String coinstate) {
		this.coinstate = coinstate;
	}

	public String getAddtimeS() {
		return addtimeS;
	}

	public void setAddtimeS(String addtimeS) {
		this.addtimeS = addtimeS;
	}

	public String getAddtimeE() {
		return addtimeE;
	}

	public void setAddtimeE(String addtimeE) {
		this.addtimeE = addtimeE;
	}

	public long getOid() {
		return oid;
	}

	public void setOid(long oid) {
		this.oid = oid;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getTelNo() {
		return telNo;
	}

	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}

	public String getGetitinerary() {
		return getitinerary;
	}

	public void setGetitinerary(String getitinerary) {
		this.getitinerary = getitinerary;
	}

	public Date getAddtime() {
		return addtime;
	}

	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

}
