package cn.itkt.btsf.phone.users.vo;

import java.util.Date;
import java.util.List;

import cn.itkt.btsf.sys.cc.national.po.SysMailPO;

public class PhoneUsersMailVO {
	
	/** ��ţ���Ա编号（会员ID） **/ 
	private long userid;
	
    /** ��Ա�ֻ会员手机号� **/ 
	private String telephone;
	
    /** ��Ա����会员密码 **/ 
	private String password;
	
    /** 会员名��Ա�� **/ 
	private String uname;
	
    /** 会员邮箱��Ա���� **/ 
	private String email;
	
	private String province;
	
	private String city;
	
	private String chaneel;
	
    /** 注册时间**/ 
	private Date adddate;
	
    /** ��Դ  ��0�� Android 来源   
��          1�� Mobile **/ 
	private String source;
	
	/** 行程单常用邮寄信息**/
	private List<SysMailPO> mailpo;
	/**畅达币余额 **/
	private String lcdcoin;
	/** 获赠畅达币总额**/
	private String receiptscoin;
	/** 消费总金额**/
	private String amount;
	
	private String recommendPhone;
	
	private String version;
	
	private String channelRemark;
	
	/**会员类型**/
	private String usertype;
	/**证件类型**/
	private String cardtype;
	/**证件号**/
	private String  cardno;
	/**备注**/
	private String  remark;
	/**性别**/
	private String  sex;
	/**出生日期**/
	private String  birthday;
	
	
	public String getLcdcoin() {
		return lcdcoin;
	}

	public void setLcdcoin(String lcdcoin) {
		this.lcdcoin = lcdcoin;
	}

	public String getReceiptscoin() {
		return receiptscoin;
	}

	public void setReceiptscoin(String receiptscoin) {
		this.receiptscoin = receiptscoin;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * mailpo.size
	 */
	private int mailpoList;
	public List<SysMailPO> getMailpo() {
		return mailpo;
	}

	public void setMailpo(List<SysMailPO> mailpo) {
		this.mailpo = mailpo;
	}

	public int getMailpoList() {
		return mailpoList;
	}

	public void setMailpoList(int mailpoList) {
		this.mailpoList = mailpoList;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getAdddate() {
		return adddate;
	}

	public void setAdddate(Date adddate) {
		this.adddate = adddate;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getChaneel() {
		return chaneel;
	}

	public void setChaneel(String chaneel) {
		this.chaneel = chaneel;
	}

	 public String getRecommendPhone() {
		return recommendPhone;
	}

	public void setRecommendPhone(String recommendPhone) {
		this.recommendPhone = recommendPhone;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getChannelRemark() {
		return channelRemark;
	}

	public void setChannelRemark(String channelRemark) {
		this.channelRemark = channelRemark;
	}

	public String getUsertype() {
		if(usertype!=null)
			return usertype.trim();
			else
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public String getCardtype() {
		if(cardtype!=null)
		return cardtype.trim();
		else
		return cardtype;
		
	}

	public void setCardtype(String cardtype) {
		this.cardtype = cardtype;
	}

	public String getCardno() {
		return cardno;
	}

	public void setCardno(String cardno) {
		this.cardno = cardno;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	
}
