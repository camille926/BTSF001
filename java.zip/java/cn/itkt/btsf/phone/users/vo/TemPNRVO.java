package cn.itkt.btsf.phone.users.vo;





/**
 * PNR信息表  
 * @author codegen 2011-11-17 16:36:46 
 */
public class TemPNRVO {

    /** �� **/ 
	private long id;
	
    /** PNR�� **/ 
	private String pnrNo;
	
    /** PNR ID **/ 
	private String pnrId;
	
    /** �ÿ����ͣ�0���ˣ�1��ͯ��2Ӥ�� **/ 
	private String passengerType;
	
    /** ��� **/ 
	private long btsfTempTerminaldoId;
	
    /** ���ȥ�̻�����PNR **/ 
	private String flightsite;
	
    /** ɽ�����չ�˾�ṩ�Ĵ�ͻ����� **/ 
	private String scJgkh;
	
    /** ��Դ51book��51BOOK��¡���������linkosky **/ 
	private String source;
	
    /** 51bookID **/ 
	private String policyid;
	

	/**
	 * 构造 
	 */
	public TemPNRVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}
	public String getPnrId() {
		return pnrId;
	}

	public void setPnrId(String pnrId) {
		this.pnrId = pnrId;
	}
	public String getPassengerType() {
		return passengerType;
	}

	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public long getBtsfTempTerminaldoId() {
		return btsfTempTerminaldoId;
	}

	public void setBtsfTempTerminaldoId(long btsfTempTerminaldoId) {
		this.btsfTempTerminaldoId = btsfTempTerminaldoId;
	}
	public String getFlightsite() {
		return flightsite;
	}

	public void setFlightsite(String flightsite) {
		this.flightsite = flightsite;
	}
	public String getScJgkh() {
		return scJgkh;
	}

	public void setScJgkh(String scJgkh) {
		this.scJgkh = scJgkh;
	}
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}
	public String getPolicyid() {
		return policyid;
	}

	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}

}