package cn.itkt.btsf.phone.users.vo;



/**
 * 移动商旅_行程单邮寄地址表 
 * @author codegen 2011-10-14 16:12:17 
 */
public class PhoneMailVO {

	/** ��ţ��ʼĵ�ַID�� **/ 
	private long addressid;
	
    /** ��ԱID **/ 
	private long userid;
	
    /** �ռ������� **/ 
	private String name;
	
    /** �������� **/ 
	private String postcode;
	
    /** �ʼĵ�ַ **/ 
	private String postaladdress;
	

	/**
	 * 构造 
	 */
	public PhoneMailVO() {
	}
	
	public long getAddressid() {
		return addressid;
	}

	public void setAddressid(long addressid) {
		this.addressid = addressid;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getPostaladdress() {
		return postaladdress;
	}

	public void setPostaladdress(String postaladdress) {
		this.postaladdress = postaladdress;
	}

}