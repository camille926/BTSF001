package cn.itkt.btsf.phone.users.vo;

import java.util.Date;


/**
 * 移动商旅_畅达币明细表 
 * @author codegen 2011-10-14 16:26:31 
 */
public class PhoneCoinDetailsVO {

	/** ����  ��� **/ 
	private long id;
	
	/**
	 * 账户id
	 */
    private long coinaccountid;
    /**
     * 支出畅达币数
     */
	private int paycoin;
	/**
	 * 收入畅达币数
	 */
	private int receiptscoin;
	/**
	 * 交易类型
	 * 00：注册， 01：低价推送，02：正常票返2%畅达币，03：活动，04：兑换，05：退票，06：购票，07：其他
	 */
	private String exchangetype;
	/**
	 * 交易时间
	 */
	private Date exchangetime;
	
	/**
	 * 票id
	 */
	private Long ticketId;
	

	

	public Long getTicketId() {
		return ticketId;
	}

	public void setTicketId(Long ticketId) {
		this.ticketId = ticketId;
	}

	public long getCoinaccountid() {
		return coinaccountid;
	}

	public void setCoinaccountid(long coinaccountid) {
		this.coinaccountid = coinaccountid;
	}

	public int getPaycoin() {
		return paycoin;
	}

	public void setPaycoin(int paycoin) {
		this.paycoin = paycoin;
	}

	public int getReceiptscoin() {
		return receiptscoin;
	}

	public void setReceiptscoin(int receiptscoin) {
		this.receiptscoin = receiptscoin;
	}

	public String getExchangetype() {
		return exchangetype;
	}

	public void setExchangetype(String exchangetype) {
		this.exchangetype = exchangetype;
	}

	public Date getExchangetime() {
		return exchangetime;
	}

	public void setExchangetime(Date exchangetime) {
		this.exchangetime = exchangetime;
	}

	/**
	 * 构造 
	 */
	public PhoneCoinDetailsVO() {
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	

}