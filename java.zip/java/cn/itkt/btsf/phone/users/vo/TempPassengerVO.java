package cn.itkt.btsf.phone.users.vo;





/**
 * 临时表_旅客信息 
 * @author codegen 2011-11-17 16:34:51 
 */
public class TempPassengerVO {

    /** �� **/ 
	private long id;
	
    /** �ÿ����� **/ 
	private String passengerName;
	
    /** �ÿ�����0����1��ͯ2Ӥ�� **/ 
	private String passengerType;
	
    /** �ÿ�֤������ **/ 
	private String passengerIdno;
	
    /** �ÿ�֤������ **/ 
	private String passengerIdtype;
	
    /** �ÿͳ������� **/ 
	private String passengerBirthday;
	
    /** �ÿ���ϵ�绰 **/ 
	private String passengerTelephone;
	
    /** �ÿ͵ĳ��ÿͿ� **/ 
	private String passengerMileagecard;
	
    /** �ÿ͵ĺ��չ�˾�� **/ 
	private String passengerAirlinemileagecard;
	
    /** �ÿ͵Ķ�ƱȫƱ�� **/ 
	private double passengerFullprice;
	
    /** ��Ʊ��ȼ��˰ **/ 
	private double passengerFueltax;
	
    /** ��Ʊ�Ļ���� **/ 
	private double passengerAirporttax;
	
    /** ��� **/ 
	private long btsfTempTerminaldoId;
	
    /** ���յķ��� **/ 
	private double insurancecount;
	
    /** ���յ��ܽ� **/ 
	private double insurancemoney;
	
    /** ����ȫƱ�� **/ 
	private double passengerFullpriceReturn;
	
    /** ����ȼ��˰ **/ 
	private double passengerFueltaxReturn;
	
    /** ���̻�� **/ 
	private double passengerAirporttaxReturn;
	
    /** �������� **/ 
	private String deptName;
	
    /** ���� **/ 
	private String operName;
	
    /** �ɱ����� **/ 
	private String costCenter;
	

	/**
	 * 构造 
	 */
	public TempPassengerVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getPassengerType() {
		return passengerType;
	}

	public void setPassengerType(String passengerType) {
		this.passengerType = passengerType;
	}
	public String getPassengerIdno() {
		return passengerIdno;
	}

	public void setPassengerIdno(String passengerIdno) {
		this.passengerIdno = passengerIdno;
	}
	public String getPassengerIdtype() {
		return passengerIdtype;
	}

	public void setPassengerIdtype(String passengerIdtype) {
		this.passengerIdtype = passengerIdtype;
	}
	public String getPassengerBirthday() {
		return passengerBirthday;
	}

	public void setPassengerBirthday(String passengerBirthday) {
		this.passengerBirthday = passengerBirthday;
	}
	public String getPassengerTelephone() {
		return passengerTelephone;
	}

	public void setPassengerTelephone(String passengerTelephone) {
		this.passengerTelephone = passengerTelephone;
	}
	public String getPassengerMileagecard() {
		return passengerMileagecard;
	}

	public void setPassengerMileagecard(String passengerMileagecard) {
		this.passengerMileagecard = passengerMileagecard;
	}
	public String getPassengerAirlinemileagecard() {
		return passengerAirlinemileagecard;
	}

	public void setPassengerAirlinemileagecard(String passengerAirlinemileagecard) {
		this.passengerAirlinemileagecard = passengerAirlinemileagecard;
	}
	public double getPassengerFullprice() {
		return passengerFullprice;
	}

	public void setPassengerFullprice(double passengerFullprice) {
		this.passengerFullprice = passengerFullprice;
	}
	public double getPassengerFueltax() {
		return passengerFueltax;
	}

	public void setPassengerFueltax(double passengerFueltax) {
		this.passengerFueltax = passengerFueltax;
	}
	public double getPassengerAirporttax() {
		return passengerAirporttax;
	}

	public void setPassengerAirporttax(double passengerAirporttax) {
		this.passengerAirporttax = passengerAirporttax;
	}
	public long getBtsfTempTerminaldoId() {
		return btsfTempTerminaldoId;
	}

	public void setBtsfTempTerminaldoId(long btsfTempTerminaldoId) {
		this.btsfTempTerminaldoId = btsfTempTerminaldoId;
	}
	public double getInsurancecount() {
		return insurancecount;
	}

	public void setInsurancecount(double insurancecount) {
		this.insurancecount = insurancecount;
	}
	public double getInsurancemoney() {
		return insurancemoney;
	}

	public void setInsurancemoney(double insurancemoney) {
		this.insurancemoney = insurancemoney;
	}
	public double getPassengerFullpriceReturn() {
		return passengerFullpriceReturn;
	}

	public void setPassengerFullpriceReturn(double passengerFullpriceReturn) {
		this.passengerFullpriceReturn = passengerFullpriceReturn;
	}
	public double getPassengerFueltaxReturn() {
		return passengerFueltaxReturn;
	}

	public void setPassengerFueltaxReturn(double passengerFueltaxReturn) {
		this.passengerFueltaxReturn = passengerFueltaxReturn;
	}
	public double getPassengerAirporttaxReturn() {
		return passengerAirporttaxReturn;
	}

	public void setPassengerAirporttaxReturn(double passengerAirporttaxReturn) {
		this.passengerAirporttaxReturn = passengerAirporttaxReturn;
	}
	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getOperName() {
		return operName;
	}

	public void setOperName(String operName) {
		this.operName = operName;
	}
	public String getCostCenter() {
		return costCenter;
	}

	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}

}