package cn.itkt.btsf.phone.users.vo;



/**
 * 移动商旅_订单扩展表 
 * @author codegen 2012-04-09 14:11:07 
 */
public class PhoneOrderExtVO {

    /** 主键 **/ 
	private long id;
	
    /** 订单号(ID),关联系统订单表 **/ 
	private long orderid;
	
    /** 是否接受低价推送服务    “0”接受 “1”不接受 **/ 
	private String isacceptsevice;
	
    /** 畅达币结算状态:0:已结算,1:未结算 **/ 
	private String coinstate;
	
    /** 移动商旅会员ID **/ 
	private long userid;
	
    /** 移送商旅会员名称 **/ 
	private String username;

	
	public PhoneOrderExtVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public long getOrderid() {
		return orderid;
	}

	public void setOrderid(long orderid) {
		this.orderid = orderid;
	}
	public String getIsacceptsevice() {
		return isacceptsevice;
	}

	public void setIsacceptsevice(String isacceptsevice) {
		this.isacceptsevice = isacceptsevice;
	}
	public String getCoinstate() {
		return coinstate;
	}

	public void setCoinstate(String coinstate) {
		this.coinstate = coinstate;
	}
	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}