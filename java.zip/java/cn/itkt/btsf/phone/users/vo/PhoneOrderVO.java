package cn.itkt.btsf.phone.users.vo;

import java.util.Date;


/**
 * 移动商旅_订单表 
 * @author codegen 2011-10-18 17:02:39 
 */
public class PhoneOrderVO {

	/**主键 �� **/ 
	private long id;
	
    /** 会员ID **/ 
	private long userid;
	
    /** ������订单号 **/ 
	private long orderid;
	
    /**航班号 ����� **/ 
	private String flightno;
	
    /** 起飞时间���ʱ�� **/ 
	private String departuredate;
	
    /** 旅客数量�ÿ��� **/ 
	private long passengercount;
	
    /** ��������ʱ��订单产生时间 **/ 
	private Date addtime;
	
    /** �Ƿ���ܵͼ����ͷ���    是否接受低价推送服务    “0”接受
“1”不接受**/ 
	private String isacceptsevice;
	
    /** 订单状态       “0”待支付
“1”已支付，未出票
   “2”已出票
“3”取消**/ 
	private String state;
	
    /**畅达币结算状态       “0” 已计算
“1” 为结算**/ 
	private String coinstate;
	
    /** 总价格**/ 
	private String totalprice;
		
    /** 出发城市�������� **/ 
	private String dptcity;
	
    /** 到达城市������� **/ 
	private String dstcity;
	
    /**行程单获取方式  “ 0” 不要   “ 1“ 邮寄   “ 2“ 终端打印 **/ 
	private String getitinerary;
	

	/**
	 * 构造 
	 */
	public PhoneOrderVO() {
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
	public long getOrderid() {
		return orderid;
	}

	public void setOrderid(long orderid) {
		this.orderid = orderid;
	}
	public String getFlightno() {
		return flightno;
	}

	public void setFlightno(String flightno) {
		this.flightno = flightno;
	}
	public String getDeparturedate() {
		return departuredate;
	}

	public void setDeparturedate(String departuredate) {
		this.departuredate = departuredate;
	}
	public long getPassengercount() {
		return passengercount;
	}

	public void setPassengercount(long passengercount) {
		this.passengercount = passengercount;
	}
	public Date getAddtime() {
		return addtime;
	}

	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}
	public String getIsacceptsevice() {
		return isacceptsevice;
	}

	public void setIsacceptsevice(String isacceptsevice) {
		this.isacceptsevice = isacceptsevice;
	}
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	public String getCoinstate() {
		return coinstate;
	}

	public void setCoinstate(String coinstate) {
		this.coinstate = coinstate;
	}
	public String getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(String totalprice) {
		this.totalprice = totalprice;
	}
	public String getDptcity() {
		return dptcity;
	}

	public void setDptcity(String dptcity) {
		this.dptcity = dptcity;
	}
	public String getDstcity() {
		return dstcity;
	}

	public void setDstcity(String dstcity) {
		this.dstcity = dstcity;
	}
	public String getGetitinerary() {
		return getitinerary;
	}

	public void setGetitinerary(String getitinerary) {
		this.getitinerary = getitinerary;
	}

}