package cn.itkt.btsf.phone.users.vo;

import java.util.Date;


/**
 * 移动商旅_会员表 
 * @author codegen 2011-10-14 15:06:10 
 */
public class PhoneUsersVO {

	/** ��ţ���ԱID�� **/ 
	private long userid;
	
    /** ��Ա�ֻ� **/ 
	private String telephone;
	
    /** ��Ա���� **/ 
	private String password;
	
    /** ��Ա�� **/ 
	private String name;
	
    /** ��Ա���� **/ 
	private String email;
	
    /** ע��ʱ�� **/ 
	private Date adddate;
	
    /** ��Դ   ��0�� Android
��1�� Mobile **/ 
	private String source;

	private String recommendPhone;
	

	/**
	 * 构造 
	 */
	public PhoneUsersVO() {
	}
	
	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public Date getAdddate() {
		return adddate;
	}

	public void setAdddate(Date adddate) {
		this.adddate = adddate;
	}
	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getRecommendPhone() {
		return recommendPhone;
	}

	public void setRecommendPhone(String recommendPhone) {
		this.recommendPhone = recommendPhone;
	}


}