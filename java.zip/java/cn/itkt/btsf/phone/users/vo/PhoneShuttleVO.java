package cn.itkt.btsf.phone.users.vo;



/**
 * 班车信息 
 * @author codegen 2011-10-15 17:00:55 
 */
public class PhoneShuttleVO {

	/** ��� 编号   主键  �� **/ 
	private long sid;
	
    /**线路名称 ��·�� **/ 
	private String name;
	
    /** 机场ID  外键��ID  ��� **/ 
	private long airportid;
	
    /** 票价 **/ 
	private String fare;
	
    /**运营时间 **/ 
	private String operationstime;
	
    /**间隔时间 ���ʱ�� **/ 
	private String intervaltime;
	
    /** 停靠车站ͣ����վ **/ 
	private String passstation;
	
    /** 始发站 **/ 
	private String startstation;
	
    /** 终点站�յ�վ **/ 
	private String endstation;
	
    /** ��ȥ���������ȥ�� 机场去市区或市区去机场   “0”机场去市区
“1”市区去机场**/
	private String driection;
	
    /**大巴热线 ������� **/ 
	private String hotline;
	
    /** �����机场所在城市 **/ 
	private String cityname;
	

	/**
	 * 构造 
	 */
	public PhoneShuttleVO() {
	}
	


	public long getSid() {
		return sid;
	}



	public void setSid(long sid) {
		this.sid = sid;
	}



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public long getAirportid() {
		return airportid;
	}

	public void setAirportid(long airportid) {
		this.airportid = airportid;
	}
	public String getFare() {
		return fare;
	}

	public void setFare(String fare) {
		this.fare = fare;
	}
	public String getOperationstime() {
		return operationstime;
	}

	public void setOperationstime(String operationstime) {
		this.operationstime = operationstime;
	}
	public String getIntervaltime() {
		return intervaltime;
	}

	public void setIntervaltime(String intervaltime) {
		this.intervaltime = intervaltime;
	}
	public String getPassstation() {
		return passstation;
	}

	public void setPassstation(String passstation) {
		this.passstation = passstation;
	}
	public String getStartstation() {
		return startstation;
	}

	public void setStartstation(String startstation) {
		this.startstation = startstation;
	}
	public String getEndstation() {
		return endstation;
	}

	public void setEndstation(String endstation) {
		this.endstation = endstation;
	}
	public String getDriection() {
		return driection;
	}

	public void setDriection(String driection) {
		this.driection = driection;
	}
	public String getHotline() {
		return hotline;
	}

	public void setHotline(String hotline) {
		this.hotline = hotline;
	}
	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

}