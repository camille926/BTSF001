package cn.itkt.btsf.phone.users.vo;



/**
 * 移动商旅_班车机场信息 
 * @author codegen 2011-10-15 16:55:58 
 */
public class PhoneAirportShuttleVO {

	/** ���   �� **/ 
	private long id;
	
    /** ���� **/ 
	private String name;
	

	/**
	 * 构造 
	 */
	public PhoneAirportShuttleVO() {
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}