package cn.itkt.btsf.phone.countreport.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.countreport.po.PhoneVisitcountPO;

/**
 * 移动商旅_访问量统计 
 * @author codegen 2012-04-13 21:05:41 
 */
public interface PhoneVisitcountDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneVisitcount 
	 */
	public PhoneVisitcountPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneVisitcountPO> 
	 */
	public List<PhoneVisitcountPO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneVisitcountPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneVisitcountPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 昨日进展第二个统计表
	 * @param modelMap
	 * @return
	 */
	public HashMap<String, String> countProgress();
	/**
	 * 业务进展新方式
	 * @return
	 */
	public List<HashMap<String,Object>> bussinessProgressOther(Map<String,String> map);
	/**
	 * 业务进展
	 * @return
	 */
	public List<HashMap<String,Object>> bussinessProgress(Map<String,String> map);
	
	public List<HashMap<String,Object>> bussinessProgress1(Map<String,String> map);

	/**
	 * 当天的业务进展
	 * @param map
	 * @return
	 */
	public List<HashMap<String,Object>> dayBussinessProgress(Map<String,String> map);
	
	
	
	/**
	 * 渠道业务进展
	 * @param startDate
	 * @return
	 */
	public List<HashMap<String,Object>> chaneelProgress(Map<String,Object> map);
	
	public List<HashMap<String,Object>> dayChaneelProgress(Map<String,Object> map);
	
	public List<HashMap<String,Object>> wChaneelProgress(Map<String,Object> map);
	/**
	 * 渠道业务进展count
	 * @param map
	 * @return
	 */
	public int chaneelProgressCount(Map<String,Object> map);
	
	public int dayChaneelProgressCount(Map<String,Object> map);
	
	public int wChaneelProgressCount(Map<String,Object> map);
	/**
	 * 促销活动
	 * @param map
	 * @return
	 */
	public List<HashMap<String,Object>> promotionActivity(Map<String,Object> map);
	
	/**
	 * 促销活动的count
	 * @param map
	 * @return
	 */
	public int countPromotionActivity(Map<String,Object> map);
	
	/**
	 * 联龙博通推广会员列表
	 * @param map
	 * @return
	 */
	public List<HashMap<String,Object>> memberListOther(Map<String,Object> map);
	/**
	 * 联龙博通推广会员列表,每一台手机第一位注册用户的注册时间
	 * @param map
	 * @return
	 */
	public List<HashMap<String,Object>> firstRegList(Map<String,Object> map);
	
	/**
	 * 联龙博通推广会员列表count值
	 * @param map
	 * @return
	 */
	public int countMemberListOther(Map<String,Object> map);
	/**
	 * 会员列表
	 * @param map
	 * @return
	 */
	public List<HashMap<String,Object>> memberList(Map<String,Object> map);
	
	/**
	 * 会员列表count值
	 * @param map
	 * @return
	 */
	public int countMemberList(Map<String,Object> map);
	
	/**
	 * 获取今天之前的访问总数和注册总数
	 * @return
	 */
	public HashMap<String,Object> getBussinessProgressLastCount();

	/** 
	 * 力美业务进展报表
	 */
	public List<HashMap<String, Object>> bussinessProgressLm(Map<String, String> map);
	/** 
	 * 力美业务进展报表总数(如注册总数，激活总数等)
	 */
	public List<HashMap<String, Object>> bussinessProgressTotalLm(Map<String, String> map);
	/** 
	 * 力美业务进展报表
	 * 1月5号之后的数据使用此方法统计,其中5号的数据要新+旧方法统计之和
	 */
	public List<HashMap<String, Object>> bussinessProgressLmNew(Map<String, String> map);
	/** 
	 * 力美业务进展报表总数(如注册总数，激活总数等)
	 * 1月5号之后的数据使用此方法统计,其中5号的数据要新+旧方法统计之和
	 */
	public List<HashMap<String, Object>> bussinessProgressTotalLmNew(Map<String, String> map);
	/**
	 * 联龙博通查询当天业务进展
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> dayBussinessProgressOther(Map<String, String> map);
	/**
	 * 联龙博通查询当天渠道业务进展
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> dayWChaneelProgress(Map<String, Object> map);

}