package cn.itkt.btsf.phone.countreport.po;

import java.io.Serializable;
import java.util.Date;


/**
 * 移动商旅_访问量统计 
 * @author codegen 2012-04-13 21:05:41 
 */
public class PhoneVisitcountPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** 主键 **/ 
	private long id;
	
    /** 设备ID **/ 
	private String equipmentid;
	
    /** 渠道ID   0：威锋   1：91  3：网站 **/ 
	private String channelid;
	
    /** 手机号 **/ 
	private String phone;
	
    /** 访问类型 0：激活量   1：查询量    2：注册量    3：出票量 **/ 
	private String visitcount;
	
    /** 添加时间 **/ 
	private Date addtime;
	

	/**
	 * 构造 
	 */
	public PhoneVisitcountPO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getEquipmentid() {
		return equipmentid;
	}

	public void setEquipmentid(String equipmentid) {
		this.equipmentid = equipmentid;
	}
	public String getChannelid() {
		return channelid;
	}

	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getVisitcount() {
		return visitcount;
	}

	public void setVisitcount(String visitcount) {
		this.visitcount = visitcount;
	}
	public Date getAddtime() {
		return addtime;
	}

	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}

}