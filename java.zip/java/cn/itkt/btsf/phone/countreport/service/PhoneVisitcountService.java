package cn.itkt.btsf.phone.countreport.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.countreport.po.PhoneVisitcountPO;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

public interface PhoneVisitcountService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneVisitcount 
	 */
	public PhoneVisitcountPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneVisitcountPO> 
	 */
	public List<PhoneVisitcountPO> findAll();

	/**
	 * 创建 
	 * @param po
	 */
	public void create(PhoneVisitcountPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneVisitcountPO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 昨日进展第二个统计表
	 * @param modelMap
	 */
	public void countProgress(ModelMap modelMap);
	/**
	 * 业务进展
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @param channel
	 */
	public void bussinessProgress(ModelMap modelMap,String startDate,String endDate,String channel);
	
	/**
	 * 渠道业务进展
	 * @param modelMap
	 * @param startDate
	 */
	public void chaneelProgress(ModelMap modelMap,String startDate,String endDate,String channel,int startIndex,int pageSize);
	/**
	 * 促销活动
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 */
	public void promotionActivity(ModelMap modelMap,String startDate,String endDate,Pages page);
	
	/**
	 * 会员列表
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 */
	public void memberList(ModelMap modelMap,String memberPhone,Pages page);
	/**
	 * 联龙博通推广会员列表
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 */
	public void memberListOther(ModelMap modelMap,int startIndex,int pageSize,Map<String,String> reqs,HttpServletRequest request);
	
	

}