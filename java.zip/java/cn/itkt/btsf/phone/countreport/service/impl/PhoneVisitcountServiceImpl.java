package cn.itkt.btsf.phone.countreport.service.impl;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.countreport.dao.PhoneVisitcountDao;
import cn.itkt.btsf.phone.countreport.po.PhoneVisitcountPO;
import cn.itkt.btsf.phone.countreport.service.PhoneVisitcountService;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

@Service
public class PhoneVisitcountServiceImpl implements PhoneVisitcountService {

	private static final Logger log = LoggerFactory.getLogger(PhoneVisitcountServiceImpl.class);

	@Resource
	private PhoneVisitcountDao phoneVisitcountDao;

	/**
	 * 查找单个
	 * 
	 * @param id
	 * @return PhoneVisitcount
	 */
	public PhoneVisitcountPO find(Serializable id) {
		return phoneVisitcountDao.find(id);
	}

	/**
	 * 查找所有
	 * 
	 * @return List<PhoneVisitcountPO>
	 */
	public List<PhoneVisitcountPO> findAll() {
		return phoneVisitcountDao.findAll();
	}

	/**
	 * 创建
	 * 
	 * @param po
	 */
	@Transactional(rollbackFor = { Exception.class })
	public void create(PhoneVisitcountPO po) throws AppException {
		try {
			if (po != null)
				phoneVisitcountDao.create(po);
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}
	}

	/**
	 * 修改
	 * 
	 * @param po
	 */
	@Transactional(rollbackFor = { Exception.class })
	public void update(PhoneVisitcountPO po) throws AppException {
		try {
			if (po != null)
				phoneVisitcountDao.update(po);
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}
	}

	/**
	 * 删除
	 * 
	 * @param id
	 */
	public void delete(Serializable id) {
		phoneVisitcountDao.delete(id);
	}

	/**
	 * 昨日进展第二个统计表
	 * 
	 * @param modelMap
	 */
	@Override
	public void countProgress(ModelMap modelMap) {
		Map<String, String> countProgress = phoneVisitcountDao.countProgress();
		modelMap.addAttribute("countProgress", countProgress);
	}

	@Override
	public void bussinessProgress(ModelMap modelMap, String startDate, String endDate,String channel) {
		try {
			String nowDate = DateUtil.dateToString(new Date(), "yyyy-MM-dd");
			List<HashMap<String, Object>> tem = new ArrayList<HashMap<String, Object>>();
			Map<String, String> map = new HashMap<String, String>();
			if (endDate == null || "".equals(endDate)) {
				endDate = nowDate;
			}
			map.put("startDate", startDate);
			map.put("endDate", endDate);
			map.put("channel", channel);

			// 暂时这么写，做测试用，以后会删除
			if ("gzyg".equals(LoginUtil.getLoginUser().getUsername())) {
				map.put("chaneelid1", "PLSYG01");
				map.put("chaneelid2", "PLSYG10");
				modelMap.addAttribute("chaneelid1", "PLSYG01");
			} else if ("oysk".equals(LoginUtil.getLoginUser().getUsername())) {
				map.put("chaneelid1", "C001");
				map.put("chaneelid2", "C100");
				modelMap.addAttribute("chaneelid1", "C001");
			} else if ("oyes".equals(LoginUtil.getLoginUser().getUsername())) {
				map.put("chaneelid1", "C001");
				map.put("chaneelid2", "C100");
				modelMap.addAttribute("chaneelid1", "C001");
			} else if ("bjoyell".equals(LoginUtil.getLoginUser().getUsername())) {
				map.put("chaneelid1", "C101");
				map.put("chaneelid2", "C200");
				modelMap.addAttribute("chaneelid1", "C101");
			} else if ("daoyoudao".equals(LoginUtil.getLoginUser().getUsername())) {
				map.put("chaneelid1", "O005");
				map.put("chaneelid2", "O005");
				modelMap.addAttribute("chaneelid1", "O005");
			} else if ("fengyi".equals(LoginUtil.getLoginUser().getUsername())) {
				map.put("chaneelid1", "iphjb0125");
				map.put("chaneelid2", "iphjb1025");
				map.put("chaneelid3", "'Iphoneap25','Iphoneap251'");// 增加查看权限以“ , "分隔 2012-08-22修改 wangyong
				map.put("chaneelid4", "Iphoneap25");
				modelMap.addAttribute("chaneelid1", "O005");
			} else if ("wanyitong".equals(LoginUtil.getLoginUser().getUsername())) {
//				map.put("chaneelid1", "'L001','Iphoneap251'");
				map.put("chaneelid1", "'O031','Iphoneap26','YL001','Iphoneap27','Iphoneap30','Iphoneap31','Iphoneap32','Iphoneap33','O001'");
				map.put("chaneelid2", "W021");
				map.put("chaneelid3", "W040");
				map.put("chaneelid4", "L%");//L开头的 
				modelMap.addAttribute("chaneelid1", "O100");
			}else if ("wpsj".equals(LoginUtil.getLoginUser().getUsername())) {//万普世纪
				map.put("chaneelid1", "W001");
				map.put("chaneelid2", "W005");//chaneelid1和chaneelid2表示一个范围区间
				map.put("chaneelid3", "'Iphoneap251','IPHONEW0125','IPHONEW0225','IPHONEW0325','IPHONEW0425','IPHONEW0525','Iphoneap26','Iphoneap27'");//chaneelid3表示一些固定值
				map.put("chaneelid4", "'W%'");//chaneelid4 表示模糊匹配
				modelMap.addAttribute("chaneelid1", "W001");
			}else if ("limei".equals(LoginUtil.getLoginUser().getUsername())) {//力美,它没有渠道
				modelMap.addAttribute("chaneelid1", "Iphoneap27");
			}
			String userRole = (String) modelMap.get("chaneelid1");
			boolean onlyTodayFlag = false;//只含今天的数据
			if (nowDate.compareTo(startDate)<=0){
				onlyTodayFlag = true;
			}
			if ("O100".equals(userRole)){ // 万易通类型的用户
				tem = phoneVisitcountDao.bussinessProgressOther(map);
				if(nowDate.equals(endDate)){//如果查询了今天，则要单独查询一下
					List<HashMap<String, Object>> dayBussinessProgress = phoneVisitcountDao.dayBussinessProgressOther(map);
					if(dayBussinessProgress!=null&&dayBussinessProgress.size()==1){
						HashMap<String, Object> map0 = dayBussinessProgress.get(0);
						map0.put("TICKETCOUNTTOTAL", Integer.parseInt(tem.get(0).get("TICKETCOUNTTOTAL").toString())+Integer.parseInt(map0.get("TICKETCOUNT").toString()));
						tem.add(0, map0);
					}
				}
			} else if("Iphoneap27".equals(userRole)){//力美
				//由于接口中途修改统计逻辑的原因，在统计时，2013-01-05号之前的数据使用bussinessProgressLm方法统计
				//2013-01-05之后的数据使用bussinessProgressLmNew统计
				//2013-01-05号当天的数据，使用两方法统计之和
				if(endDate.compareTo("2013-01-05")<0){
					tem = phoneVisitcountDao.bussinessProgressLm(map);
					List<HashMap<String, Object>> TotalLm = phoneVisitcountDao.bussinessProgressTotalLm(map);
					for(HashMap<String, Object> dayBussiness:tem){
						String visitTime = (String) dayBussiness.get("VISITTIME");
						for(HashMap<String, Object> total:TotalLm){
							if(visitTime.equals(total.get("VISITTIME"))){
								dayBussiness.put("ACTIVATETOTAL", total.get("ACTIVATETOTAL"));
								dayBussiness.put("REGISTERTOTAL", total.get("REGISTERTOTAL"));
								dayBussiness.put("TICKETCOUNTTOTAL", total.get("TICKETCOUNTTOTAL"));
							}
						}
					}
				}else if(endDate.compareTo("2013-01-05")>=0){
					if(startDate.compareTo("2013-01-05")<=0){//如果开始日期在5号或5号之前即5号在当前范围内
						//1.对于新增数据,即要查询5号之前的,也要查询5号之后的
						//先查5号或5号之前的数据
						map.put("endDate", "2013-01-05");
						List<HashMap<String, Object>> temOld = phoneVisitcountDao.bussinessProgressLm(map);
						//后查5号之后的数据
						map.put("startDate", "2013-01-05");
						map.put("endDate", endDate);
						List<HashMap<String, Object>> temNew = phoneVisitcountDao.bussinessProgressLmNew(map);
						//处理新增数据
						//处理5号数据
						int addActivateCount = Integer.parseInt(String.valueOf(temOld.get(0).get("ADDACTIVATECOUNT")))
						+Integer.parseInt(String.valueOf(temNew.get(temNew.size()-1).get("ADDACTIVATECOUNT")));
						temNew.get(temNew.size()-1).put("ADDACTIVATECOUNT", addActivateCount);
						
						int addRegisterCount = Integer.parseInt(String.valueOf(temOld.get(0).get("ADDREGISTERCOUNT")))
						+Integer.parseInt(String.valueOf(temNew.get(temNew.size()-1).get("ADDREGISTERCOUNT")));
						temNew.get(temNew.size()-1).put("ADDREGISTERCOUNT", addRegisterCount);
						
						int queryCount = Integer.parseInt(String.valueOf(temOld.get(0).get("QUERYCOUNT")))
						+Integer.parseInt(String.valueOf(temNew.get(temNew.size()-1).get("QUERYCOUNT")));
						temNew.get(temNew.size()-1).put("QUERYCOUNT", queryCount);
						
						int ticketCount = Integer.parseInt(String.valueOf(temOld.get(0).get("TICKETCOUNT")))
						+Integer.parseInt(String.valueOf(temNew.get(temNew.size()-1).get("TICKETCOUNT")));
						temNew.get(temNew.size()-1).put("TICKETCOUNT", ticketCount);
						
						int tickerTotalAmount = Integer.parseInt(String.valueOf(temOld.get(0).get("TICKERTOTALAMOUNT")))
						+Integer.parseInt(String.valueOf(temNew.get(temNew.size()-1).get("TICKERTOTALAMOUNT")));
						temNew.get(temNew.size()-1).put("TICKERTOTALAMOUNT", tickerTotalAmount);
						
						
						//添加5号之后数据
						for(int i=1;i<temOld.size();i++){
							temNew.add(temOld.get(i));
						}
						//2.对总量数据
						//2.对于总量数据,需要考虑5号之前的数据
						//先查5号与5号之前的总量数据
						map.put("endDate", "2013-01-05");
						List<HashMap<String, Object>> TotalLm = phoneVisitcountDao.bussinessProgressTotalLm(map);
						//获取截止到5号的总量数据,相当于用新方式查询的基数
						int activateTotal = Integer.parseInt(String.valueOf(TotalLm.get(0).get("ACTIVATETOTAL")));
						int registerTotal = Integer.parseInt(String.valueOf(TotalLm.get(0).get("REGISTERTOTAL")));
						int ticketCountTotal = Integer.parseInt(String.valueOf(TotalLm.get(0).get("TICKETCOUNTTOTAL")));
						//后查5号之后的总量数据
						map.put("startDate", "2013-01-05");
						map.put("endDate", endDate);
						List<HashMap<String, Object>> TotalLmNew = phoneVisitcountDao.bussinessProgressTotalLmNew(map);
						for(HashMap<String, Object> dayBussiness:temNew){
							String visitTime = (String) dayBussiness.get("VISITTIME");
							if(visitTime.compareTo("2013-01-05")<0){//5号之前的数据,直接put上旧方式统计的总量即可
								for(HashMap<String, Object> total:TotalLm){
									if(visitTime.equals(total.get("VISITTIME"))){
										dayBussiness.put("ACTIVATETOTAL", total.get("ACTIVATETOTAL"));
										dayBussiness.put("REGISTERTOTAL", total.get("REGISTERTOTAL"));
										dayBussiness.put("TICKETCOUNTTOTAL", total.get("TICKETCOUNTTOTAL"));
									}
								}
							}else if(visitTime.compareTo("2013-01-05")>=0){//5号与5号之后的数据,需要再加上旧方式的基数与新方式统计之和
								for(HashMap<String, Object> total:TotalLmNew){
									if(visitTime.equals(total.get("VISITTIME"))){
										int tempActivateTotal= activateTotal + Integer.parseInt(String.valueOf(total.get("ACTIVATETOTAL")));
										dayBussiness.put("ACTIVATETOTAL", tempActivateTotal);
										int tempRegisterTotal = registerTotal + Integer.parseInt(String.valueOf(total.get("REGISTERTOTAL")));
										dayBussiness.put("REGISTERTOTAL", tempRegisterTotal);
										int tempTicketCountTotal = ticketCountTotal + Integer.parseInt(String.valueOf(total.get("TICKETCOUNTTOTAL")));
										dayBussiness.put("TICKETCOUNTTOTAL", tempTicketCountTotal);
									}
								}
							}
						}
						tem = temNew;
					}else if(startDate.compareTo("2013-01-05")>0){//如果开始日期在5号之后即5号不在当前范围内
						//1.对于新增数据：只用bussinessProgressLmNew查即可
						tem = phoneVisitcountDao.bussinessProgressLmNew(map);
						//2.对于总量数据,需要考虑5号之前的数据
						//先查5号与5号之前的总量数据
						map.put("endDate", "2013-01-05");
						List<HashMap<String, Object>> TotalLm = phoneVisitcountDao.bussinessProgressTotalLm(map);
						//获取截止到5号的总量数据,相当于用新方式查询的基数
						int activateTotal = Integer.parseInt(String.valueOf(TotalLm.get(0).get("ACTIVATETOTAL")));
						int registerTotal = Integer.parseInt(String.valueOf(TotalLm.get(0).get("REGISTERTOTAL")));
						int ticketCountTotal = Integer.parseInt(String.valueOf(TotalLm.get(0).get("TICKETCOUNTTOTAL")));
						//后查5号之后的总量数据
						map.put("startDate", "2013-01-05");
						map.put("endDate", endDate);
						List<HashMap<String, Object>> TotalLmNew = phoneVisitcountDao.bussinessProgressTotalLmNew(map);
						for(HashMap<String, Object> dayBussiness:tem){
							String visitTime = (String) dayBussiness.get("VISITTIME");
							for(HashMap<String, Object> total:TotalLmNew){
								if(visitTime.equals(total.get("VISITTIME"))){
									int tempActivateTotal = activateTotal + Integer.parseInt(String.valueOf(total.get("ACTIVATETOTAL")));
									dayBussiness.put("ACTIVATETOTAL", tempActivateTotal);
									int tempRegisterTotal = registerTotal + Integer.parseInt(String.valueOf(total.get("REGISTERTOTAL")));
									dayBussiness.put("REGISTERTOTAL", tempRegisterTotal);
									int tempTicketCountTotal = ticketCountTotal + Integer.parseInt(String.valueOf(total.get("TICKETCOUNTTOTAL")));
									dayBussiness.put("TICKETCOUNTTOTAL", tempTicketCountTotal);
								}
							}
						}
					}
				}
			} else {
				// 判断当前时间是否在开始时间和结束时间之间
				List<HashMap<String, Object>> dayBussinessProgress = null;
				if (nowDate.equals(endDate) || endDate == nowDate||endDate.compareTo(nowDate)>0) {
					dayBussinessProgress = phoneVisitcountDao.dayBussinessProgress(map);
				}
				if(onlyTodayFlag){
					Calendar cal = Calendar.getInstance();
					cal.add(Calendar.DATE, -1);
					map.put("startDate", new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime()));
					tem = phoneVisitcountDao.bussinessProgress(map);
				}else{
					tem = phoneVisitcountDao.bussinessProgress(map);
				}
				if(tem!=null&&tem.size()>1&&"C101".equals(map.get("chaneelid1"))){
					//在sql中，在今天之前的数据中，C101用户下，新增激活数与激活总数都要乘以0.95，这样再一四舍五入后，
					//前一天的激活累计总数+今天的新增数可能就不等于今天的累计总数了，因此做这个处理
					int size = tem.size();
					for(int i=0;i<size-1;i++){
						long ACTIVITYCOUNT = Long.parseLong(tem.get(i).get("ACTIVATETOTAL") == null ? "0" : tem.get(i).get("ACTIVATETOTAL").toString());
						long ADDACTIVATECOUNT = Long.parseLong(tem.get(i).get("ADDACTIVATECOUNT").toString()==null?"0":tem.get(i).get("ADDACTIVATECOUNT").toString());
						long ACTIVITYCOUNT_yestoday = Long.parseLong(tem.get(i+1).get("ACTIVATETOTAL") == null ? "0" : tem.get(i+1).get("ACTIVATETOTAL").toString());
						if(ACTIVITYCOUNT!=ADDACTIVATECOUNT+ACTIVITYCOUNT_yestoday){
							log.debug("出现一个不相等...(前一天的激活累计总数("+ACTIVITYCOUNT_yestoday+")+今天的新增数("+ADDACTIVATECOUNT+")可能就不等于今天的累计总数("+ACTIVITYCOUNT+"))");
							tem.get(i).put("ACTIVATETOTAL", ADDACTIVATECOUNT+ACTIVITYCOUNT_yestoday);
						}
					}
				}
				/*
				 * //新改的需求，普通用户只能查看新增激活量和激活总量的98%（由于在原sql上改，改动比较大，所以重新写了一个sql） 
				 * if( map.get("chaneelid1") != null){ 
				 * 	tem = phoneVisitcountDao.bussinessProgress1(map); 
				 * }else{
				 *  tem =
				 * 	phoneVisitcountDao.bussinessProgress(map); 
				 * }
				 */
				if ((dayBussinessProgress != null && dayBussinessProgress.size() > 0) && tem != null && tem.size() > 0) {
					Map temmap = tem.get(0);
					long REGISTRATIONCOUNT = Long.parseLong(temmap.get("REGISTERTOTAL") == null ? "0" : temmap.get("REGISTERTOTAL").toString());
					long ACTIVITYCOUNT = Long.parseLong(temmap.get("ACTIVATETOTAL") == null ? "0" : temmap.get("ACTIVATETOTAL").toString());
					long TICKETCOUNT = Long.parseLong(temmap.get("TICKETCOUNTTOTAL") == null ? "0" : temmap.get("TICKETCOUNTTOTAL").toString());
					long ACTIVITYDAY = Long.parseLong(dayBussinessProgress.get(0).get("ACTIVITYDAY").toString()==null?"0":dayBussinessProgress.get(0).get("ACTIVITYDAY").toString());
					// 当前计算的激活数*0.95
					if ("C101".equals(map.get("chaneelid1"))) {
						//[当天新增的*0.95]
						ACTIVITYDAY =Math.round(ACTIVITYDAY*0.95) ;
						dayBussinessProgress.get(0).put("ACTIVITYDAY", ACTIVITYDAY);
					}

					REGISTRATIONCOUNT += Long.parseLong(dayBussinessProgress.get(0).get("REGISTRATIONDAY").toString());
					ACTIVITYCOUNT += Long.parseLong(dayBussinessProgress.get(0).get("ACTIVITYDAY").toString());
					TICKETCOUNT += Long.parseLong(dayBussinessProgress.get(0).get("TICKETNUM").toString());

					dayBussinessProgress.get(0).put("REGISTRATIONCOUNT", REGISTRATIONCOUNT);
					dayBussinessProgress.get(0).put("ACTIVITYCOUNT", ACTIVITYCOUNT);
					dayBussinessProgress.get(0).put("TICKETCOUNT", TICKETCOUNT);
					// modelMap.put("dayCountProgress",dayBussinessProgress ) ;
				}
				modelMap.put("dayCountProgress", dayBussinessProgress);
			}
			if(!onlyTodayFlag){
				modelMap.put("countProgress", tem);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void chaneelProgress(ModelMap modelMap, String startDate, String endDate,String channel, int startIndex,int pageSize) {
		Map<String, Object> map = new HashMap<String, Object>();
		// 暂时这么写，做测试用，以后会删除
		if ("gzyg".equals(LoginUtil.getLoginUser().getUsername())) {
			map.put("chaneelid1", "PLSYG01");
			map.put("chaneelid2", "PLSYG10");
			modelMap.addAttribute("chaneelid1", "PLSYG01");
		} else if ("oysk".equals(LoginUtil.getLoginUser().getUsername())) {
			map.put("chaneelid1", "C001");
			map.put("chaneelid2", "C100");
			modelMap.addAttribute("chaneelid1", "C001");
		} else if ("oyes".equals(LoginUtil.getLoginUser().getUsername())) {
			map.put("chaneelid1", "C001");
			map.put("chaneelid2", "C100");
			modelMap.addAttribute("chaneelid1", "C001");
		} else if ("bjoyell".equals(LoginUtil.getLoginUser().getUsername())) {
			map.put("chaneelid1", "C101");
			map.put("chaneelid2", "C200");
			modelMap.addAttribute("chaneelid1", "C101");
		} else if ("daoyoudao".equals(LoginUtil.getLoginUser().getUsername())) {
			map.put("chaneelid1", "O005");
			map.put("chaneelid2", "O005");
			modelMap.addAttribute("chaneelid1", "O005");
		} else if ("fengyi".equals(LoginUtil.getLoginUser().getUsername())) {
			map.put("chaneelid1", "iphjb0125");
			map.put("chaneelid2", "iphjb1025");
			map.put("chaneelid3", "'Iphoneap25','Iphoneap251'");// 增加查看权限以“,"分隔 2012-08-22修改 wangyong
			map.put("chaneelid4", "Iphoneap25");
			modelMap.addAttribute("chaneelid1", "O005");
		} else if ("wanyitong".equals(LoginUtil.getLoginUser().getUsername())) {
			//map.put("chaneelid1", "'L001','Iphoneap251'");
			map.put("chaneelid1", "'O031','Iphoneap26','YL001','Iphoneap27','Iphoneap30','Iphoneap31','Iphoneap32','Iphoneap33','O001'");
			map.put("chaneelid2", "W021");
			map.put("chaneelid3", "W040");
			map.put("chaneelid4", "L%");//L开头的 
			modelMap.addAttribute("chaneelid1", "O100");
		}else if ("wpsj".equals(LoginUtil.getLoginUser().getUsername())) {//万普世纪
			map.put("chaneelid1", "W001");
			map.put("chaneelid2", "W005");
			map.put("chaneelid3", "'Iphoneap251','IPHONEW0125','IPHONEW0225','IPHONEW0325','IPHONEW0425','IPHONEW0525','Iphoneap26','Iphoneap27'");
			map.put("chaneelid4", "'W%'");
			modelMap.addAttribute("chaneelid1", "W001");
		}

		if (endDate == null && "".equals(endDate)) {
			endDate = DateUtil.dateToString(new Date(), "yyyy-MM-dd");
		}

		map.put("startDate", startDate);
		map.put("endDate", endDate);
		map.put("channel", channel);
		map.put("startIndex", startIndex);
		map.put("pageSize", pageSize);
		
		//如果是万易通用户则进行特定的查询
		if ("O100".equals(modelMap.get("chaneelid1"))){ // 万易通类型的用户
			List<HashMap<String, Object>> wChaneelProgress = null;
			wChaneelProgress = phoneVisitcountDao.wChaneelProgress(map);
			int count = phoneVisitcountDao.wChaneelProgressCount(map);
			Pages<HashMap<String, Object>> page = new Pages<HashMap<String, Object>>(startIndex, pageSize);
			String nowDate = DateUtil.dateToString(new Date(), "yyyy-MM-dd");
			if(nowDate.endsWith(endDate)){
				List<HashMap<String,Object>> list = phoneVisitcountDao.dayWChaneelProgress(map);
				for(HashMap<String, Object> map0:wChaneelProgress){
					for(HashMap<String, Object> map1:list){//当天
						if(map0.get("CHANNEL").equals(map1.get("CHANNEL"))){
							map1.put("ACTIVITYDAY",Integer.parseInt(map1.get("ACTIVITYDAY").toString())+Integer.parseInt(map0.get("ACTIVITYDAY").toString()));
							map1.put("REGISTRATIONDAY",Integer.parseInt(map1.get("REGISTRATIONDAY").toString())+Integer.parseInt(map0.get("REGISTRATIONDAY").toString()));
							map1.put("REGISTRATIONCOUNT",Integer.parseInt(map1.get("REGISTRATIONCOUNT").toString())+Integer.parseInt(map0.get("REGISTRATIONCOUNT").toString()));
							map1.put("TICKETNUM",Integer.parseInt(map1.get("TICKETNUM").toString())+Integer.parseInt(map0.get("TICKETNUM").toString()));
							map1.put("TICKETNUMCOUNT",Integer.parseInt(map1.get("TICKETNUM").toString())+Integer.parseInt(map0.get("TICKETNUMCOUNT").toString()));
						}
					}
				}
				page.setItems(list);
			}else{
				page.setItems(wChaneelProgress);
			}
			page.setTotalCount(count);
			modelMap.put("page", page);
			return ;
		}
		
		
		/*
		 * 数据库中将总数给为每个渠道，当天之前的总数 所以代码做相应的调整
		 *  1.判断查询的时候是否包含当天的数据 
		 *  2.如果不包含，直接到统计表中获取数据 
		 *  3.如果包含，首先获取当时的时时数据，然后获取数据库中当天以前的数据 将当前数据和之前的数据相加，如果当前数据为空，则将之前的数据返回
		 */
		// 判断当前时间是否在开始时间和结束时间之间
		String nowDate = DateUtil.dateToString(new Date(), "yyyy-MM-dd");
		// 如果查询当天数据，总数需要从前一天的数据中获取
		if (nowDate == startDate || startDate.equals(nowDate)) {
			// 将开始数据往前推迟一天
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -1);
			map.put("startDate", new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime()));
		}
		
		List<HashMap<String, Object>> dayChaneelProgress = null;
		int daycount = 0;
		if (nowDate.equals(endDate) || endDate == nowDate||endDate.compareTo(nowDate)>0) {
			// 获取当天数据,渠道是有史以来所有的渠道
			dayChaneelProgress = phoneVisitcountDao.dayChaneelProgress(map);
			daycount = phoneVisitcountDao.dayChaneelProgressCount(map);
		}

		String temchannel = "";
		if (dayChaneelProgress != null && dayChaneelProgress.size() > 0) {
			for (int t = 0; t < dayChaneelProgress.size(); t++) {
				temchannel += "'" + dayChaneelProgress.get(t).get("CHANEEL").toString() + "'" + ",";
			}
		}

		if (temchannel.length() > 0) {
			temchannel = temchannel.substring(0, temchannel.length() - 1);
		}
		map.put("temchannel", temchannel);

		List<HashMap<String, Object>> chaneelProgress =null;
		int count = 0;
		// 获取之前的数据
		if("".equals(temchannel)){//如果当天没数据，则只查询统计表tem
			chaneelProgress = phoneVisitcountDao.chaneelProgress(map);
			count = phoneVisitcountDao.chaneelProgressCount(map);
		}else{//否则，以当天为准（如果开始时间也是今天，则这里只要前一天的激活、注册等总数；如果开始时间已经包含今天以前，则其他数据都需要）
			Map<String, Object> map0 = new HashMap<String, Object>();
			map0.put("temchannel", temchannel);
			map0.put("channel", channel);
			map0.put("startDate", map.get("startDate"));
			map0.put("endDate", endDate);
			map0.put("startIndex", 0);
			map0.put("pageSize", 1000);
			chaneelProgress = phoneVisitcountDao.chaneelProgress(map0);
			count = phoneVisitcountDao.chaneelProgressCount(map0);
		}
		
		Pages<HashMap<String, Object>> page = new Pages<HashMap<String, Object>>(startIndex, pageSize);
		boolean containPreFlag = false;//包含以前的数据
		if (nowDate.compareTo(startDate)>0){
			containPreFlag = true;
		}
		if (dayChaneelProgress != null && daycount != 0 && chaneelProgress != null && count != 0) {
			// 将之前的总数取出来，加上今天的值为今天的总数
			for (int i = 0; i < chaneelProgress.size(); i++) {
				String channle = chaneelProgress.get(i).get("CHANEEL").toString();
				for (int k = 0; k < dayChaneelProgress.size(); k++) {
					String daychannle = dayChaneelProgress.get(k).get("CHANEEL").toString();
					if (channle == daychannle || channle.equals(daychannle)) {
						int activatecday = Integer.parseInt(dayChaneelProgress.get(k).get("ACTIVITYDAY") == null ? "0" : dayChaneelProgress.get(k).get("ACTIVITYDAY").toString()); // 当天激活量
						if(containPreFlag){//加上前几天的新增激活数
							int activatecdayNew = Integer.parseInt(chaneelProgress.get(i).get("ACTIVITYDAY").toString()) + activatecday;
							dayChaneelProgress.get(k).put("ACTIVITYDAY", activatecdayNew);
						}
						
						int registerday = Integer.parseInt(dayChaneelProgress.get(k).get("REGISTRATIONDAY") == null ? "0" : dayChaneelProgress.get(k).get("REGISTRATIONDAY").toString()); // 当天注册量
						if(containPreFlag){//加上前几天的新增注册数
							int registerdayNew = Integer.parseInt(chaneelProgress.get(i).get("REGISTRATIONDAY").toString()) + registerday;
							dayChaneelProgress.get(k).put("REGISTRATIONDAY", registerdayNew);
						}
						
						int ticketday = Integer.parseInt(dayChaneelProgress.get(k).get("TICKETNUM") == null ? "0" : dayChaneelProgress.get(k).get("TICKETNUM").toString()); // 当天出票量
						if(containPreFlag){//加上前几天的新增出票张数
							int ticketdayNew = Integer.parseInt(chaneelProgress.get(i).get("TICKETNUM").toString()) + ticketday;
							dayChaneelProgress.get(k).put("TICKETNUM", ticketdayNew);
						}
						/*激活总数*/
						int activatectotal = Integer.parseInt(chaneelProgress.get(i).get("ACTIVITYCOUNT").toString()) + activatecday;
						dayChaneelProgress.get(k).put("ACTIVITYCOUNT", activatectotal);

						/*注册总数*/
						int registertotal = Integer.parseInt(chaneelProgress.get(i).get("REGISTRATIONCOUNT").toString()) + registerday;
						dayChaneelProgress.get(k).put("REGISTRATIONCOUNT", registertotal);

						/*出票总数*/
						int tickettotal = Integer.parseInt(chaneelProgress.get(i).get("TICKETNUMCOUNT") == null ? "0" : chaneelProgress.get(i).get("TICKETNUMCOUNT").toString()) + ticketday;
						dayChaneelProgress.get(k).put("TICKETNUMCOUNT", tickettotal);
						
						/*出票总金额*/
						if(containPreFlag){
							int ticketamountToday = Integer.parseInt(dayChaneelProgress.get(k).get("TICKETAMOUNT") == null ? "0" : dayChaneelProgress.get(k).get("TICKETAMOUNT").toString()); // 当天出票金额
							int ticketamount =Integer.parseInt(chaneelProgress.get(i).get("TICKETAMOUNT").toString())+ticketamountToday;
							dayChaneelProgress.get(k).put("TICKETAMOUNT", ticketamount);
						}
					}
				}
			}
			page.setItems(dayChaneelProgress);
			page.setTotalCount(daycount);

		}
		// 如果之前的数据为空,相当于只查今天的
		if (chaneelProgress == null || count == 0) {
			page.setItems(dayChaneelProgress);
			page.setTotalCount(daycount);
		}
		// 如果当前的数据为空,相当于查之前的
		if (dayChaneelProgress == null || daycount == 0) {
			page.setItems(chaneelProgress);
			page.setTotalCount(count);
		}

		modelMap.put("page", page);
	}

	/**
	 * 促销活动
	 */
	@Override
	public void promotionActivity(ModelMap modelMap, String startDate, String endDate, Pages page) {

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startDate", startDate);
		map.put("endDate", endDate);
		map.put("page", page);
		int count = phoneVisitcountDao.countPromotionActivity(map);

		/*
		 * if((page.getStartIndex()+page.getPageSize())>count){ if(page.getPageSize() == 999999999){ //导出excel page.setPageSize(count); }else{ page.setPageSize(count-page.getStartIndex()); }
		 * map.put("page", page); }
		 */
		page.setTotalCount(count);
		page.setItems(phoneVisitcountDao.promotionActivity(map));
		page.setPageSize(10);
		// modelMap.put("countProgress", phoneVisitcountDao.promotionActivity(map));
		modelMap.put("page", page);
	}

	/**
	 * 会员列表
	 */
	@Override
	public void memberList(ModelMap modelMap, String memberPhone, Pages page) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("memberPhone", memberPhone);
		map.put("page", page);

		page.setTotalCount(phoneVisitcountDao.countMemberList(map));
		page.setItems(phoneVisitcountDao.memberList(map));
		modelMap.put("page", page);
		// modelMap.put("countTicket", phoneVisitcountDao.memberList(map));
	}
	
	/**
	 * 联龙博通推广会员列表
	 */
	@Override
	public void memberListOther(ModelMap modelMap,int startIndex,int pageSize,Map<String,String> reqs,HttpServletRequest request) {
		Pages page = new Pages(startIndex,pageSize);
		Map<String, Object> map = new HashMap<String, Object>();
		map.putAll(reqs);
		map.put("startIndex", startIndex);
		map.put("chaneelid1", "'O031','Iphoneap26','YL001','Iphoneap27','Iphoneap30','Iphoneap31','Iphoneap32','Iphoneap33','O001'");
		map.put("chaneelid2", "W021");
		map.put("chaneelid3", "W040");
		map.put("chaneelid4", "L%");//L开头的 
		map.put("pageSize", pageSize);
		List<HashMap<String,Object>> memberListOther = phoneVisitcountDao.memberListOther(map);
		HttpSession session = request.getSession(true);
		List<HashMap<String,Object>> firstRegList = (List<HashMap<String,Object>>)session.getAttribute("firstRegList");
		if(firstRegList==null){
			firstRegList = phoneVisitcountDao.firstRegList(map);
			session.setAttribute("firstRegList", firstRegList);
			session.setMaxInactiveInterval(2*60);//两分钟失效
		}
		HashMap<String,Object> firstRegMap = new HashMap<String, Object>();
		for(HashMap<String,Object> fr : firstRegList){
			firstRegMap.put(fr.get("EQUIPMENTID").toString(), fr.get("MINADDTIME"));
		}
		for(HashMap<String,Object> mem:memberListOther){
			String minTime = (String)firstRegMap.get(mem.get("EQUIPMENTID"));
			mem.put("ACTIVITY", "否");
			if(mem.get("ADDTIME").equals(minTime)){
				mem.put("ACTIVITY", "是");
			}
		}
		page.setItems(memberListOther);
		page.setTotalCount(phoneVisitcountDao.countMemberListOther(map));
		modelMap.put("page", page);
		modelMap.put("startDate",reqs.get("startDate"));
		modelMap.put("endDate",reqs.get("endDate"));
		modelMap.put("channelid",reqs.get("channelid"));
		modelMap.put("recommendPhone",reqs.get("recommendPhone"));
	}

}