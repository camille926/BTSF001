package cn.itkt.btsf.phone.countreport.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.countreport.service.PhoneVisitcountService;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.pagination.Pages;

@Service
public class PhoneVisitcountControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(PhoneVisitcountControllerSupport.class);
	
	@Resource
	private  PhoneVisitcountService  phoneVisitcountService;
	
	/**
	 * 昨日进展
	 * @param modelMap
	 * @return
	 */
	public void yesterdayProgress(ModelMap modelMap){
		//业务发展之日起至今统计数据
		phoneVisitcountService.countProgress(modelMap);
	}
	/**
	 * 业务进展
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 */
	public void bussinessProgress(ModelMap modelMap,String startDate,String endDate,String channel){
		try {
			if(endDate != null && !"".equals(endDate)){
				modelMap.put("endDate", DateUtil.stringToDate(endDate, "yyyy-MM-dd"));
			}else{
				Calendar   cal   =   Calendar.getInstance();
				cal.add(Calendar.DATE,   -1);
				endDate = new SimpleDateFormat( "yyyy-MM-dd").format(cal.getTime());
				modelMap.put("endDate", cal.getTime());
				
				//modelMap.put("endDate", new Date());
				//endDate = DateUtil.dateToString(new Date(), "yyyy-MM-dd");
			}
			
			if(startDate != null && !"".equals(startDate)){
				modelMap.put("startDate", DateUtil.stringToDate(startDate, "yyyy-MM-dd"));
			}else{
				//默认查询一星期的数据
				Date d=new SimpleDateFormat("yyyy-MM-dd").parse(endDate);  
				Calendar   cal   =   Calendar.getInstance();
				cal.setTime(d);
				cal.add(Calendar.DATE,   -6);
				startDate = new SimpleDateFormat( "yyyy-MM-dd").format(cal.getTime());
				modelMap.put("startDate", DateUtil.stringToDate(startDate, "yyyy-MM-dd"));
			}
			channel = channel==null?"":channel.toString().trim();
			modelMap.put("channel", channel);
			phoneVisitcountService.bussinessProgress(modelMap,startDate,endDate,channel);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 渠道进展
	 * @param modelMap
	 * @param startDate
	 */
	public void chaneelProgress(ModelMap modelMap,String startDate,String endDate,String channel,int startIndex,int pageSize){
		try {
			if(endDate == null || "".equals(endDate)){
				Calendar   cal   =   Calendar.getInstance();
				cal.add(Calendar.DATE,   -1);
				endDate = new SimpleDateFormat( "yyyy-MM-dd").format(cal.getTime());
				modelMap.put("endDate", cal.getTime());
			}else{
				modelMap.put("endDate", DateUtil.stringToDate(endDate, "yyyy-MM-dd"));
			}
			
			if(startDate != null && !"".equals(startDate)){
				modelMap.put("startDate", DateUtil.stringToDate(startDate, "yyyy-MM-dd"));
			}else{
				//默认查询一星期的数据
				 Date d=new SimpleDateFormat("yyyy-MM-dd").parse(endDate);  
				 Calendar   cal   =   Calendar.getInstance();
				 cal.setTime(d);
				 cal.add(Calendar.DATE,   -6);
				 startDate = new SimpleDateFormat( "yyyy-MM-dd").format(cal.getTime());
				 modelMap.put("startDate", DateUtil.stringToDate(startDate, "yyyy-MM-dd"));
			}
			channel = channel==null?"":channel.toString().trim();
			modelMap.put("channel", channel);
			phoneVisitcountService.chaneelProgress(modelMap,startDate,endDate,channel,startIndex,pageSize);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 促销活动
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 */

	public void promotionActivity(ModelMap modelMap,String startDate,String endDate,Pages page){
		try {
			if(startDate != null && !"".equals(startDate)){
				modelMap.put("startDate", DateUtil.stringToDate(startDate, "yyyy-MM-dd"));
			}
			if(endDate != null && !"".equals(endDate)){
				modelMap.put("endDate", DateUtil.stringToDate(endDate, "yyyy-MM-dd"));
			}else{
				modelMap.put("endDate", new Date());
			}
			phoneVisitcountService.promotionActivity(modelMap,startDate,endDate,page);	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 会员列表
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 */
	public void memberList(ModelMap modelMap,String memberPhone,Pages page){
		try {
			phoneVisitcountService.memberList(modelMap,memberPhone,page);	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 联龙博通推广会员列表
	 * @param modelMap
	 * @param page
	 */
	public void memberListOther(ModelMap modelMap,int startIndex,int pageSize,Map<String,String> reqs,HttpServletRequest request){
		try {
			phoneVisitcountService.memberListOther(modelMap,startIndex,pageSize,reqs,request);	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}