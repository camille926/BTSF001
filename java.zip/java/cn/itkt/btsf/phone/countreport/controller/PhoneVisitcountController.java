package cn.itkt.btsf.phone.countreport.controller;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.itkt.btsf.sys.security.vo.UserVO;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.pagination.Pages;


@Controller
@RequestMapping("/phone/countreport/phonevisitcount")
public class PhoneVisitcountController {

	@Resource
	private  PhoneVisitcountControllerSupport  phoneVisitcountControllerSupport;
	private final static String[] SN = {"chenlei","yanjp","hanxj","wangwj","liukai"};
	/**
	 * 昨日进展
	 * @param modelMap
	 * @param 
	 * @return
	 */
	
	@RequestMapping(value="/yesterday")
	public String yesterdayProgress(ModelMap modelMap){
		phoneVisitcountControllerSupport.yesterdayProgress(modelMap);
		return "phone/countreport/progressYesterday";		
		
	}
	
	/**
	 * 业务进展
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/bussiness")
	public String bussinessProgress(ModelMap modelMap,String startDate,String endDate,String channel){
		phoneVisitcountControllerSupport.bussinessProgress(modelMap, startDate, endDate,channel);
		String userRole=(String) modelMap.get("chaneelid1");
		if("O100".equals(userRole)){ //万易通用户
		  return "phone/countreport/progressBusinessOther";
		}else{
			openSearch(modelMap);
			return "phone/countreport/progressBusiness";
		}
	}
	
	/**
	 * 渠道业务进展
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value="/chaneel")
	public String chaneelProgress(ModelMap modelMap,String startDate,String endDate,String channel,
			@RequestParam(value = "startIndex", defaultValue = "0") int startIndex){
		phoneVisitcountControllerSupport.chaneelProgress(modelMap,startDate,endDate,channel,startIndex,50);
		String userRole=(String) modelMap.get("chaneelid1");
		if("O100".equals(userRole)){
		    return "phone/countreport/progressChaneelOther";
		}else{ 
			openSearch(modelMap);
			return "phone/countreport/progressChaneel";
		}
	}
	/**
	 * 促销活动
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/promotionactivity")
	public String promotionActivity(ModelMap modelMap,String startDate,String endDate,
			@RequestParam(value = "startIndex", defaultValue = "0") int startIndex){
		Pages page = new Pages(startIndex);
		phoneVisitcountControllerSupport.promotionActivity(modelMap, startDate, endDate,page);
		return "phone/countreport/promotionActivity";
	}
	/**
	 * 会员列表
	 * @param modelMap
	 * @param memberPhone
	 * @return
	 */
	
	@RequestMapping(value="/memberlist")
	public String memberList(ModelMap modelMap,String memberPhone,@RequestParam(value = "startIndex", defaultValue = "0") int startIndex,@RequestParam Map<String, String> reqs,HttpServletRequest request){
		if("wanyitong".equals(LoginUtil.getLoginUser().getUsername().toLowerCase())){//联龙博通(万易通)推广用户
			if(StringUtils.isEmpty(reqs.get("startDate"))&&StringUtils.isEmpty(reqs.get("endDate"))){
				Calendar calendar = new GregorianCalendar();
				calendar.setTime(new Date());
				calendar.add(Calendar.DATE, -1);
				String yesterday = new SimpleDateFormat("yyyy-MM-dd").format(calendar.getTime());
				reqs.put("startDate", yesterday);
				reqs.put("endDate", yesterday);
			}
		
			phoneVisitcountControllerSupport.memberListOther(modelMap,startIndex,10,reqs,request);
			return "phone/countreport/memberListOther"; 
		}
		Pages page = new Pages(startIndex);
		phoneVisitcountControllerSupport.memberList(modelMap, memberPhone,page);
		modelMap.put("memberPhone", memberPhone);
		return "phone/countreport/memberList"; 
	}
	
	/**
	 * 注册指定日期格式的日期属性编辑器
	 * 
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		formater.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formater, true));
	}
	/**
	 * 导出业务统计报表
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value="/exportBissness")
	public String exportBissness(ModelMap modelMap,String startDate,String endDate,String channel){
		phoneVisitcountControllerSupport.bussinessProgress(modelMap, startDate, endDate,channel);
		openSearch(modelMap);
		return "exportBissnessExcel";
	}
	
	/**
	 * 导出渠道业务统计报表
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value="/exportchaneel")
	public String exportChaneel(ModelMap modelMap,String startDate,String channel,String endDate){
//		Pages page = new Pages(0);  //报表不需要分页，
//		page.setPageSize(999999999);
		phoneVisitcountControllerSupport.chaneelProgress(modelMap,startDate,endDate,channel,0,999999999);
		if("O100".equals(modelMap.get("chaneelid1"))){
			return "exportChaneelExcelOther";
		}
		openSearch(modelMap);
		return "exportChaneelExcel";
	}
	
	/**
	 * 导出促销活动统计报表
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value="/exportActivity")
	public String exportPromotionActivity(ModelMap modelMap,String startDate,String endDate){
		Pages page = new Pages(0);
		page.setPageSize(999999999);
		phoneVisitcountControllerSupport.promotionActivity(modelMap, startDate, endDate,page);
		return "exportActivityExcel";
	}
	
	@RequestMapping(value="/exportMember")
	public String exportMember(ModelMap modelMap,String memberPhone,@RequestParam Map<String, String> reqs,HttpServletRequest request){
		if("wanyitong".equals(LoginUtil.getLoginUser().getUsername().toLowerCase())){//联龙博通(万易通)推广用户
			phoneVisitcountControllerSupport.memberListOther(modelMap,0,65536,reqs,request);
			return "exportMemberListOtherExcel";
		}
		Pages page = new Pages(0);
		page.setPageSize(999999999);
		phoneVisitcountControllerSupport.memberList(modelMap, memberPhone,page);
		modelMap.put("memberPhone", memberPhone);
		return "exportMemberExcel";
	}
	private void openSearch(ModelMap modelMap){
		UserVO loginUser = LoginUtil.getLoginUser();
		String userName = loginUser.getUsername();
		for(String n:SN){
			if(n.equals(userName)){
				modelMap.put("openSearch", "yes");
				break;
			}
		}
	}
	
}