package cn.itkt.btsf.phone.export;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;

import cn.itkt.btsf.util.DateUtil;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

/**
 * 会员列表导出excel
 * @author Administrator
 *
 */
public class MemberExcel extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> arg0,
			HSSFWorkbook Workbook, HttpServletRequest arg2, HttpServletResponse arg3)
			throws Exception {
		String filename = "";
		HSSFSheet sheet = Workbook.createSheet("会员列表");
		sheet.setDefaultColumnWidth(20);
		setText(getCell(sheet,0,0),"手机号");
		setText(getCell(sheet,0,1),"版本");
		setText(getCell(sheet,0,2),"终端类型");
		setText(getCell(sheet,0,3),"渠道");
		setText(getCell(sheet,0,4),"注册日期");
		setText(getCell(sheet,0,5),"消费总金额");
		setText(getCell(sheet,0,6),"用户支出金额");
		setText(getCell(sheet,0,7),"畅达币支出金额");
		setText(getCell(sheet,0,8),"获赠畅达币总金额");
		setText(getCell(sheet,0,9),"畅达币余额");
		//setText(getCell(sheet,0,10),"成长点");
		
		Pages page = (Pages)arg0.get("page");
		List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )page.getItems();
		//List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )arg0.get("countTicket");
		for (int i =0;i<list.size();i++) {
			HashMap<String, Object> hashMap = list.get(i);
			setText(getCell(sheet,(i+1),0),String.valueOf(SysUtil.ifNull(hashMap.get("PHONE"))));
			setText(getCell(sheet,(i+1),1),String.valueOf(SysUtil.ifNull(hashMap.get("VERSION"))));
			setText(getCell(sheet,(i+1),2),String.valueOf(SysUtil.ifNull(hashMap.get("SYSTEMTYPE"))));
			setText(getCell(sheet,(i+1),3),String.valueOf(SysUtil.ifNull(hashMap.get("CHANNELID"))));
			setText(getCell(sheet,(i+1),4),String.valueOf(SysUtil.ifNull(hashMap.get("ADDTIME"))));
			setText(getCell(sheet,(i+1),5),String.valueOf(SysUtil.ifNull(hashMap.get("TOTALAMOUNT"))));
			
			BigDecimal totalAmount = hashMap.get("TOTALAMOUNT")==null?new BigDecimal(0):(BigDecimal) hashMap.get("TOTALAMOUNT");
			BigDecimal totalCoin =  hashMap.get("TOTALCOIN")==null?new BigDecimal(0): (BigDecimal)hashMap.get("TOTALCOIN");
			totalAmount = totalAmount.add(totalCoin);
			if(totalAmount.compareTo(new BigDecimal(0))==0){
				setText(getCell(sheet,(i+1),6),String.valueOf(SysUtil.ifNull("")));
			}else{
				setText(getCell(sheet,(i+1),6),String.valueOf(SysUtil.ifNull(totalAmount)));
			}
			
			
			setText(getCell(sheet,(i+1),7),String.valueOf(SysUtil.ifNull(hashMap.get("PAYCOIN"))));
			setText(getCell(sheet,(i+1),8),String.valueOf(SysUtil.ifNull(hashMap.get("RECEIPTSCOIN"))));
			
			setText(getCell(sheet,(i+1),9),String.valueOf(SysUtil.ifNull(hashMap.get("PAYCOIN"))));
			
			//setText(getCell(sheet,(i+1),10),String.valueOf(SysUtil.ifNull(hashMap.get("PAYCOIN"))));
		}
		//设置下载时客户端Excel的名称
//		if(arg0.get("startDate") == null && arg0.get("endDate") != null){
//			filename = "会员列表业务发展日起"+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";  
//		}else if(arg0.get("endDate") == null && arg0.get("startDate") != null){
//			filename = "会员列表"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-至今"+".xls"; 
//		}else if(arg0.get("endDate") == null && arg0.get("startDate") == null){
//			filename = "会员列表 业务发展日起-至今.xls";
//		}else{
//			filename = "会员列表"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";
//		}
		if(arg0.get("memberPhone") == null || "".equals(arg0.get("memberPhone"))){
			filename = "会员列表 业务发展日起-至今.xls";
		}else{
			filename = "会员列表 "+arg0.get("memberPhone")+".xls";
		}
		    
		filename = this.encodeFilename(filename, arg2);//处理中文文件名   
		arg3.setContentType("application/vnd.ms-excel");      
		arg3.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = arg3.getOutputStream();      
		Workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close();      
	}
	/**   
	     * 设置下载文件中文件的名称   
	     *    
	     * @param filename   
	     * @param request   
	     * @return   
	     */     
	    public static String encodeFilename(String filename, HttpServletRequest request) {     
	      /**   
	       * 获取客户端浏览器和操作系统信息   
	      * 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)   
	       * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6   
	       */     
	      String agent = request.getHeader("USER-AGENT");     
	      try {     
	        if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {     
	          String newFileName = URLEncoder.encode(filename, "UTF-8");     
	          newFileName = newFileName.replace("+", "%20");     
	          if (newFileName.length() > 150) {     
	            newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");     
	            newFileName = newFileName.replace("+", "%20");     
	          }     
	          return newFileName;     
	        }     
	        if ((agent != null) && (-1 != agent.indexOf("Mozilla")))     
	          return MimeUtility.encodeText(filename, "UTF-8", "B");     
	       
	        return filename;     
	      } catch (Exception ex) {     
	        return filename;     
	      }     
	    }  
}
