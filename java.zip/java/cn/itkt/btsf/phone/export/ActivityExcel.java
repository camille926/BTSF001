package cn.itkt.btsf.phone.export;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;

import cn.itkt.btsf.util.DateUtil;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

/**
 * 促销活动导出excel
 * @author Administrator
 *
 */
public class ActivityExcel extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> arg0,
			HSSFWorkbook Workbook, HttpServletRequest arg2, HttpServletResponse arg3)
			throws Exception {
		String filename = "";
		HSSFSheet sheet = Workbook.createSheet("促销活动");
		sheet.setDefaultColumnWidth(20);
		setText(getCell(sheet,0,0),"日期");
		setText(getCell(sheet,0,1),"新增成功推荐人数");
		setText(getCell(sheet,0,2),"累计成功推荐人数");
		setText(getCell(sheet,0,3),"当日推荐起飞人次");
		setText(getCell(sheet,0,4),"累计推荐起飞人次");
		
		setText(getCell(sheet,0,5),"当日畅达币赠送金额");
		setText(getCell(sheet,0,6),"累计畅达币赠送金额");
		
		//setText(getCell(sheet,0,7),"当日畅达币支出金额");
		//setText(getCell(sheet,0,7),"累计畅达币支出金额");
		
		Pages page = (Pages)arg0.get("page");
		List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )page.getItems();
		for (int i =0;i<list.size();i++) {
			HashMap<String, Object> hashMap = list.get(i);
			setText(getCell(sheet,(i+1),0),String.valueOf(SysUtil.ifNull(hashMap.get("TTIME"))));
			setText(getCell(sheet,(i+1),1),String.valueOf(SysUtil.ifNull(hashMap.get("COUNTNUM"))));
			setText(getCell(sheet,(i+1),2),String.valueOf(SysUtil.ifNull(hashMap.get("TOTALCOUNTNUM"))));
			setText(getCell(sheet,(i+1),3),String.valueOf(SysUtil.ifNull(hashMap.get("COUNTMER"))));
			setText(getCell(sheet,(i+1),4),String.valueOf(SysUtil.ifNull(hashMap.get("TOTALCOUNTMER"))==""?"0":SysUtil.ifNull(hashMap.get("TOTALCOUNTMER"))));
			setText(getCell(sheet,(i+1),5),String.valueOf(SysUtil.ifNull(hashMap.get("COUNTCOIN"))));
			
			setText(getCell(sheet,(i+1),6),String.valueOf(SysUtil.ifNull(hashMap.get("TOTALCOUNTCOIN"))==""?"0":SysUtil.ifNull(hashMap.get("TOTALCOUNTCOIN"))));
			
			//setText(getCell(sheet,(i+1),7),String.valueOf(SysUtil.ifNull(hashMap.get("COUNTPAY"))));
			//setText(getCell(sheet,(i+1),8),String.valueOf(SysUtil.ifNull(hashMap.get("TOTALCOUNTPAY"))));
			
		}
		//设置下载时客户端Excel的名称
		if(arg0.get("startDate") == null && arg0.get("endDate") != null){
			filename = "促销活动 业务发展日起"+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";  
		}else if(arg0.get("endDate") == null && arg0.get("startDate") != null){
			filename = "促销活动"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-至今"+".xls"; 
		}else if(arg0.get("endDate") == null && arg0.get("startDate") == null){
			filename = "促销活动 业务发展日起-至今.xls";
		}else{
			filename = "促销活动"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";
		}
		    
		filename = this.encodeFilename(filename, arg2);//处理中文文件名   
		arg3.setContentType("application/vnd.ms-excel");      
		arg3.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = arg3.getOutputStream();      
		Workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close();      
	}
	/**   
	     * 设置下载文件中文件的名称   
	     *    
	     * @param filename   
	     * @param request   
	     * @return   
	     */     
	    public static String encodeFilename(String filename, HttpServletRequest request) {     
	      /**   
	       * 获取客户端浏览器和操作系统信息   
	      * 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)   
	       * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6   
	       */     
	      String agent = request.getHeader("USER-AGENT");     
	      try {     
	        if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {     
	          String newFileName = URLEncoder.encode(filename, "UTF-8");     
	          newFileName = newFileName.replace("+", "%20");     
	          if (newFileName.length() > 150) {     
	            newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");     
	            newFileName = newFileName.replace("+", "%20");     
	          }     
	          return newFileName;     
	        }     
	        if ((agent != null) && (-1 != agent.indexOf("Mozilla")))     
	          return MimeUtility.encodeText(filename, "UTF-8", "B");     
	       
	        return filename;     
	      } catch (Exception ex) {     
	        return filename;     
	      }     
	    }  
}
