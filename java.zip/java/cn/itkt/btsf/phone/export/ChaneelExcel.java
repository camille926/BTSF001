package cn.itkt.btsf.phone.export;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;

import cn.itkt.btsf.util.DateUtil;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

public class ChaneelExcel extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> arg0,
			HSSFWorkbook Workbook, HttpServletRequest arg2, HttpServletResponse arg3)
			throws Exception {
		String filename = "";
		HSSFSheet sheet = Workbook.createSheet("渠道业务进展");
		sheet.setDefaultColumnWidth(20);
		boolean isLcd =  arg0.get("chaneelid1")==null||arg0.get("chaneelid1").equals("");
		int tmpIndex = -1;
		setText(getCell(sheet,0,tmpIndex+=1),"渠道");
		setText(getCell(sheet,0,tmpIndex+=1),"新增注册数");
		if(isLcd){
			setText(getCell(sheet,0,tmpIndex+=1),"注册用户总数");
		}
		setText(getCell(sheet,0,tmpIndex+=1),"新增激活数");
		if(isLcd){
			setText(getCell(sheet,0,tmpIndex+=1),"激活用户总数");
		}
		setText(getCell(sheet,0,tmpIndex+=1),"注册转化率");
		//查询次数暂时屏蔽2012-10-16 xuyh
		//setText(getCell(sheet,0,5),"查询次数");
		if("yes".equals(arg0.get("openSearch"))){
			setText(getCell(sheet,0,tmpIndex+=1),"查询次数");
		}
		//if(arg0.get("chaneelid1") == null){
		setText(getCell(sheet,0,tmpIndex+=1),"出票张数");
		setText(getCell(sheet,0,tmpIndex+=1),"出票总张数");
		setText(getCell(sheet,0,tmpIndex+=1),"出票金额");
		//}
		
		Pages page = (Pages)arg0.get("page");
		List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )page.getItems();
		//List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )arg0.get("countProgress");
		for (int i =0;i<list.size();i++) {
			int tmpIndex0 = -1;
			HashMap<String, Object> hashMap = list.get(i);
			setText(getCell(sheet,(i+1),tmpIndex0+=1),String.valueOf(SysUtil.ifNull(hashMap.get("CHANEEL"))));
			setText(getCell(sheet,(i+1),tmpIndex0+=1),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTRATIONDAY"))));
			if(isLcd){
				setText(getCell(sheet,(i+1),tmpIndex0+=1),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTRATIONCOUNT"))));
			}
			setText(getCell(sheet,(i+1),tmpIndex0+=1),String.valueOf(SysUtil.ifNull(hashMap.get("ACTIVITYDAY"))));
			if(isLcd){
				setText(getCell(sheet,(i+1),tmpIndex0+=1),String.valueOf(SysUtil.ifNull(hashMap.get("ACTIVITYCOUNT"))));
			}
			String addRegStr = SysUtil.ifNull(hashMap.get("REGISTRATIONDAY"));
			String addActStr = SysUtil.ifNull(hashMap.get("ACTIVITYDAY"));
			String actReg = "0%";
			if("".equals(addActStr)||"".equals(addRegStr)||"0".equals(addActStr)||"0".equals(addRegStr)){
				actReg = "0%";
			}else{
				float actRegStr = Float.parseFloat(addRegStr)/Float.parseFloat(addActStr);
				actReg = String.format("%2.1f", actRegStr*100)+"%";
			}
			setText(getCell(sheet,(i+1),tmpIndex0+=1),actReg);
			//查询次数暂时屏蔽2012-10-16 xuyh
			//setText(getCell(sheet,(i+1),5),String.valueOf(SysUtil.ifNull(hashMap.get("QUERYCOUNT"))));
			if("yes".equals(arg0.get("openSearch"))){
				String queryconut = String.valueOf(SysUtil.ifNull(hashMap.get("QUERYCOUNT")));
				try{
					queryconut = Integer.parseInt(queryconut)*2+"";
				}catch(Exception e){}
				
				setText(getCell(sheet,(i+1),tmpIndex0+=1),queryconut);
			}
			//if(arg0.get("chaneelid1") == null){
			setText(getCell(sheet,(i+1),tmpIndex0+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETNUM"))));
			setText(getCell(sheet,(i+1),tmpIndex0+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETNUMCOUNT"))));
			setText(getCell(sheet,(i+1),tmpIndex0+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETAMOUNT"))));
			//}
		}
		//设置下载时客户端Excel的名称
		if(arg0.get("startDate") == null && arg0.get("endDate") != null){
			filename = "渠道业务进展 业务发展日起"+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";  
		}else if(arg0.get("endDate") == null && arg0.get("startDate") != null){
			filename = "渠道业务进展"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-至今"+".xls"; 
		}else if(arg0.get("endDate") == null && arg0.get("startDate") == null){
			filename = "渠道业务进展 业务发展日起-至今.xls";
		}else{
			filename = "渠道业务进展"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";
		}
		    
		filename = this.encodeFilename(filename, arg2);//处理中文文件名   
		arg3.setContentType("application/vnd.ms-excel");      
		arg3.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = arg3.getOutputStream();      
		Workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close();      
	}
	/**   
	     * 设置下载文件中文件的名称   
	     *    
	     * @param filename   
	     * @param request   
	     * @return   
	     */     
	    public static String encodeFilename(String filename, HttpServletRequest request) {     
	      /**   
	       * 获取客户端浏览器和操作系统信息   
	      * 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)   
	       * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6   
	       */     
	      String agent = request.getHeader("USER-AGENT");     
	      try {     
	        if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {     
	          String newFileName = URLEncoder.encode(filename, "UTF-8");     
	          newFileName = newFileName.replace("+", "%20");     
	          if (newFileName.length() > 150) {     
	            newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");     
	            newFileName = newFileName.replace("+", "%20");     
	          }     
	          return newFileName;     
	        }     
	        if ((agent != null) && (-1 != agent.indexOf("Mozilla")))     
	          return MimeUtility.encodeText(filename, "UTF-8", "B");     
	       
	        return filename;     
	      } catch (Exception ex) {     
	        return filename;     
	      }     
	    }  
}
