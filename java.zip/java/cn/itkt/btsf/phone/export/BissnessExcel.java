package cn.itkt.btsf.phone.export;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;

import cn.itkt.btsf.util.DateUtil;
import cn.itkt.util.SysUtil;

public class BissnessExcel extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> arg0,
			HSSFWorkbook Workbook, HttpServletRequest arg2, HttpServletResponse arg3)
			throws Exception {
		boolean flag = "O100".equals(arg0.get("chaneelid1"));
		String filename = "";
		HSSFSheet sheet = Workbook.createSheet("业务进展");
		sheet.setDefaultColumnWidth(20);
		boolean isLcd =  arg0.get("chaneelid1")==null||arg0.get("chaneelid1").equals("");
		if(flag){//万易通
			int col=0;
			setText(getCell(sheet,0,col++),"日期");
			setText(getCell(sheet,0,col++),"新增注册数");
			if(isLcd){
				setText(getCell(sheet,0,col++),"注册用户总数");
			}
			setText(getCell(sheet,0,col++),"出票张数");
			setText(getCell(sheet,0,col++),"出票总张数");
		}else{
			int tmpIndex = -1;
			setText(getCell(sheet,0,tmpIndex+=1),"日期");
			setText(getCell(sheet,0,tmpIndex+=1),"新增注册数");
			if(isLcd){
				setText(getCell(sheet,0,tmpIndex+=1),"注册用户总数");
			}
			setText(getCell(sheet,0,tmpIndex+=1),"新增激活数");
			if(isLcd){
				setText(getCell(sheet,0,tmpIndex+=1),"激活用户总数");
			}
			setText(getCell(sheet,0,tmpIndex+=1),"日注册转化率");
			//查询次数暂时屏蔽2012-10-16 xuyh
			//setText(getCell(sheet,0,6),"查询次数");
			//if(arg0.get("chaneelid1") == null){
			if("yes".equals(arg0.get("openSearch"))){
				setText(getCell(sheet,0,tmpIndex+=1),"查询次数");
			}
			setText(getCell(sheet,0,tmpIndex+=1),"出票张数");
			setText(getCell(sheet,0,tmpIndex+=1),"出票总张数");
			setText(getCell(sheet,0,tmpIndex+=1),"出票金额");
			//}
		}
		if(flag){//万易通
			//对返回多个list做处理
			List<HashMap<String, Object>> list0 = (List<HashMap<String, Object>> )arg0.get("countProgress");
			if(list0 != null && list0.size()>0){
				for (int i =0;i<list0.size();i++) {
					int col=0;
					HashMap<String, Object> hashMap = list0.get(i);
					setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("REPORTDATE"))));
					setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTRATIONDAY"))));
					if(isLcd){
						setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTRATIONTOTAL"))));
					}	
					setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETCOUNT"))));
					setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETCOUNTTOTAL"))));
				}
			}
		}else{
		//对返回多个list做处理
//		List<HashMap<String, Object>> list = reList(arg0);
		List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )arg0.get("dayCountProgress");
		int tem = 1;
		if(list != null && list.size()>0){
			tem = 2;
			for (int i =0;i<list.size();i++) {
				int tmpIndex = -1;
				HashMap<String, Object> hashMap = list.get(i);
				setText(getCell(sheet,(i+1),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("REPORTDATE"))));
				setText(getCell(sheet,(i+1),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTRATIONDAY"))));
				if(isLcd){
					setText(getCell(sheet,(i+1),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTRATIONCOUNT"))));
				}
				setText(getCell(sheet,(i+1),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("ACTIVITYDAY"))));
				if(isLcd){
					setText(getCell(sheet,(i+1),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("ACTIVITYCOUNT"))));
				}
				
				float aa = Float.parseFloat(hashMap.get("REGISTRATIONDAY").toString());
				float bb = Float.parseFloat(hashMap.get("ACTIVITYDAY").toString());
				float tt = aa/bb*1000;
				tt = (float) (Math.round(tt)/10.0); 
				//System.out.println(Math.round(tt)/10.0);
				setText(getCell(sheet,(i+1),tmpIndex+=1),tt+"%");
				//查询次数暂时屏蔽2012-10-16 xuyh
				//setText(getCell(sheet,(i+1),6),String.valueOf(SysUtil.ifNull(hashMap.get("QUERYCOUNT"))));
				//if(arg0.get("chaneelid1") == null){
				if("yes".equals(arg0.get("openSearch"))){
					String queryconut = String.valueOf(SysUtil.ifNull(hashMap.get("QUERYCOUNT")));
					try{
						queryconut = Integer.parseInt(queryconut)*2+"";
					}catch(Exception e){}
					setText(getCell(sheet,(i+1),tmpIndex+=1),queryconut);
				}
				setText(getCell(sheet,(i+1),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETNUM"))));
				setText(getCell(sheet,(i+1),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETCOUNT"))));
				setText(getCell(sheet,(i+1),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETAMOUNT"))));
				//}
			}
		}
		
		list = (List<HashMap<String, Object>> )arg0.get("countProgress");
		if(list != null && list.size()>0){
			for (int i =0;i<list.size();i++) {
				int tmpIndex = -1;
				HashMap<String, Object> hashMap = list.get(i);
				setText(getCell(sheet,(tem+i),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("VISITTIME"))));
				setText(getCell(sheet,(tem+i),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("ADDREGISTERCOUNT"))));
				if(isLcd){
					setText(getCell(sheet,(tem+i),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTERTOTAL"))));
				}
				setText(getCell(sheet,(tem+i),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("ADDACTIVATECOUNT"))));
				if(isLcd){
					setText(getCell(sheet,(tem+i),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("ACTIVATETOTAL"))));
				}
				
				float aa = Float.parseFloat(hashMap.get("ADDREGISTERCOUNT").toString());
				float bb = Float.parseFloat(hashMap.get("ADDACTIVATECOUNT").toString());
				float tt = aa/bb*1000;
				if(bb==0.0){
					tt=0.0f;
				}else{
					tt = (float) (Math.round(tt)/10.0); 
				}
				//System.out.println(Math.round(tt)/10.0);
				setText(getCell(sheet,(tem+i),tmpIndex+=1),tt+"%");
				//查询次数暂时屏蔽2012-10-16 xuyh
				//setText(getCell(sheet,(tem+i),6),String.valueOf(SysUtil.ifNull(hashMap.get("QUERYCOUNT"))));
				//if(arg0.get("chaneelid1") == null){
				if("yes".equals(arg0.get("openSearch"))){
					String queryconut = String.valueOf(SysUtil.ifNull(hashMap.get("QUERYCOUNT")));
					try{
						queryconut = Integer.parseInt(queryconut)*2+"";
					}catch(Exception e){}
					setText(getCell(sheet,(tem+i),tmpIndex+=1),queryconut);
				}
				setText(getCell(sheet,(tem+i),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETCOUNT"))));
				setText(getCell(sheet,(tem+i),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETCOUNTTOTAL"))));
				setText(getCell(sheet,(tem+i),tmpIndex+=1),String.valueOf(SysUtil.ifNull(hashMap.get("TICKERTOTALAMOUNT"))));
				//}
			}
		}
		}

		
		//设置下载时客户端Excel的名称
		if(arg0.get("startDate") == null && arg0.get("endDate") != null){
			filename = "业务进展 业务发展日起"+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";  
		}else if(arg0.get("endDate") == null && arg0.get("startDate") != null){
			filename = "业务进展"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-至今"+".xls"; 
		}else if(arg0.get("endDate") == null && arg0.get("startDate") == null){
			filename = "业务进展 业务发展日起-至今.xls";
		}else{
			filename = "业务进展"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";
		}
		    
		filename = this.encodeFilename(filename, arg2);//处理中文文件名   
		arg3.setContentType("application/vnd.ms-excel");      
		arg3.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = arg3.getOutputStream();      
		Workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close(); 
 

	}
	
	/**
	 * 对返回多个list做处理
	 * @param arg0
	 * @return
	 */
	private List<HashMap<String, Object>> reList(Map<String, Object> arg0){
		List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )arg0.get("dayCountProgress");
		if(list == null || list.size() <= 0 ){
			list = (List<HashMap<String, Object>> )arg0.get("countProgress");
		}else{
			List<HashMap<String, Object>> list1 = (List<HashMap<String, Object>> )arg0.get("countProgress");
			if(list1 != null && list1.size()>0){
				for(int i = 0; i< list1.size(); i++){
					list.add(list1.get(i));
				}
			}
		}
		return list;
	} 
	/**   
	     * 设置下载文件中文件的名称   
	     *    
	     * @param filename   
	     * @param request   
	     * @return   
	     */     
	    public static String encodeFilename(String filename, HttpServletRequest request) {     
	      /**   
	       * 获取客户端浏览器和操作系统信息   
	      * 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)   
	       * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6   
	       */     
	      String agent = request.getHeader("USER-AGENT");     
	      try {     
	        if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {     
	          String newFileName = URLEncoder.encode(filename, "UTF-8");     
	          newFileName = newFileName.replace("+", "%20");     
	          if (newFileName.length() > 150) {     
	            newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");     
	            newFileName = newFileName.replace("+", "%20");     
	          }     
	          return newFileName;     
	        }     
	        if ((agent != null) && (-1 != agent.indexOf("Mozilla")))     
	          return MimeUtility.encodeText(filename, "UTF-8", "B");     
	       
	        return filename;     
	      } catch (Exception ex) {     
	        return filename;     
	      }     
	    }  

}
