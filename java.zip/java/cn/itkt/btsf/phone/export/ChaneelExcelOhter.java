package cn.itkt.btsf.phone.export;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;

import cn.itkt.btsf.util.DateUtil;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;
/**
 * 万易通专用
 * @author Administrator
 *
 */
public class ChaneelExcelOhter extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> arg0,
			HSSFWorkbook Workbook, HttpServletRequest arg2, HttpServletResponse arg3)
			throws Exception {
		String filename = "";
		HSSFSheet sheet = Workbook.createSheet("渠道业务进展");
		sheet.setDefaultColumnWidth(20);
		int hcol = 0;
		setText(getCell(sheet,0,hcol++),"渠道");
		setText(getCell(sheet,0,hcol++),"新增激活数");
		setText(getCell(sheet,0,hcol++),"新增注册数");
//		setText(getCell(sheet,0,hcol++),"注册用户总数");
		setText(getCell(sheet,0,hcol++),"出票张数");
		setText(getCell(sheet,0,hcol++),"出票总张数");
		
		Pages page = (Pages)arg0.get("page");
		List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )page.getItems();
		//List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )arg0.get("countProgress");
		for (int i =0;i<list.size();i++) {
			int col=0;
			HashMap<String, Object> hashMap = list.get(i);
			setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("CHANNEL"))));
			setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("ACTIVITYDAY"))));
			setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTRATIONDAY"))));
//			setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("REGISTRATIONCOUNT"))));
			setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETNUM"))));
			setText(getCell(sheet,(i+1),col++),String.valueOf(SysUtil.ifNull(hashMap.get("TICKETNUMCOUNT"))));
			//}
		}
		//设置下载时客户端Excel的名称
		if(arg0.get("startDate") == null && arg0.get("endDate") != null){
			filename = "渠道业务进展 业务发展日起"+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";  
		}else if(arg0.get("endDate") == null && arg0.get("startDate") != null){
			filename = "渠道业务进展"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-至今"+".xls"; 
		}else if(arg0.get("endDate") == null && arg0.get("startDate") == null){
			filename = "渠道业务进展 业务发展日起-至今.xls";
		}else{
			filename = "渠道业务进展"+DateUtil.dateToString((Date)arg0.get("startDate"))+"-"+DateUtil.dateToString((Date)arg0.get("endDate"))+".xls";
		}
		    
		filename = this.encodeFilename(filename, arg2);//处理中文文件名   
		arg3.setContentType("application/vnd.ms-excel");      
		arg3.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = arg3.getOutputStream();      
		Workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close();      
	}
	/**   
	     * 设置下载文件中文件的名称   
	     *    
	     * @param filename   
	     * @param request   
	     * @return   
	     */     
	    public static String encodeFilename(String filename, HttpServletRequest request) {     
	      /**   
	       * 获取客户端浏览器和操作系统信息   
	      * 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)   
	       * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6   
	       */     
	      String agent = request.getHeader("USER-AGENT");     
	      try {     
	        if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {     
	          String newFileName = URLEncoder.encode(filename, "UTF-8");     
	          newFileName = newFileName.replace("+", "%20");     
	          if (newFileName.length() > 150) {     
	            newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");     
	            newFileName = newFileName.replace("+", "%20");     
	          }     
	          return newFileName;     
	        }     
	        if ((agent != null) && (-1 != agent.indexOf("Mozilla")))     
	          return MimeUtility.encodeText(filename, "UTF-8", "B");     
	       
	        return filename;     
	      } catch (Exception ex) {     
	        return filename;     
	      }     
	    }  
}
