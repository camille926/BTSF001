package cn.itkt.btsf.phone.export;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;
/**
 * 导出用户明细表 万易通专用
 * @author Administrator
 *
 */
public class MemberListOther extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> modelMap,
			HSSFWorkbook Workbook, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		String filename = "";
		HSSFSheet sheet = Workbook.createSheet("联龙博通推广用户明细");
		sheet.setDefaultColumnWidth(20);
		sheet.createFreezePane(0, 1);
		setText(getCell(sheet,0,0),"推荐号码");
		setText(getCell(sheet,0,1),"注册用户");
		setText(getCell(sheet,0,2),"归属渠道");
		setText(getCell(sheet,0,3),"注册时间");
		setText(getCell(sheet,0,4),"是否首次激活");
		
		Pages page = (Pages)modelMap.get("page");
		List<HashMap<String, Object>> list = (List<HashMap<String, Object>> )page.getItems();
		for (int i =0;i<list.size();i++) {
			HashMap<String, Object> hashMap = list.get(i);
			setText(getCell(sheet,(i+1),0),String.valueOf(SysUtil.ifNull(hashMap.get("RECOMMENDPHONE"))));
			setText(getCell(sheet,(i+1),1),String.valueOf(SysUtil.ifNull(hashMap.get("PHONE"))));
			setText(getCell(sheet,(i+1),2),String.valueOf(SysUtil.ifNull(hashMap.get("CHANNELID"))));
			setText(getCell(sheet,(i+1),3),String.valueOf(SysUtil.ifNull(hashMap.get("ADDTIME"))));
			setText(getCell(sheet,(i+1),4),String.valueOf(SysUtil.ifNull(hashMap.get("ACTIVITY"))));
		}
		//设置下载时客户端Excel的名称
		if(modelMap.get("startDate") == null && modelMap.get("endDate") != null){
			filename = "联龙博通推广用户明细[自推广之日"+"~"+modelMap.get("endDate")+"].xls";  
		}else if(modelMap.get("endDate") == null && modelMap.get("startDate") != null){
			filename = "联龙博通推广用户明细["+modelMap.get("startDate")+"~至今]"+".xls"; 
		}else if(modelMap.get("endDate") == null && modelMap.get("startDate") == null){
			filename = "联龙博通推广用户明细[自推广之日~至今].xls";
		}else{
			if(modelMap.get("endDate").equals(modelMap.get("startDate"))){
				filename = "联龙博通推广用户明细["+modelMap.get("startDate")+"].xls";
			}else{
				filename = "联龙博通推广用户明细["+modelMap.get("startDate")+"~"+modelMap.get("endDate")+"].xls";
			}
		}
		    
		filename = this.encodeFilename(filename, request);//处理中文文件名   
		response.setContentType("application/vnd.ms-excel");      
		response.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = response.getOutputStream();      
		Workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close();      
	}
	/**   
	     * 设置下载文件中文件的名称   
	     *    
	     * @param filename   
	     * @param request   
	     * @return   
	     */     
	    public static String encodeFilename(String filename, HttpServletRequest request) {     
	      /**   
	       * 获取客户端浏览器和操作系统信息   
	      * 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)   
	       * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6   
	       */     
	      String agent = request.getHeader("USER-AGENT");     
	      try {     
	        if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {     
	          String newFileName = URLEncoder.encode(filename, "UTF-8");     
	          newFileName = newFileName.replace("+", "%20");     
	          if (newFileName.length() > 150) {     
	            newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");     
	            newFileName = newFileName.replace("+", "%20");     
	          }     
	          return newFileName;     
	        }     
	        if ((agent != null) && (-1 != agent.indexOf("Mozilla")))     
	          return MimeUtility.encodeText(filename, "UTF-8", "B");     
	       
	        return filename;     
	      } catch (Exception ex) {     
	        return filename;     
	      }     
	    }  
}
