package cn.itkt.btsf.phone.export;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import cn.itkt.btsf.phone.ticketrate.po.TicketRatePO;
import cn.itkt.btsf.sys.baseinfo.po.ShippingSpacePO;
import cn.itkt.util.SysUtil;

public class RefundRateExcel extends AbstractExcelView{

	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook Workbook, HttpServletRequest arg2, HttpServletResponse arg3)
			throws Exception {
		HSSFSheet sheet = Workbook.createSheet("退票费率信息");
		sheet.setDefaultColumnWidth(20);
		setText(getCell(sheet,0,0),"AIRCODE");
		setText(getCell(sheet,0,1),"SEAT");
		setText(getCell(sheet,0,2),"HOURTWOBEFORE");
		setText(getCell(sheet,0,3),"HOURTWOAFTER");
		setText(getCell(sheet,0,4),"HOURBEFOUR");
		setText(getCell(sheet,0,5),"HOURAFTER");
		setText(getCell(sheet,0,6),"STANDARD");
		setText(getCell(sheet,0,7),"HOURTFBEFORE");
		setText(getCell(sheet,0,8),"");
		setText(getCell(sheet,0,9),"HOURTFAFTER");
		setText(getCell(sheet,0,10),"BASECABINBEFORE");
		setText(getCell(sheet,0,11),"BASECABINAFTER");
		setText(getCell(sheet,0,12),"");
		setText(getCell(sheet,0,13),"");
		setText(getCell(sheet,0,14),"");
		
		setText(getCell(sheet,1,0),"航空公司字节码");
		setText(getCell(sheet,1,1),"舱位");
		setText(getCell(sheet,1,2),"起飞前2小时之前");
		setText(getCell(sheet,1,3),"起飞前2小时之后");
		setText(getCell(sheet,1,4),"起飞前");
		setText(getCell(sheet,1,5),"起飞后");
		setText(getCell(sheet,1,6),"标准");
		setText(getCell(sheet,1,7),"起飞前24小时之前");
		setText(getCell(sheet,1,8),"起飞前24小时(不含)至2小时(不含)之间");
		setText(getCell(sheet,1,9),"24小时及以后");
		setText(getCell(sheet,1,10),"起飞前按基准舱X%");
		setText(getCell(sheet,1,11),"起飞后按基准舱X%");
		setText(getCell(sheet,1,12),"未办理过值机");
		setText(getCell(sheet,1,13),"办理过值机");
		setText(getCell(sheet,1,14),"客规编号");
		
		List<ShippingSpacePO> shippingSpacePO = (List<ShippingSpacePO>)model.get("refundRateList");
		if(shippingSpacePO != null){
			ShippingSpacePO po = null;
			TicketRatePO ticketrate = null;
			for(int i=1; i < shippingSpacePO.size();i++){
				po = shippingSpacePO.get(i);
				ticketrate = po.getTicketrate();
				if(ticketrate != null){
					setText(getCell(sheet,(i+1),0),po.getAirlinesCode());
					setText(getCell(sheet,(i+1),1),po.getSpaceCode());
					setText(getCell(sheet,(i+1),2),SysUtil.ifNull(ticketrate.getHourtwobefore())+"%");
					setText(getCell(sheet,(i+1),3),SysUtil.ifNull(ticketrate.getHourtwoafter())+"%");
					setText(getCell(sheet,(i+1),4),SysUtil.ifNull(ticketrate.getTakebefore())+"%");
					setText(getCell(sheet,(i+1),5),SysUtil.ifNull(ticketrate.getTakeafter())+"%");
					setText(getCell(sheet,(i+1),6),SysUtil.ifNull(ticketrate.getStandard())+"%");
					setText(getCell(sheet,(i+1),7),SysUtil.ifNull(ticketrate.getTakebeforetf())+"%");
					setText(getCell(sheet,(i+1),8),SysUtil.ifNull(ticketrate.getTakebeforetfbf())+"%");
					setText(getCell(sheet,(i+1),9),SysUtil.ifNull(ticketrate.getHourtfafter())+"%");
					setText(getCell(sheet,(i+1),10),SysUtil.ifNull(ticketrate.getBasecabinbefore())+"%");
					setText(getCell(sheet,(i+1),11),SysUtil.ifNull(ticketrate.getBasecabinafter())+"%");
					setText(getCell(sheet,(i+1),12),SysUtil.ifNull(ticketrate.getNcheckin())+"%");
					setText(getCell(sheet,(i+1),13),SysUtil.ifNull(ticketrate.getCheckin())+"%");
					setText(getCell(sheet,(i+1),14),SysUtil.ifNull(po.getGuestRulesCode()));
				}else{
					setText(getCell(sheet,(i+1),0),po.getAirlinesCode());
					setText(getCell(sheet,(i+1),1),po.getSpaceCode());
					setText(getCell(sheet,(i+1),2),"0%");
					setText(getCell(sheet,(i+1),3),"0%");
					setText(getCell(sheet,(i+1),4),"0%");
					setText(getCell(sheet,(i+1),5),"0%");
					setText(getCell(sheet,(i+1),6),"0%");
					setText(getCell(sheet,(i+1),7),"0%");
					setText(getCell(sheet,(i+1),8),"0%");
					setText(getCell(sheet,(i+1),9),"0%");
					setText(getCell(sheet,(i+1),10),"0%");
					setText(getCell(sheet,(i+1),11),"0%");
					setText(getCell(sheet,(i+1),12),"0%");
					setText(getCell(sheet,(i+1),13),"0%");
					setText(getCell(sheet,(i+1),14),po.getGuestRulesCode());
				}
			}
		}
		
	}

}
