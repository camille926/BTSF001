package cn.itkt.btsf.phone.ticketrate.vo;

import java.io.Serializable;
import java.util.Date;


/**
 * ${comments.get( $tablename)} 
 * @author codegen 2012-03-12 11:26:26 
 */
public class TicketRateVO {

    /** id **/ 
	private long id;
	
    /** 关联舱位表id **/ 
	private long cabinId;
	
    /** 时间类型(01:起飞前2小时之前,02:起飞前2小时之后,03:起飞前,04:起飞后,05:标准,06:起飞前24小时之前,07:起飞前24小时(不含)至2小时(不含)之间,08:起飞前24小时之后,09:起飞前按基准舱X%,10:起飞后按基准舱X%,11:未办理置机,12:办理置机) **/ 
	private String type;
	
    /** 费率 **/ 
	private double rate;
	

	/**
	 * 构造 
	 */
	public TicketRateVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public long getCabinId() {
		return cabinId;
	}

	public void setCabinId(long cabinId) {
		this.cabinId = cabinId;
	}
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


	public double getRate() {
		return rate;
	}


	public void setRate(double rate) {
		this.rate = rate;
	}

}