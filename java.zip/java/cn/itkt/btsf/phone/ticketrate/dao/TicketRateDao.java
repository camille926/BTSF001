package cn.itkt.btsf.phone.ticketrate.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Date;
import java.util.Map;

import cn.itkt.btsf.phone.ticketrate.po.TicketRatePO;
import cn.itkt.btsf.sys.baseinfo.po.ShippingSpacePO;

/**
 * ${comments.get( $tablename)} 
 * @author codegen 2012-03-12 11:26:26 
 */
public interface TicketRateDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return TicketRate 
	 */
	public TicketRatePO find(Serializable id);

	/**
	 * 查找所有  分页查询
	 * @return List<ticketRatePO> 
	 */
	public List<ShippingSpacePO> findAll(Map<String,Object> map);
	/**
	 * 总计数量
	 * @param map
	 * @return
	 */
	public int count(Map<String,Object> map);

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(TicketRatePO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(TicketRatePO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 删除所有
	 */
	public void deleteAll();
	/**
	 * 根据舱位id获得退票费率信息（返回这一舱位的费率信息没有的值填充0）
	 * @param cabinId
	 * @return
	 */
	public ShippingSpacePO findByCabinId(String cabinId);
	
	/**
	 * 根据舱位id获得退票费率信息
	 * @param cabinId
	 * @return
	 */
	public List<TicketRatePO> findByCId(String cabinId);
	
	
	/**
	 * 通过舱位id和时间类型查找退票费率信息
	 * @param map
	 * @return
	 */
	public TicketRatePO findByMap(Map<String,Object> map);
	
	/**
	 * 根据当前时间和航空公司和舱位查找舱位id
	 * @param map
	 * @return
	 */
	public String findcabinIdByTime(Map<String,Object> map);
	
	/**
	 * 根据客规编号和航空公司和舱位查找舱位id
	 * @param map
	 * @return
	 */
	public String findcabinIdByRuleCode(Map<String,Object> map);
	
	/**
	 * 根据id删除
	 */
	public void deleteById(Long id);
	
	/**
	 * 查询所有
	 */
	public List<ShippingSpacePO> findAll1();
	/**
	 * 根据舱位id和类型删除数据
	 * @param map
	 */
	public void deleteByCabinIdAndType(Map<String,Object> map);

}