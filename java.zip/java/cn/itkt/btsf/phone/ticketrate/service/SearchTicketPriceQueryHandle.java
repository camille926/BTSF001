package cn.itkt.btsf.phone.ticketrate.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import cn.itkt.btsf.sys.cc.national.dao.RefundTicketDao;
import cn.itkt.btsf.sys.cc.national.vo.RefundTicketInfoVO;
import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.util.SysUtil;

public class SearchTicketPriceQueryHandle extends AbstractWebserviceInvoker{
	@Override
	public Object[] buildArgument(Object args) throws Exception {
		RefundTicketInfoVO findTicketInfoAndStandardInfo = (RefundTicketInfoVO)args;
		Object[] obj = null;
		if(findTicketInfoAndStandardInfo != null){
			obj = new Object[8];
			obj[0] = findTicketInfoAndStandardInfo.getAtmNo();//自助终端编号
			obj[1] = findTicketInfoAndStandardInfo.getTakeofflocus();//起点站
			obj[2] = findTicketInfoAndStandardInfo.getArrivelocus();//到达站
			obj[3] = DateUtil.dateToString(findTicketInfoAndStandardInfo.getTakeofftime(), "yyyy-MM-dd HH:mm:ss");//起飞时间
			obj[4] = DateUtil.dateToString(findTicketInfoAndStandardInfo.getArrivetime(), "yyyy-MM-dd HH:mm:ss");//到达时间
			obj[5] = findTicketInfoAndStandardInfo.getAirteamnum();//航班号
			obj[6] = new String[]{findTicketInfoAndStandardInfo.getStandardSpace()};//舱位
			obj[7] = findTicketInfoAndStandardInfo.getAirplanetype();//机型
		}
		
		return obj;
	}

	@Override
	public Object buildResult(Object result) {
		TicketPrice ticketPrice = new TicketPrice();
		List<Map<String,Object>> list = null;
		try {
			String[] results = (String[])result;
			
			if(results != null && "0".equals(results[0])){
				ticketPrice.setResult(results[0]);
				ticketPrice.setErrorDescription(results[1]);
				String[] split = results[2].split(";");
				list = new ArrayList<Map<String,Object>>();
				Map<String,Object> map = new HashMap<String,Object>();
				for (String string : split) {
					String[] split2 = string.split("/");
					map.put("cabin", split2[0]);
					map.put("price", SysUtil.changeDecimal(Integer.parseInt(split2[1])*0.01));
					list.add(map);
				}
				ticketPrice.setCabinPriceList(list);
				
			}else{
				ticketPrice.setResult("");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ticketPrice;
	}
	
	public class TicketPrice{
		private String result;
		private String errorDescription;
		private List<Map<String,Object>> cabinPriceList;
		public String getResult() {
			return result;
		}
		public void setResult(String result) {
			this.result = result;
		}
		public String getErrorDescription() {
			return errorDescription;
		}
		public void setErrorDescription(String errorDescription) {
			this.errorDescription = errorDescription;
		}
		public List<Map<String, Object>> getCabinPriceList() {
			return cabinPriceList;
		}
		public void setCabinPriceList(List<Map<String, Object>> cabinPriceList) {
			this.cabinPriceList = cabinPriceList;
		}
		
		
		
	}
}
