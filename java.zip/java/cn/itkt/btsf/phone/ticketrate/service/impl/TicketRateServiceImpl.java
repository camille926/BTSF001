package cn.itkt.btsf.phone.ticketrate.service.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;


import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import cn.itkt.exception.AppException;
import cn.itkt.util.DateUtil;
import cn.itkt.util.SysUtil;
import cn.itkt.btsf.phone.ticketrate.po.TicketRatePO;
import cn.itkt.btsf.phone.ticketrate.dao.TicketRateDao;
import cn.itkt.btsf.phone.ticketrate.service.SearchTicketPriceQueryHandle;
import cn.itkt.btsf.phone.ticketrate.service.TicketRateService;
import cn.itkt.btsf.phone.ticketrate.service.SearchTicketPriceQueryHandle.TicketPrice;
import cn.itkt.btsf.sys.baseinfo.dao.GuestRuleDao;
import cn.itkt.btsf.sys.baseinfo.po.GuestRulePO;
import cn.itkt.btsf.sys.baseinfo.po.ShippingSpacePO;
import cn.itkt.btsf.sys.cc.national.dao.RefundTicketDao;
import cn.itkt.btsf.sys.cc.national.dao.TicketInfoDao;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.vo.RefundTicketInfoVO;
import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;
import cn.itkt.btsf.sys.common.constant.WebServiceConstant;
import cn.itkt.btsf.sys.terminal.dao.AtmDetailDao;
import cn.itkt.btsf.sys.terminal.po.AtmDetailPO;

@Service
public class TicketRateServiceImpl implements TicketRateService {

	private static final Logger log = LoggerFactory.getLogger(TicketRateServiceImpl.class);
	@Resource
	private RefundTicketDao refundTicketDao;
	
	@Resource
	private  TicketRateDao  ticketRateDao;
	
	@Resource
	private TicketInfoDao ticketInfoDao;
	@Resource
	private GuestRuleDao<GuestRulePO> guestRuleDao;
	/**
	 * 终端信息Dao对象
	 */
	@Resource
	private AtmDetailDao atmDetailDao;
	/**
	 * 查找单个 
	 * @param id 
	 * @return TicketRate 
	 */
	public TicketRatePO find(Serializable id){
		return ticketRateDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<ticketRatePO> 
	 */
	public List<ShippingSpacePO> findAll(Map<String,Object> map){
		return ticketRateDao.findAll(map);	
	}
	public int count(Map<String,Object> map){
		return ticketRateDao.count(map);
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean create(ModelMap modelMap,ShippingSpacePO shippingSpacePO) throws AppException{
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,Object> map1  = new HashMap<String,Object>();
		TicketRatePO ticketRatePO = new TicketRatePO();
		boolean flag = false;
		try{
			//通过客规编号和航空公司和舱位编号去舱位表找对应的舱位id(cabin_id)
			map.put("spaceCode", shippingSpacePO.getSpaceCode());
			map.put("aillinesCode", shippingSpacePO.getAirlinesCode());
			map.put("ruleCode", shippingSpacePO.getTicketrate().getRuleCode());
			String cabinId =ticketRateDao.findcabinIdByRuleCode(map);
			if(cabinId != null){
				//通过cabin_id和时间查找退票费率信息，如果没有那么组合信息新增退票费率信息，如果有，那么返回页面告知客户此航空公司和舱位已有对应的退票费率信息，请找到后进行修改
				TicketRatePO ticketrate = shippingSpacePO.getTicketrate();
				HashMap<String, Object> map2 = TicketRatePO.list(ticketrate);
				Iterator<String> iterator = map2.keySet().iterator();
				while(iterator.hasNext()){
					String next = iterator.next();
					if(map2.get(next) != null){
						//根据舱位id和时间类型查找退票费率信息
						map1.put("type", TicketRatePO.list().get(next));
						map1.put("cabinId", cabinId);
						TicketRatePO findByMap = ticketRateDao.findByMap(map1);
						if(findByMap != null){
							ticketRateDao.deleteById(findByMap.getId());
						}
						ticketRatePO.setCabinId(Long.valueOf(cabinId));
						ticketRatePO.setType(TicketRatePO.list().get(next));
						ticketRatePO.setRate(map2.get(next)==null?null:Double.parseDouble(map2.get(next).toString()));
						ticketRateDao.create(ticketRatePO);	
					}else{
						//新增
						ticketRatePO.setCabinId(Long.valueOf(cabinId));
						ticketRatePO.setType(TicketRatePO.list().get(next));
						ticketRatePO.setRate(map2.get(next)==null?null:Double.parseDouble(map2.get(next).toString()));
						ticketRateDao.create(ticketRatePO);
					}
					
					
				}
				flag = true;
			}else{
				flag = false;
			}
			
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
		return flag;
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean update(TicketRatePO po) throws AppException {
		boolean flag= false;
		Map<String,Object> map1  = new HashMap<String,Object>();
		TicketRatePO ticketRatePO = new TicketRatePO();
		HashMap<String, Object> map2= null;
		try{
			HashMap<String, Object> map = TicketRatePO.list(po);
			Iterator<String> iterator = map.keySet().iterator();
			
			//根据cabinid获取退票费率信息
			ShippingSpacePO findByCabinId = ticketRateDao.findByCabinId(po.getCabinId()+"");
			TicketRatePO ticketrate = findByCabinId.getTicketrate();
			if(ticketrate != null){
				map2 = TicketRatePO.list(ticketrate);
				while(iterator.hasNext()){
					String next = iterator.next();
					if(map.get(next)==null||!map.get(next).equals(map2.get(next))){
						//根据舱位id和时间类型查找退票费率信息
						map1.put("type", TicketRatePO.list().get(next));
						map1.put("cabinId", po.getCabinId());
						TicketRatePO findByMap = ticketRateDao.findByMap(map1);
						if(findByMap == null){
							//新增
							ticketRatePO.setCabinId(po.getCabinId());
							ticketRatePO.setType(TicketRatePO.list().get(next));
							ticketRatePO.setRate(map.get(next)==null?null:Double.parseDouble(map.get(next).toString()));
							ticketRateDao.create(ticketRatePO);
						}else{
							//修改
							findByMap.setRate(map.get(next)==null?null:Double.parseDouble(map.get(next).toString()));
							ticketRateDao.update(findByMap);
						}
						if(map.get(next) ==null){
							ticketRateDao.deleteByCabinIdAndType(map1);
						}
					}
					
				}
			}else{
				
			}
			
			
			flag= true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
		return flag;
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 ticketRateDao.delete(id);
	}
	/**
	 * 根据舱位id获得退票费率信息
	 * @param cabinId
	 * @return
	 */
	public ShippingSpacePO findByCabinId(String cabinId){
		return ticketRateDao.findByCabinId(cabinId);
	}

	@Override
	public List<ShippingSpacePO> export() {
		List<ShippingSpacePO> findAll = null;
		try {
			//获取退票费率所有信息
			findAll = ticketRateDao.findAll1();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return findAll;
	}

	@Override
	public void batchCreateRefundRate(List<ShippingSpacePO> list) {
		Map<String,Object> map = new HashMap<String,Object>();
		HashMap<String, Object> map2 = null;
		TicketRatePO ticketRatePO = new TicketRatePO();
		//删除所有退票费率信息
		ticketRateDao.deleteAll();
		
		for (ShippingSpacePO shippingSpacePO : list) {
			//当客规编号不为空才能导入
			if(shippingSpacePO.getTicketrate().getRuleCode() != null){
				//通过客规编号和航空公司和舱位去客规表找对应的舱位id(cabin_id)
				map.put("spaceCode", shippingSpacePO.getSpaceCode());
				map.put("aillinesCode", shippingSpacePO.getAirlinesCode());
				map.put("ruleCode", shippingSpacePO.getTicketrate().getRuleCode());
				String cabinId = ticketRateDao.findcabinIdByRuleCode(map);
				if(!SysUtil.isEmpty(cabinId)){
					TicketRatePO ticketrate = shippingSpacePO.getTicketrate();
					map2 = TicketRatePO.list(ticketrate);
					Iterator<String> iterator = map2.keySet().iterator();
					while(iterator.hasNext()){
						String next = iterator.next();
						if(map2.get(next) != null){
							//新增
							ticketRatePO.setCabinId(Long.valueOf(cabinId));
							ticketRatePO.setType(TicketRatePO.list().get(next));
							ticketRatePO.setRate((Double) map2.get(next));
							ticketRateDao.create(ticketRatePO);
						}
					}
				}
			}
		}
	}

	@Override
	public Map<String,Integer> getRefundRateByAirlinesAndSpace(String ticketNo) {
		int rate = 0;//退票费率
		int fee = 0;//退票手续费
		Double ticketPriceTotal;//票面价
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,Integer> result = new HashMap<String,Integer>();
		
		//票信息
		TicketInfoPO ticketInfoByTicketNo = ticketInfoDao.getTicketInfoByTicketNo(ticketNo);
		
		//票面价
		if("07".equals(ticketInfoByTicketNo.getSaleType())){
			ticketPriceTotal = ticketInfoByTicketNo.getTicketPricePm();
		}else{
			ticketPriceTotal = ticketInfoByTicketNo.getTicketPrice();
		}
		
		
		//通过当前时间和航空公司和舱位去客规表找对应的舱位id(cabin_id)
		map.put("spaceCode", ticketInfoByTicketNo.getCabin());
		map.put("aillinesCode", ticketInfoByTicketNo.getAirways());
		map.put("takeofftime", ticketInfoByTicketNo.getTakeofftime());
		String cabinId = ticketRateDao.findcabinIdByTime(map);
		
		//当前时间和起飞时间的相差小时
		long subduce = DateUtil.subduce(cn.itkt.btsf.util.DateUtil.dateToString(ticketInfoByTicketNo.getTakeofftime(), "yyyy-MM-dd HH:mm:ss"));
		
		if(!SysUtil.isEmpty(cabinId)){
			//通过cabinId获得该舱位的所有退票费率
			List<TicketRatePO> findByCId = ticketRateDao.findByCId(cabinId);
			if(findByCId.size()>= 1 ){
				for (TicketRatePO ticketRatePO : findByCId) {
					String type = ticketRatePO.getType();//时间类型
					
					//判断该航空公司舱位属于哪种退票类型
					if("01".equals(type) || "02".equals(type) ){
						if(subduce > 7200 && "01".equals(type)){
						//06:起飞前2小时之前
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}else if(subduce < 7200 && "02".equals(type)){
						//02:起飞前2小时之后
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}
						
					}else if("03".equals(type) || "04".equals(type) ){
						if("03".equals(type) && subduce>0){
						//03:起飞前
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}else if("04".equals(type) && subduce <0){
						//04:起飞后
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}
						
					}else if("05".equals(type)){
						//05:标准
						rate = SysUtil.changeDecimal(ticketRatePO.getRate());
						fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
						
					}else if("06".equals(type) ||  "08".equals(type)){
						if(subduce >86400 && "06".equals(type)){
						//06:起飞前24小时之前
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}else if(subduce <86400 && "08".equals(type)){
						//08:起飞前24小时之后
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}
						
					}else if("06".equals(type) || "07".equals(type) ||"02".equals(type)){
						if(subduce >86400 && "06".equals(type)){
						//06:起飞前24小时之前
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee = SysUtil.changeDecimal(rate *  ticketPriceTotal*0.01);
							
						}else if(subduce <= 86400 && subduce > 7200 && "07".equals(type)){
						//07:起飞前24小时(不含)至2小时(不含)之间
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}else if(subduce < 7200 && "02".equals(type)){
						//02:起飞前2小时之后
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}
						
					}else if("09".equals(type) || "10".equals(type)){
						//获取通过票号获取票信息和基准舱位、终端号信息
						RefundTicketInfoVO findTicketInfoAndStandardInfo = refundTicketDao.findTicketInfoAndStandardInfo(ticketNo);
						
						//查询机票时间
						AbstractWebserviceInvoker searchTicketPriceQuery = new SearchTicketPriceQueryHandle();
						//调用机票票价查询接口查询基准舱位价格
						TicketPrice ticketPrice =  (TicketPrice)searchTicketPriceQuery.invoke(WebServiceConstant.getEndPoint(), "searchTicketPriceQuery", WebServiceConstant.getQname(),findTicketInfoAndStandardInfo);
						if(!"".equals(ticketPrice.getResult()) && "0".equals(ticketPrice.getResult()) && ticketPrice.getCabinPriceList().size()>0){
							//获得基准舱位价格
							List<Map<String, Object>> cabinPriceList = ticketPrice.getCabinPriceList();
							
							if("09".equals(type) && subduce > 0){
							//09:起飞前按基准舱X%
								rate = SysUtil.changeDecimal(ticketRatePO.getRate());
								fee =  SysUtil.changeDecimal(rate * Integer.parseInt(cabinPriceList.get(0).get("price").toString())*0.01);
								
							}else if("10".equals(type) && subduce < 0){
							//10:起飞后按基准舱X%
								rate = SysUtil.changeDecimal(ticketRatePO.getRate());
								fee =  SysUtil.changeDecimal(rate * Integer.parseInt(cabinPriceList.get(0).get("price").toString())*0.01);
							}
							
						}
					}else if("11".equals(type) || "12".equals(type)){
						//12:办理置机
						if("1".equals(ticketInfoByTicketNo.getTicketRealState()) && "12".equals(type)){
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}else if("11".equals(type) && !"1".equals(ticketInfoByTicketNo.getTicketRealState())){
						//11:未办理置机
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketPriceTotal*0.01);
							
						}
					}
				}
			}
			
			String airway=ticketInfoByTicketNo.getAirways();
			String cabinLevel = ticketInfoByTicketNo.getCabinLevel();
			//获取通过票号获取票信息和基准舱位、终端号信息
			RefundTicketInfoVO findTicketInfoAndStandardInfo = refundTicketDao.findTicketInfoAndStandardInfo(ticketNo);
			if ((airway.equals("MU")
					|| airway.equals("FM")
					|| airway.equals("KN")) && rate != 0 && !"F".equals(findTicketInfoAndStandardInfo.getStandardSpace())) {
					if (rate * ticketPriceTotal/ 100 > 50) {
//						if (rate * ticketprice/ 100 % 10 > 0) {
//							fee = (int) Math.round(rate* ticketprice/ 100+ (10 - rate* ticketprice/ 100% 10));
//						} else {
						fee = (int) Math.round(rate* ticketPriceTotal/ 100);
//						}

					} else {
						fee = 50;
					}
			}
			
		}
		result.put("rate", rate);
		result.put("fee", fee);
		return result;
	}

	@Override
	public Map<String, Integer> getRefundRate(TicketInfoPO ticketInfoByTicketNo) {
		int rate = 0;//退票费率
		int fee = 0;//退票手续费
		Map<String,Object> map = new HashMap<String,Object>();
		Map<String,Integer> result = new HashMap<String,Integer>();

		//通过当前时间和航空公司和舱位去客规表找对应的舱位id(cabin_id)
		map.put("spaceCode", ticketInfoByTicketNo.getCabin());
		map.put("aillinesCode", ticketInfoByTicketNo.getAirways());
		map.put("takeofftime", ticketInfoByTicketNo.getTakeofftime());
		String cabinId = ticketRateDao.findcabinIdByTime(map);
		
		//当前时间和起飞时间的相差小时
		long subduce = DateUtil.subduce(cn.itkt.btsf.util.DateUtil.dateToString(ticketInfoByTicketNo.getTakeofftime(), "yyyy-MM-dd HH:mm:ss"));
		
		if(!SysUtil.isEmpty(cabinId)){
			//通过cabinId获得该舱位的所有退票费率
			List<TicketRatePO> findByCId = ticketRateDao.findByCId(cabinId);
			if(findByCId.size()>= 1 ){
				for (TicketRatePO ticketRatePO : findByCId) {
					String type = ticketRatePO.getType();//时间类型
					
					//判断该航空公司舱位属于哪种退票类型
					if("01".equals(type) || "02".equals(type) ){
						if(subduce > 7200 && "01".equals(type)){
						//06:起飞前2小时之前
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}else if(subduce < 7200 && "02".equals(type)){
						//02:起飞前2小时之后
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}
						
					}else if("03".equals(type) || "04".equals(type) ){
						if("03".equals(type) && subduce>0){
						//03:起飞前
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}else if("04".equals(type) && subduce <0){
						//04:起飞后
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}
						
					}else if("05".equals(type)){
						//05:标准
						rate = SysUtil.changeDecimal(ticketRatePO.getRate());
						fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
						
					}else if("06".equals(type) ||  "08".equals(type)){
						if(subduce >86400 && "06".equals(type)){
						//06:起飞前24小时之前
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}else if(subduce <86400 && "08".equals(type)){
						//08:起飞前24小时之后
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}
						
					}else if("06".equals(type) || "07".equals(type) ||"02".equals(type)){
						if(subduce >86400 && "06".equals(type)){
						//06:起飞前24小时之前
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee = SysUtil.changeDecimal(rate *  ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}else if(subduce <= 86400 && subduce > 7200 && "07".equals(type)){
						//07:起飞前24小时(不含)至2小时(不含)之间
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}else if(subduce < 7200 && "02".equals(type)){
						//02:起飞前2小时之后
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}
						
					}else if("09".equals(type) || "10".equals(type)){
						TicketPrice ticketPrice;
						if(ticketInfoByTicketNo.getTicketNo()==null||"".equals(ticketInfoByTicketNo.getTicketNo())){
							RefundTicketInfoVO searchTicketPriceRefund=new RefundTicketInfoVO();
							AtmDetailPO atmPo=atmDetailDao.find(ticketInfoByTicketNo.getAtmId());
							searchTicketPriceRefund.setAtmNo(atmPo.getAtmNo());
							//findTicketInfoAndStandardInfo.getAtmNo();//自助终端编号
							searchTicketPriceRefund.setTakeofflocus(ticketInfoByTicketNo.getTakeofflocus());//起点站
							searchTicketPriceRefund.setArrivelocus(ticketInfoByTicketNo.getArrivelocus());//到达站
							searchTicketPriceRefund.setTakeofftime(ticketInfoByTicketNo.getTakeofftime());//起飞时间
							searchTicketPriceRefund.setArrivetime(ticketInfoByTicketNo.getArrivetime());//到达时间
							searchTicketPriceRefund.setAirteamnum(ticketInfoByTicketNo.getAirteamnum());//航班号
							searchTicketPriceRefund.setStandardSpace(ticketInfoByTicketNo.getCabinLevel());//舱位
							searchTicketPriceRefund.setAirplanetype(ticketInfoByTicketNo.getAirplanetype());//机型
							AbstractWebserviceInvoker searchTicketPriceQuery = new SearchTicketPriceQueryHandle();
							//调用机票票价查询接口查询基准舱位价格
							 ticketPrice =  (TicketPrice)searchTicketPriceQuery.invoke(WebServiceConstant.getEndPoint(), "searchTicketPriceQuery", WebServiceConstant.getQname(),searchTicketPriceRefund);
						}else{
							RefundTicketInfoVO findTicketInfoAndStandardInfo = refundTicketDao.findTicketInfoAndStandardInfo(ticketInfoByTicketNo.getTicketNo());
							
							//查询机票时间
							AbstractWebserviceInvoker searchTicketPriceQuery = new SearchTicketPriceQueryHandle();
							//调用机票票价查询接口查询基准舱位价格
							 ticketPrice =  (TicketPrice)searchTicketPriceQuery.invoke(WebServiceConstant.getEndPoint(), "searchTicketPriceQuery", WebServiceConstant.getQname(),findTicketInfoAndStandardInfo);
						}
						//获取通过票号获取票信息和基准舱位、终端号信息
						
						if(!"".equals(ticketPrice.getResult()) && "0".equals(ticketPrice.getResult()) && ticketPrice.getCabinPriceList().size()>0){
							//获得基准舱位价格
							List<Map<String, Object>> cabinPriceList = ticketPrice.getCabinPriceList();
							
							if("09".equals(type) && subduce > 0){
							//09:起飞前按基准舱X%
								rate = SysUtil.changeDecimal(ticketRatePO.getRate());
								fee =  SysUtil.changeDecimal(rate * Integer.parseInt(cabinPriceList.get(0).get("price").toString())*0.01);
								
							}else if("10".equals(type) && subduce < 0){
							//10:起飞后按基准舱X%
								rate = SysUtil.changeDecimal(ticketRatePO.getRate());
								fee =  SysUtil.changeDecimal(rate * Integer.parseInt(cabinPriceList.get(0).get("price").toString())*0.01);
							}
							
						}
					}else if("11".equals(type) || "12".equals(type)){
						//12:办理置机
						if("1".equals(ticketInfoByTicketNo.getTicketRealState()) && "12".equals(type)){
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}else if("11".equals(type) && !"1".equals(ticketInfoByTicketNo.getTicketRealState())){
						//11:未办理置机
							rate = SysUtil.changeDecimal(ticketRatePO.getRate());
							fee =  SysUtil.changeDecimal(rate * ticketInfoByTicketNo.getTicketPrice()*0.01);
							
						}
					}
				}
			}
			
		}
		result.put("rate", rate);
		result.put("fee", fee);
		return result;
	}


}