package cn.itkt.btsf.phone.ticketrate.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.ui.ModelMap;

import cn.itkt.exception.AppException;
import cn.itkt.btsf.phone.ticketrate.po.TicketRatePO;
import cn.itkt.btsf.sys.baseinfo.po.ShippingSpacePO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;

public interface TicketRateService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return TicketRate 
	 */
	public TicketRatePO find(Serializable id);

	/**
	 * 查找所有 分页查询
	 * @return List<ticketRatePO> 
	 */
	public List<ShippingSpacePO> findAll(Map<String,Object> map);
	
	public int count(Map<String,Object> map);

	/**
	 * 创建 
	 * @param po
	 */
	public boolean create(ModelMap modelMap,ShippingSpacePO shippingSpacePO) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public boolean update(TicketRatePO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 根据舱位id获得退票费率信息
	 * @param cabinId
	 * @return
	 */
	public ShippingSpacePO findByCabinId(String cabinId);

	/**
	 * 导出退票费率信息
	 */
	public List<ShippingSpacePO> export();
	/**
	 * 批量插入退票费率信息
	 * @param list
	 */
	public void batchCreateRefundRate(List<ShippingSpacePO> list);
	/**
	 * 通过票号获得退票费率和手续费
	 * @param airlinesCode
	 * @param spaceCode
	 * @return
	 */
	public Map<String,Integer> getRefundRateByAirlinesAndSpace(String ticketNo);
	
	/**
	 * 获取退票费和退票费率
	 * 查询的必须字段为：
	 * map.put("spaceCode", ticketInfoByTicketNo.getCabin());
	   map.put("aillinesCode", ticketInfoByTicketNo.getAirways());
	   map.put("takeofftime", ticketInfoByTicketNo.getTakeofftime());
	 * @param ticketInfo
	 * @return
	 */
	public Map<String,Integer> getRefundRate(TicketInfoPO ticketInfo);

}