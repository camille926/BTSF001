package cn.itkt.btsf.phone.ticketrate.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;

import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

import cn.itkt.btsf.phone.ticketrate.po.TicketRatePO;
import cn.itkt.btsf.phone.ticketrate.vo.TicketRateVO;
import cn.itkt.btsf.phone.ticketrate.dao.TicketRateDao;
import cn.itkt.btsf.phone.ticketrate.service.TicketRateService;
import cn.itkt.btsf.sys.baseinfo.po.ShippingSpacePO;
import cn.itkt.btsf.sys.member.po.MemberEnterprisePO;
import cn.itkt.btsf.util.ExcelImport;

@Service
public class TicketRateControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(TicketRateControllerSupport.class);
	
	@Resource
	private  TicketRateService  ticketRateService;
	
	public void findAll(int startIndex,ModelMap modelMap,ShippingSpacePO shippingSpacePO){
		Pages<ShippingSpacePO> page = new Pages<ShippingSpacePO>(startIndex);
		int pageSize = 20;
		page.setPageSize(pageSize);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("startIndex", startIndex);
		map.put("pageSize", pageSize);
		map.put("airlinesCode", shippingSpacePO.getAirlinesCode());
		map.put("spaceCode", shippingSpacePO.getSpaceCode());
		map.put("guestRulesCode", shippingSpacePO.getGuestRulesCode());
		page.setItems(ticketRateService.findAll(map));
		page.setTotalCount(ticketRateService.count(map));
		modelMap.addAttribute("airlinesCode", shippingSpacePO.getAirlinesCode());
		modelMap.addAttribute("spaceCode", shippingSpacePO.getSpaceCode());
		modelMap.addAttribute("guestRulesCode", shippingSpacePO.getGuestRulesCode());
		modelMap.addAttribute("page", page);
	}
	
	public boolean deleteByCabinId(ModelMap modelMap,String cabinId){
		boolean flag = false;
		try {
			ticketRateService.delete(cabinId);
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	/**
	 * 根据舱位id获得退票费率信息
	 * @param cabinId
	 * @return
	 */
	public void findByCabinId(ModelMap modelMap,String cabinId){
		try {
			modelMap.addAttribute("shippingSpacePO", ticketRateService.findByCabinId(cabinId));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean update(ModelMap modelMap,TicketRatePO ticketRatePO){
			return ticketRateService.update(ticketRatePO);
	}
	
	public boolean save(ModelMap modelMap,ShippingSpacePO shippingSpacePO,TicketRatePO ticketRatePO){
		shippingSpacePO.setTicketrate(ticketRatePO);
		return ticketRateService.create(modelMap,shippingSpacePO);
			
	}
	public List<ShippingSpacePO> export(){
		return ticketRateService.export();
		
	}
	public boolean importExcel(Set<MultipartFile> set) throws IOException,AppException{
		if(set != null){
			Iterator<MultipartFile> it = set.iterator();
			MultipartFile multipartFile = null;
			while(it.hasNext()){
				multipartFile = it.next();
				break;
			}
			
			if(multipartFile != null){
				InputStream excelToLoad = multipartFile.getInputStream();
				ExcelImport excelImport = new ExcelImport();
				List<Map<String, String>> enterpriseMapList = excelImport.getXlsList(excelToLoad);
				if(enterpriseMapList != null){
					List<ShippingSpacePO> shippingSpacePOlist = parseMap(enterpriseMapList);
					ticketRateService.batchCreateRefundRate(shippingSpacePOlist);
					return true;
				}
			}
			return false;
		}else{
			throw new AppException("解析导入文件出现错误!");
		}
	}
	private List<ShippingSpacePO> parseMap(List<Map<String, String>> enterpriseMapList){
		List<ShippingSpacePO> enterpriseList = new ArrayList<ShippingSpacePO>();
		Map<String, String>  map;
		//第一行是表头，所以跳过第一行
		for(int i=2, size=enterpriseMapList.size(); i<size; i++){
			map = enterpriseMapList.get(i);
			ShippingSpacePO po = new ShippingSpacePO();
			po.setAirlinesCode(map.get("key0"));
			po.setSpaceCode(map.get("key1"));
			
			TicketRatePO ticketRatePO = new TicketRatePO();
			ticketRatePO.setHourtwobefore(this.valueOf(map.get("key2")));
			ticketRatePO.setHourtwoafter(this.valueOf(map.get("key3")));
			ticketRatePO.setTakebefore(this.valueOf(map.get("key4")));
			ticketRatePO.setTakeafter(this.valueOf(map.get("key5")));
			ticketRatePO.setStandard(this.valueOf(map.get("key6")));
			ticketRatePO.setTakebeforetf(this.valueOf(map.get("key7")));
			ticketRatePO.setTakebeforetfbf(this.valueOf(map.get("key8")));
			ticketRatePO.setHourtfafter(this.valueOf(map.get("key9")));
			ticketRatePO.setBasecabinbefore(this.valueOf(map.get("key10")));
			ticketRatePO.setBasecabinafter(this.valueOf(map.get("key11")));
			ticketRatePO.setNcheckin(this.valueOf(map.get("key12")));
			ticketRatePO.setCheckin(this.valueOf(map.get("key13")));
			ticketRatePO.setRuleCode(String.valueOf(map.get("key14")));
			po.setTicketrate(ticketRatePO);
			enterpriseList.add(po);
		}
		return enterpriseList;
	}
	/**
	 * 将字符串的%替换后转换成int类型，如果是“”则返回0
	 * @param str
	 * @return
	 */
	private int valueOf(String str){
		String replace = str.replace("%", "");
		int Int = 0;
		if(!"".equals(replace)){
			Int = Integer.parseInt(replace);
		}
		return Int;
		
	}
}