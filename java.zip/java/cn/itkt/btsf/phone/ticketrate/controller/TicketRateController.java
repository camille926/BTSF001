package cn.itkt.btsf.phone.ticketrate.controller;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.annotation.Resource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.exception.AppException;
import cn.itkt.util.SysUtil;

import cn.itkt.btsf.phone.ticketrate.po.TicketRatePO;
import cn.itkt.btsf.phone.ticketrate.vo.TicketRateVO;
import cn.itkt.btsf.sys.baseinfo.po.ShippingSpacePO;
import cn.itkt.btsf.util.UploadController;


@Controller
@RequestMapping("/phone/ticketrate/ticketrate")
public class TicketRateController {
	private UploadController uploader = new UploadController();
	@Resource
	private  TicketRateControllerSupport  ticketRateControllerSupport;
	/**
	 * 查询列表
	 * @param startIndex
	 * @param modelMap
	 * @param shippingSpacePO
	 * @return
	 */
	@RequestMapping("/findAll")
	public String findTicketRateInfo(@RequestParam(value = "startIndex", required = false, defaultValue = "0") int startIndex,
			ModelMap modelMap,ShippingSpacePO shippingSpacePO) {
		ticketRateControllerSupport.findAll(startIndex, modelMap,shippingSpacePO);
		return "phone/ticketrate/list";
	}
	/**
	 * 删除退票费率
	 * @param modelMap
	 * @param cabinId
	 * @return
	 */
	@RequestMapping("/delete")
	public ModelAndView deleteByCabinId(ModelMap modelMap,String cabinId){
		boolean deleteByCabinId = ticketRateControllerSupport.deleteByCabinId(modelMap,cabinId);
		modelMap.addAttribute("success",deleteByCabinId);
		return new ModelAndView("jsonView");
	}
	/**
	 * 根据舱位id查找退票费率信息
	 * @param modelMap
	 * @param cabinId
	 * @return
	 */
	@RequestMapping("/findBy")
	public String findBy(ModelMap modelMap,String cabinId){
		ticketRateControllerSupport.findByCabinId(modelMap,cabinId);
		return "phone/ticketrate/update";
	}
	/**
	 * 修改退票费率信息
	 * @param modelMap
	 * @param ticketRatePO
	 * @return
	 */
	@RequestMapping("/update")
	public ModelAndView update(ModelMap modelMap,TicketRatePO ticketRatePO){
		 boolean update = ticketRateControllerSupport.update(modelMap,ticketRatePO);
		 if(update){
			 modelMap.addAttribute("result", "true");
		 }else{
			 modelMap.addAttribute("result", "false");
		 }
		 return new ModelAndView("jsonView");
	}
	/**
	 * 添加退票费率信息
	 * @param modelMap
	 * @param shippingSpacePO
	 * @param ticketRatePO
	 * @return
	 */
	@RequestMapping("/insert")
	public ModelAndView insert(ModelMap modelMap,ShippingSpacePO shippingSpacePO,TicketRatePO ticketRatePO){
		TicketRatePO tic = new TicketRatePO();
//		int hourtwobefore = ticketRatePO.getHourtwobefore();
//		int hourtwoafter = ticketRatePO.getHourtwoafter();
//		int takebefore = ticketRatePO.getTakebefore();
//		int takeafter = ticketRatePO.getTakeafter();
//		int takebeforetfbf = ticketRatePO.getTakebeforetfbf();
//		int standard = ticketRatePO.getStandard();
//		int takebeforetf = ticketRatePO.getTakebeforetf();
//		int hourtfafter = ticketRatePO.getHourtfafter();
//		int basecabinbefore = ticketRatePO.getBasecabinbefore();
//		int basecabinafter = ticketRatePO.getBasecabinafter();
//		int ncheckin = ticketRatePO.getNcheckin();
//		int checkin = ticketRatePO.getCheckin();
		
		boolean insert = ticketRateControllerSupport.save(modelMap,shippingSpacePO,ticketRatePO);
		if(insert){
			modelMap.addAttribute("result", "true");
		}else{
			modelMap.addAttribute("result", "false");
		}
		return new ModelAndView("jsonView");
	}
	/**
	 * 导出退票费率信息
	 */
	@RequestMapping("/refundrate.xls")
	public String export(ModelMap modelMap){
		List<ShippingSpacePO> export = ticketRateControllerSupport.export();
		modelMap.addAttribute("refundRateList", export);
		return "phoneRefundRateExcel";
	}
	/**
	 * 导入退票费率信息
	 * @param request
	 * @param response
	 */
	@RequestMapping("/importxls")
	public void importxls(ModelMap modelMap,HttpServletRequest request,HttpServletResponse response){
		Set<MultipartFile> mfs = uploader.getFileSet(request);
		String result = null;
		try {
			result = ticketRateControllerSupport.importExcel(mfs) ?"1":"0";
			SysUtil.render(response, result);
		}  catch (Exception e) {
			e.printStackTrace();
		}
	}
}