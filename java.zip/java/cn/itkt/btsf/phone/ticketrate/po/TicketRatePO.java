package cn.itkt.btsf.phone.ticketrate.po;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


/**
 * ${comments.get( $tablename)} 
 * @author codegen 2012-03-12 11:26:26 
 */
public class TicketRatePO implements Serializable {

	/** serialVersionUID **/ 
	private static final Long serialVersionUID = 1L;
	
    /** id **/ 
	private Long id;
	
    /** 关联舱位表id **/ 
	private Long cabinId;
	
    /** 时间类型(01:起飞前2小时之前,02:起飞前2小时之后,03:起飞前,04:起飞后,05:标准,06:起飞前24小时之前,07:起飞前24小时(不含)至2小时(不含)之间,08:起飞前24小时之后,09:起飞前按基准舱X%,10:起飞后按基准舱X%,11:未办理置机,12:办理置机) **/ 
	private String type;
	
    /** 费率 **/ 
	private Double rate;
	
	/////////虚拟字段////////////////
	private Integer hourtwobefore;//起飞前2小时之前
	private Integer hourtwoafter;//起飞前2小时之后
	private Integer takebefore;//起飞前
	private Integer takeafter ;//起飞后
	private Integer standard ;//标准
	private Integer takebeforetf ;//起飞前24小时之前
	private Integer takebeforetfbf ;//起飞前24小时(不含)至2小时(不含)之间
	private Integer hourtfafter ;//24小时及以后
	private Integer basecabinbefore ;//起飞前按基准舱X%
	private Integer basecabinafter ;//起飞后按基准舱X%
	private Integer ncheckin ;//未办理过值机
	private Integer checkin ;//办理过值机
	private String ruleCode;//客规编号
	/////////虚拟字段////////////////
	
	
	/**
	 * 将虚拟字段转换成Map
	 */
	public static HashMap<String,Object> list(TicketRatePO po){
		HashMap<String,Object> map = new HashMap<String,Object>();
		map.put("hourtwobefore", po.getHourtwobefore());
		map.put("hourtwoafter", po.getHourtwoafter());
		map.put("takebefore", po.getTakebefore());
		map.put("takeafter", po.getTakeafter());
		map.put("standard", po.getStandard());
		map.put("takebeforetf", po.getTakebeforetf());
		map.put("takebeforetfbf", po.getTakebeforetfbf());
		map.put("hourtfafter", po.getHourtfafter());
		map.put("basecabinbefore", po.getBasecabinbefore());
		map.put("basecabinafter", po.getBasecabinafter());
		map.put("ncheckin", po.getNcheckin());
		map.put("checkin", po.getCheckin());
		return map;
	} 
	
	/**
	 * 将虚拟字段转换成代码
	 */
	public static HashMap<String,String> list(){
		HashMap<String,String> map = new HashMap<String,String>();
		map.put("hourtwobefore", "01");
		map.put("hourtwoafter", "02");
		map.put("takebefore", "03");
		map.put("takeafter", "04");
		map.put("standard", "05");
		map.put("takebeforetf", "06");
		map.put("takebeforetfbf", "07");
		map.put("hourtfafter","08");
		map.put("basecabinbefore", "09");
		map.put("basecabinafter", "10");
		map.put("ncheckin", "11");
		map.put("checkin", "12");
		return map;
	}

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the cabinId
	 */
	public Long getCabinId() {
		return cabinId;
	}

	/**
	 * @param cabinId the cabinId to set
	 */
	public void setCabinId(Long cabinId) {
		this.cabinId = cabinId;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the rate
	 */
	public Double getRate() {
		return rate;
	}

	/**
	 * @param rate the rate to set
	 */
	public void setRate(Double rate) {
		this.rate = rate;
	}

	/**
	 * @return the hourtwobefore
	 */
	public Integer getHourtwobefore() {
		return hourtwobefore;
	}

	/**
	 * @param hourtwobefore the hourtwobefore to set
	 */
	public void setHourtwobefore(Integer hourtwobefore) {
		this.hourtwobefore = hourtwobefore;
	}

	/**
	 * @return the hourtwoafter
	 */
	public Integer getHourtwoafter() {
		return hourtwoafter;
	}

	/**
	 * @param hourtwoafter the hourtwoafter to set
	 */
	public void setHourtwoafter(Integer hourtwoafter) {
		this.hourtwoafter = hourtwoafter;
	}

	/**
	 * @return the takebefore
	 */
	public Integer getTakebefore() {
		return takebefore;
	}

	/**
	 * @param takebefore the takebefore to set
	 */
	public void setTakebefore(Integer takebefore) {
		this.takebefore = takebefore;
	}

	/**
	 * @return the takeafter
	 */
	public Integer getTakeafter() {
		return takeafter;
	}

	/**
	 * @param takeafter the takeafter to set
	 */
	public void setTakeafter(Integer takeafter) {
		this.takeafter = takeafter;
	}

	/**
	 * @return the standard
	 */
	public Integer getStandard() {
		return standard;
	}

	/**
	 * @param standard the standard to set
	 */
	public void setStandard(Integer standard) {
		this.standard = standard;
	}

	/**
	 * @return the takebeforetf
	 */
	public Integer getTakebeforetf() {
		return takebeforetf;
	}

	/**
	 * @param takebeforetf the takebeforetf to set
	 */
	public void setTakebeforetf(Integer takebeforetf) {
		this.takebeforetf = takebeforetf;
	}

	/**
	 * @return the takebeforetfbf
	 */
	public Integer getTakebeforetfbf() {
		return takebeforetfbf;
	}

	/**
	 * @param takebeforetfbf the takebeforetfbf to set
	 */
	public void setTakebeforetfbf(Integer takebeforetfbf) {
		this.takebeforetfbf = takebeforetfbf;
	}

	/**
	 * @return the hourtfafter
	 */
	public Integer getHourtfafter() {
		return hourtfafter;
	}

	/**
	 * @param hourtfafter the hourtfafter to set
	 */
	public void setHourtfafter(Integer hourtfafter) {
		this.hourtfafter = hourtfafter;
	}

	/**
	 * @return the basecabinbefore
	 */
	public Integer getBasecabinbefore() {
		return basecabinbefore;
	}

	/**
	 * @param basecabinbefore the basecabinbefore to set
	 */
	public void setBasecabinbefore(Integer basecabinbefore) {
		this.basecabinbefore = basecabinbefore;
	}

	/**
	 * @return the basecabinafter
	 */
	public Integer getBasecabinafter() {
		return basecabinafter;
	}

	/**
	 * @param basecabinafter the basecabinafter to set
	 */
	public void setBasecabinafter(Integer basecabinafter) {
		this.basecabinafter = basecabinafter;
	}

	/**
	 * @return the ncheckin
	 */
	public Integer getNcheckin() {
		return ncheckin;
	}

	/**
	 * @param ncheckin the ncheckin to set
	 */
	public void setNcheckin(Integer ncheckin) {
		this.ncheckin = ncheckin;
	}

	/**
	 * @return the checkin
	 */
	public Integer getCheckin() {
		return checkin;
	}

	/**
	 * @param checkin the checkin to set
	 */
	public void setCheckin(Integer checkin) {
		this.checkin = checkin;
	}

	/**
	 * @return the ruleCode
	 */
	public String getRuleCode() {
		return ruleCode;
	}

	/**
	 * @param ruleCode the ruleCode to set
	 */
	public void setRuleCode(String ruleCode) {
		this.ruleCode = ruleCode;
	}

	 
	

}