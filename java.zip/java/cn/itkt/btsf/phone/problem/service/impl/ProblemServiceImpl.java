package cn.itkt.btsf.phone.problem.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.itkt.btsf.phone.problem.dao.ProblemDao;
import cn.itkt.btsf.phone.problem.service.ProblemService;
import cn.itkt.btsf.phone.problem.vo.ProblemVO;
@Service
public class ProblemServiceImpl implements ProblemService {
	@Resource
	private ProblemDao problemDao;
	/**
	 * 查询反馈问题列表
	 * @param map
	 * @return
	 */
	@Override
	public int count(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return problemDao.count(map);
	}
	/**
	 * 查询反馈问题总数
	 * @param map
	 * @return
	 */
	@Override
	public List<ProblemVO> list(Map<String, Object> map) {
		return problemDao.list(map);
	}
	/**
	 * 查询反馈问题详细信息
	 * @param id
	 * @return
	 */
	public ProblemVO findDetail(long id){
		return problemDao.findDetail(id);
	}
}
