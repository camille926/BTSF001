package cn.itkt.btsf.phone.problem.service;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;

import cn.itkt.btsf.util.DateUtil;

public class ProblemQueryExcel extends AbstractExcelView {

	@SuppressWarnings("unchecked")
	@Override
	protected void buildExcelDocument(Map<String, Object> model,
			HSSFWorkbook Workbook, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		//添加单元格格式
		HSSFCellStyle cellStyle=Workbook.createCellStyle();
		HSSFFont font=Workbook.createFont();
		font.setFontHeightInPoints((short)10);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		cellStyle.setFont(font);
		cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		//文件名
		String filename = "";
		
		//创建sheet
		HSSFSheet sheet = Workbook.createSheet("掌上航旅问题反馈");
		//默认列宽
		sheet.setDefaultColumnWidth(20);
		//居中排列
		getCell(sheet,0,0).getCellStyle().setAlignment(HSSFCellStyle.ALIGN_CENTER);
		//设置单元格格式
		getCell(sheet,0,0).setCellStyle(cellStyle);
		//列标题
		String[] columnTitles={"ID","会员名称","反馈的问题","反馈的答案","反馈添加时间"};
		//列对应的get方法
		String[] getMethods={"getId","getUserName","getProblem","getAnswer","getProblemAddDate"};
		//设置标题
		setText(getCell(sheet,0,0),"掌上航旅问题反馈");
		sheet.addMergedRegion(new CellRangeAddress(0,1,0,columnTitles.length-1));
		//设置列标题
		for(int i=0;i<columnTitles.length;i++){
			setText(getCell(sheet,2,i),columnTitles[i]);
			getCell(sheet,2,i).setCellStyle(cellStyle);
		}
		//问题反馈数据列表
		List<Object> problemList=(List<Object>) model.get("problemList");
		//问题反馈对象
		Object problem;
		//问题反馈对象的class对象
		Class clazz;
		//get方法名称
		String getMethod;
		//设置数据列
		for(int i=0;i<problemList.size();i++){
			problem=problemList.get(i);
			//获取对象的class对象
			clazz=problem.getClass();
			//依次获取属性
			for(int j=0;j<getMethods.length;j++){
				getMethod=getMethods[j];
				//获取属性值
				Object property=clazz.getMethod(getMethod, null).invoke(problem, null);
				//日期格式化
				if(property instanceof Date){
					setText(getCell(sheet,i+3,j),DateUtil.dateToString((Date) property,DateUtil.PATTERN_TIME4));
				//其他类型的属性
				}else if(property!=null){
					setText(getCell(sheet,i+3,j),property.toString());
				}
			}
		}
		//设置下载时客户端Excel的名称
		filename=DateUtil.dateToString(new Date(), "yyyy-MM-dd")+"_prolem"+".xls";
		    
		filename = encodeFilename(filename, request);//处理中文文件名   
		response.setContentType("application/vnd.ms-excel");      
		response.setHeader("Content-disposition", "attachment;filename=" + filename);      
		OutputStream ouputStream = response.getOutputStream();      
		Workbook.write(ouputStream);      
		ouputStream.flush();      
		ouputStream.close();      
		
		
	}
	/**   
     * 设置下载文件中文件的名称   
     *    
     * @param filename   
     * @param request   
     * @return   
     */     
    public static String encodeFilename(String filename, HttpServletRequest request) {     
      /**   
       * 获取客户端浏览器和操作系统信息   
      * 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)   
       * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6   
       */     
      String agent = request.getHeader("USER-AGENT");     
      try {     
        if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {     
          String newFileName = URLEncoder.encode(filename, "UTF-8");     
          newFileName = newFileName.replace("+", "%20");     
          if (newFileName.length() > 150) {     
            newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");     
            newFileName = newFileName.replace("+", "%20");     
          }     
          return newFileName;     
        }     
        if ((agent != null) && (-1 != agent.indexOf("Mozilla")))     
          return MimeUtility.encodeText(filename, "UTF-8", "B");     
       
        return filename;     
      } catch (Exception ex) {     
        return filename;     
      }     
    }  

}
