package cn.itkt.btsf.phone.problem.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.axis.utils.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;


import cn.itkt.btsf.phone.problem.service.ProblemService;
import cn.itkt.btsf.phone.problem.vo.ProblemVO;
import cn.itkt.pagination.Pages;
@Service
public class ProblemControllerSupport {
	@Resource
	private ProblemService problemService;
	public void list(int startIndex, ModelMap model, ProblemVO queryVO) {
		Pages<ProblemVO> pages=new Pages<ProblemVO>(startIndex);
		//查询条件
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("startIndex", startIndex);
		map.put("pageSize", 10);
		map.put("userPhone", queryVO.getUserPhone());
		map.put("problem", queryVO.getProblem());
		map.put("answer", queryVO.getAnswer());
		if(!StringUtils.isEmpty(queryVO.getProblemAddDateStart())){
			map.put("problemAddDateStart", queryVO.getProblemAddDateStart()+" 00:00:00");
		}
		if(!StringUtils.isEmpty(queryVO.getProblemAddDateEnd())){
			map.put("problemAddDateEnd", queryVO.getProblemAddDateEnd()+" 23:59:59");
		}
		//查询反馈问题列表
		List<ProblemVO> problemList=problemService.list(map);
		//查询反馈问题总数
		int count=problemService.count(map);
		pages.setItems(problemList);
		pages.setTotalCount(count);
		model.addAttribute("page", pages);
		model.addAttribute("queryVO",queryVO);
	}
	/**
	 * 查询问题反馈详细信息
	 * @param model
	 * @param id
	 */
	public void findDetail(ModelMap model, long id) {
		ProblemVO detail=problemService.findDetail(id);
		model.addAttribute("problem", detail);
	}
	/**
	 * 查询所有符合条件的问题反馈
	 * @param model
	 * @param queryVO
	 */
	public void listAllForCondition(ModelMap model, ProblemVO queryVO) {
		//查询条件
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("startIndex", 0);
		map.put("userName", queryVO.getUserName());
		map.put("problem", queryVO.getProblem());
		map.put("answer", queryVO.getAnswer());
		if(!StringUtils.isEmpty(queryVO.getProblemAddDateStart())){
			map.put("problemAddDateStart", queryVO.getProblemAddDateStart()+" 00:00:00");
		}
		if(!StringUtils.isEmpty(queryVO.getProblemAddDateEnd())){
			map.put("problemAddDateEnd", queryVO.getProblemAddDateEnd()+" 23:59:59");
		}
		//查询反馈问题总数
		int count=problemService.count(map);
		map.put("pageSize",count);
		//查询反馈问题列表
		List<ProblemVO> problemList=problemService.list(map);
		model.addAttribute("problemList",problemList);
	}

}
