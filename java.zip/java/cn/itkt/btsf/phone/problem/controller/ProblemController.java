package cn.itkt.btsf.phone.problem.controller;

import javax.annotation.Resource;

import org.hibernate.annotations.Parameter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.itkt.btsf.phone.problem.vo.ProblemVO;

@Controller
@RequestMapping("/phone/problem")
public class ProblemController {
	@Resource
	private ProblemControllerSupport problemControllerSupport;
	/**
	 * 查询问题反馈列表
	 * @param model
	 * @param queryVO
	 * @param startIndex
	 * @return
	 */
	@RequestMapping("/list")
	public String listProblem(ModelMap model,ProblemVO queryVO,
			@RequestParam(value="startIndex",required=false,defaultValue="0") int startIndex ){
		problemControllerSupport.list(startIndex,model,queryVO);
		return "phone/problem/problemList";
	}
	/**
	 * 查询问题反馈详细信息
	 * @param model
	 * @param id
	 * @return
	 */
	@RequestMapping("/view")
	public String showDetail(ModelMap model,
			@RequestParam(value="id",required=true) long id ){
		problemControllerSupport.findDetail(model,id);
		return "phone/problem/problemView";
	}
	/**
	 * 将问题反馈列表导出到excel
	 * @param model
	 * @param queryVO
	 * @param startIndex
	 * @return
	 */
	@RequestMapping("/listExportToExcel")
	public String listExportToExcel(ModelMap model,ProblemVO queryVO){
		problemControllerSupport.listAllForCondition(model,queryVO);
		return "exportProblemQueryExcel";
	}
}
