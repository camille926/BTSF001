package cn.itkt.btsf.phone.problem.vo;

import java.util.Date;

public class ProblemVO {
	private long id;
	//会员id
	private String userId;
	//会员名称
	private String userName;
	//会员手机号
	private String userPhone;
	//会员emial
	private String userEmail;
	//会员注册时间
	private Date userAddDate;
	//反馈添加时间
	private Date problemAddDate;
	//反馈的问题
	private String problem;
	//反馈的回答
	private String answer;
	//查询反馈开始时间
	private String problemAddDateStart;
	//查询反馈结束时间
	private String problemAddDateEnd;
	
	
	public String getProblemAddDateStart() {
		return problemAddDateStart;
	}
	public void setProblemAddDateStart(String problemAddDateStart) {
		this.problemAddDateStart = problemAddDateStart;
	}
	public String getProblemAddDateEnd() {
		return problemAddDateEnd;
	}
	public void setProblemAddDateEnd(String problemAddDateEnd) {
		this.problemAddDateEnd = problemAddDateEnd;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public Date getUserAddDate() {
		return userAddDate;
	}
	public void setUserAddDate(Date userAddDate) {
		this.userAddDate = userAddDate;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Date getProblemAddDate() {
		return problemAddDate;
	}
	public void setProblemAddDate(Date problemAddDate) {
		this.problemAddDate = problemAddDate;
	}

}
