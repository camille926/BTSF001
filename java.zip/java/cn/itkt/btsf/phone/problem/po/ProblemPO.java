package cn.itkt.btsf.phone.problem.po;

import java.util.Date;
/**
 * 移动商旅问题反馈Po
 * @author lixu
 * @date 12.5.23
 */
public class ProblemPO {
	//主键
	private long id;
	//会员id
	private long userId;
	//反馈时间
	private Date addDate;
	//反馈的问题
	private String problem;
	//反馈的回答
	private String answer;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public Date getAddDate() {
		return addDate;
	}
	public void setAddDate(Date addDate) {
		this.addDate = addDate;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}
