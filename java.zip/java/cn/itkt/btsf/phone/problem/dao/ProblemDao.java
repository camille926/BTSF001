package cn.itkt.btsf.phone.problem.dao;

import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.problem.vo.ProblemVO;

public interface ProblemDao {
	/**
	 * 查询反馈问题总数
	 * @param map
	 * @return
	 */
	public int count(Map<String, Object> map);
	
	/**
	 * 查询反馈问题列表
	 * @param map
	 * @return
	 */
	public List<ProblemVO> list(Map<String, Object> map);
	/**
	 * 查询问题反馈详细信息
	 * @param id
	 * @return
	 */
	public ProblemVO findDetail(long id);

}
