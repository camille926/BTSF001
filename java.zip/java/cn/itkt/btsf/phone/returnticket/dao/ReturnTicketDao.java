package cn.itkt.btsf.phone.returnticket.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.returnticket.po.ReturnTicketPO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;

/**
 * 移动商旅_退票表 
 * @author codegen 2011-10-17 10:33:07 
 */
public interface ReturnTicketDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return ReturnTicket 
	 */
	public ReturnTicketPO find(Serializable id);
	
	public ReturnTicketPO findByTicketNo(String ticketNo);
	/**
	 * 查找所有 
	 * @return List<ReturnTicketPO> 
	 */
	public List<ReturnTicketPO> findAll(Map<String,Object> map);
	/**
	 * 
	 * @param查询出票时间
	 * @return
	 */
	public List<TicketInfoPO> findchecktime();

	public int count(Map<String,Object> map);
	/**
	 * 创建 
	 * @param po 
	 */
	public void create(ReturnTicketPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(ReturnTicketPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	/**
	 * 根据票号修改状态为已处理
	 * @param ticketNo
	 */
	public void updateStateByTicketNo(String ticketNo);
	/**
	 * 根据订单id判断是否是从未起飞过的会员
	 * @param orderId
	 * @return 0从未起飞过的会员 >0则不是未起飞过的会员
	 */
	public int isFirstByOrderId(long orderId);
	/**
	 * 查询是否在手机端已退票
	 */
	public ReturnTicketPO findstate(String tickno);

}