package cn.itkt.btsf.phone.returnticket.vo;

import java.util.Date;


/**
 * 移动商旅_退票表 
 * @author codegen 2011-10-17 10:33:07 
 */
public class ReturnTicketVO {

    /** 编号 **/ 
	private long id;
	
    /** 票号 **/ 
	private String ticketno;
	
    /** 退票时间 **/ 
	private Date addtime;
	
    /** 状态 “0” 未处理
“1” 已处理 **/ 
	private String state;
	
    /** 会员ID **/ 
	private long userid;
	
    /** 退票方式 “0”返畅达币
“1”原卡退回 **/ 
	private String refundtype;
	

	/**
	 * 构造 
	 */
	public ReturnTicketVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getTicketno() {
		return ticketno;
	}

	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}
	public Date getAddtime() {
		return addtime;
	}

	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getRefundtype() {
		return refundtype;
	}

	public void setRefundtype(String refundtype) {
		this.refundtype = refundtype;
	}

}