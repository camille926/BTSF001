package cn.itkt.btsf.phone.returnticket.po;

import java.io.Serializable;
import java.util.Date;


/**
 * 移动商旅_退票表 
 * @author codegen 2011-10-17 10:33:07 
 */
public class ReturnTicketPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** 编号 **/ 
	private long id;
	
    /** 票号 **/ 
	private String ticketno;
	
    /** 退票时间 **/ 
	private Date addtime;
	
    /** 状态 “0” 未处理
“1” 已处理 **/ 
	private String state;
	
    /** 会员ID **/ 
	private long userid;
	
    /** 退票方式 “0”返畅达币
“1”原卡退回 **/ 
	private String refundtype;
	
	private String addtimeStr;
	
	private String name;
	private String telephone;
	
	private String refundRate;   //退票费率
	
	private String refundPrice;  //退票费
	
	/**
	 * 构造 
	 */
	public ReturnTicketPO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getTicketno() {
		return ticketno;
	}

	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}
	public Date getAddtime() {
		return addtime;
	}

	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getRefundtype() {
		return refundtype;
	}

	public void setRefundtype(String refundtype) {
		this.refundtype = refundtype;
	}


	public String getAddtimeStr() {
		return addtimeStr;
	}


	public void setAddtimeStr(String addtimeStr) {
		this.addtimeStr = addtimeStr;
	}
	
	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getTelephone() {
		return telephone;
	}


	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}


	public String getRefundRate() {
		return refundRate;
	}


	public void setRefundRate(String refundRate) {
		this.refundRate = refundRate;
	}


	public String getRefundPrice() {
		return refundPrice;
	}


	public void setRefundPrice(String refundPrice) {
		this.refundPrice = refundPrice;
	}
	
	
}