package cn.itkt.btsf.phone.returnticket.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.returnticket.po.ReturnTicketPO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.vo.TicketRequestVO;
import cn.itkt.exception.AppException;

public interface ReturnTicketService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return ReturnTicket 
	 */
	public ReturnTicketPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<ReturnTicketPO> 
	 */
	public List<ReturnTicketPO> findAll(Map<String,Object> map);
	public List<TicketInfoPO> findchecktime();

	public int count(Map<String,Object> map);

	/**
	 * 创建 
	 * @param po
	 */
	public void create(ReturnTicketPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(ReturnTicketPO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(Serializable id) throws AppException;
	/**
	 * 根据票号查找退票申请信息
	 * @param modelMap
	 * @param ticketNo
	 * @return
	 */
	public ReturnTicketPO findByTicketNo(ModelMap modelMap,String ticketNo);
	
	/**
	 * 根据票号获取退票费率和退票手续费，
	 * @param findByRequisitionId
	 * @param ticketNo
	 * @return
	 */
	public TicketRequestVO rebuildTicketRequestVO(ModelMap modelMap,TicketRequestVO findByRequisitionId);
	/**
	 * 根据订单id判断是否是从未起飞过的会员,
	 * @param orderId
	 * @return true 是 false 不是从未起飞过的会员
	 */
	public boolean isFirstByOrderId(long orderId);
	/**
	 * 
	 * @param tickno
	 * @return查询是否在手机端已退票
	 */
		public String findstate(String tickno);
}