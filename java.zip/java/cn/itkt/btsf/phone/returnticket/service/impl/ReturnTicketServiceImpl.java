package cn.itkt.btsf.phone.returnticket.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.returnticket.dao.ReturnTicketDao;
import cn.itkt.btsf.phone.returnticket.po.ReturnTicketPO;
import cn.itkt.btsf.phone.returnticket.service.ReturnTicketService;
import cn.itkt.btsf.phone.ticketrate.service.TicketRateService;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.po.TicketRefundinfoDetailPO;
import cn.itkt.btsf.sys.cc.national.vo.RefundTicketInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.TicketRequestVO;
import cn.itkt.exception.AppException;

@Service
public class ReturnTicketServiceImpl implements ReturnTicketService {

	

	private static final Logger log = LoggerFactory.getLogger(ReturnTicketServiceImpl.class);
	
	@Resource
	private  ReturnTicketDao  returnTicketDao;
	@Resource
	private TicketRateService ticketRateService;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return ReturnTicket 
	 */
	public ReturnTicketPO find(Serializable id){
		return returnTicketDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<ReturnTicketPO> 
	 */
	public List<ReturnTicketPO> findAll(Map<String,Object> map){
		return returnTicketDao.findAll(map);	
	}
	public List<TicketInfoPO>findchecktime(){
		return returnTicketDao.findchecktime();
	}
	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(ReturnTicketPO po) throws AppException{
		try{
			if( po != null )
				 returnTicketDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(ReturnTicketPO po) throws AppException {
		try{
			if( po != null )
				 returnTicketDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(Serializable id)throws AppException{
		try{
			if( id != null )
				returnTicketDao.delete(id);
				return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}
		
		 
	}

	@Override
	public int count(Map<String, Object> map) {
		return returnTicketDao.count(map);
	}
	@Override
	public ReturnTicketPO findByTicketNo(ModelMap modelMap, String ticketNo) {
		 ReturnTicketPO findByTicketNo = returnTicketDao.findByTicketNo(ticketNo);
		 modelMap.addAttribute("ifRefundType", findByTicketNo);
		 return findByTicketNo;
	}

	@Override
	public TicketRequestVO rebuildTicketRequestVO(ModelMap modelMap,TicketRequestVO findByRequisitionId) {
		//退票申请单中的退票费率信息
		TicketRefundinfoDetailPO ticketRefundinfoDetailPO = null;
		List<TicketRefundinfoDetailPO> list = new ArrayList<TicketRefundinfoDetailPO>();
		
		try {
			
			//获取票列表
			List<TicketInfoPO> ticketInfoPO = findByRequisitionId.getTicketInfoPO();
			
			if(ticketInfoPO == null){
				List<RefundTicketInfoVO> ticketInfoByTicketNo = (List<RefundTicketInfoVO>)modelMap.get("ticketinfolist");
				for (RefundTicketInfoVO refundTicketInfoVO : ticketInfoByTicketNo) {
					//通过票号获得退票费率和手续费
					Map<String, Integer> refundRateByAirlinesAndSpace = ticketRateService.getRefundRateByAirlinesAndSpace(refundTicketInfoVO.getTicketNo());
					ticketRefundinfoDetailPO = new TicketRefundinfoDetailPO();
					ticketRefundinfoDetailPO.setRate(refundRateByAirlinesAndSpace.get("rate"));
					ticketRefundinfoDetailPO.setFee(refundRateByAirlinesAndSpace.get("fee"));
					ticketRefundinfoDetailPO.setTicketNo(refundTicketInfoVO.getTicketNo());
					list.add(ticketRefundinfoDetailPO);
				}
				findByRequisitionId.setTicketRefundinfoDetailPO(list);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return findByRequisitionId;
	}

	@Override
	public boolean isFirstByOrderId(long orderId) {
		boolean flag = false;
		try {
			int val = returnTicketDao.isFirstByOrderId(orderId);
			if(val == 0){
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	@Override
	public String findstate(String tickno) {
		ReturnTicketPO refund = returnTicketDao.findstate(tickno);
		String state ="";
		if(refund !=null){
			state = "1";
		}
		return state;
	}
}