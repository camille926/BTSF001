package cn.itkt.btsf.phone.returnticket.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.btsf.sys.cc.national.controller.WasteTicketSupport;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.common.constant.ConstantUtil;
import cn.itkt.util.DateUtil;


@Controller
@RequestMapping("/phone/returnticket/returnticket")
public class ReturnTicketController {

	@Resource
	private  ReturnTicketControllerSupport  returnTicketControllerSupport;
	
	@Resource
	private WasteTicketSupport wasteTicketSupport;

	/**
	 * 查询退票信息
	 * @param startIndex
	 * @param telephone 手机号
	 * @param addtimeStr 申请日起
	 * @param ticketno 票号
	 * @param modelMap
	 * @return
	 */
	@RequestMapping()
	public String list(@RequestParam(value="startIndex", required=false, defaultValue="0") int startIndex,
			@RequestParam(value="telephone",required=false) String telephone,
			@RequestParam(value="addtimeStr",required=false) String addtimeStr,
			@RequestParam(value="ticketno",required=false)String ticketno, ModelMap modelMap){
		
		if(telephone!=null&&!"".equals(telephone)){
			telephone = telephone.trim();
			modelMap.addAttribute("telephone", telephone);
		}
		
		if(addtimeStr!=null&&!"".equals(addtimeStr)){
			addtimeStr = addtimeStr.trim();
			modelMap.addAttribute("addtimeStr", addtimeStr);
		}	
		if(ticketno!=null&&!"".equals(ticketno)){
			ticketno = ticketno.trim();
			if(ticketno.contains("-")){
				ticketno = ticketno.replace("-", "");
			}
			modelMap.addAttribute("addtimeStr", addtimeStr);
		}	
		
		modelMap.addAttribute("ticketno", ticketno);
		returnTicketControllerSupport.list(telephone, addtimeStr, ticketno,startIndex, modelMap);
		//returnTicketControllerSupport.checktime(modelMap);
		return "phone/returnticket/returnticket";
	}
	
	@RequestMapping("/findticket")
	public @ResponseBody List<TicketInfoPO>  checkTime(ModelMap map){
		 return returnTicketControllerSupport.checktime();		
	}
	
	/**
	 * 查询退票查看信息
	 * @param flowNo 当type=0，则为票号，type=1，为订单id
	 * @param refundtype 退款方式
	 * @param modelMap
	 * @return
	 */
	@RequestMapping("/query")
	public String query(ModelMap modelMap, String flowNo, String paymentType, String type, String refundtype){
		returnTicketControllerSupport.query(modelMap,flowNo,type,refundtype);
		modelMap.addAttribute("refundWayList", ConstantUtil.getDictionary("21"));
		modelMap.addAttribute("paymentType",paymentType);
		return "phone/returnticket/queryreturnticket";
	}
	/**
	 * 处理退票状态
	 * @param id
	 * @return
	 */
	@RequestMapping("/updateState")
	public ModelAndView updateState(ModelMap modelMap,@RequestParam(value="id") Long id){
		boolean flag = false;
		if(id == 1){
			flag= true;
		}else{
			flag=returnTicketControllerSupport.updateState(id);
		}
//		if(flag){
//			modelMap.addAttribute("message", "退票信息提交成功");
//		}else{
//			modelMap.addAttribute("message", "退票信息提交失败");
//		}
		return new ModelAndView("jsonView");
	}
	/**
	 * 取消操作
	 * @param id
	 * @return
	 */
	@RequestMapping("/delete")
	public @ResponseBody Map<String,Object> isCancel(@RequestParam(value="id") Long id){
		Map<String,Object> modelMap=new HashMap<String,Object>();
		boolean flag=returnTicketControllerSupport.isCancel(id);
		if(flag){
			modelMap.put("success", "true");
		}else{
			modelMap.put("success", "false");
		}
		return modelMap;
	}
	/**
	 * 退畅达币
	 * @param modelMap
	 * @param requisitionCode
	 * @return
	 */
	@RequestMapping("/refundMoney")
	public ModelAndView refundMoney(
			ModelMap modelMap,
			@RequestParam(value="requisitionCode") String requisitionCode,
			String type){
		if(!"edit".equals(type)){
				boolean refundMoney = returnTicketControllerSupport.refundMoney(modelMap, requisitionCode);
				if(refundMoney){
					modelMap.addAttribute("message","退畅达币成功！");
				}else{
					modelMap.addAttribute("message","退畅达币失败！");
				}
		}
		return new ModelAndView("jsonView");
	}
}