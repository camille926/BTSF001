package cn.itkt.btsf.phone.returnticket.controller;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestParam;

import cn.itkt.btsf.phone.pushticket.po.PushprocessedPO;
import cn.itkt.btsf.phone.pushticket.service.PushprocessService;
import cn.itkt.btsf.phone.returnticket.po.ReturnTicketPO;
import cn.itkt.btsf.phone.returnticket.service.ReturnTicketService;
import cn.itkt.btsf.phone.ticketrate.service.TicketRateService;
import cn.itkt.btsf.phone.users.service.PhoneCoinService;
import cn.itkt.btsf.sys.baseinfo.po.BusinessParameterPO;
import cn.itkt.btsf.sys.baseinfo.service.BusinessParameterService;
import cn.itkt.btsf.sys.cc.national.controller.RefundTicketSupport;
import cn.itkt.btsf.sys.cc.national.dao.TicketRefundinfoDetailDao;
import cn.itkt.btsf.sys.cc.national.po.OrderInfoPO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.po.TicketRefundinfoDetailPO;
import cn.itkt.btsf.sys.cc.national.po.TicketRequestPO;
import cn.itkt.btsf.sys.cc.national.service.OrderManageService;
import cn.itkt.btsf.sys.cc.national.service.RefundTicketService;
import cn.itkt.btsf.sys.cc.national.service.TicketRefundInfoService;
import cn.itkt.btsf.sys.cc.national.service.TicketRequestService;
import cn.itkt.btsf.sys.cc.national.vo.RefundOrderInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.RefundTicketInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.TicketRequestVO;
import cn.itkt.btsf.sys.pay.po.PayJournalPO;
import cn.itkt.btsf.sys.pay.service.PayJournalService;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

@Service
public class ReturnTicketControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(ReturnTicketControllerSupport.class);
	
	@Resource
	private  ReturnTicketService  returnTicketService;
	@Resource
	private RefundTicketSupport refundTicketSupport;
	@Resource
	private TicketRequestService ticketRequestService;
	@Resource
	private RefundTicketService refundTicketService;
	@Resource
	private TicketRefundInfoService ticketRefundInfoService;
	@Resource
	private BusinessParameterService businessParameterService;
	@Resource
	private PhoneCoinService phoneCoinService;
	@Resource
	private OrderManageService orderManageService;
	@Resource
	private TicketRefundinfoDetailDao ticketRefundinfoDetailDao;

	private boolean firstByOrderId;
	
	
	/**
	 * 查询退票
	 * @param telephone
	 * @param addtime
	 * @param startIndex
	 * @param modelMap
	 */
	public void list(String telephone,String addtimeStr,String ticketno,int startIndex,ModelMap modelMap){
		Pages<ReturnTicketPO> page = new Pages<ReturnTicketPO>(startIndex);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("telephone", telephone);
		map.put("addtime", addtimeStr);
		map.put("startIndex", startIndex);
		map.put("pageSize", 10);
		map.put("ticketno", ticketno);
		
		List<ReturnTicketPO> list=returnTicketService.findAll(map);
		int count=returnTicketService.count(map);
		page.setItems(list);
		page.setTotalCount(count);
		modelMap.addAttribute("page", page);
	
	}
	public void checktime(ModelMap modelMap){
		List<TicketInfoPO> list = returnTicketService.findchecktime();
		modelMap.addAttribute("checktime", list);
	}
	public List<TicketInfoPO> checktime(){
		return  returnTicketService.findchecktime();
	}
	/**
	 * 查看退票信息
	 * @param modelMap
	 * @param ticketNo
	 */
	public void query(ModelMap modelMap,String flowNo,String type,String refundtype){
		try {
			long orderIds = 0;//订单号
			List<RefundTicketInfoVO> ticketInfoByTicketNo = null;
			
			//查找移动商旅退票申请信息
			returnTicketService.findByTicketNo(modelMap, flowNo);
			
			//type=0,则flowNo为票号，type=1，则flowNo为订单id
			if("0".equals(type)){
				//当传进来的是票号，那么入口是移动商旅退票
				
				//根据票号获取订单id
				ticketInfoByTicketNo = refundTicketService.getTicketInfoByTicketNo(flowNo);
				modelMap.addAttribute("ticketinfolist", ticketInfoByTicketNo );
				
				if(ticketInfoByTicketNo != null && ticketInfoByTicketNo.size()>0){
					//获得订单id
					RefundTicketInfoVO refundTicketInfoVO = ticketInfoByTicketNo.get(0);
					orderIds = refundTicketInfoVO.getOrderId();
					
				}
				
			}else{
				//如果传进来的是订单id,那么入口是呼叫中心
				orderIds = Long.valueOf(flowNo);
				refundTicketService.getTicketInfoByOrderId(modelMap, orderIds);
				
			}
			
			
			if( "1".equals(type) || ("0".equals(type) && ticketInfoByTicketNo != null && ticketInfoByTicketNo.size()>0)){
				
				//获取订单信息
				refundTicketSupport.getOrderById(modelMap, orderIds);//获取订单信息
				
				//获取退票申请单编号
				TicketRequestVO vo = new TicketRequestVO();
				vo.setRequisitionCode(DateUtil.getTimeSequence("GNTP"));
				TicketRequestVO findByRequisitionId = ticketRefundInfoService.findByRequisitionId(modelMap, vo);
				returnTicketService.rebuildTicketRequestVO(modelMap,findByRequisitionId);//设置退票费率和退票手续费
				modelMap.addAttribute("ticketrequest", findByRequisitionId);
				
				//获取相关订单信息
				refundTicketSupport.getAboutOrderInfo(modelMap,orderIds);
				
				//获取即将到期客票有效期
				List<BusinessParameterPO> poList = businessParameterService.findBusinessParameterAll();
				if(poList.size()>0){
					modelMap.addAttribute("invalid", poList.get(0).getTicketInvalidDate());
				}else{
					modelMap.addAttribute("invalid", 0);
				}
				
				//获得畅达币和支付信息
				ticketRequestService.getPayDetailInfo(modelMap, orderIds,refundtype,"");
				refundTicketSupport.getSelectedInfo(modelMap);
			}
			
			//判断该会员是否是从未起飞过的会员，1：是，0：否
			this.isFirst(modelMap, orderIds);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//判断该会员是否是从未起飞过的会员，1：是，0：否
	public boolean isFirst(ModelMap modelMap,long orderId){
		boolean isFirstboo = false;
		//判断该会员是否是从未起飞过的会员，1：是，0：否
		isFirstboo = returnTicketService.isFirstByOrderId(orderId);
		if(isFirstboo){
			modelMap.addAttribute("isFirst", "1");
		}else{
			modelMap.addAttribute("isFirst", "0");
		}
		return isFirstboo;
	}
	/**
	 * 修改退票信息状态
	 */
	public boolean updateState(Long id){
		boolean flag = false;
		try {
			ReturnTicketPO find = returnTicketService.find(id);
			find.setState("1");
			returnTicketService.update(find);
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	/**
	 * 取消退票
	 * @param id
	 * @return
	 */
	public boolean isCancel(Long id){
		boolean flag=false;
		try {
			flag=returnTicketService.delete(id);
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	/**
	 * 退票后退畅达币
	 * @param modelMap
	 * @param requisitionCode
	 */
	public boolean refundMoney(ModelMap modelMap,String requisitionCode){
		boolean flag = false;
		try {
			//获得申请单信息
			TicketRequestPO ticketRequestPO = ticketRequestService.find(requisitionCode);
			if(ticketRequestPO != null){
				//获得订单信息
				OrderInfoPO orderInfoPO = orderManageService.find(String.valueOf(ticketRequestPO.getOrderId()));
				//获得申请单详细信息
				List<TicketRefundinfoDetailPO> findDetailInfoByReqCode = ticketRefundinfoDetailDao.findDetailInfoByReqCode(requisitionCode);
				//退畅达币
				flag = phoneCoinService.refundLcdCoin(String.valueOf(orderInfoPO.getClearobjectId()), ticketRequestPO.getLcdcoin(), findDetailInfoByReqCode.get(0).getTicketId(), "05");
			}
			} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}