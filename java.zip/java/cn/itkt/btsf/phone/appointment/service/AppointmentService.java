package cn.itkt.btsf.phone.appointment.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.appointment.po.AppointmentPO;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.sys.baseinfo.po.CityPO;
import cn.itkt.exception.AppException;

public interface AppointmentService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return Appointment 
	 */
	public AppointmentPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<AppointmentPO> 
	 */
	public List<AppointmentPO> findAll(Map<String,Object> map);

	/**
	 * 创建 
	 * @param po
	 */
	public boolean create(AppointmentPO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(Long id)throws AppException;
	
	/**
	 * 根据手机号查找用户ID
	 * @param phone
	 * @return
	 */
	public PhoneUsersPO findUserByPhone(String phone);

	/**
	 * 统计记录数
	 * @param map
	 * @return
	 */
	public int count(Map<String,Object> map);
	
	public List<CityPO> findAllCities()throws AppException;
}