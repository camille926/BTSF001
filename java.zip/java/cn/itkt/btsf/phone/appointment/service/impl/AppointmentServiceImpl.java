package cn.itkt.btsf.phone.appointment.service.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.appointment.dao.AppointmentDao;
import cn.itkt.btsf.phone.appointment.po.AppointmentPO;
import cn.itkt.btsf.phone.appointment.service.AppointmentService;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.sys.baseinfo.po.CityPO;
import cn.itkt.btsf.sys.baseinfo.service.CityService;
import cn.itkt.exception.AppException;

@Service
public class AppointmentServiceImpl implements AppointmentService {

	private static final Logger log = LoggerFactory.getLogger(AppointmentServiceImpl.class);
	
	@Resource
	private  AppointmentDao  appointmentDao;
	@Resource
	private CityService cityService;
	/**
	 * 查找单个 
	 * @param id 
	 * @return Appointment 
	 */
	public AppointmentPO find(Serializable id){
		return appointmentDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<AppointmentPO> 
	 */
	public List<AppointmentPO> findAll(Map<String,Object> map){
		return appointmentDao.findAll(map);	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean create(AppointmentPO po) throws AppException{
		try{
			if( po != null )
				 appointmentDao.create(po);
			return true;
		}catch(Exception e){
			log.error(e.getMessage());
			e.printStackTrace();
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(Long id)throws AppException{
		try{
			 appointmentDao.delete(id);
			 return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}		 
	}

	@Override
	public int count(Map<String, Object> map) {
		return appointmentDao.count(map);
	}

	@Override
	public PhoneUsersPO findUserByPhone(String phone) {
		// TODO Auto-generated method stub
		return appointmentDao.findUserByPhone(phone);
	}

	/**
	 * 根据所有城市的概要信息
	 * 
	 * @return
	 * @throws AppException
	 */
	public List<CityPO> findAllCities() throws AppException {
		Map<String, Object> sqlParamMap = new HashMap<String, Object>();
		sqlParamMap.put("startIndex", 0);
		sqlParamMap.put("pageSize", 999999);
		try {
			return cityService.findSummaryCityList(sqlParamMap);
		} catch (Exception e) {
			e.printStackTrace();
			throw new AppException("system.exception");
		}
	}

}