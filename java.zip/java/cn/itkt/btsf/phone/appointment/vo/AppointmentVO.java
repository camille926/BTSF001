package cn.itkt.btsf.phone.appointment.vo;

import java.util.Date;


/**
 * 移动商旅_机票预约表 
 * @author codegen 2011-10-13 11:45:35 
 */
public class AppointmentVO {

    /** 主键  编号 **/ 
	private long id;
	
    /** 会员ID **/ 
	private long userid;
	
    /** 出发城市三字代码 **/ 
	private String dptcity;
	
    /** 到达城市的机场三字代码 **/ 
	private String arrcity;
	
    /** 开始日期   具体格式: yyyy-MM-dd **/ 
	private Date startedate;
	
    /** 结束日期   具体格式: yyyy-MM-dd **/ 
	private Date enddate;
	
    /** 起飞时段     该时间之后的，比如‘12’，就表示12点之后的 **/ 
	private String flyperiod;
	
    /** 星期选择    可以选择周一~周日的任何一天
（1—7） 0不限星期 **/ 
	private String week;
	
    /** 接受方式   提供邮件和手机短信两种方式，其中邮件是默认的
“0”为邮件
“1”为手机短信   目前只支持短息，传1就行 **/ 
	private String accept;
	
    /** 短信接收时间   短信订阅可以选择发送时段，避免晚上时候打扰到睡觉 “0”白天（9：00-21:00）
“1”全天 **/ 
	private String smstime;
	
    /** 舱位折扣    折扣选择只包含整数折扣（3-9和、全价共计7个）价格应低于全价 **/ 
	private String cabindiscount;
	
    /** 预约时间  具体格式: yyyy-MM-dd HH:mm:ss **/ 
	private String adddate;
	
	/** 手机号码 **/
	private String telephone;
	
	private String name;

	private String startedateStr;

	private String enddateStr;
	/**
	 * 构造 
	 */
	public AppointmentVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
	public String getDptcity() {
		return dptcity;
	}

	public void setDptcity(String dptcity) {
		this.dptcity = dptcity;
	}
	public String getArrcity() {
		return arrcity;
	}

	public void setArrcity(String arrcity) {
		this.arrcity = arrcity;
	}
	public Date getStartedate() {
		return startedate;
	}

	public void setStartedate(Date startedate) {
		this.startedate = startedate;
	}
	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	public String getFlyperiod() {
		return flyperiod;
	}

	public void setFlyperiod(String flyperiod) {
		this.flyperiod = flyperiod;
	}
	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}
	public String getAccept() {
		return accept;
	}

	public void setAccept(String accept) {
		this.accept = accept;
	}
	public String getSmstime() {
		return smstime;
	}

	public void setSmstime(String smstime) {
		this.smstime = smstime;
	}
	public String getCabindiscount() {
		return cabindiscount;
	}

	public void setCabindiscount(String cabindiscount) {
		this.cabindiscount = cabindiscount;
	}
	public String getAdddate() {
		return adddate;
	}

	public void setAdddate(String adddate) {
		this.adddate = adddate;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getTelephone() {
		return telephone;
	}


	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}


	public String getStartedateStr() {
		return startedateStr;
	}


	public void setStartedateStr(String startedateStr) {
		this.startedateStr = startedateStr;
	}


	public String getEnddateStr() {
		return enddateStr;
	}


	public void setEnddateStr(String enddateStr) {
		this.enddateStr = enddateStr;
	}
	
}