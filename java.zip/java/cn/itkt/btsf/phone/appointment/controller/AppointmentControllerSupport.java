package cn.itkt.btsf.phone.appointment.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.appointment.po.AppointmentPO;
import cn.itkt.btsf.phone.appointment.service.AppointmentService;
import cn.itkt.btsf.phone.appointment.vo.AppointmentVO;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

@Service
public class AppointmentControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(AppointmentControllerSupport.class);
	
	@Resource
	private  AppointmentService  appointmentService;
	
	public void list(String telephone,int startIndex,ModelMap modelMap){
		Pages<AppointmentPO> page = new Pages<AppointmentPO>(startIndex);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("startIndex", startIndex);
		map.put("pageSize", 10);
		map.put("telephone", telephone);
		List<AppointmentPO> list=appointmentService.findAll(map);
		int count=appointmentService.count(map);
		page.setItems(list);
		page.setTotalCount(count);
		modelMap.addAttribute("page", page);
	}
	
	public int create(Map<String, Object> modelMap,AppointmentVO vo){
		AppointmentPO po=new AppointmentPO();
		if(vo!=null){
			SysUtil.cloneObject(vo, po);
		}
		int flag=0;
		try {
			PhoneUsersPO user=appointmentService.findUserByPhone(po.getTelephone());
			if(user!=null){
				po.setUserid(user.getUserid());
			}
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("telephone", po.getTelephone());
			int count = appointmentService.count(map);
			//检查预约是否超过3次，最多只能预约3次
			if(count >= 3){
				flag = 3;
				
			}else{
				boolean create = appointmentService.create(po);
				if(create){
					flag = 1;
				}else{
					flag = 0;
				}
			}
			
		} catch (AppException e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean delete(Long id){
		boolean flag=false;
		if(id>0&&id!=null){
			try {
				flag=appointmentService.delete(id);
			} catch (AppException e) {
				e.printStackTrace();
			}
		}
		return flag;
	}
	
	public void findUser(String telephone,ModelMap modelMap){
		PhoneUsersPO userpo=appointmentService.findUserByPhone(telephone);
		modelMap.addAttribute("user", userpo);
	}
	
	public void findById(Long id,ModelMap modelMap){
		if(id!=null&&id>0){
			AppointmentPO po=appointmentService.find(id);
			modelMap.addAttribute("appointment", po);
		}
	}
	
	/**
	 * 选择所有城市
	 * 
	 * @param modelMap
	 * @throws AppException
	 */
	public void findAllCities(ModelMap modelMap) throws AppException {
		modelMap.addAttribute("allCities",appointmentService.findAllCities());
	}

}