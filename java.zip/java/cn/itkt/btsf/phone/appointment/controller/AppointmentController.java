package cn.itkt.btsf.phone.appointment.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.itkt.btsf.phone.appointment.vo.AppointmentVO;
import cn.itkt.exception.AppException;
import cn.itkt.util.DateUtil;

@Controller
@RequestMapping("/phone/appointment/appointment")
public class AppointmentController {

	@Resource
	private AppointmentControllerSupport appointmentControllerSupport;

	@RequestMapping("/findall")
	public String list(
			@RequestParam(value = "startIndex", required = false, defaultValue = "0") int startIndex,
			@RequestParam(value = "telephone", required = false) String telephone,
			ModelMap modelMap) {
		appointmentControllerSupport.list(telephone, startIndex, modelMap);
		if (telephone != null && !"".equals(telephone)) {
			modelMap.put("telephone", telephone);
		}
		return "phone/appointment/appointment";
	}

	@RequestMapping("/find")
	public String findById(@RequestParam(value = "id") Long id,
			ModelMap modelMap) {
		appointmentControllerSupport.findById(id, modelMap);
		return "";
	}

	@RequestMapping("/create")
	public @ResponseBody Map<String, Object> create(AppointmentVO vo) {
		String start = vo.getStartedateStr();
		String end = vo.getEnddateStr();
		if ((start != null && !"".equals(start))
				&& (end != null && !"".equals(end))) {
			vo.setStartedate(DateUtil.transferStringToDate(start));
			vo.setEnddate(DateUtil.transferStringToDate(end));
		}
		Map<String, Object> modelMap = new HashMap<String, Object>();
		int create = appointmentControllerSupport.create(modelMap,vo);
		if (create == 1) {
			modelMap.put("success", "true");
		} else if(create == 0) {
			modelMap.put("success", "false");
		}else if (create ==3){
			modelMap.put("success", "fake");
		}
		return modelMap;
	}

	@RequestMapping("/delete")
	public @ResponseBody Map<String, Object> delete(@RequestParam(value = "id") Long id) {
		Map<String, Object> modelMap = new HashMap<String, Object>();
		boolean flag = appointmentControllerSupport.delete(id);
		if (flag) {
			modelMap.put("success", "true");
		} else {
			modelMap.put("fail", "false");
		}
		return modelMap;
	}

	@RequestMapping(value = "/choosecity")
	public String findCity(ModelMap modelMap) {
		try {
			appointmentControllerSupport.findAllCities(modelMap);
		} catch (AppException e) {
			e.printStackTrace();
		}
		return "phone/appointment/choosecity";
	}
	@RequestMapping(value = "/chooseuser")
	public String findUser(@RequestParam(value = "phone") String phone,ModelMap modelMap){
		appointmentControllerSupport.findUser(phone, modelMap);
		return "phone/appointment/chooseuser";
	}
}