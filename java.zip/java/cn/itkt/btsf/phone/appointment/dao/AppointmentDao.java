package cn.itkt.btsf.phone.appointment.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.appointment.po.AppointmentPO;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;

/**
 * 移动商旅_机票预约表 
 * @author codegen 2011-10-13 11:45:35 
 */
public interface AppointmentDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return Appointment 
	 */
	public AppointmentPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<AppointmentPO> 
	 */
	public List<AppointmentPO> findAll(Map<String,Object> map);
	
	/**
	 * 根据手机号查找用户ID
	 * @param phone
	 * @return
	 */
	public PhoneUsersPO findUserByPhone(String phone);
	/**
	 * 创建 
	 * @param po 
	 */
	public void create(AppointmentPO po);
	
	/**
	 * 统计记录数
	 * @param map
	 * @return
	 */
	public int count(Map<String,Object> map);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);

}