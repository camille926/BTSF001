package cn.itkt.btsf.phone.helpproblem.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.helpproblem.dao.HelpProblemDao;
import cn.itkt.btsf.phone.helpproblem.po.HelpProblemPO;
import cn.itkt.btsf.phone.helpproblem.service.HelpProblemService;
import cn.itkt.exception.AppException;

@Service
public class HelpProblemServiceImpl implements HelpProblemService {

	private static final Logger log = LoggerFactory.getLogger(HelpProblemServiceImpl.class);
	
	@Resource
	private  HelpProblemDao  helpProblemDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return HelpProblem 
	 */
	public HelpProblemPO find(Long id){
		return helpProblemDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<HelpProblemPO> 
	 */
	public List<HelpProblemPO> findAll(Map<String,Object> map){
		return helpProblemDao.findAll(map);	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean create(HelpProblemPO po) throws AppException{
		try{
			if( po != null )
				 helpProblemDao.create(po);
			return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean update(HelpProblemPO po) throws AppException {
		try{
			if( po != null )
				 helpProblemDao.update(po);
			return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(String[] id)throws AppException{
		try{
			 helpProblemDao.delete(id);
			 return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}
	}
	
	/**
	 * 统计记录数
	 */
	@Override
	public int count(Map<String, Object> map) {		
		return helpProblemDao.count(map);
	}



}