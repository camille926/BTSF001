package cn.itkt.btsf.phone.helpproblem.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.helpproblem.po.HelpProblemPO;
import cn.itkt.exception.AppException;

public interface HelpProblemService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return HelpProblem 
	 */
	public HelpProblemPO find(Long id);

	/**
	 * 查找所有 
	 * @return List<HelpProblemPO> 
	 */
	public List<HelpProblemPO> findAll(Map<String,Object> map);

	/**
	 * 创建 
	 * @param po
	 */
	public boolean create(HelpProblemPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public boolean update(HelpProblemPO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(String[] id)throws AppException;

	/**
	 * 统计记录数
	 * @param map
	 * @return
	 */
	public int count(Map<String,Object> map);

}