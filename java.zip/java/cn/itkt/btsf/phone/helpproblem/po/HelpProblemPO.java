package cn.itkt.btsf.phone.helpproblem.po;

import java.io.Serializable;


/**
 * 移动商旅_使用帮助表 
 * @author codegen 2011-10-13 11:45:29 
 */
public class HelpProblemPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** 主键 **/ 
	private long id;
	
    /** 类别编码   00  机票预订
01  畅达币
02  航班动态
03  信用卡支付 **/ 
	private String classnum;
	
    /** 问题内容 **/ 
	private String problem;
	
    /** 问题答案 **/ 
	private String answer;
	

	/**
	 * 构造 
	 */
	public HelpProblemPO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getClassnum() {
		return classnum;
	}

	public void setClassnum(String classnum) {
		this.classnum = classnum;
	}
	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}
	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

}