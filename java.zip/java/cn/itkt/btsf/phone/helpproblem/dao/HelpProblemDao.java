package cn.itkt.btsf.phone.helpproblem.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.helpproblem.po.HelpProblemPO;

/**
 * 移动商旅_使用帮助表 
 * @author codegen 2011-10-13 11:45:29 
 */
public interface HelpProblemDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return HelpProblem 
	 */
	public HelpProblemPO find(Long id);

	/**
	 * 查找所有 
	 * @return List<HelpProblemPO> 
	 */
	public List<HelpProblemPO> findAll(Map<String,Object> map);

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(HelpProblemPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(HelpProblemPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 统计记录数
	 * @param map
	 * @return
	 */
	public int count(Map<String,Object> map);
}