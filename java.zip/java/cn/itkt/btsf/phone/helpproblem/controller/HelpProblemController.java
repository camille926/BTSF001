package cn.itkt.btsf.phone.helpproblem.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.itkt.btsf.phone.helpproblem.vo.HelpProblemVO;


@Controller
@RequestMapping("/phone/helpproblem/helpproblem")
public class HelpProblemController {

	@Resource
	private  HelpProblemControllerSupport  helpProblemControllerSupport;
	
	@RequestMapping("/findall")
	public String list(@RequestParam(value="startIndex", required=false, defaultValue="0") int startIndex,
			@RequestParam(value="classnum",required=false) String classnum,ModelMap modelMap){
		helpProblemControllerSupport.list(classnum, startIndex, modelMap);
		if(classnum!=null&&!"".equals(classnum)){
			modelMap.addAttribute("classnum", classnum);
		}
		return "phone/helpproblem/helpproblem";
	}
	@RequestMapping("/create")
	public @ResponseBody Map<String,Object> create(HelpProblemVO vo){
		Map<String,Object> modelMap=new HashMap<String,Object>();
		boolean flag=helpProblemControllerSupport.create(vo);
		if(flag){
			modelMap.put("success", "true");
		}else{
			modelMap.put("fail", "false");
		}
		return modelMap;
	}
	@RequestMapping("/delete")
	public @ResponseBody Map<String,Object> delete(@RequestParam(value="id") String id){
		Map<String,Object> modelMap=new HashMap<String,Object>();
		boolean flag=helpProblemControllerSupport.delete(id);
		if(flag){
			modelMap.put("success", "true");
		}else{
			modelMap.put("fail", "false");
		}
		return modelMap;
	}
	
	@RequestMapping("/find")
	public String findById(@RequestParam(value="id") Long id,ModelMap modelMap){
		helpProblemControllerSupport.findById(id, modelMap);
		return "phone/helpproblem/helpproblemdetails";
	}
	@RequestMapping("/showedit")
	public String showEdit(@RequestParam(value="id") Long id,ModelMap modelMap){
		helpProblemControllerSupport.findById(id, modelMap);
		return "phone/helpproblem/helpproblemupdate";
	}
	@RequestMapping("/update")
	public @ResponseBody Map<String,Object> update(HelpProblemVO vo){
		Map<String,Object> modelMap=new HashMap<String,Object>();
		boolean flag=helpProblemControllerSupport.update(vo);
		if(flag){
			modelMap.put("success", "true");
		}else{
			modelMap.put("fail", "false");
		}
		return modelMap;		
	}
}