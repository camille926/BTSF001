package cn.itkt.btsf.phone.helpproblem.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.helpproblem.po.HelpProblemPO;
import cn.itkt.btsf.phone.helpproblem.service.HelpProblemService;
import cn.itkt.btsf.phone.helpproblem.vo.HelpProblemVO;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

@Service
public class HelpProblemControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(HelpProblemControllerSupport.class);
	
	@Resource
	private  HelpProblemService  helpProblemService;
	/**
	 * 列表
	 * @param classnum
	 * @param startIndex
	 * @param modelMap
	 */
	public void list(String classnum,int startIndex,ModelMap modelMap){
		Pages<HelpProblemPO> page = new Pages<HelpProblemPO>(startIndex);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("startIndex", startIndex);
		map.put("pageSize", 10);
		map.put("classnum", classnum);
		List<HelpProblemPO> list=helpProblemService.findAll(map);
		int count=helpProblemService.count(map);
		page.setItems(list);
		page.setTotalCount(count);
		modelMap.addAttribute("page", page);
		
	}
	/**
	 * 创建
	 * @param vo
	 * @return
	 */
	public boolean create(HelpProblemVO vo){
		HelpProblemPO po=new HelpProblemPO();
		if(vo!=null){
			SysUtil.cloneObject(vo, po);
		}
		boolean flag=false;
		try {
			flag=helpProblemService.create(po);
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	/**
	 * 删除
	 * @param id
	 * @return
	 */
	public boolean delete(String id){
		boolean flag=false;
			try {
				flag=helpProblemService.delete(id.split(","));
			} catch (AppException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return flag;
	}
	/**
	 * 查找单个
	 * @param id
	 * @param modelMap
	 */
	public void findById(Long id,ModelMap modelMap){
		HelpProblemPO po=helpProblemService.find(id);
		if(po!=null){
			modelMap.addAttribute("helpProblem", po);
		}
		
	}
	/**
	 * 修改
	 * @param vo
	 * @return
	 */
	public boolean update(HelpProblemVO vo){
		HelpProblemPO po=new HelpProblemPO();
		if(vo!=null){
			SysUtil.cloneObject(vo, po);
		}
		boolean flag=false;
		try {
			flag=helpProblemService.update(po);
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
}