package cn.itkt.btsf.phone.circum.vo;



/**
 * 移动商旅_机场周边服务表 
 * @author codegen 2011-10-13 15:16:51 
 */
public class CircumServiceVO {

    /** 编号 主键 **/ 
	private long id;
	
    /** 服务名称 **/ 
	private String servicename;
	

	/**
	 * 构造 
	 */
	public CircumServiceVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getServicename() {
		return servicename;
	}

	public void setServicename(String servicename) {
		this.servicename = servicename;
	}

}