package cn.itkt.btsf.phone.circum.vo;



/**
 * 移动商旅_班车机场信息 
 * @author codegen 2011-10-12 21:05:05 
 */
public class AirportShuttleVO {

    /** 编号   主键 **/ 
	private long id;
	
    /** 机场名称 **/ 
	private String name;
	

	/**
	 * 构造 
	 */
	public AirportShuttleVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}