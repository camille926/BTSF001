package cn.itkt.btsf.phone.circum.controller;



import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.btsf.phone.circum.vo.PhoneActivityVO;



@Controller
@RequestMapping("/sys/phoneactivity")
public class PhoneActivityController {

	@Resource
	private  PhoneActivityControllerSupport  phoneActivityControllerSupport;
	
	
	/**
	 * 分页
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/list")
	public String list(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex){
		//调用Support处理业务逻辑
		phoneActivityControllerSupport.list(modelMap, startIndex);
		return "phone/activity/view";		
		
	}
	
	/**
	 * 分页--条件查询
	 * @param modelMap
	 * @param startIndex 开始页数
	 * @return
	 */
	
	@RequestMapping(value="/listForfind")
	public String list1(ModelMap modelMap,	
			@RequestParam(value="startIndex" ,required=false, defaultValue="0") int startIndex,PhoneActivityVO vo){
		//调用Support处理业务逻辑
		phoneActivityControllerSupport.listForFind(modelMap, startIndex, vo);
		return "phone/activity/view";		
		
	}
	
	
	/**
	 * 跳转添加信息
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toAdd")
	public String templatevUpdate(ModelMap modelMap){
		return "phone/activity/add";
	}
	
	/**
	 * 跳转修改信息
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toUpdate")
	public String templatevUpdate(ModelMap modelMap,
			@RequestParam(value="Id" ,required=false, defaultValue="") String Id){
		
		this.phoneActivityControllerSupport.findById(modelMap, Id);
		
		return "phone/activity/edit";
	}
	
	/**
	 * 验证
	 * @param sendOption 发送项
	 * @return
	 */
	@RequestMapping(value="/validationName")
	public @ResponseBody boolean validationName(@RequestParam(value="activityname",required=false,defaultValue="") String activityname,@RequestParam(value="id",required=false,defaultValue="") String id){
		return this.phoneActivityControllerSupport.validationName(activityname,id);
	}

	/**
	 * 添加
	 * @param modelMap	
	 * @param vo
	 */
	@RequestMapping(value="/add")
	public ModelAndView add(ModelMap modelMap, @ModelAttribute PhoneActivityVO vo,HttpServletResponse response){
		this.phoneActivityControllerSupport.add(modelMap, vo);
		return new ModelAndView("jsonView");
	}
	/**
	 * 更新
	 * @param modelMap
	 * @param 
	 * @return
	 */
	@RequestMapping(value="/update")
	public ModelAndView update(ModelMap modelMap,@ModelAttribute("PhoneActivityVO") PhoneActivityVO phoneActivityVO){
		this.phoneActivityControllerSupport.update(modelMap, phoneActivityVO);
		return new ModelAndView("jsonView");
	}
	
	/**
	 * 注册指定日期格式的日期属性编辑器
	 * 
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		formater.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formater, true));
	}
	
	/**
	 * 删除
	 * @param modelMap
	 * @param roleVO 用户信息
	 * @return
	 */
	@RequestMapping(value="/delete")
	public ModelAndView delete(ModelMap modelMap,
			@RequestParam(value="Id" ,required=false, defaultValue="") String Id){
		this.phoneActivityControllerSupport.delete(modelMap, Id);
		return new ModelAndView("jsonView");
	}




}