package cn.itkt.btsf.phone.circum.controller;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.circum.po.PhoneActivityPO;
import cn.itkt.btsf.phone.circum.service.PhoneActivityService;
import cn.itkt.btsf.phone.circum.vo.PhoneActivityVO;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

@Service
public class PhoneActivityControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(PhoneActivityControllerSupport.class);
	
	@Resource
	private  PhoneActivityService  phoneActivityService;
	
	/**
	 * 跳转列表
	 * 
	 * @param modelMap
	 */
	public void list(ModelMap modelMap,int startIndex){
	  try {
		  Pages<PhoneActivityVO> pages=new Pages<PhoneActivityVO>(startIndex);
		  Map<Object,Object> map=new HashMap<Object,Object>();
		  map.put("startIndex", startIndex);
		  map.put("pageSize", 10);
		  List<PhoneActivityVO> temList=this.phoneActivityService.poListToVoList(this.phoneActivityService.findAllForPage(map));
		  pages.setItems(temList);
		  pages.setTotalCount(phoneActivityService.countFindAllForPage(map));
		  modelMap.addAttribute("page",pages);
	} catch (Exception e) {
		e.printStackTrace();
		log.error(e.getMessage());
	}
		
	}
	
	//查询
	public void listForFind(ModelMap modelMap, int startIndex,PhoneActivityVO vo) {
		try {
			Pages<PhoneActivityPO> pages = new Pages<PhoneActivityPO>(startIndex);
			Map<Object, Object> map = new HashMap<Object, Object>();
		if (!vo.getActivityname().equals("")) {
			map.put("activityname", vo.getActivityname());
			modelMap.addAttribute("activityname", vo.getActivityname());
			
		}
		if (vo.getStarttime()!=null) {
			map.put("starttime", vo.getStarttime());
			modelMap.addAttribute("starttime", vo.getStarttime());
		}
		if (vo.getEndtime()!=null) {
			map.put("endtime", vo.getEndtime());
			modelMap.addAttribute("endtime",vo.getEndtime());
		}

			//map.put("sendType", "2");
			map.put("startIndex", startIndex);
			map.put("pageSize", 10);
			List<PhoneActivityPO> list = this.phoneActivityService.findAllForPage(map);
			//List<MsgSendVO> mList = this.msgSendService.poListToVoList(list);
			pages.setItems(list);
			pages.setTotalCount(phoneActivityService.countFindAllForPage(map));
			modelMap.addAttribute("page", pages);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}

	}
	
	/**
	 * 新增
	 * @param modelMap
	 * @param vo
	 */
	public void add(ModelMap modelMap, PhoneActivityVO vo){
		try {
			
			this.phoneActivityService.create(this.phoneActivityService.voToPo(vo));
			modelMap.clear();
			modelMap.addAttribute("message", "保存成功");
			modelMap.addAttribute("status", true);
		} catch (AppException e) {
			log.error(e.getMessage());
			modelMap.addAttribute("message", "保存失败");
			modelMap.addAttribute("status", false);
		}
	}
	
	/**
	 * 验证数据否存在
	 * @param varNo 
	 * @return
	 */
	public boolean validationName(String name,String id){
		try {
			PhoneActivityPO po = this.phoneActivityService.findByName(name);
			if(po==null||id.equals(String.valueOf(po.getId())))
				return true;
			else
				return false;
		} catch (AppException e) {
			log.error(e.getMessage());
			return false;
		}
	}
	
	 /** 根据ID查询
	 * @param modelMap
	 * @param teamInfoId 班组ID
	 */
	public void findById(ModelMap modelMap,String id){
		

		try {
			PhoneActivityPO po=this.phoneActivityService.find(id);
			
			modelMap.addAttribute("activity", this.phoneActivityService.poToVo(po));
			
		} catch (Exception e) {
			
			log.error(e.getMessage());
		}
	}
	/**
	 * 更新
	 * @param modelMap
	 * @param userVO 角色信息
	 */
	public void update(ModelMap modelMap,PhoneActivityVO phoneActivityVO){
		try {
			this.phoneActivityService.update(this.phoneActivityService.voToPo(phoneActivityVO));
			modelMap.clear();
			modelMap.addAttribute("message", "保存成功");
			modelMap.addAttribute("status", true);
		} catch (AppException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage());
			modelMap.addAttribute("message", "保存失败");
			modelMap.addAttribute("status", false);
		}

	}
	
	/**
	 * 删除
	 * @param modelMap
	 * @param teamInfoId 班组Id
	 */
	public void delete(ModelMap modelMap,String Id){
		try {
			this.phoneActivityService.delete(Id);
			modelMap.clear();
			modelMap.addAttribute("message", "删除成功");
			modelMap.addAttribute("status", true);
		} catch (AppException e) {
			log.error(e.getMessage());
			modelMap.addAttribute("message", "删除失败");
			modelMap.addAttribute("status", false);
		}
		
	}

	



}