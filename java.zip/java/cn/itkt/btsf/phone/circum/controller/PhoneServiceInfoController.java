package cn.itkt.btsf.phone.circum.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import cn.itkt.btsf.phone.circum.po.AirportServicePO;
import cn.itkt.btsf.phone.circum.vo.AirportServiceVO;
import cn.itkt.btsf.sys.baseinfo.po.AirportPO;
import cn.itkt.btsf.sys.cc.national.controller.ShoppingReserveController;
import cn.itkt.btsf.sys.constant.po.ConstantPO;
import cn.itkt.btsf.util.UploadController;
import cn.itkt.util.SysUtil;


@Controller
@RequestMapping("/phone/circum/airportserviceinfo")
public class PhoneServiceInfoController {
	private static final Logger log = LoggerFactory.getLogger(ShoppingReserveController.class);
	@Resource
	private  PhoneServiceInfoControllerSupport  phoneServiceInfoControllerSupport;
	@RequestMapping("/addOrUpdate")
	public @ResponseBody Map<String, Object> create(AirportServiceVO vo){
		boolean flag= false;
		Map<String, Object> modelMap = new HashMap<String, Object>(3);
		String[] split = vo.getAirportname().split(",");
		if(split.length>0){
			if(split[0] != null && !"".equals(split[0])){//机场的id,新增操作时为0
				vo.setAirportid(Long.valueOf(split[0]));
			}
			if(split[1] != null && !"".equals(split[1])){//机场名称
				vo.setAirportname(split[1]);
			}
		}
		String serviceType = vo.getServicetype();
		if(vo.getAirportid()==0){//新增操作airportid为0,根据airportname 查询airportid
			AirportPO airport = phoneServiceInfoControllerSupport.findAirportByAirportName(vo.getAirportname());
			if(airport != null){
				vo.setAirportid(airport.getId());
			}
		}
		Long airportId = vo.getAirportid();
		String airportName = vo.getAirportname();
		//根据条件查询
		AirportServicePO po = phoneServiceInfoControllerSupport.findByAirportIdAndServiceType(airportId,airportName, serviceType, modelMap);
		if(po != null){
			//如果拥有此机场id与服务类型的记录存在，则更新此条记录的详情信息，避免同个机场下拥有多条相同服务类型的记录.
			SysUtil.cloneObject(vo, po);
			flag = phoneServiceInfoControllerSupport.updateByAirportIDAndServiceType(po);
			if(flag){
				modelMap.put("success", "trueUpdate");
			}else{
				modelMap.put("fail", "false");
			}
		}else{
			//如果没有此机场信息或，此机场信息下没有此服务类型，则新添加
			flag = phoneServiceInfoControllerSupport.create(vo);
			if(flag){
				modelMap.put("success", "trueSave");
			}else{
				modelMap.put("fail", "false");
			}
		}

		return modelMap;
	}
	@RequestMapping("/update")
	public @ResponseBody Map<String, Object> update(AirportServiceVO vo){
		Map<String, Object> modelMap = new HashMap<String, Object>(3);
		boolean flag=phoneServiceInfoControllerSupport.update(vo);
		if(flag){
			modelMap.put("success", "true");
		}else{
			modelMap.put("fail", "false");
		}
		return modelMap;
	}
	@RequestMapping("/delete")
	public @ResponseBody Map<String, Object> delete(@RequestParam(value="id") String id){
		Map<String, Object> modelMap = new HashMap<String, Object>(3);
		boolean flag=phoneServiceInfoControllerSupport.delete(id);
		if(flag){
			modelMap.put("success","true");
		}else{
			modelMap.put("fail","false");
		}
		return modelMap;
	}
	@RequestMapping("/findall")
	public String findAll(@RequestParam(value="startIndex", required=false, defaultValue="0") int startIndex,
			@RequestParam(value="name",required=false) String name,
			@RequestParam(value="servicename",required=false) String servicename,ModelMap modelMap){
		phoneServiceInfoControllerSupport.findAll(name,servicename,startIndex, modelMap);
		if(name!=null&&!"".equals(name)){
			modelMap.addAttribute("name", name);
		}
		if(servicename!=null&&!"".equals(servicename)){
			modelMap.addAttribute("servicename", servicename);
		}
		return "phone/circum/airportservice";
	}
	@RequestMapping("/find")
	public String findById(@RequestParam(value="id") Long id,ModelMap modelMap){
		phoneServiceInfoControllerSupport.findById(id, modelMap);
		return "phone/circum/airportservicedetails";
	}
	
	@RequestMapping("/findservicetype")
	public String findServiceType(ModelMap modelMap){
		Map<String, String> dictionaryEntries = new HashMap<String, String>();
		List<ConstantPO> list = phoneServiceInfoControllerSupport.getConstantPOes(32l);
		//查询服务类型列表
		for(ConstantPO constantPO : list){
			dictionaryEntries.put(constantPO.getKey(), constantPO.getValue());
		}
		modelMap.addAttribute("servicetype", dictionaryEntries);
		return "phone/circum/manageservicetype";
	}
	/**
	 * 完成字典表里，周边环境服务信息的更新、新增、删除功能
	 * @param po在操作的对象
	 * @param operateType操作类型，当进行删除操作时，此字段不为空。
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/addOrUpdateServiceType")
	public @ResponseBody Map<String, Object> addOrUpdateServiceType(ConstantPO po, String operateType) throws Exception{
		String result = "";
		boolean flag= false;
		Map<String, Object> modelMap = new HashMap<String, Object>(3);
		 po.setValue(new String(po.getValue().getBytes("ISO-8859-1"), "UTF-8"));// 解决乱码问题
		if(!"".equals(po.getKey())&& po.getKey() != null){
			if("delete".equals(operateType) && operateType != null){
				//在这里做删除操作
				flag = phoneServiceInfoControllerSupport.deleteConstantPO(po);
				if(flag){
					result =  "trueDelete";
				}
			}else{
				//这是更新操作
				flag = phoneServiceInfoControllerSupport.updateServiceType(po);
				if(flag){
					result = "trueUpdate";
				}
			}
		}else{
			//这是新增操作
			List<ConstantPO> list = phoneServiceInfoControllerSupport.getConstantPOes(32l);
			Long poKey = 0l;
			//新添加servicetype 时，取出所有记录中key 最大的，然后将新添加的记录的key 再加1
			for(ConstantPO constantPO: list){
				Long key = Long.parseLong(constantPO.getKey());
				if(key>poKey){
					poKey = key;
				}
			}
			Long d = (poKey+1);
			po.setKey(d.toString());//将最大的key 付给新添加的记录
			flag = phoneServiceInfoControllerSupport.saveConstantPO(po);
			if(flag){
				result =  "trueSave";
			}
		}
		//返回页面的提示信息
		if(flag){
			modelMap.put("success", result);
		}else{
			modelMap.put("fail", "false");
		}
		return modelMap;
	}
	/**
	 * 转到导入页面
	 * @param modelMap
	 * @return
	 */
	@RequestMapping("/toImportServiceType")
	public String importservicetype(ModelMap modelMap){
		return "phone/circum/importservicetype";
	}
	/**
	 * 导入写在EXCEL表格里的个人会员信息
	 * 
	 * @param modelMap
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/importExcel")
	public  void importExcel(HttpServletRequest request, HttpServletResponse response){
		List<ConstantPO>  constantPO = phoneServiceInfoControllerSupport.getConstantPOes(32l);

		JSONArray jsonArray = new JSONArray();
		Map<String, Object> modelMap = new HashMap<String, Object>(3);
		UploadController uploader = new UploadController();
		Set<MultipartFile> mfs = uploader.getFileSet(request);
		try {
			 phoneServiceInfoControllerSupport.importExcel(mfs, modelMap);
			 //将失败的记录返回页面
			 List<AirportServiceVO> errorList = (List<AirportServiceVO>) modelMap.get("errorVos");
			 if(errorList.size()>0 && errorList != null){
				 for(AirportServiceVO vo : errorList){
					 JSONObject obj = new JSONObject();
					 obj.put("airportName", vo.getAirportname());
					 for(ConstantPO po : constantPO){
						 if(po.getKey().equals(vo.getServicetype())){
							 vo.setServicetype(po.getValue());
							 break;
						 }
					 }
					 obj.put("serviceType", vo.getServicetype());
					 obj.put("serviceInfo", vo.getServiceinfo());
					 obj.put("status", "失败");
					 jsonArray.add(obj);
				 }
			 }
			 //成功的记录返回页面
			 List<AirportServiceVO> successList = (List<AirportServiceVO>) modelMap.get("successVos");
			 if(successList.size()>0 && successList != null){
				 for(AirportServiceVO vo : successList){
					 JSONObject obj = new JSONObject();
					 obj.put("airportName", vo.getAirportname());
					 for(ConstantPO po : constantPO){
						 if(po.getKey().equals(vo.getServicetype())){
							 vo.setServicetype(po.getValue());
							 break;
						 }
					 }
					 obj.put("serviceType", vo.getServicetype());
					 obj.put("serviceInfo", "无");
					 obj.put("status", "成功");
					 jsonArray.add(obj);
				 }
			 }
			 SysUtil.render(response, jsonArray.toString());
		} catch (Exception e) {
			SysUtil.render(response, "0");
		}
	}
	/**
	 * 转到显示导入周边信息的模板页面
	 * @param modelMap
	 * @return
	 */
	@RequestMapping("/importServiceTypeTemplate")
	public String importServiceTypeTemplate(ModelMap modelMap){
		return "phone/circum/importServiceTypeTemplate";
	}
	/**
	 * 根据输入值模糊查询机场名称,自动提示
	 * @return
	 */
	@RequestMapping("/qryAirport")
	@ResponseBody
	public Object qryEntmbr(@RequestParam(value="namePrefix",required=false, defaultValue="") String namePrefix, ModelMap model){
			
			try {
				namePrefix = URLDecoder.decode(namePrefix, "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			log.debug("**********查询企业会员，按名称前缀匹配，当前输入值【{}】 ", namePrefix);
			List<AirportPO> resultList = phoneServiceInfoControllerSupport.findAirportByInput(namePrefix);
			
			return resultList;
	}
}