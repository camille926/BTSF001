package cn.itkt.btsf.phone.circum.controller;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;

import cn.itkt.btsf.phone.circum.po.AirportServicePO;
import cn.itkt.btsf.phone.circum.service.AirportServiceService;
import cn.itkt.btsf.phone.circum.vo.AirportServiceVO;
import cn.itkt.btsf.sys.baseinfo.po.AirportPO;
import cn.itkt.btsf.sys.baseinfo.service.AirportService;
import cn.itkt.btsf.sys.common.constant.ConstantUtil;
import cn.itkt.btsf.sys.constant.dao.ConstantDao;
import cn.itkt.btsf.sys.constant.po.ConstantPO;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

@Service
public class PhoneServiceInfoControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(PhoneServiceInfoControllerSupport.class);
	
	@Resource
	private  AirportServiceService  airportServiceService;
	
	@Resource
	private  ConstantDao constantDao;
	@Resource
	private AirportService airportService;
	/**
	 * 添加
	 * @param vo
	 * @return
	 */
	public boolean create(AirportServiceVO vo){
		AirportServicePO po=new AirportServicePO();
		SysUtil.cloneObject(vo, po);
		boolean flag=false;
		try {
			flag=airportServiceService.create(po);
			return flag;
		} catch (AppException e) {
			e.printStackTrace();
			return flag;
		}
	}
	/**
	 * 添加
	 * @param vo
	 * @return
	 */
	public boolean update(AirportServiceVO vo){
		AirportServicePO po=new AirportServicePO();
		SysUtil.cloneObject(vo, po);
		boolean flag=false;
		try {
			flag=airportServiceService.update(po);
			return flag;
		} catch (AppException e) {
			e.printStackTrace();
			return flag;
		}
	}
	
	/**
	 * 删除
	 * @param id
	 */
	public boolean delete(String sid){
		boolean flag=false;
		try {
			flag = airportServiceService.delete(sid.split(","));
		} catch (AppException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	public void findAll(String name,String servicename,int startIndex,ModelMap modelMap){
		Pages<AirportServicePO> page = new Pages<AirportServicePO>(startIndex);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("startIndex", startIndex);
		map.put("pageSize", 10);
		map.put("name", name);
		map.put("servicename", servicename);
		List<AirportServicePO> list=airportServiceService.findAll(map);
		int count=airportServiceService.count(map);
		//查询服务类型列表
		Map<String, String> dictionaryEntries = new HashMap<String, String>();
		List<ConstantPO> lists = this.getConstantPOes(32l);
		//查询服务类型列表
		for(ConstantPO constantPO : lists){
			dictionaryEntries.put(constantPO.getKey(), constantPO.getValue());
		}
		modelMap.addAttribute("servicetype", dictionaryEntries);
//		Map<String, String> dictionaryEntries = ConstantUtil.getDictionary("32");//项目启动时进行了缓存，导致更新后，取到的仍是内存中未修改的数据。
		//查询机场名称列表
		Map<String,String> map1 = new HashMap<String,String>();
		List<AirportPO> findInitAirport = airportService.findInitAirport(map1);
		modelMap.addAttribute("airportname", findInitAirport);
		for (AirportServicePO po : list) {
			po.setServicetype(dictionaryEntries.get(po.getServicetype()));
		}
		page.setItems(list);
		page.setTotalCount(count);
		page.setPageSize(10);
		modelMap.put("page", page);
	}

	public void findById(Long id,ModelMap modelMap){
		//查询服务类型列表
		Map<String, String> dictionaryEntries = new HashMap<String, String>();
		List<ConstantPO> lists = this.getConstantPOes(32l);
		//查询服务类型列表
		for(ConstantPO constantPO : lists){
			dictionaryEntries.put(constantPO.getKey(), constantPO.getValue());
		}
		modelMap.addAttribute("servicetype", dictionaryEntries);
		
		//查询机场名称列表
		Map<String,String> map1 = new HashMap<String,String>();
		List<AirportPO> findInitAirport = airportService.findInitAirport(map1);
		modelMap.addAttribute("airportname", findInitAirport);
		
		AirportServicePO po=airportServiceService.find(id);
		if(po != null){
			po.setServicetype(dictionaryEntries.get(po.getServicetype()));
			modelMap.addAttribute("airportService", po);
		}
	}
	/**
	 * 根据id，服务类型查询记录，如果存在则更新，如果不存在则增加一条
	 * @param id
	 * @param serviceType
	 * @param modelMap
	 */
	public AirportServicePO findByAirportIdAndServiceType(Long airportId,String airportName, String serviceType, Map<String, Object> modelMap) {
		Map<String, Object> queryMap = null;
		queryMap = new HashMap<String, Object>();
		if(airportId > 0){
			queryMap.put("airportId", airportId);
		}
		if(serviceType != null && !"".equals(serviceType)){
			queryMap.put("serviceType", serviceType);
		}
		if(airportName != null && !"".equals(airportName)){
			queryMap.put("airportName", airportName);
		}
		AirportServicePO po=airportServiceService.findByAirportIdAndServiceType(queryMap);
		return po;
	}
	public Boolean updateByAirportIDAndServiceType(AirportServicePO po) {
			try {
				airportServiceService.updateByAirportIDAndServiceType(po);
				return true;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
	}
	public Boolean updateServiceType(ConstantPO po){
		try {
			constantDao.updateByKey(po);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	//根据字典类型id 查询所有子类型
	public List<ConstantPO> getConstantPOes(Long typeId){
		return constantDao.findConstantByTypeid(typeId);
	}
	/**
	 * 删除一条字典信息，周边服务名称
	 * @param po
	 * @return
	 */
	public boolean saveConstantPO(ConstantPO po){
		 try {
			constantDao.create(po);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public boolean deleteConstantPO(ConstantPO po){
		List<ConstantPO> list = getConstantPOes(32l);
		for(ConstantPO constantPO: list){
			if(constantPO.getKey().equals(po.getKey())&&constantPO.getValue().equals(po.getValue())){
				po.setId(constantPO.getId());
			}
		}
		try {
			constantDao.delete(po.getId());
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	/**
	 * 根据输入名字自动提示机场名称
	 * @param namePrefix 输入的字符
	 * @return
	 */
	public List<AirportPO> findAirportByInput(String namePrefix){
		Map<String,String> queryMap = new HashMap<String,String>();
		queryMap.put("airportName", namePrefix.toUpperCase());
		List<AirportPO> findInitAirport = airportService.findByInput(queryMap);
		return findInitAirport;
	}
	/**
	 * 新增加，批量导入周边信息
	 * @param mfs
	 * @return
	 */
	public void importExcel(Set<MultipartFile> mfs, Map<String, Object> modelMap) {
		InputStream excelToLoad = null;
		if(mfs != null){
			////存放不符合条件的记录
			List<AirportServiceVO> errorAirportServiceVOs = null;
			//存放转换后的对象集合
			List<AirportServiceVO> vos = null;
			Iterator<MultipartFile> ite = mfs.iterator();
			MultipartFile multipartFile = null;
			while(ite.hasNext()){
				multipartFile = ite.next();
				break; //只有一个文件，所以直接跳出
			}
			try {
				if(multipartFile != null){
					excelToLoad = multipartFile.getInputStream();
					//将excel 中的数据转成List<Map<String, String>>格式
					List<Map<String, String>> serviceTypeList = this.parseXlsFileField(excelToLoad);
					//存放不符合条件的记录
					errorAirportServiceVOs = new ArrayList<AirportServiceVO>();
					//将List<Map<String, String>>转成对象的集合List
					vos = transferList(serviceTypeList, errorAirportServiceVOs);
					//存储List<AirportServiceVO> vos,难点是将成功存入的记录数与失败的记录数记录下来
					if(vos != null && vos.size()>0){
						for(int i = 0; i<vos.size(); i++){
							AirportServiceVO vo = vos.get(i);
							try {
								AirportServicePO po = this.findByAirportIdAndServiceType(vo.getAirportid(), "",vo.getServicetype(), null);
								if(po != null){
									po.setServiceinfo(vos.get(i).getServiceinfo());
									this.updateByAirportIDAndServiceType(po);
								}else{
									AirportServicePO newpo = new AirportServicePO();
									SysUtil.cloneObject(vo, newpo);
									boolean flag = airportServiceService.create(newpo);
									if(!flag){
										vo.setServiceinfo("此条未导入，原因：未知!");
										errorAirportServiceVOs.add(vo);//失败信息集合中加入此条
										vos.remove(vo);//成功信息集合中移除此条
									}
								}
							} catch (Exception e) {
								e.printStackTrace();
								vo.setServiceinfo("此条未导入，原因："+ e.getMessage().subSequence(0, 100));
								errorAirportServiceVOs.add(vo);
								continue;
							}
							
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if(excelToLoad != null){
						excelToLoad.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			//将结果信息放在modelMap中，便于在页面显示失败或成功数
			modelMap.put("errorVos", errorAirportServiceVOs);
			modelMap.put("successVos", vos);
			
		}else{
			throw new AppException("parse.excel.exception");
		}
	}

	/**
	 * 将List<Map<String,String>> 形式的数据转换成List<AirportServiceVO> 格式
	 * @param list
	 * @param errorData
	 * @return
	 */
	private List<AirportServiceVO> transferList(List<Map<String,String>> list, List<AirportServiceVO> errorAirportServiceVOs){
		Integer num = 0;
		List<AirportServiceVO> airportServiceVOs = new ArrayList<AirportServiceVO>();
		//未导入数据，如机场名不存在，服务类型不存在等情况，则数据不能导入.
		AirportServiceVO vo = null;
		for(Map<String, String> map: list){
			num++;
			vo = new AirportServiceVO();
			Long airportId = 0l;
			String serviceType = "";
			String airportName = map.get("机场名称");
			String serviceTypeName = map.get("服务名称");
			String serviceInfo = map.get("服务详情");
			//根据机场名称查找机场id
			try {
				if(!"".equals(airportName) && airportName != null &&  //机场名称不为空
						!"".equals(serviceTypeName) && serviceTypeName != null &&//服务类型不为空
						!"".equals(serviceInfo) && serviceInfo != null){//服务详情不为空
					//将以下两个属性换下值，为了记录不符合条件的记录，如果能进入这个循环，则
					//证明，三个属性都不为空，再不符合条件的可能是，服务名称或机场机场名称不存在
					airportId = -1l;
					serviceType = "-1";
					AirportPO airport = airportService.findAirportByAirportName(airportName);
					if(airport != null){
						airportId = airport.getId();
					}
					//查询所有的服务类型
					List<ConstantPO>  constantPO = this.getConstantPOes(32l);
					//根据服务类型查找服务类型id
					for(ConstantPO po: constantPO){
						if(po.getValue().equals(serviceTypeName)){
							serviceType = po.getKey();
							break;
						}
					}
					//如果插入对象所需的信息齐全，则加入List,此要信息待插入
					if(airportId > 0 && !"".equals(airportName)
							&&!"-1".equals(serviceType) && !"-1".equals(serviceInfo)){
						vo.setAirportid(airportId);
						vo.setAirportname(airportName);
						vo.setServicetype(serviceType);
						vo.setServiceinfo(serviceInfo);
						airportServiceVOs.add(vo);
					}else{
						//记录不符合条件的记录
						buildUnqualifiedInfos(errorAirportServiceVOs, airportId, serviceType, airportName, serviceTypeName,
								serviceInfo,num);
					}
				}else{
					buildUnqualifiedInfos(errorAirportServiceVOs, airportId, serviceType, airportName, serviceTypeName, serviceInfo,num);
				}
	
			} catch (Exception e) {
				e.printStackTrace();
				buildUnqualifiedInfos(errorAirportServiceVOs, airportId, serviceType, airportName, serviceTypeName, serviceInfo, num);
				continue;
			}
		}
		return airportServiceVOs;
	}
	/**
	 * 记录不符合条件的导入记录,如：机场不存在，服务类型不存在，等
	 * @param errorData记录不符合条件的记录的容器
	 * @param airportId机场id,默认为0,将根据机场名称airportName从数据库取，
	 * @param serviceType服务类型编码，默认为"",根据服务名称serviceTypeName从数据库中取
	 * @param airportName机场名称
	 * @param serviceTypeName服务名称
	 * @param serviceInfo服务详情
	 */
	private void buildUnqualifiedInfos(List<AirportServiceVO> errorAirportServiceVOs, Long airportId, String serviceType,
			String airportName, String serviceTypeName, String serviceInfo, Integer num) {
		StringBuffer errors = new StringBuffer();
		AirportServiceVO airportServiceVO = new AirportServiceVO();
		//errors.append(airportName + " : " + serviceTypeName + "未导入!");
		errors.append("第"+num+"条未导入, "+"原因：");
		if("".equals(airportName)){
			errors.append("机场名称：" + " \"" +airportName + "\" "+ "为空值!");
		}
		if("".equals(serviceTypeName)){
			errors.append("服务名称：" + " \"" +serviceTypeName + "\" "+ "为空值!");
		}
		if("".equals(serviceInfo)){
			errors.append("服务详情：" + " \"" + serviceInfo+ "\" " + "为空值!");
		}
		if(airportId == -1){
			errors.append("机场名称：" + " \"" + airportName+ "\" " + "不存在!");
		}
		if("-1".equals(serviceType)){
			errors.append("服务名称：" + " \"" + serviceTypeName+ "\" " + "不存在!");
		}

		airportServiceVO.setAirportname(airportName);
		airportServiceVO.setServicetype(serviceTypeName);
		airportServiceVO.setServiceinfo(errors.toString());
		errorAirportServiceVOs.add(airportServiceVO);
	}
	/**
	 * 解析导入进来的excel文件，将文件解析成输入流(InputStream)格式，然后利用
	 * jxl.jar 进行解析并封装，jxl.jar 与poi.jar 各有利弊，jxl.jar 不用解析数据格式，因为传入的都为字符串格式
	 * @param is
	 * @return
	 */
	private List<Map<String, String>> parseXlsFileField(InputStream is) {
		Workbook book = null;
		List<String> fieldList = new ArrayList<String>();// 存入字段的集合，存放文本的第一行
		List<Map<String, String>> dataList = new ArrayList<Map<String, String>>();
		try {
			book = Workbook.getWorkbook(is);
			// 获得第一个工作表对象
			//Sheet sheet = book.getSheet(0);
			// 得到第一列第一行的单元格
			Sheet[] sheets = book.getSheets();
			//循环sheet
			for (int k = 0; k < sheets.length; k++) {
				int rows = sheets[k].getRows();
				int columns = sheets[k].getColumns();
				//对列进行判断，表头是三列，数据有可能是二列,第三列没数据
				columns = getRealColumnSize(columns, sheets[k]);
				//循环行
				for (int i = 0; i < rows; i++) {
					Map<String, String> map = new HashMap<String, String>();
					// 循环列
					for (int j = 0; j < columns; j++) {
						Cell cell = sheets[k].getCell(j, i);
						String content = cell.getContents();
						//得到表头，
						if (!fieldList.isEmpty() && fieldList.size() > 0 && fieldList.size() == columns) {
							List<String> valueList = new ArrayList<String>();
								valueList.add(content==null?" ":content);
								if (!fieldList.get(j).isEmpty())
									//放入将值放入map中，key: 第几列的表头，value:第几列第几行下的值.
									map.put(fieldList.get(j).trim(), valueList.get(0).trim());
						} else {
							if (content != null && !"".equals(content))
								fieldList.add(content.trim());
						}
						// System.out.print(content + "\t");
					}
					if(!map.isEmpty() && map.size() >0){
						dataList.add(map);
					}
				}

			}
			//System.out.println("dataList: " + dataList);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if(book != null){
				book.close();
			}
		}
		return dataList;
	}
	/**
	 * 得到真正的列数，比如有三个表头，有些行的第三列可能没有数据，
	 * @param columns
	 * @param sheet
	 * @return
	 */
	private int getRealColumnSize(int columns, Sheet sheet) {
		int i = 0;
		for (int j = 0; j < columns; j++) {
			Cell cell = sheet.getCell(j, 0);
			String content = cell.getContents();
			if (content != null && !"".equals(content)) {
				i++;
			}
		}
		return i;
	}
	public AirportPO findAirportByAirportName(String airportname) {
		// TODO Auto-generated method stub
		return airportService.findAirportByAirportName(airportname);
	}
}