package cn.itkt.btsf.phone.circum.po;



import java.io.Serializable;
import java.util.Date;


/**
 * 移动商旅_活动信息表 
 * @author codegen 2011-10-13 14:04:30 
 */
public class PhoneActivityPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
	/** ���  编号主键 �� **/ 
	private long id;
	
    /** �活动名称�� **/ 
	private String activityname;
	
    /** 名称图片Url **/ 
	private String nameimgurl;
	
    /** �活动URL **/ 
	private String activityurl;
	
    /** �活动开始时间��ʼʱ�� **/ 
	private Date starttime;
	
    /** �活动结束时间����ʱ�� **/ 
	private Date endtime;
	

	/**
	 * 构造 
	 */
	public PhoneActivityPO() {
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getActivityname() {
		return activityname;
	}

	public void setActivityname(String activityname) {
		this.activityname = activityname;
	}
	public String getNameimgurl() {
		return nameimgurl;
	}

	public void setNameimgurl(String nameimgurl) {
		this.nameimgurl = nameimgurl;
	}
	public String getActivityurl() {
		return activityurl;
	}

	public void setActivityurl(String activityurl) {
		this.activityurl = activityurl;
	}
	public Date getStarttime() {
		return starttime;
	}

	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}
	public Date getEndtime() {
		return endtime;
	}

	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}

}