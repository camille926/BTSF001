package cn.itkt.btsf.phone.circum.po;

import java.io.Serializable;


/**
 * 移动商旅_机场周边服务详情表 
 * @author codegen 2011-10-13 13:44:18 
 */
public class AirportServicePO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** 主键  编号 **/ 
	private long id;
	
    /** 机场ID **/ 
	private long airportid;
	
    /** 周边服务名称 **/ 
	private String servicetype;
	
    /** 服务详情 **/ 
	private String serviceinfo;
	
    /**
     * 机场名称
     */
    private String airportname;
	

	public String getServicetype() {
		return servicetype;
	}


	public void setServicetype(String servicetype) {
		this.servicetype = servicetype;
	}


	public String getAirportname() {
		return airportname;
	}


	public void setAirportname(String airportname) {
		this.airportname = airportname;
	}


	/**
	 * 构造 
	 */
	public AirportServicePO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public long getAirportid() {
		return airportid;
	}

	public void setAirportid(long airportid) {
		this.airportid = airportid;
	}
	
	public String getServiceinfo() {
		return serviceinfo;
	}

	public void setServiceinfo(String serviceinfo) {
		this.serviceinfo = serviceinfo;
	}


	

}