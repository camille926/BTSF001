package cn.itkt.btsf.phone.circum.po;

import java.io.Serializable;


/**
 * 移动商旅_机场周边服务表 
 * @author codegen 2011-10-13 15:16:51 
 */
public class CircumServicePO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** 编号 主键 **/ 
	private long id;
	
    /** 服务名称 **/ 
	private String servicename;
	

	/**
	 * 构造 
	 */
	public CircumServicePO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public String getServicename() {
		return servicename;
	}

	public void setServicename(String servicename) {
		this.servicename = servicename;
	}

}