package cn.itkt.btsf.phone.circum.service.impl;

import java.io.Serializable;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.circum.dao.AirportShuttleDao;
import cn.itkt.btsf.phone.circum.po.AirportShuttlePO;
import cn.itkt.btsf.phone.circum.service.AirportShuttleService;
import cn.itkt.exception.AppException;

@Service
public class AirportShuttleServiceImpl implements AirportShuttleService {

	private static final Logger log = LoggerFactory.getLogger(AirportShuttleServiceImpl.class);
	
	@Resource
	private  AirportShuttleDao  airportShuttleDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return AirportShuttle 
	 */
	public AirportShuttlePO find(Serializable id){
		return airportShuttleDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<AirportShuttlePO> 
	 */
	public List<AirportShuttlePO> findAll(){
		return airportShuttleDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public Long create(AirportShuttlePO po) throws AppException{
		Long id=airportShuttleDao.findId();
		try{
			if( po != null&&id>0 )
				po.setId(id);
				 airportShuttleDao.create(po);
				 return id;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(AirportShuttlePO po) throws AppException {
		try{
			if( po != null )
				 airportShuttleDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(Serializable id){
		 int flag=airportShuttleDao.delete(id);
		 if(flag!=0){
			 return true;
		 }else{
			 return false;
		 }
	}



}