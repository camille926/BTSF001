package cn.itkt.btsf.phone.circum.service.impl;



import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.circum.dao.PhoneActivityDao;
import cn.itkt.btsf.phone.circum.po.PhoneActivityPO;
import cn.itkt.btsf.phone.circum.service.PhoneActivityService;
import cn.itkt.btsf.phone.circum.vo.PhoneActivityVO;
import cn.itkt.exception.AppException;

@Service
public class PhoneActivityServiceImpl implements PhoneActivityService {

	private static final Logger log = LoggerFactory.getLogger(PhoneActivityServiceImpl.class);
	
	@Resource
	private  PhoneActivityDao  phoneActivityDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneActivity 
	 */
	public PhoneActivityPO find(Serializable id){
		return phoneActivityDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PhoneActivityPO> 
	 */
	public List<PhoneActivityPO> findAll(){
		return phoneActivityDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PhoneActivityPO po) throws AppException{
		try{
			if( po != null )
				 phoneActivityDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(PhoneActivityPO po) throws AppException {
		try{
			if( po != null )
				 phoneActivityDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 phoneActivityDao.delete(id);
	}

	@Override
	public List<PhoneActivityPO> findAllForPage(Map<Object, Object> map) {
		return phoneActivityDao.findAllForPage(map);
	}

	@Override
	public int countFindAllForPage(Map<Object, Object> map) {
		return phoneActivityDao.countFindAllForPage(map);
	}

	@Override
	public List<PhoneActivityVO> poListToVoList(List<PhoneActivityPO> poList) {
		List<PhoneActivityVO> voList = new ArrayList<PhoneActivityVO>();
		for (PhoneActivityPO po : poList) {
			voList.add(this.poToVo(po));
		}
		return voList;
	}

	@Override
	public PhoneActivityVO poToVo(PhoneActivityPO po) {
		PhoneActivityVO vo = new PhoneActivityVO();
		try {
			PropertyUtils.copyProperties(vo, po);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vo;
	}

	@Override
	public PhoneActivityPO voToPo(PhoneActivityVO vo) {
		PhoneActivityPO po = new PhoneActivityPO();
		try {
			PropertyUtils.copyProperties(po, vo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return po;
	}

	@Override
	public PhoneActivityPO findByName(String activityname) {
		return phoneActivityDao.findByName(activityname);
	}
	



}