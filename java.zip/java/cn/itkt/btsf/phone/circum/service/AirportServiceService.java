package cn.itkt.btsf.phone.circum.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.circum.po.AirportServicePO;
import cn.itkt.exception.AppException;

public interface AirportServiceService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return AirportService 
	 */
	public AirportServicePO find(Long id);

	/**
	 * 查找所有 
	 * @return List<AirportServicePO> 
	 */
	public List<AirportServicePO> findAll(Map<String,Object> map);

	/**
	 * 创建 
	 * @param po
	 */
	public boolean create(AirportServicePO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public boolean update(AirportServicePO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(String[] id)throws AppException;
	
	public int count(Map<String,Object> map);

	public AirportServicePO findByAirportIdAndServiceType(Map<String, Object> queryMap);

	public void updateByAirportIDAndServiceType(AirportServicePO po);


}