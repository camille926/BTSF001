package cn.itkt.btsf.phone.circum.service.impl;

import java.io.Serializable;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.circum.dao.CircumServiceDao;
import cn.itkt.btsf.phone.circum.po.CircumServicePO;
import cn.itkt.btsf.phone.circum.service.CircumServiceService;
import cn.itkt.exception.AppException;

@Service
public class CircumServiceServiceImpl implements CircumServiceService {

	private static final Logger log = LoggerFactory.getLogger(CircumServiceServiceImpl.class);
	
	@Resource
	private  CircumServiceDao  circumServiceDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return CircumService 
	 */
	public CircumServicePO find(Serializable id){
		return circumServiceDao.find(id);	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public Long create(CircumServicePO po) throws AppException{
		Long id=circumServiceDao.findId();
		try{
			if( po != null&&id>0)
				po.setId(id);
				circumServiceDao.create(po);
				return id;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(CircumServicePO po) throws AppException {
		try{
			if( po != null )
				 circumServiceDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 circumServiceDao.delete(id);
	}



}