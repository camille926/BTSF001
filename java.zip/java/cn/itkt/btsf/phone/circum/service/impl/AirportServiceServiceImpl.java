package cn.itkt.btsf.phone.circum.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.circum.dao.AirportServiceDao;
import cn.itkt.btsf.phone.circum.po.AirportServicePO;
import cn.itkt.btsf.phone.circum.service.AirportServiceService;
import cn.itkt.exception.AppException;

@Service
public class AirportServiceServiceImpl implements AirportServiceService {

	private static final Logger log = LoggerFactory.getLogger(AirportServiceServiceImpl.class);
	
	@Resource
	private  AirportServiceDao  airportServiceDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return AirportService 
	 */
	public AirportServicePO find(Long id){
		return airportServiceDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<AirportServicePO> 
	 */
	public List<AirportServicePO> findAll(Map<String,Object> map){
		return airportServiceDao.findAll(map);	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean create(AirportServicePO po) throws AppException{
		try{
			if( po != null )
				 airportServiceDao.create(po);
			return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean update(AirportServicePO po) throws AppException {
		try{
			if( po != null )
				 airportServiceDao.update(po);
			return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(String[] id)throws AppException{
		try{
		 airportServiceDao.delete(id);
		 return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}
	}

	@Override
	public int count(Map<String, Object> map) {		
		return airportServiceDao.count(map);
	}

	@Override
	public AirportServicePO findByAirportIdAndServiceType(Map<String, Object> queryMap) {
		return airportServiceDao.findByAirportIdAndServiceType(queryMap);
	}

	@Override
	public void updateByAirportIDAndServiceType(AirportServicePO po) {
		airportServiceDao.updateByAirportIDAndServiceType(po);
	}



}