package cn.itkt.btsf.phone.circum.service;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.circum.po.AirportShuttlePO;
import cn.itkt.exception.AppException;

public interface AirportShuttleService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return AirportShuttle 
	 */
	public AirportShuttlePO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<AirportShuttlePO> 
	 */
	public List<AirportShuttlePO> findAll();

	/**
	 * 创建 
	 * @param po
	 */
	public Long create(AirportShuttlePO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(AirportShuttlePO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public boolean delete(Serializable id);



}