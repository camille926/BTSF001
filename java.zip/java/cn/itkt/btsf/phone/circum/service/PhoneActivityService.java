package cn.itkt.btsf.phone.circum.service;



import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.circum.po.PhoneActivityPO;
import cn.itkt.btsf.phone.circum.vo.PhoneActivityVO;
import cn.itkt.exception.AppException;



public interface PhoneActivityService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneActivity 
	 */
	public PhoneActivityPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneActivityPO> 
	 */
	public List<PhoneActivityPO> findAll();
	
	/**
	 * 根据名称查询
	 * @param useType
	 * @return
	 */
	public PhoneActivityPO findByName(String activityname) throws AppException;
	
	/**
	 * 查找所有 --分页
	 * @return List<PhoneActivityPO> 
	 */
	public List<PhoneActivityPO> findAllForPage(Map<Object,Object> map);
	
	/**
	 * 取站内所有数据行
	 * @param po 
	 */
	public int countFindAllForPage(Map<Object,Object> map);

	/**
	 * 创建 
	 * @param po
	 */
	public void create(PhoneActivityPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneActivityPO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id)throws AppException;
	
	/**
	 * po与vo转换
	 * @param po
	 * @return vo
	 */
	PhoneActivityVO poToVo(PhoneActivityPO po);
	
	/**
	 * vo与po转换
	 * @param po
	 * @return vo
	 */
	PhoneActivityPO voToPo(PhoneActivityVO vo);
	
	
	/**
	 * po列表与vo列表转换
	 * @param poList
	 * @return voList
	 */
	List<PhoneActivityVO> poListToVoList(List<PhoneActivityPO> poList);



}