package cn.itkt.btsf.phone.circum.dao;

import java.io.Serializable;
import java.util.List;

import cn.itkt.btsf.phone.circum.po.AirportShuttlePO;

/**
 * 移动商旅_班车机场信息 
 * @author codegen 2011-10-12 21:05:05 
 */
public interface AirportShuttleDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return AirportShuttle 
	 */
	public AirportShuttlePO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<AirportShuttlePO> 
	 */
	public List<AirportShuttlePO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(AirportShuttlePO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(AirportShuttlePO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public int delete(Serializable id);
	
	public Long findId();

}