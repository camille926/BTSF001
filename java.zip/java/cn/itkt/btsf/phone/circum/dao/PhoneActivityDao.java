package cn.itkt.btsf.phone.circum.dao;



import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.circum.po.PhoneActivityPO;



/**
 * 移动商旅_活动信息表 
 * @author codegen 2011-10-13 14:04:30 
 */
public interface PhoneActivityDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneActivity 
	 */
	public PhoneActivityPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<PhoneActivityPO> 
	 */
	public List<PhoneActivityPO> findAll();
	
	/**
	 * 查找所有 --分页
	 * @return List<PhoneActivityPO> 
	 */
	public List<PhoneActivityPO> findAllForPage(Map<Object,Object> map);
	
	/**
	 * 取站内所有数据行
	 * @param po 
	 */
	public int countFindAllForPage(Map<Object,Object> map);
	
	
	/**
	 * 根据名称查询
	 * @param useType
	 * @return
	 */
	public PhoneActivityPO findByName(String activityname);
	
	
	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PhoneActivityPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(PhoneActivityPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);

}