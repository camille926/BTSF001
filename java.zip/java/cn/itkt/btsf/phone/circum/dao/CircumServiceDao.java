package cn.itkt.btsf.phone.circum.dao;

import java.io.Serializable;

import cn.itkt.btsf.phone.circum.po.CircumServicePO;

/**
 * 移动商旅_机场周边服务表 
 * @author codegen 2011-10-13 15:16:51 
 */
public interface CircumServiceDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return CircumService 
	 */
	public CircumServicePO find(Serializable id);

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(CircumServicePO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(CircumServicePO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	public Long findId();

}