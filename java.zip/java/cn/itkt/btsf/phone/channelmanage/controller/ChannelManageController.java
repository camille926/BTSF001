package cn.itkt.btsf.phone.channelmanage.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.itkt.btsf.phone.channelmanage.po.ChannelManagePO;

/**
 * 
 * @author wy
 *2012-8-17
 */

@Controller
@RequestMapping("/phone/channelmanage")
public class ChannelManageController {

	@Resource
	private  ChannelManageControllerSupport channelmanageSupport;

	
	/**
	 * 渠道管理
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value="/manage")
	public String chaneelProgress(ModelMap modelMap,String channelid,
			@RequestParam(value = "startIndex", defaultValue = "0") int startIndex){
		channelmanageSupport.chaneelSearch(modelMap,startIndex,channelid);
		modelMap.put("channelid", channelid==null?"":channelid.trim());
		return "phone/channelmanage/chaneelManage";
	}
	
	/**
	 * 更新
	 * @param modelMap
	 * @param 
	 * @return
	 */
	@RequestMapping(value="/update")
	public @ResponseBody String update(ModelMap modelMap,HttpServletRequest request){
		ChannelManagePO po = new ChannelManagePO();
		String id = request.getParameter("id");
		if(id!=null&&!"".equals(id)){
			po.setId(Integer.parseInt(id));
		}
		String channelname = request.getParameter("channelname");
		po.setChannelname(channelname);
		String channelremark = request.getParameter("channelremark").trim();
		po.setChannelremark(channelremark);
		String result = this.channelmanageSupport.updateOrInsert(modelMap,id,po);
		return result;
	}
	/**
	 * 跳转修改信息
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toUpdate")
	public String templatevUpdate(ModelMap modelMap,
			@RequestParam(value="Id" ,required=false, defaultValue="") String Id,String name){
		this.channelmanageSupport.findById(modelMap, Id,name);
		return "phone/channelmanage/channelEdit";
	}
	
}