package cn.itkt.btsf.phone.channelmanage.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.channelmanage.po.ChannelManagePO;
import cn.itkt.btsf.phone.channelmanage.service.ChannelManageService;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;
import cn.itkt.util.DateUtil;

@Service
public class ChannelManageControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(ChannelManageControllerSupport.class);
	
	@Resource
	private  ChannelManageService  ChannelManageService;
	
	
	/**
	 * 渠道管理
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @param page
	 * @param channelid 渠道ID
	 */
	public void chaneelSearch(ModelMap modelMap,int startIndex,String channelid){
		try {
			  Pages<HashMap<String, Object>> pages=new Pages<HashMap<String, Object>>(startIndex);
			  Map<String,Object> map=new HashMap<String,Object>();
			  map.put("startIndex", startIndex);
			  map.put("pageSize", 1000);
			  map.put("channelid", channelid!=null?channelid.trim():"");
			  List<HashMap<String, Object>> temList = ChannelManageService.chaneelSearchList(map);
			  pages.setItems(temList);
			  pages.setTotalCount(ChannelManageService.chaneelSearchListCount(map));
			  modelMap.addAttribute("page",pages);
			  modelMap.addAttribute("list","list");
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}		
	}
	
	/** 根据ID查询
	 * @param modelMap
	 * @param teamInfoId 班组ID
	 */
	public void findById(ModelMap modelMap,String id,String name){
		try {
			ChannelManagePO po=new ChannelManagePO();
			if(id!=null&&!"".equals(id))
			  po=this.ChannelManageService.find(id);
			else
			{
			  po.setChannelname(name);
			}
			modelMap.addAttribute("shuttle",po);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}
	
	/**
	 * 更新
	 * @param modelMap
	 * @param userVO 角色信息
	 */
	public String updateOrInsert(ModelMap modelMap,String id,ChannelManagePO PO){
		String result = "success";
		try {
			PO.setAddtime(new Date());//添加时间
			//if(id==null||"".equals(id)||PO.getId()==0){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("channelname", PO.getChannelname());
			int count = ChannelManageService.findByChannelId(map);
			if(count==0){
				this.ChannelManageService.create(PO);
			}else{
				this.ChannelManageService.update(PO);
			}
		} catch (AppException e) {
			result = "failed";
		}
		return result;

	}
	
	/**
	 * 删除
	 * @param modelMap
	 * @param teamInfoId 班组Id
	 */
	public void delete(ModelMap modelMap,String Id){
		try {
			this.ChannelManageService.delete(Id.split(","));
			modelMap.clear();
			modelMap.addAttribute("message", "删除成功");
			modelMap.addAttribute("status", true);
		} catch (Exception e) {
			log.error(e.getMessage());
			modelMap.addAttribute("message", "删除失败");
			modelMap.addAttribute("status", false);
		}
		
	}
	
}