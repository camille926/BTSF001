package cn.itkt.btsf.phone.channelmanage.po;

import java.io.Serializable;
import java.util.Date;


/**
 * 移动商旅_渠道 管理 
 * @author codegen 2012-04-13 21:05:41 
 */
public class ChannelManagePO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** 主键 **/ 
	private long id;
	/**渠道名称 **/
    private String channelname;
    /**渠道备注**/
    private String channelremark;
    /**添加时间**/
    private Date addtime;
    
	public ChannelManagePO() {
	}

	public ChannelManagePO(long id, String channelname, String channelremark) {
		this.id = id;
		this.channelname = channelname;
		this.channelremark = channelremark;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getChannelname() {
		return channelname;
	}
	public void setChannelname(String channelname) {
		this.channelname = channelname;
	}
	public String getChannelremark() {
		return channelremark;
	}
	public void setChannelremark(String channelremark) {
		this.channelremark = channelremark;
	}

	public Date getAddtime() {
		return addtime;
	}

	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}
    
   
    
}