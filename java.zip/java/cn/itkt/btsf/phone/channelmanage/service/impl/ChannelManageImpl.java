package cn.itkt.btsf.phone.channelmanage.service.impl;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.phone.channelmanage.dao.ChannelManageDao;
import cn.itkt.btsf.phone.channelmanage.po.ChannelManagePO;
import cn.itkt.btsf.phone.channelmanage.service.ChannelManageService;
import cn.itkt.btsf.phone.users.vo.PhoneUsersMailVO;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

@Service
public class ChannelManageImpl implements ChannelManageService {

	private static final Logger log = LoggerFactory.getLogger(ChannelManageImpl.class);
	
	@Resource
	private  ChannelManageDao  ChannelManageDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return ChannelManage 
	 */
	public ChannelManagePO find(Serializable id){
		return ChannelManageDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<ChannelManagePO> 
	 */
	public List<ChannelManagePO> findAll(){
		return ChannelManageDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(ChannelManagePO po) throws AppException{
		try{
			if( po != null )
				 ChannelManageDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(ChannelManagePO po) throws AppException {
		try{
			if( po != null )
				 ChannelManageDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}
	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 ChannelManageDao.delete(id);
	}
	@Override
	public List<HashMap<String, Object>> chaneelSearchList(Map<String,Object> map) {
		return ChannelManageDao.chaneelList(map);
	}

	@Override
	public int chaneelSearchListCount(Map<String, Object> map) {
		return ChannelManageDao.chaneelListCount(map);
	}
	
	public int findByChannelId(Map<String, Object> map){
		return ChannelManageDao.findByChannelId(map);
	}
}