package cn.itkt.btsf.phone.channelmanage.service;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.channelmanage.po.ChannelManagePO;
import cn.itkt.exception.AppException;


public interface ChannelManageService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return ChannelManage 
	 */
	public ChannelManagePO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<ChannelManagePO> 
	 */
	public List<ChannelManagePO> findAll();

	/**
	 * 创建 
	 * @param po
	 */
	public void create(ChannelManagePO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(ChannelManagePO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 渠道查询
	 * @param modelMap
	 * @param startDate
	 */
	public List<HashMap<String, Object>> chaneelSearchList(Map<String,Object> map);
	
	/**
	 * 渠道数量
	 * @param modelMap
	 * @param startDate
	 */
	public int chaneelSearchListCount(Map<String,Object> map);
	
	/**
	 * 查看是否存在该渠道号所指定的渠道记录
	 * @param map
	 * @return
	 */
	public int findByChannelId(Map<String, Object> map);
}