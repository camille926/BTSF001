package cn.itkt.btsf.phone.channelmanage.dao;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.channelmanage.po.ChannelManagePO;


/**
 * 渠道管理
 * @author wy
 *2012-8-17
 */
public interface ChannelManageDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return PhoneVisitcount 
	 */
	public ChannelManagePO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<ChannelManagePO> 
	 */
	public List<ChannelManagePO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(ChannelManagePO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(ChannelManagePO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	

		
	/**
	 * 渠道管理
	 * @param 
	 * @return
	 */
	public List<HashMap<String,Object>> chaneelList(Map<String,Object> map);
	
	
	/**
	 * 渠道管理count
	 * @param map
	 * @return
	 */
	public int chaneelListCount(Map<String,Object> map);
	/**
	 * 查看是否存在该渠道号所指定的渠道记录
	 * @param map
	 * @return
	 */
	public int findByChannelId(Map<String,Object> map);
}