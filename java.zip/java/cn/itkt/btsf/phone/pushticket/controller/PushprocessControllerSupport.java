package cn.itkt.btsf.phone.pushticket.controller;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestParam;

import cn.itkt.btsf.phone.pushticket.po.PushprocessPO;
import cn.itkt.btsf.phone.pushticket.po.PushprocessedPO;
import cn.itkt.btsf.phone.pushticket.service.FlightQueryLowHandle;
import cn.itkt.btsf.phone.pushticket.service.MakeTicketHandler;
import cn.itkt.btsf.phone.pushticket.service.PayLcdCoinHandler;
import cn.itkt.btsf.phone.pushticket.service.PushprocessService;
import cn.itkt.btsf.phone.pushticket.service.PushprocessedService;
import cn.itkt.btsf.phone.ticketrate.service.TicketRateService;
import cn.itkt.btsf.phone.users.po.PhoneCoinDetailsPO;
import cn.itkt.btsf.phone.users.po.PhoneCoinPO;
import cn.itkt.btsf.phone.users.service.PhoneCoinDetailsService;
import cn.itkt.btsf.phone.users.service.PhoneCoinService;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.sys.balance.service.ClearingMemberService;
import cn.itkt.btsf.sys.cc.national.dao.TicketInfoDao;
import cn.itkt.btsf.sys.cc.national.po.OrderInfoPO;
import cn.itkt.btsf.sys.cc.national.po.PsrInfoPO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.service.InsuranceInfoService;
import cn.itkt.btsf.sys.cc.national.service.OrderInfoService;
import cn.itkt.btsf.sys.cc.national.service.webservice.InsurancePurchaseHandler;
import cn.itkt.btsf.sys.cc.national.vo.FlightInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.InsuranceInfoVO;
import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;
import cn.itkt.btsf.sys.common.constant.WebServiceConstant;
import cn.itkt.btsf.sys.message.service.MessageContants;
import cn.itkt.btsf.sys.message.service.ReplaceTemplateService;
import cn.itkt.btsf.sys.message.vo.MessageSendingVO;
import cn.itkt.btsf.sys.terminal.po.AtmDetailPO;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.btsf.util.log.OrderLogUtil;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;
import cn.itkt.util.DateUtil;
import cn.itkt.util.SysUtil;

@Service
public class PushprocessControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(PushprocessControllerSupport.class);
	
	@Resource
	private  PushprocessService  pushprocessService;
	@Resource
	private PushprocessedService pushprocessedService;
	@Resource
	private OrderInfoService orderInfoService;
	@Resource
	private TicketInfoDao ticketInfoDao;
	@Resource
	private PhoneCoinService phoneCoinService;
	@Resource
	private PhoneCoinDetailsService phoneCoinDetailsService;
	@Resource
	private InsuranceInfoService insuranceInfoService;
	@Resource
	private TicketRateService ticketRateService;
	@Resource
	private ClearingMemberService clearingMemberService;
	@Resource
	private ReplaceTemplateService replaceTemplateService;
	@Resource
	private PhoneUsersService phoneUsersService;
	public void list(String processstatus,String ticktNo,String passengerName,String pushdate,String identityCardNo,String clearobjectName,int startIndex,ModelMap modelMap){
		Pages page=new Pages(startIndex);
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("page", page);
		map.put("processstatus", processstatus);
		map.put("ticktNo", ticktNo);
		map.put("passengerName", passengerName);
		map.put("pushdate", pushdate);
		map.put("identityCardNo", identityCardNo);
		map.put("clearobjectName", clearobjectName);
		List<Map> list=pushprocessService.findAll1(map);
		int count=pushprocessService.count1(map);
		page.setItems(list);
		page.setTotalCount(count);
		modelMap.put("page", page);
	}
	
	/**
	 * 低价推送处理操作
	 * 1.预定 2.出票 3.判断预定和出票是否失败 4.购保/订单关联/退票
	 * @param pushid
	 * @return resultstr 规则：000表示所以操作都成功,300表示网络异常
	 * 第一位表示出票状态（0成功，1失败，2预定失败）
	 * 第二位表示购保状态（0成功，1失败）
	 * 第三位表示退票状态（0成功，1失败）
	 */
	public Map<String,Object> createOrder(ModelMap modelMap,PushprocessPO pushprocessPO,Double rate,String totalAmount,String lcdCoin){
		Map<String,Object> resultmap = new HashMap<String,Object>();
		String resultstr = "0";
		String oldTicketNo="";  //旧票号
		String newTicketNo="";  //新票号
		String returnTicket = "";
		
		/*
		resultmap.put("flag", "020");
		resultmap.put("reqNo", "3333333");
		resultmap.put("oldTicketNo", "11111111");
		resultmap.put("newTicketNo", "2222222222222");
		return resultmap;
		*/
		
		PushprocessPO po=null;//低价推送处理信息
		String neworderId = "";//新订单id
		OrderInfoPO newOrderInfo = null;
		OrderInfoPO orderInfoPo = null;
		TicketInfoPO oldTicket = null;//原票信息
		TicketInfoPO newTicket = null;
		try {
			if(pushprocessPO.getPushid()>0){
				//获得低价推送处理信息
				po = pushprocessService.find(pushprocessPO.getPushid());
				oldTicketNo = po.getTicketno();  //旧票号赋值
				oldTicket = ticketInfoDao.getTicketInfoByTicketNo(po.getTicketno());//原票信息
				String state = oldTicket.getTicketstate();
				orderInfoPo = orderInfoService.find(po.getIphoneorderid());	//原订单信息
				if(("02".equals(state) || "2".equals(state))){
					
				
					//1.预定
					neworderId = pushprocessService.orderTicket(pushprocessPO);//订座成功返回订单ID
					
					if(!"".equals(neworderId)&&neworderId!=null){
					
						newOrderInfo = orderInfoService.find(neworderId);  //新订单信息
					
					 
					
						//2.出票(购票)
						boolean payTicket = makeTicket(newOrderInfo,orderInfoPo);  
						if(payTicket){//购票成功
							OrderLogUtil.log(Long.parseLong(neworderId), "自动降价生成订单，出票成功",LoginUtil.getLoginUser().getName());
							//查询新票信息
							Map<String, Object> param =  new HashMap<String, Object>();
							param.put("orderId", Long.valueOf(neworderId));
							List<TicketInfoPO> findTicketAndPassenger = ticketInfoDao.findTicketByOrderId(param);
						
							if(findTicketAndPassenger.size()>0){
								newTicket = findTicketAndPassenger.get(0);//新票信息
								newTicketNo = newTicket.getTicketNo();  //新票号赋值
							}
						
							//3.新票购保
							String isInsurance = payForInsurance(oldTicket,newTicket);
							if(isInsurance.equals("0")){
								resultstr= resultstr +"0";
							}else if(isInsurance.equals("1")){
								resultstr= resultstr +"1";
							}else{
								resultstr= resultstr +"2";
							}
						
							Map<String,Integer> rateMap=ticketRateService.getRefundRateByAirlinesAndSpace(oldTicket.getTicketNo());
							//5.退票
							//自动生成退票申请单
							String autoCreateRefundTicket = pushprocessedService.autoCreateRefundTicket(modelMap, po.getIphoneorderid(), po.getTicketno(), rate, (double)rateMap.get("fee"), totalAmount, newOrderInfo.getOrderNo());
							if(!"".equals(autoCreateRefundTicket)){
								resultstr= resultstr +"0";
								returnTicket = autoCreateRefundTicket;
							}else{
								resultstr= resultstr +"1";
							}
							//为新票生成支付流水
							boolean bl =payForTicket(neworderId,newTicket.getPayableAmount(),orderInfoPo.getClearobjectId());
							//返还畅达币的操作
							updateCoin(orderInfoPo,lcdCoin);
							//畅达币明细
							updateCoinDetails(orderInfoPo,newTicket,oldTicket,lcdCoin,totalAmount);
							//发送自动降价短信
							sengMessageToPhoneUser(oldTicket,lcdCoin,orderInfoPo.getClearobjectId());
							try {
								//更新处理表的接收状态为接受
								Map<String,Object> map=new HashMap<String,Object>();
								map.put("pushid", po.getPushid());
								map.put("status", "1");
								map.put("processstatus", "1");
								boolean sign=pushprocessService.update(map);
								//根据id查询处理表，把信息保存到处理结果表
								PushprocessedPO ped=new PushprocessedPO();
								if(po!=null && sign){
									ped.setPushid(po.getPushid());
									ped.setTicketno(po.getTicketno());
									ped.setProcessdate(new Date());
									ped.setProcessperson(LoginUtil.getLoginUser().getName());
									ped.setProcessstatus("1");	
									ped.setRemark("");	
									ped.setNewticketno(newTicket.getTicketNo());
									ped.setOrderNo(orderInfoPo.getOrderNo());
									ped.setNewOrderNo(newOrderInfo.getOrderNo());
									ped.setReqNo(autoCreateRefundTicket);
									ped.setCoin(lcdCoin);
									pushprocessedService.create(ped);
								}
							} catch (Exception e) {
								//更新数据库数据异常
								resultstr="400";
							}
						}else{//出票失败
							resultstr="100";
						}
					}else{//预定失败
						resultstr="200";
					}
				}else{
					resultstr="500"; 
				}
			}
				
		} catch (Exception e) {
			e.printStackTrace();
			resultstr="300";
			
		}finally{
			resultmap.put("flag", resultstr);
			resultmap.put("reqNo", returnTicket);
			resultmap.put("oldTicketNo", oldTicketNo);
			resultmap.put("newTicketNo", newTicketNo);
			resultmap.put("oldOrderId", orderInfoPo.getId());
		}
		return resultmap;
	}
	/**
	 * 发送自动降价短信
	 * @param oldTicket
	 * @param lcdCoin
	 * @param userId
	 */
	private void sengMessageToPhoneUser(TicketInfoPO oldTicket,String lcdCoin,Long userId) {
		//拼接短信
		StringBuffer msgContent=new StringBuffer();
		msgContent.append("【掌上航旅】您好！您在");
		//自动降价办理日期
		msgContent.append(DateUtil.transferDateToString(new Date(), "MM月dd日"));
		msgContent.append("办理了");
		//起飞日期
		msgContent.append(DateUtil.transferDateToString(oldTicket.getTakeofftime(), "MM月dd日"));
		msgContent.append("起飞的");
		//出发地
		msgContent.append(oldTicket.getTakeofflocusname());
		msgContent.append("--");
		//到达地
		msgContent.append(oldTicket.getArrivelocusname());
		//航班号
		msgContent.append(oldTicket.getAirteamnum());
		msgContent.append("航班，乘机人");
		//乘机人
		msgContent.append(oldTicket.getPassengerName());
		msgContent.append("的自动降价服务，获得畅达币");
		//获得畅达币数量
		msgContent.append(lcdCoin);
		msgContent.append("个已到达您的会员账户，了解详情请登录客户端或网站我的航旅中查看。");
		//msgContent.
		MessageSendingVO  msgSendingVO = new MessageSendingVO();
		msgSendingVO.setCommport("/dev/ttyS0");//端口
		msgSendingVO.setState("0");//状态
		msgSendingVO.setContent(msgContent.toString());//内容
		msgSendingVO.setSmstype(MessageContants.SMS_PUSH_TICKET);
		msgSendingVO.setSendlevel(0);
		//发送人手机设置为登录用户的手机号
		msgSendingVO.setSender("隆畅达");
		//接收人手机号设置为乘机人手机号
		msgSendingVO.setReceiver(phoneUsersService.find(userId).getTelephone());
		replaceTemplateService.ReplaceTemplateContent(null, msgContent.toString(), "1", msgSendingVO);
		
	}
	/**
	 * 生成畅达币明细
	 * @return
	 */
	public boolean updateCoinDetails(OrderInfoPO orderInfoPo,TicketInfoPO newTicket,TicketInfoPO oldTicket,String lcdCoin,String totalAmount){
		try {
//			//退剩余的畅达币给客户
			PhoneCoinPO findByUserId = phoneCoinService.findByUserId(String.valueOf(orderInfoPo.getClearobjectId()));//该用户的畅达币信息
//			findByUserId.setLcdcoin(Integer.parseInt(findByUserId.getLcdcoin())+Integer.parseInt(lcdCoin)+"");//可用畅达币(原畅达币数量+返的畅达币数量)
//			findByUserId.setAlllcdcoin(SysUtil.changeDecimal(Double.parseDouble(findByUserId.getAlllcdcoin()))+Integer.valueOf(lcdCoin)+"");//累积畅达币(原畅达币数量+返的畅达币数量)
//			phoneCoinService.update(findByUserId);//更新畅达币信息
//			
			//记录退票畅达币交易明细
			PhoneCoinDetailsPO phoneCoinDetailsPO = new PhoneCoinDetailsPO();
			phoneCoinDetailsPO.setCoinaccountid(findByUserId.getId());
			phoneCoinDetailsPO.setPaycoin(0);
			phoneCoinDetailsPO.setReceiptscoin(Integer.parseInt(totalAmount));
			phoneCoinDetailsPO.setExchangetype("19");
			phoneCoinDetailsPO.setExchangetime(new Date());
			phoneCoinDetailsPO.setTicketId(oldTicket.getId());
			phoneCoinDetailsService.create(phoneCoinDetailsPO);
			//记录购票畅达币交易明细
			phoneCoinDetailsPO.setCoinaccountid(findByUserId.getId());
			phoneCoinDetailsPO.setPaycoin(Integer.parseInt(totalAmount)-Integer.parseInt(lcdCoin));
			phoneCoinDetailsPO.setReceiptscoin(0);
			phoneCoinDetailsPO.setExchangetype("20");
			phoneCoinDetailsPO.setExchangetime(new Date());
			phoneCoinDetailsPO.setTicketId(newTicket.getId());
			phoneCoinDetailsPO.setOrderId(newTicket.getOrderId());
			phoneCoinDetailsService.create(phoneCoinDetailsPO);
			//记录自动降价畅达币明细
			//PhoneCoinDetailsPO phoneCoinDetailsPO = new PhoneCoinDetailsPO();
			phoneCoinDetailsPO.setCoinaccountid(findByUserId.getId());
			phoneCoinDetailsPO.setPaycoin(0);
			phoneCoinDetailsPO.setReceiptscoin(Integer.parseInt(lcdCoin));
			phoneCoinDetailsPO.setExchangetype("01");
			phoneCoinDetailsPO.setExchangetime(new Date());
			phoneCoinDetailsPO.setTicketId(oldTicket.getId());
			phoneCoinDetailsService.create(phoneCoinDetailsPO);
		} catch (Exception e) {
			return false;
		}
		return true;
	}
	/**
	 * 更新畅达币（将自动降价获取的畅达币返还给客户）
	 * @param orderInfoPo
	 * @param lcdCoin
	 * @return
	 */
	public boolean updateCoin(OrderInfoPO orderInfoPo,String lcdCoin){
		try {
			PhoneCoinPO findByUserId = phoneCoinService.findByUserId(String.valueOf(orderInfoPo.getClearobjectId()));//该用户的畅达币信息
			findByUserId.setLcdcoin(Integer.parseInt(findByUserId.getLcdcoin())+Integer.parseInt(lcdCoin)+"");//可用畅达币(原畅达币数量+返的畅达币数量)
			findByUserId.setAlllcdcoin(SysUtil.changeDecimal(Double.parseDouble(findByUserId.getAlllcdcoin()))+Integer.valueOf(lcdCoin)+"");//累积畅达币(原畅达币数量+返的畅达币数量)
			phoneCoinService.update(findByUserId);//更新畅达币信息
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	/**
	 * 购票操作
	 * @return
	 */
	public boolean makeTicket(OrderInfoPO newOrderInfo,OrderInfoPO orderInfoPo){
		//调用接口订票
		boolean payTicket = false;
		try {
			String neworderId = newOrderInfo.getId().toString();
			AbstractWebserviceInvoker payLcdCoinHandler = new MakeTicketHandler();
			//String terminalId="callcenter;callcenter:"+(cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
			//String terminalId=orderInfoPo.getTerminalNo()+";"+orderInfoPo.getTerminalNo()+":"+(cn.itkt.util.MD5Util.getMD5Message(orderInfoPo.getTerminalNo()+";"+orderInfoPo.getTerminalNo()+orderInfoPo.getTerminalNo())).toUpperCase();
			AtmDetailPO atmDetail=pushprocessService.getAtmDetail(orderInfoPo.getTerminalId());
			String terminalId=atmDetail.getAtmNo();
			//boolean payTicket = (Boolean)payLcdCoinHandler.invoke(WebServiceConstant.getEndPoint(), "issueTicketiphone", WebServiceConstant.getQname(),new Object[] {terminalId,neworderId,"","","","0","","","","000000",DateUtil.transferDateToString(new Date(),"yyyy-MM-dd HH:mm:ss"),newOrderInfo.getAmountPayable().toString(),String.valueOf(orderInfoPo.getClearobjectId()),"3DES",""});
			//String url ="http://192.168.3.20:8088/stsf/services/TICKETSERVICE?WSDL";
			payTicket = (Boolean)payLcdCoinHandler.invoke(WebServiceConstant.getEndPoint(), "issueTicketForTicketPush", WebServiceConstant.getQname(),new Object[] {terminalId,neworderId,"","","","0","","","","000000",DateUtil.transferDateToString(new Date(),"yyyy-MM-dd HH:mm:ss"),newOrderInfo.getAmountPayable().toString(),String.valueOf(orderInfoPo.getClearobjectId()),"3DES",""});
			if(payTicket){
				pushprocessService.updateOrderAndTicketTerminal(newOrderInfo.getId(), orderInfoPo.getTerminalId());
			}
		} catch (Exception e) {
			return false;
		}
		return payTicket;
	}
	
	/**
	 * 支付获取流水信息
	 * @return
	 */
	public boolean payForTicket(String orderID,double payCoin, Long userID){
		boolean payTicket = false;
		try {
			AbstractWebserviceInvoker payLcdCoinHandler = new PayLcdCoinHandler();
			//String url ="http://192.168.3.20:8088/stsf/services/TICKETSERVICE?WSDL";
			//参数：订单号，使用畅达币数量，掌上航旅会员id
			payTicket = (Boolean)payLcdCoinHandler.invoke(WebServiceConstant.getEndPoint(), "addPayJournalForTicketPush", WebServiceConstant.getQname(),new Object[] {String.valueOf(orderID),String.valueOf(payCoin),String.valueOf(userID),"COIN"});
		} catch (Exception e) {
			return false;
		}
		return payTicket;
	}
	
	/**
	 * 购保
	 * 判断原票是否购买保险金，
	 * 如果原票购买，则对新票也购买保险金
	 * @return
	 */
	public String  payForInsurance(TicketInfoPO oldTicket,TicketInfoPO newTicket){
		try {
			Double oldInPrice = 0.0;//原票保险金额
			//判断原票是否有保单
			List<InsuranceInfoVO> findInsByTicketNo = insuranceInfoService.findInsByTicketId(oldTicket.getId());
			if(findInsByTicketNo.size()>0){
				oldInPrice = findInsByTicketNo.get(0).getPrice();//原票保险金额
			}
			//判断新票是否已经购保，如果已经购保，则不再重复购保，返回购保成功
			List<InsuranceInfoVO> newInsInfo = insuranceInfoService.findInsByTicketId(newTicket.getId());
			if(newInsInfo.size()>0){
				return "0";
			}
			
			//为新票买保险
			if(oldInPrice >0){
				String[] insuranceArray = {newTicket.getTicketNo()+";1"};
				AbstractWebserviceInvoker invoker = new InsurancePurchaseHandler();
				String wsReturnVal = (String)invoker.invoke(WebServiceConstant.getInsuranceEndpoint(), "addTicketInsure", WebServiceConstant.getQname(), insuranceArray);
				if(wsReturnVal.equals("success")){
					return "0";
				}else{
					return "1";
				}
			}
			return "2";
		} catch (Exception e) {
			return "1";
		}
	}

	public void getProcessedResult(String pushid,ModelMap modelMap){
		if(pushid!=null && !"".equals(pushid)){
			PushprocessedPO result=pushprocessedService.find(pushid);
			modelMap.addAttribute("result",result);
		}
	}
	
	/**
	 * 获取推送票的最低舱位信息
	 * @param modelMap
	 * @param pushid
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public void getPushInfo(ModelMap modelMap,@RequestParam(value="pushid", required=false)Long pushid){
		PushprocessPO pushprocessPO = null;//低价推送信息
		TicketInfoPO ticketInfopo = null;//最低票价航班信息
		TicketInfoPO ticketInfoByTicketNo = null;//原票信息
		Double fee = 0.0;//手续费
		Double totalAmount = 0.0;//实际退款金额
		String refundLcdCoin = "";//可获得的畅达币数量
		
		try {
			//获取低价推送信息
			pushprocessPO = pushprocessService.find(pushid);
			
			//获取低价推送时的客票退改签规定
			String newRule = getRules(pushprocessPO);
			
			//原票信息
			ticketInfoByTicketNo = ticketInfoDao.getTicketInfoByTicketNo(pushprocessPO.getTicketno());
			//获取保险
			Map temp = new HashMap();
			temp.put("ticketNo", ticketInfoByTicketNo.getTicketNo());
			Map mm = clearingMemberService.getInsuranceInfoByOrderCcextId(temp);
			if(mm.get("INSURANCEAMOUNT") == null || "".equals(mm.get("INSURANCENUM")) ) {
				ticketInfoByTicketNo.setInsuranceAmount(0d);
			}else {
				ticketInfoByTicketNo.setInsuranceAmount(20d);
			}
			//获取原票的退票费率和退票费
			Map<String, Integer> refundRateByAirlinesAndSpace = ticketRateService.getRefundRateByAirlinesAndSpace(pushprocessPO.getTicketno());
			int oldfee = refundRateByAirlinesAndSpace.get("fee");  //原退票费
			int oldrate = refundRateByAirlinesAndSpace.get("rate"); //原退票费率
			modelMap.addAttribute("oldfee", oldfee);
			modelMap.addAttribute("oldrate", oldrate);
			
			
			//调用接口获取该航班在此刻的最低航班舱位信息
			AbstractWebserviceInvoker invoker = new FlightQueryLowHandle();
			ticketInfopo = (TicketInfoPO)invoker.invoke(WebServiceConstant.getEndPoint(), "getBestSegsInfos", WebServiceConstant.getQname(),new Object[] {pushprocessPO.getTicketno()});
			ticketInfopo.setAtmId(ticketInfoByTicketNo.getAtmId());
			refundRateByAirlinesAndSpace = ticketRateService.getRefundRate(ticketInfopo);
			int rate = refundRateByAirlinesAndSpace.get("rate");
			int newfee =  refundRateByAirlinesAndSpace.get("fee");
			modelMap.addAttribute("newfee", newfee);
			modelMap.addAttribute("newrate", rate);
			int newtotalAmount =(int) Double.parseDouble(pushprocessPO.getPushprice())+(int) Double.parseDouble(pushprocessPO.getFueltax())+(int) Double.parseDouble(pushprocessPO.getAirporttax())+(int)ticketInfoByTicketNo.getInsuranceAmount()-newfee;
			modelMap.addAttribute("newtotalAmount", newtotalAmount);
			
			if(ticketInfopo != null){
				if("-1".equals(ticketInfopo.getTicketlevel())){
					//如果没有找到退票费率则不予退票
					modelMap.addAttribute("flag", "0");
					return;
				}
				//fee = ticketInfoByTicketNo.getTicketPrice()*Integer.parseInt(ticketInfopo.getTicketlevel()) * 0.01;//应扣手续费
				//实际退款金额 = 票总价+保险金额  - 手续费
				totalAmount = ticketInfoByTicketNo.getTicketTotalAmount()+ticketInfoByTicketNo.getInsuranceAmount() - oldfee;
				
				//可获得的畅达币数量 = 原票票面价 - 手续费 - 新票票面价
				//refundLcdCoin = String.valueOf(ticketInfoByTicketNo.getTicketPrice() +ticketInfoByTicketNo.getFueltax()+ticketInfoByTicketNo.getDrometax()- oldfee - ticketInfopo.getTicketPrice()-ticketInfopo.getFueltax()-ticketInfopo.getDrometax());
				refundLcdCoin = String.valueOf(ticketInfoByTicketNo.getTicketPrice() - oldfee - ticketInfopo.getTicketPrice());
				DecimalFormat df = new DecimalFormat("#");
				refundLcdCoin = String.valueOf(df.parse(refundLcdCoin));
				
				pushprocessPO.setLcdcoin(SysUtil.changeDecimal(Double.valueOf(refundLcdCoin))+"");
				modelMap.addAttribute("fee", SysUtil.changeDecimal(fee));//手续费
				modelMap.addAttribute("totalAmount", SysUtil.changeDecimal(totalAmount));//实际退款金额
				
				modelMap.addAttribute("flightInfo", ticketInfopo);//新航班信息
				modelMap.addAttribute("pushprocessPO", pushprocessPO);//推送信息
			}
			modelMap.addAttribute("ticketInfo", ticketInfoByTicketNo);//原票信息
			modelMap.addAttribute("pushid", pushid);
			modelMap.addAttribute("newRule", newRule);
		} catch (Exception e) {
			modelMap.addAttribute("flag", "-1");
			System.out.println(e.getMessage());
		}
		
	}
	
	private String getRules(PushprocessPO pushprocessPO){
		Map<String,Object> map = new HashMap<String ,Object>(); 
		map.put("startTime", pushprocessPO.getDeparturedate().substring(0, 10));
		map.put("airLine", pushprocessPO.getAirline());
		map.put("baseCabin", pushprocessPO.getBasecabin());
		List<String> rules= pushprocessService.getRules(map);
		if(rules==null){
			return "";
		}
		if(rules.size()>0){
			return rules.get(0);
		}else{
			return "";
		}
	}
	
	/**
	 * 判断是否有符合自动降价的条件
	 * 1.客票状态已改变
	 * 2.无降价折扣
	 * 3.退改签政策变动（不够100畅达币）
	 * 返回值resultstr =0表示可以低价推送
	 * =1表示客票状态已改变
	 * =2表示无降价折扣
	 * =3退改签政策变动（不够100畅达币）
	 * @return
	 * @throws ParseException 
	 */
	public String checkTicket(String ticketNo,String pushId){
		String resultstr = "0";
		try {
			//1.判断客票状态是否已改变
			Map map = new HashMap();
			map.put("ticketNo", ticketNo);
			
			TicketInfoPO ticket = pushprocessService.getTicket(map);
			//String flag = ticket.getTicketRealState();  //客票状态为open for use 
			String state = ticket.getTicketstate();
			if(("02".equals(state) || "2".equals(state))){
				//客票状态未改变
				resultstr =  "0";
			}else{
				resultstr = "1";
				return resultstr;
			}
			
			//2.判断是否仍有本自动降价当前折扣，只做当前折扣筛查
			//2.1.调用接口获取该航班在此刻的最低航班舱位信息
			AbstractWebserviceInvoker invoker = new FlightQueryLowHandle();
			TicketInfoPO ticketInfopo = (TicketInfoPO)invoker.invoke(WebServiceConstant.getEndPoint(), "getBestSegsInfos", WebServiceConstant.getQname(),new Object[] {ticketNo});
			
			if(ticketInfopo == null){
				resultstr = "2";
				return resultstr;
			}else{
				if("-1".equals(ticketInfopo.getTicketlevel())){
					//如果没有找到退票费率则不予退票
					resultstr = "2";
					return resultstr;
				}
				
				Double newPrice = ticketInfopo.getTicketPrice();
				
				//2.2.根据pushId获取数据库中低价推送的退票费
				PushprocessPO pushprocessPO = pushprocessService.find(Long.parseLong(pushId));
				Double oldPrice = Double.parseDouble(pushprocessPO.getPushprice());
				if(!newPrice.equals(oldPrice)){
					resultstr = "2";
					return resultstr;
				}
				
				Double fee = 0.0;//手续费
				Double refundLcdCoin = 0.0;//可获得的畅达币数量
				fee = ticket.getTicketPrice()*Integer.parseInt(ticketInfopo.getTicketlevel()) * 0.01;//应扣手续费
				
				//可获得的畅达币数量 = 原票票面价 - 手续费 - 新票推送票面价
				refundLcdCoin = ticket.getTicketPrice() - fee - ticketInfopo.getTicketPrice();
				if(refundLcdCoin<100){
					resultstr = "3";
				}
				
				if(((int)ticket.getDrometax())!=(int)(ticketInfopo.getFueltax())||(int)(ticket.getFueltax())!=(int)(ticketInfopo.getDrometax())){
					resultstr = "2";
					return resultstr;
				}
			}
		} catch (Exception e) {
			//System.out.println(e.getMessage());
			resultstr = "-1";
		}
		return resultstr;
	}
	
	/**
	 * flag=0表示可以继续自动降价（未接受，已处理，还可以进行自动降价）
	 * flag=1表示取消（未接受，已处理，不进行自动降价）
	 * flag=2表示未接受（未接受，已处理，不进行自动降价）
	 * @param pushId
	 * @param ticktNo
	 * @param flag
	 * @return
	 */
	public String dealTicket(String pushId,String ticketNo,String flag){
		String resultstr = "0";
		try {
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("pushid", pushId);
			map.put("ticketNo", ticketNo);
			
			PushprocessPO pushprocessPO = pushprocessService.find(Long.parseLong(pushId));
			if("0".equals(flag)){ 
				map.put("processstatus", "1");  //已处理
				map.put("status", "1");         //已接受
				//map.put("serverstatus", "1");   //不做低价推送
				pushprocessService.update(map);
				//pushprocessService.updatePushTicketNo(map);
				createPushprocessedPO(pushprocessPO);
			}
			if("1".equals(flag)){
				map.put("processstatus", "1");  //已处理
				map.put("status", "1");         //已接受
				map.put("serverstatus", "1");   //不做低价推送
				pushprocessService.update(map);
				pushprocessService.updatePushTicketNo(map);
				createPushprocessedPO(pushprocessPO);
			}
			if("2".equals(flag)){ 
				map.put("processstatus", "1");  //已处理
				map.put("status", "0");         //未接受
				map.put("serverstatus", "1");   //不做低价推送
				pushprocessService.update(map);
				pushprocessService.updatePushTicketNo(map);
				createPushprocessedPO(pushprocessPO);
			}
		} catch (Exception e) {
			resultstr = "1";
			System.out.println(e.getMessage());
			return resultstr;
		}
		return resultstr;
	}
	
	private boolean createPushprocessedPO(PushprocessPO pushprocessPO){
		PushprocessedPO po = new PushprocessedPO();
		po.setPushid(pushprocessPO.getPushid());
		po.setTicketno(pushprocessPO.getTicketno());
		po.setProcessperson(LoginUtil.getLoginUser().getUsername());
		po.setProcessdate(new Date());
		po.setProcessstatus("0");
		po.setRemark("");
		po.setNewticketno("");
		po.setCoin(pushprocessPO.getLcdcoin());
		po.setOrderNo(pushprocessPO.getOrderno());
		po.setNewOrderNo("");
		po.setReqNo("");
		return pushprocessedService.create(po);
	}
	
	public FlightInfoVO getTicketInfo(String ticketNo){
		FlightInfoVO flightInfoVO = new FlightInfoVO();
		TicketInfoPO po = ticketInfoDao.getTicketInfoByTicketNo(ticketNo);
		flightInfoVO.setTakeOffAirportName(po.getTakeofflocusname());
		flightInfoVO.setMidAirportName("");
		flightInfoVO.setArriveAirportName(po.getArrivelocusname());
		flightInfoVO.setTerminalNo("callcenter");
		Date dd = po.getTakeofftime();
		
		flightInfoVO.setTakeofftime(new SimpleDateFormat("yyyy-MM-dd hh24:mm:ss").format(dd));
		flightInfoVO.setRebacktime(po.getTakeofflocusname2());
		flightInfoVO.setMidTakeofftime("");
		flightInfoVO.setFlightType(po.getFlightType());
		flightInfoVO.setAirlinesCode(po.getAirways());
		flightInfoVO.setGoOrReturn("1");
		flightInfoVO.setIsCodeShare("0");
		return flightInfoVO;
	}
	
	
}