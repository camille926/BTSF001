package cn.itkt.btsf.phone.pushticket.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.itkt.btsf.phone.pushticket.po.PushprocessPO;
import cn.itkt.btsf.sys.baseinfo.po.AirlinesPO;
import cn.itkt.btsf.sys.baseinfo.service.AirlinesService;
import cn.itkt.btsf.sys.cc.national.controller.FlightsQueryControllerSupport;
import cn.itkt.btsf.sys.cc.national.vo.FlightInfoVO;
import cn.itkt.util.DateUtil;


@Controller
@RequestMapping("/phone/pushticket/pushprocess")
public class PushprocessController {

	@Resource
	private  PushprocessControllerSupport  pushprocessControllerSupport;
	
	@Resource
	private AirlinesService airlinesService;
	
	@RequestMapping()
	public String list(@RequestParam(value="processstatus", required=false,defaultValue="0")String processstatus,
			@RequestParam(value="ticktNo", required=false) String ticktNo,
			@RequestParam(value="passengerName", required=false) String passengerName,
			@RequestParam(value="pushdateStr", required=false) String pushdateStr,
			@RequestParam(value="identityCardNo", required=false) String identityCardNo,
			@RequestParam(value="clearobjectName", required=false) String clearobjectName,
			@RequestParam(value="startIndex", required=false, defaultValue="0")int startIndex,ModelMap modelMap){
		String pushdate=null;
		if(processstatus!=null&&!"".equals(processstatus)){
			processstatus = processstatus.trim();
			modelMap.addAttribute("processstatus", processstatus);
		}
		if(ticktNo!=null&&!"".equals(ticktNo)){
			ticktNo = ticktNo.trim();
			ticktNo = ticktNo.replace("-", "");
			ticktNo = ticktNo.replace(" ", "");
			ticktNo = ticktNo.replace("\t", "");
			modelMap.addAttribute("ticktNo", ticktNo);
		}
		if(passengerName!=null&&!"".equals(passengerName)){
			passengerName = passengerName.trim();
			modelMap.addAttribute("passengerName", passengerName);
		}
		if(pushdateStr!=null&&!"".equals(pushdateStr)){
			pushdateStr=pushdateStr.trim();
			modelMap.addAttribute("pushdateStr", pushdateStr);
			//pushdate=DateUtil.transferStringToDate(pushdateStr);
		}
		if(identityCardNo != null && !"".equals(identityCardNo)){
			identityCardNo = identityCardNo.trim();
			modelMap.addAttribute("identityCardNo", identityCardNo);
		}
		if(clearobjectName != null && !"".equals(clearobjectName)){
			clearobjectName = clearobjectName.trim();
			modelMap.addAttribute("clearobjectName", clearobjectName);
		}
		pushprocessControllerSupport.list(processstatus, ticktNo,passengerName,pushdateStr,identityCardNo,clearobjectName,startIndex, modelMap);
		return "phone/pushticket/list";
	}


	/**
	 * 显示低价推送处理结果
	 * @param pushid
	 * @param modelMap
	 * @return
	 */
	@RequestMapping("/result")
	public String getProcessedResult(@RequestParam(value="pushid", required=false)String pushid,ModelMap modelMap){
		pushprocessControllerSupport.getProcessedResult(pushid, modelMap);
		return "phone/pushticket/results";
	}
	
	/**
	 * 获取推送票的最低舱位信息
	 * @param modelMap
	 * @param pushid
	 * @return
	 */
	@RequestMapping("/getPushInfo")
	public String getPushInfo(ModelMap modelMap,@RequestParam(value="pushid", required=false)Long pushid){
		pushprocessControllerSupport.getPushInfo(modelMap,pushid);
		return "phone/pushticket/createOrder";
	}
	
	/**
	 * 判断是否有符合自动降价的条件
	 * 1.客票状态已改变
	 * 2.无降价折扣
	 * 3.退改签政策变动（不够100畅达币）
	 * @return
	 */
	@RequestMapping("/checkTicket")
	public @ResponseBody String checkTicket(@RequestParam(value="ticktNo", required=false) String ticktNo,
			@RequestParam(value="pushId", required=false) String pushId){
		return pushprocessControllerSupport.checkTicket(ticktNo,pushId);
	}
	
	/**
	 * 处理自动降价
	 * @return
	 */
	@RequestMapping("/dealTicket")
	public @ResponseBody String dealTicket(@RequestParam(value="pushId", required=false) String pushId,
			@RequestParam(value="ticktNo", required=false) String ticktNo,
			@RequestParam(value="flag", required=false) String flag){
		
		return pushprocessControllerSupport.dealTicket(pushId,ticktNo,flag);
	}
	
	/**
	 * 查询航班
	 * @return
	 */
	@RequestMapping("/doquery")
	public String doquery(@RequestParam(value="pushId", required=false) String pushId,
			@RequestParam(value="ticketNo", required=false) String ticketNo,ModelMap modelMap){
		List<AirlinesPO> airlinesList = airlinesService.findAll();
		modelMap.addAttribute("airlinesList",airlinesList);
		FlightInfoVO flightInfoVO = pushprocessControllerSupport.getTicketInfo(ticketNo);
		modelMap.addAttribute("flightInfoVO", flightInfoVO);
		return "phone/pushticket/doqueryFlight";
	}
	
	/**
	 * 生成订单操作
	 * @param modelMap
	 * @param pushprocessPO
	 * @param rate
	 * @param totalAmount
	 * @param lcdcoin
	 * @return
	 */
	@RequestMapping("/createOrder")
	public @ResponseBody Map createOrder(ModelMap modelMap,PushprocessPO pushprocessPO,Double rate,String totalAmount,String lcdCoin){
		
		return pushprocessControllerSupport.createOrder(modelMap, pushprocessPO, rate, totalAmount, lcdCoin);
	}
	
	
}