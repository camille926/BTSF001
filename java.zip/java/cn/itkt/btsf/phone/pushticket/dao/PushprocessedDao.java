package cn.itkt.btsf.phone.pushticket.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.pushticket.po.PushprocessedPO;

/**
 * 移动商旅_低价推送处理结果表 
 * @author codegen 2011-10-19 11:19:48 
 */
public interface PushprocessedDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return Pushprocessed 
	 */
	public PushprocessedPO findDetail(String id);

	/**
	 * 查找所有 
	 * @return List<PushprocessedPO> 
	 */
	public List<PushprocessedPO> findAll();

	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PushprocessedPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(Map<String,Object> map);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);

	/**
	 * 根据推送id查询推送结果
	 * @param pushid
	 * @return
	 */
	public PushprocessedPO findByPushid(Long pushid);
}