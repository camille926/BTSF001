package cn.itkt.btsf.phone.pushticket.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.pushticket.po.PushprocessPO;

/**
 * 移动商旅_低价推送待处理表 
 * @author codegen 2011-10-19 11:19:23 
 */
public interface PushprocessDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return Pushprocess 
	 */
	public PushprocessPO find(Long id);
	/**
	 * 根据条件统计记录数
	 * @param map
	 * @return
	 */
	public int count(Map<String,Object> map);
	
	/**
	 * 新的sql
	 * @param map
	 * @return
	 */
	public int count1(Map<String,Object> map);
	/**
	 * 查找所有 
	 * @return List<PushprocessPO> 
	 */
	public List<PushprocessPO> findAll(Map<String,Object> map);
	
	/**
	 * 新的sql
	 * @param map
	 * @return
	 */
	public List<Map> findAll1(Map<String,Object> map);
	
	/**
	 * 创建 
	 * @param po 
	 */
	public void create(PushprocessPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(Map<String,Object> map);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 根据票号修改退改签状态 “0” 正常“1” 退票“2” 改期“3” 升舱“4” 废票
	 * @param map
	 */
	public void updateByTicketNo(Map<String,Object> map);
	
	/**
	 * 修改表BTSF_PHONE_PUSHTICKETNO的服务状态
	 * @param map
	 */
	public void updatePushTicketNo(Map<String,Object> map);
	
	/**
	 * 获取低价推送时票的退改签规定
	 * @return
	 */
	public List<String> getRules(Map<String,Object> map);
	/**
	 * 更新订单终端号
	 * @param map
	 */
	public void updateOrderTerminal(Map<String,Object> map);
	/**
	 * 更新订单终端号
	 * @param map
	 */
	public void updateTicketTerminal(Map<String,Object> map);
	
}