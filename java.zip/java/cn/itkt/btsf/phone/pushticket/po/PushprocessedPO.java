package cn.itkt.btsf.phone.pushticket.po;

import java.io.Serializable;
import java.util.Date;


/**
 * 移动商旅_低价推送处理结果表 
 * @author codegen 2011-10-19 11:19:48 
 */
public class PushprocessedPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** 编号 **/ 
	private long id;
	
    /** 低价推送待处理ID **/ 
	private long pushid;
	
    /** 票号 **/ 
	private String ticketno;
	
    /** 新票号 **/ 
	private String newticketno;
	
    /** 处理时间 **/ 
	private Date processdate;
	
    /** 处理人 **/ 
	private String processperson;
	
    /** 处理结果状态         “0” 处理失败（旅客未接受或接受出票失败）
“1” 处理成功（旅客接受的，并且成功出新票） **/ 
	private String processstatus;
	
    /** 备注 **/ 
	private String remark;
	
	private String orderNo;  //原订单号
	
	private String newOrderNo;  //新订单号
	
	private String reqNo;    //原退票申请单
	
	private String coin;  //返还畅达币
	
	private String ticketPrice; //原票价
	
	private String pushPrice;   //推送价 
	
	private String cabinLevel;  //原票舱位
	
	private String basecabin;
	
	private String status;     //处理状态
	
	private String orderId;   //原订单ID
	

	/**
	 * 构造 
	 */
	public PushprocessedPO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public long getPushid() {
		return pushid;
	}

	public void setPushid(long pushid) {
		this.pushid = pushid;
	}
	public String getTicketno() {
		return ticketno;
	}

	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}
	public String getNewticketno() {
		return newticketno;
	}

	public void setNewticketno(String newticketno) {
		this.newticketno = newticketno;
	}
	public Date getProcessdate() {
		return processdate;
	}

	public void setProcessdate(Date processdate) {
		this.processdate = processdate;
	}
	public String getProcessperson() {
		return processperson;
	}

	public void setProcessperson(String processperson) {
		this.processperson = processperson;
	}
	public String getProcessstatus() {
		return processstatus;
	}

	public void setProcessstatus(String processstatus) {
		this.processstatus = processstatus;
	}
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}


	public String getOrderNo() {
		return orderNo;
	}


	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}


	public String getNewOrderNo() {
		return newOrderNo;
	}


	public void setNewOrderNo(String newOrderNo) {
		this.newOrderNo = newOrderNo;
	}


	public String getReqNo() {
		return reqNo;
	}


	public void setReqNo(String reqNo) {
		this.reqNo = reqNo;
	}


	public String getCoin() {
		return coin;
	}


	public void setCoin(String coin) {
		this.coin = coin;
	}


	public String getTicketPrice() {
		return ticketPrice;
	}


	public void setTicketPrice(String ticketPrice) {
		this.ticketPrice = ticketPrice;
	}


	public String getPushPrice() {
		return pushPrice;
	}


	public void setPushPrice(String pushPrice) {
		this.pushPrice = pushPrice;
	}


	public String getCabinLevel() {
		return cabinLevel;
	}


	public void setCabinLevel(String cabinLevel) {
		this.cabinLevel = cabinLevel;
	}


	public String getBasecabin() {
		return basecabin;
	}


	public void setBasecabin(String basecabin) {
		this.basecabin = basecabin;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
}