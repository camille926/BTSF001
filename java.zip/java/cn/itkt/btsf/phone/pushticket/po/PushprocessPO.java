package cn.itkt.btsf.phone.pushticket.po;

import java.io.Serializable;
import java.util.Date;


/**
 * 移动商旅_低价推送待处理表 
 * @author codegen 2011-10-19 11:19:23 
 */
public class PushprocessPO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	
    /** 编号 **/ 
	private long pushid;
	
    /** 订单号 **/ 
	private long iphoneorderid;
	
    /** 票号 **/ 
	private String ticketno;
	
    /** 原票价 **/ 
	private String price;
	
    /** 低价（推送价） **/ 
	private String pushprice;
	
    /** 推送后可获取的畅达币 **/ 
	private String lcdcoin;
	
    /** 推送时间 **/ 
	private Date pushdate;
	
    /** 接受状态    “0” 未接受
“1” 已接受 **/ 
	private String status;
	
    /** 处理状态    “0” 未处理
“1” 已处理 **/ 
	private String processstatus;
	
    /** 新出发日期 **/ 
	private String departuredate;
	
    /** 新航班号 **/ 
	private String flightno;
	
    /** 新舱位代码 **/ 
	private String basecabin;
	
    /** 新航空公司 **/ 
	private String airline;
	
    /** 新特价票编号 **/ 
	private String specialflightnum;
	
    /** 新到达时间 **/ 
	private String arrivaldate;
	
    /** 新舱位折扣 **/ 
	private String cabindiscount;
	
    /** 新机型 **/ 
	private String planetype;
	
    /** 新燃油费 **/ 
	private String fueltax;
	
    /** 新机建费 **/ 
	private String airporttax;
	
    /** 新基准舱位 **/ 
	private String basiccabin;
	
	private String orderno;
	

	/**
	 * 构造 
	 */
	public PushprocessPO() {
	}
	

	public long getPushid() {
		return pushid;
	}

	public void setPushid(long pushid) {
		this.pushid = pushid;
	}
	public long getIphoneorderid() {
		return iphoneorderid;
	}

	public void setIphoneorderid(long iphoneorderid) {
		this.iphoneorderid = iphoneorderid;
	}
	public String getTicketno() {
		return ticketno;
	}

	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}
	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	public String getPushprice() {
		return pushprice;
	}

	public void setPushprice(String pushprice) {
		this.pushprice = pushprice;
	}
	public String getLcdcoin() {
		return lcdcoin;
	}

	public void setLcdcoin(String lcdcoin) {
		this.lcdcoin = lcdcoin;
	}
	public Date getPushdate() {
		return pushdate;
	}

	public void setPushdate(Date pushdate) {
		this.pushdate = pushdate;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public String getProcessstatus() {
		return processstatus;
	}

	public void setProcessstatus(String processstatus) {
		this.processstatus = processstatus;
	}
	public String getDeparturedate() {
		return departuredate;
	}

	public void setDeparturedate(String departuredate) {
		this.departuredate = departuredate;
	}
	public String getFlightno() {
		return flightno;
	}

	public void setFlightno(String flightno) {
		this.flightno = flightno;
	}
	public String getBasecabin() {
		return basecabin;
	}

	public void setBasecabin(String basecabin) {
		this.basecabin = basecabin;
	}
	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getSpecialflightnum() {
		return specialflightnum;
	}

	public void setSpecialflightnum(String specialflightnum) {
		this.specialflightnum = specialflightnum;
	}
	public String getArrivaldate() {
		return arrivaldate;
	}

	public void setArrivaldate(String arrivaldate) {
		this.arrivaldate = arrivaldate;
	}
	public String getCabindiscount() {
		return cabindiscount;
	}

	public void setCabindiscount(String cabindiscount) {
		this.cabindiscount = cabindiscount;
	}
	public String getPlanetype() {
		return planetype;
	}

	public void setPlanetype(String planetype) {
		this.planetype = planetype;
	}
	public String getFueltax() {
		return fueltax;
	}

	public void setFueltax(String fueltax) {
		this.fueltax = fueltax;
	}
	public String getAirporttax() {
		return airporttax;
	}

	public void setAirporttax(String airporttax) {
		this.airporttax = airporttax;
	}
	public String getBasiccabin() {
		return basiccabin;
	}

	public void setBasiccabin(String basiccabin) {
		this.basiccabin = basiccabin;
	}


	public String getOrderno() {
		return orderno;
	}


	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}

}