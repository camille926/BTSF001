package cn.itkt.btsf.phone.pushticket.vo;

import java.util.Date;


/**
 * 移动商旅_低价推送处理结果表 
 * @author codegen 2011-10-19 11:19:48 
 */
public class PushprocessedVO {

    /** 编号 **/ 
	private long id;
	
    /** 低价推送待处理ID **/ 
	private long pushid;
	
    /** 票号 **/ 
	private String ticketno;
	
    /** 新票号 **/ 
	private String newticketno;
	
    /** 处理时间 **/ 
	private Date processdate;
	
    /** 处理人 **/ 
	private String processperson;
	
    /** 处理结果状态         “0” 处理失败（旅客未接受或接受出票失败）
“1” 处理成功（旅客接受的，并且成功出新票） **/ 
	private String processstatus;
	
    /** 备注 **/ 
	private String remark;
	

	/**
	 * 构造 
	 */
	public PushprocessedVO() {
	}
	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	public long getPushid() {
		return pushid;
	}

	public void setPushid(long pushid) {
		this.pushid = pushid;
	}
	public String getTicketno() {
		return ticketno;
	}

	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}
	public String getNewticketno() {
		return newticketno;
	}

	public void setNewticketno(String newticketno) {
		this.newticketno = newticketno;
	}
	public Date getProcessdate() {
		return processdate;
	}

	public void setProcessdate(Date processdate) {
		this.processdate = processdate;
	}
	public String getProcessperson() {
		return processperson;
	}

	public void setProcessperson(String processperson) {
		this.processperson = processperson;
	}
	public String getProcessstatus() {
		return processstatus;
	}

	public void setProcessstatus(String processstatus) {
		this.processstatus = processstatus;
	}
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}