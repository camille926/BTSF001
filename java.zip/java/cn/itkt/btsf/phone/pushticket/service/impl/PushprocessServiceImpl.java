package cn.itkt.btsf.phone.pushticket.service.impl;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.itkt.btsf.phone.pushticket.dao.PushprocessDao;
import cn.itkt.btsf.phone.pushticket.po.PushprocessPO;
import cn.itkt.btsf.phone.pushticket.service.PushprocessService;
import cn.itkt.btsf.phone.pushticket.service.SeatReservationIphoneHandler;
import cn.itkt.btsf.phone.users.dao.PhoneOrderExtDao;
import cn.itkt.btsf.phone.users.po.PhoneOrderExtPO;
import cn.itkt.btsf.sys.cc.national.dao.OrderContactorDao;
import cn.itkt.btsf.sys.cc.national.dao.OrderMsgExtDao;
import cn.itkt.btsf.sys.cc.national.dao.PsrInfoDao;
import cn.itkt.btsf.sys.cc.national.dao.TicketInfoDao;
import cn.itkt.btsf.sys.cc.national.po.InsuranceInfoPO;
import cn.itkt.btsf.sys.cc.national.po.OrderContactorPO;
import cn.itkt.btsf.sys.cc.national.po.OrderMsgExtPO;
import cn.itkt.btsf.sys.cc.national.po.PsrInfoPO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.service.FlightQueryService;
import cn.itkt.btsf.sys.cc.national.service.InsuranceInfoService;
import cn.itkt.btsf.sys.cc.national.service.webservice.SeatReservationHandler;
import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;
import cn.itkt.btsf.sys.common.constant.WebServiceConstant;
import cn.itkt.btsf.sys.terminal.dao.AtmDetailDao;
import cn.itkt.btsf.sys.terminal.po.AtmDetailPO;
import cn.itkt.exception.AppException;
import cn.itkt.util.SysUtil;

@Service
public class PushprocessServiceImpl implements PushprocessService {

	

	private static final Logger log = LoggerFactory.getLogger(PushprocessServiceImpl.class);
	
	@Resource
	private  PushprocessDao  pushprocessDao;
	@Resource
	private TicketInfoDao ticketInfoDao;
	@Resource
	private PsrInfoDao psrInfoDao;
	@Resource
	private InsuranceInfoService insuranceInfoService;
	@Resource
	private FlightQueryService flightQueryService;
	@Resource
	private OrderMsgExtDao orderMsgExtDao;
	@Resource
	private OrderContactorDao orderContactorDao;
	@Resource
	private PhoneOrderExtDao phoneOrderExtDao;
	@Resource
	private AtmDetailDao atmDetailDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return Pushprocess 
	 */
	public PushprocessPO find(Long id){
		return pushprocessDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PushprocessPO> 
	 */
	public List<PushprocessPO> findAll(Map<String,Object> map){
		return pushprocessDao.findAll(map);	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(PushprocessPO po) throws AppException{
		try{
			if( po != null )
				 pushprocessDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean update(Map<String,Object> map) throws AppException {
		try{			
		     pushprocessDao.update(map);
		     return true;
		}catch(Exception e){
			log.error(e.getMessage());
			e.printStackTrace();
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 pushprocessDao.delete(id);
	}

	@Override
	public int count(Map<String, Object> map) {
		return pushprocessDao.count(map);
	}
	@Override
	public String orderTicket(PushprocessPO po) throws AppException {
		String flyerCard = "";//旅客常旅客卡
		String[][] psgList = null;//第一个参数：旅客信息
		String[][] SegsInfos = null;//第二个参数：航程信息
		String[] saleTypeInfo = new String[2];//销售类型
		String[] mailInfo = null;//邮寄地址信息
		String[] contactorInfo = null;//联系人信息
		String orderId ="";
		String userId = "";
		String isacceptsevice = "0";//是否接受低价推送，默认为不接受
		String receiptType = "0";//行程单获取方式,默认为无需获取行程单
		
		try {
			//原客票信息
			TicketInfoPO ticketInfo = ticketInfoDao.getTicketInfoByTicketNo(po.getTicketno());
			
			if(ticketInfo != null){
				//原客票乘客信息
				PsrInfoPO psrInfo = psrInfoDao.find(ticketInfo.getPassengerId());
				//原订单邮寄配送信息
				OrderMsgExtPO findMsgByOrderId = orderMsgExtDao.findMsgByOrderId(ticketInfo.getOrderId());
				//原订单联系人
				OrderContactorPO findByOrderId = orderContactorDao.findByOrderId(ticketInfo.getOrderId());
				//获得订单扩展表信息
				PhoneOrderExtPO findByOrderId2 = phoneOrderExtDao.findByOrderId(ticketInfo.getOrderId());
				
				if(psrInfo != null){
					//如果旅客常旅客卡不为空则获取常旅客卡所在航空公司代码
					if(psrInfo.getFlyerCard() != null){
						flyerCard = psrInfo.getFlyerCard();
					}
					//获得机票保险总份数和保险总金额
					List<Map>  ins=insuranceInfoService.findInsNumberAndAmount(ticketInfo.getId());
					HashMap hm=(HashMap)ins.get(0);
					String insuranceNumber=hm.get("INSURANCE_NUMBER").toString();
					String insuranceAmount=hm.get("INSURANCE_AMOUNT").toString();
					
					String birthday ="";
					SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
					if(psrInfo.getBirthday()!=null){
						birthday = sf.format(psrInfo.getBirthday());
					}
					
					//拼第一个参数：旅客信息
					psgList = new String[1][16];
					psgList[0][0] = SysUtil.ifNull(psrInfo.getName()).trim();//旅客姓名
					psgList[0][1] = SysUtil.ifNull(psrInfo.getPassengertype()).trim();//旅客类型
					psgList[0][2] = SysUtil.ifNull(psrInfo.getIdentityCardType()).trim();//旅客证件类型
					psgList[0][3] = SysUtil.ifNull(psrInfo.getIdentityCardNo()).trim();//旅客证件号码
					//psgList[0][4] = SysUtil.ifNull(psrInfo.getBirthday()).trim();//旅客生日
					psgList[0][4] = SysUtil.ifNull(birthday).trim();//旅客生日
					psgList[0][5] = "";//常旅客卡所在航空公司代码
					psgList[0][6] = SysUtil.ifNull(flyerCard).trim();//旅客常旅客卡
					psgList[0][7] = SysUtil.ifNull(psrInfo.getMobile()).trim();//联系电话
//					psgList[0][8] = SysUtil.ifNull(String.valueOf(Double.parseDouble(po.getPushprice())-Double.parseDouble(po.getFueltax())-Double.parseDouble(po.getAirporttax()))).trim();//票面价格
					psgList[0][8] = SysUtil.ifNull(String.valueOf(Double.parseDouble(po.getPushprice())).trim());//票面价格
					psgList[0][9] = SysUtil.ifNull( String.valueOf(po.getAirporttax())).trim();//单程燃油税
					psgList[0][10] = SysUtil.ifNull(String.valueOf(po.getFueltax())).trim();//单程机建费
					psgList[0][11] = insuranceNumber;//保险的份数
					psgList[0][12] = insuranceAmount;//保险的金额
					psgList[0][13] = "0";//往返返程票面价，单程时为0
					psgList[0][14] = "0";//往返返程燃油税，单程时为0
					psgList[0][15] = "0";//往返返程机建费，单程时为0
					
					//第二个参数：航程信息
					SegsInfos = new String[1][11];
					SegsInfos[0][0] = SysUtil.ifNull(ticketInfo.getTakeofflocus()).trim();//出发地代码
					SegsInfos[0][1] = SysUtil.ifNull(ticketInfo.getArrivelocus()).trim();//到达地代码
					SegsInfos[0][2] = po.getDeparturedate();//出发日期，具体格式: yyyy-MM-dd HH:mm:ss
					SegsInfos[0][3] = po.getBasecabin().trim();//舱位代码
					SegsInfos[0][4] = po.getBasiccabin().trim();//基准舱位代码
					SegsInfos[0][5] = po.getAirline().trim();//航空公司
					SegsInfos[0][6] = po.getFlightno().trim();//航班号
					SegsInfos[0][7] = SysUtil.ifNull(po.getSpecialflightnum());//特价票编号
					SegsInfos[0][8] = po.getArrivaldate();//到达时间，具体格式: yyyy-MM-dd HH:mm:ss
					SegsInfos[0][9] = po.getCabindiscount();//舱位折扣
					SegsInfos[0][10] = po.getPlanetype();//机型
					
					saleTypeInfo[0] = "07";
					//saleTypeInfo[1] = "admin";
					String terminalId="callcenter;callcenter:"+(cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
					String saleTime= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(po.getDeparturedate()).getTime() - 3 * 60 * 60 *1000));
					
					//邮寄地址信息
					mailInfo = new String[4];
					if(findMsgByOrderId != null){
						mailInfo[0] = SysUtil.ifNull(findMsgByOrderId.getRecipient());//收件人
						mailInfo[1] = SysUtil.ifNull(findMsgByOrderId.getAddress());//收件人地址
						mailInfo[2] = SysUtil.ifNull(findMsgByOrderId.getPostCode());//邮编
						mailInfo[3] = SysUtil.ifNull(findMsgByOrderId.getSmsSendMobile());//手机号
						receiptType = findMsgByOrderId.getReceiptGetType();//行程单获取方式
					}
					
					//联系人信息
					contactorInfo = new String[3];
					if(findByOrderId != null){
						contactorInfo[0] = SysUtil.ifNull(findByOrderId.getContactorname());//联系人姓名
						contactorInfo[1] = SysUtil.ifNull(findByOrderId.getMobile());//联系人手机号
						contactorInfo[2] = SysUtil.ifNull(findByOrderId.getTelephone());//联系人电话
					}
					//获得会员id
					if(findByOrderId2 != null){
						userId = SysUtil.ifNull(findByOrderId2.getUserid());
						//isacceptsevice = SysUtil.ifNull(findByOrderId2.getIsacceptsevice());
					}
					
					//调用Webservice订座
					SeatReservationIphoneHandler.SeatReserveResult reserveResultObj = null;
					try {
						log.info("================开始调用Webservice预定座位===================");
						AbstractWebserviceInvoker  webserviceInvoker = new SeatReservationIphoneHandler();
						reserveResultObj = (SeatReservationIphoneHandler.SeatReserveResult)webserviceInvoker.invoke(
								WebServiceConstant.getEndPoint(), 
								"makeReservationiphone", 
								WebServiceConstant.getQname(), 
								new Object[] {psgList,SegsInfos,terminalId,saleTime, "01","1",saleTypeInfo,mailInfo,contactorInfo,isacceptsevice,userId,receiptType});
						
					} catch (Exception e) {
						log.error("===================== 调用Webservice预定座位异常=======================");
						e.printStackTrace();
						throw new AppException("ticket.seat.reservation.exception");
					}	
					
					if(reserveResultObj.isSuccess()){
						 orderId = reserveResultObj.getFlowNo();
					}else{
						throw new AppException(reserveResultObj.getErrorDescriptionCode());
					}
				}else{
					throw new AppException("原客票乘机人不存在！");
				}
				
			}else{
				throw new AppException("客票不存在！");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return orderId;
	}

	@Override
	public List<Map> findAll1(Map<String, Object> map) {
		return pushprocessDao.findAll1(map);	
	}

	@Override
	public int count1(Map<String, Object> map) {
		return pushprocessDao.count1(map);
	}

	/**
	 * 获取票信息
	 * 新添的方法
	 * @param map
	 * @return
	 */
	@Override
	public TicketInfoPO getTicket(Map<String, Object> map) {
		return ticketInfoDao.getTicket(map);
	}

	@Override
	public boolean updatePushTicketNo(Map<String, Object> map) {
		try{			
		     pushprocessDao.updatePushTicketNo(map);
		     return true;
		}catch(Exception e){
			log.error(e.getMessage());
			e.printStackTrace();
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 获取低价推送时票的退改签规定
	 * @return
	 */
	@Override
	public List<String> getRules(Map<String, Object> map) {
		return pushprocessDao.getRules(map);
	}
	/**
	 * 修改订单和票的终端号
	 * @param orderId
	 * @param terminalId
	 * @return
	 */
	public boolean updateOrderAndTicketTerminal(long orderId,long terminalId){
		try{
			Map<String,Object> map=new HashMap<String,Object>();
			map.put("orderId", orderId);
			map.put("terminalId", terminalId);
			pushprocessDao.updateOrderTerminal(map);
			pushprocessDao.updateTicketTerminal(map);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	/**
	 * 查询终端详情
	 * @param terminalId
	 * @return
	 */
	public AtmDetailPO getAtmDetail(Long terminalId){
		return atmDetailDao.find(terminalId);
	}

}