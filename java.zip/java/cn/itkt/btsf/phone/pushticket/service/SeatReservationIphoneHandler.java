/**
 * SeatReservationHandler.java  2012-3-1     
 *
 * Copyright (c) ITKT, 2012, All Rights Reserved.
*/
package cn.itkt.btsf.phone.pushticket.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;

/**
 * 移动商旅航班订座接口
 * @author   luxueping
 * @Date	 2012-4-24 
 * @version  
 */
public class SeatReservationIphoneHandler extends AbstractWebserviceInvoker {
	private Logger log = LoggerFactory.getLogger(SeatReservationIphoneHandler.class);

	/**
	 * 航班订座接口参数
	 * 
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@Override
	public Object[] buildArgument(Object args) {
		return (Object[])args;
	}

	/**
	 * 航班订座接口返回SeatReservationIphoneResult实例。
	 * 
	 * @param result
	 * @return
	 * @throws Exception
	 */
	@Override
	public Object buildResult(Object result){
		String PNRInfos = (String)result;
		String[] returnState = PNRInfos.split("\"");
		
		SeatReserveResult resultObject = new SeatReserveResult();
		resultObject.setSuccess("0".equals(returnState[1]) ? true : false);
		
		if(resultObject.isSuccess){//返回数据成功
			log.info("---订座成功---订单Id："+returnState[5].trim());
			resultObject.setFlowNo(returnState[5].trim());
		
			resultObject.setPnrs(returnState[9]);
			
		}else{  
			//resultObject.setErrorDescriptionCode(returnState[1]);
		}
		return resultObject;
	}
	
	/**
	 * 订座结果封装类
	 *
	 * @author   luxueping
	 * @Date	 2012-3-6  下午02:06:29
	 * @version  SeatReservationIphoneResult
	 */
	public static class SeatReserveResult{
		private boolean isSuccess; //true-成功，false-失败
		private String errorDescriptionCode = ""; //失败时错误描述。成功时为""
		private String flowNo;
		
		private String pnrs ="";

		public boolean isSuccess() {
			return isSuccess;
		}

		public void setSuccess(boolean isSuccess) {
			this.isSuccess = isSuccess;
		}

		public String getErrorDescriptionCode() {
			return errorDescriptionCode;
		}

		public void setErrorDescriptionCode(String errorDescriptionCode) {
			this.errorDescriptionCode = errorDescriptionCode;
		}

		public String getFlowNo() {
			return flowNo;
		}

		public void setFlowNo(String flowNo) {
			this.flowNo = flowNo;
		}

		public String getPnrs() {
			return pnrs;
		}

		public void setPnrs(String pnrs) {
			this.pnrs = pnrs;
		}

		
	}
}
