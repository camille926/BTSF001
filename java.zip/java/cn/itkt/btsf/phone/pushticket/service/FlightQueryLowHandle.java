package cn.itkt.btsf.phone.pushticket.service;

import java.util.HashMap;
import java.util.Map;

import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;
import cn.itkt.btsf.util.DateUtil;

public class FlightQueryLowHandle extends AbstractWebserviceInvoker{

	@Override
	public Object[] buildArgument(Object args) throws Exception {
		return (Object[])args;
	}

	@Override
	public Object buildResult(Object result) {
		TicketInfoPO ticketInfoPO = null;
		String[] flightInfo = (String[])result;
		if("0".equals(flightInfo[0])){
			try {
				
			ticketInfoPO = new TicketInfoPO();
			ticketInfoPO.setTakeofflocus(flightInfo[2]);//出发地代码
			ticketInfoPO.setArrivelocus(flightInfo[3]);//到达地代码
			ticketInfoPO.setTakeofftime(DateUtil.stringToDate(flightInfo[4], "yyyy-MM-dd HH:mm:ss"));//出发日期，具体格式: yyyy-MM-dd HH:mm:ss
			ticketInfoPO.setCabin(flightInfo[5]);//舱位代码
			ticketInfoPO.setCabinLevel(flightInfo[6]);//基准舱位代码
			ticketInfoPO.setAirways(flightInfo[7]);//航空公司
			ticketInfoPO.setAirteamnum(flightInfo[8]);//航班号
			ticketInfoPO.setIsspecialflight(flightInfo[9]);//特价票编号
			ticketInfoPO.setArrivetime(DateUtil.stringToDate(flightInfo[10],"yyyy-MM-dd HH:mm:ss"));//到达时间，具体格式: yyyy-MM-dd HH:mm:ss
			ticketInfoPO.setTicketdiscount(flightInfo[11]);//舱位折扣
			ticketInfoPO.setAirplanetype(flightInfo[12]);//机型
			ticketInfoPO.setTicketPrice(Double.parseDouble(flightInfo[13]));//票价
			ticketInfoPO.setTicketlevel(flightInfo[14]);//退票费率
			ticketInfoPO.setDrometax(Double.parseDouble(flightInfo[15]));//机建税
			ticketInfoPO.setFueltax(Double.parseDouble(flightInfo[16]));//燃油税
			
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return ticketInfoPO;
	}

}
