package cn.itkt.btsf.phone.pushticket.service;

import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;

public class PayLcdCoinHandler extends AbstractWebserviceInvoker{

	@Override
	public Object[] buildArgument(Object args) throws Exception {
		return (Object[])args;
	}

	@Override
	public Object buildResult(Object result) {
		boolean payTicket = false;
		String results[] = (String[])result;
		if("0".equals(results[0])){
			payTicket = true;
		}
		return payTicket;
	}

}
