package cn.itkt.btsf.phone.pushticket.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import cn.itkt.btsf.phone.pushticket.po.PushprocessedPO;
import org.springframework.ui.ModelMap;
import cn.itkt.exception.AppException;

public interface PushprocessedService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return Pushprocessed 
	 */
	public PushprocessedPO find(String id);

	/**
	 * 查找所有 
	 * @return List<PushprocessedPO> 
	 */
	public List<PushprocessedPO> findAll();

	/**
	 * 创建 
	 * @param po
	 */
	public boolean create(PushprocessedPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(Map<String,Object> map) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 根据推送id查询推送结果
	 * @param pushid
	 * @return
	 */
	public PushprocessedPO findByPushid(Long pushid);
	
	/**
	 * 自动生成退票申请单
	 * orderid 订单id
	 * ticketNo 票号
	 * rate 退票手续费率
	 * fee 退票手续费
	 * exceptFee 实际退款金额
	 * newOrderNo 新订单编号
	 */
	public String autoCreateRefundTicket(ModelMap modelMap,long orderid,String ticketNo,Double rate,Double fee,String lcdCoin,String newOrderNo);

	

}