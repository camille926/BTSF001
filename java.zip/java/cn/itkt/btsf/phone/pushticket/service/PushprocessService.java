package cn.itkt.btsf.phone.pushticket.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.pushticket.po.PushprocessPO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.terminal.po.AtmDetailPO;
import cn.itkt.exception.AppException;

public interface PushprocessService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return Pushprocess 
	 */
	public PushprocessPO find(Long id);
	/**
	 * 根据条件统计记录数
	 * @param map
	 * @return
	 */
	public int count(Map<String,Object> map);
	
	/**
	 * 新的sql
	 * @param map
	 * @return
	 */
	public int count1(Map<String,Object> map);
	/**
	 * 查找所有 
	 * @return List<PushprocessPO> 
	 */
	public List<PushprocessPO> findAll(Map<String,Object> map);
	
	/**
	 * 新的sql
	 * @param map
	 * @return
	 */
	public List<Map> findAll1(Map<String,Object> map);

	/**
	 * 创建 
	 * @param po
	 */
	public void create(PushprocessPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public boolean update(Map<String,Object> map) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	/**
	 * 预订新票和新订单
	 * @return
	 * @throws AppException
	 */
	public String orderTicket(PushprocessPO po) throws AppException;

	/**
	 * 获取票信息
	 * 新添的方法
	 * @param map
	 * @return
	 */
	public TicketInfoPO getTicket(Map<String,Object> map);
	
	/**
	 * 修改表BTSF_PHONE_PUSHTICKETNO的服务状态
	 * @param map
	 */
	public boolean updatePushTicketNo(Map<String,Object> map);
	
	/**
	 * 获取低价推送时票的退改签规定
	 * @return
	 */
	public List<String> getRules(Map<String,Object> map);
	/**
	 * 修改订单和票的终端号
	 * @param orderId
	 * @param terminalId
	 * @return
	 */
	public boolean updateOrderAndTicketTerminal(long orderId,long terminalId);
	/**
	 * 查询终端详情
	 * @param terminalId
	 * @return
	 */
	public AtmDetailPO getAtmDetail(Long terminalId);

}