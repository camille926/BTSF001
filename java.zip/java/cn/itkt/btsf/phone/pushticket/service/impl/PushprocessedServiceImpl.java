package cn.itkt.btsf.phone.pushticket.service.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import cn.itkt.btsf.phone.pushticket.dao.PushprocessedDao;
import cn.itkt.btsf.phone.pushticket.po.PushprocessedPO;
import cn.itkt.btsf.phone.pushticket.service.PushprocessedService;
import cn.itkt.btsf.sys.cc.national.controller.RefundTicketSupport;
import cn.itkt.btsf.sys.cc.national.dao.InsuranceInfoDao;
import cn.itkt.btsf.sys.cc.national.dao.OrderMsgExtDao;
import cn.itkt.btsf.sys.cc.national.dao.TicketInfoDao;
import cn.itkt.btsf.sys.cc.national.po.OrderMsgExtPO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.vo.InsuranceInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.TicketRequestVO;
import cn.itkt.btsf.sys.receipt.dao.ReceiptPrintDao;
import cn.itkt.btsf.sys.receipt.po.ReceiptPrintPO;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.exception.AppException;

@Service
public class PushprocessedServiceImpl implements PushprocessedService {

	private static final Logger log = LoggerFactory.getLogger(PushprocessedServiceImpl.class);
	
	@Resource
	private  PushprocessedDao  pushprocessedDao;
	@Resource
	private RefundTicketSupport refundTicketSupport;
	@Resource
	private TicketInfoDao ticketInfoDao;
	@Resource
	private ReceiptPrintDao receiptPrintDao;
	@Resource
	private OrderMsgExtDao orderMsgExtDao;
	@Resource
	private  InsuranceInfoDao  insuranceInfoDao;

	/**
	 * 查找单个 
	 * @param id 
	 * @return Pushprocessed 
	 */
	public PushprocessedPO find(String id){
		
		return pushprocessedDao.findDetail(id);	
	}

	/**
	 * 查找所有 
	 * @return List<PushprocessedPO> 
	 */
	public List<PushprocessedPO> findAll(){
		return pushprocessedDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public boolean create(PushprocessedPO po) throws AppException{
		try{
			if( po != null )
				 pushprocessedDao.create(po);
			return true;
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(Map<String,Object> map) throws AppException {
		try{
			map=new HashMap<String,Object>();
				 pushprocessedDao.update(map);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 pushprocessedDao.delete(id);
	}

	@Override
	public PushprocessedPO findByPushid(Long pushid) {
		return pushprocessedDao.findByPushid(pushid);
	}
	/**
	 * 自动生成退票申请单
	 * orderid 订单id
	 * ticketNo 票号
	 * rate 退票手续费率
	 * fee 退票手续费
	 * exceptFee 实际退款金额
	 * newOrderNo 新订单编号
	 */
	@Override
	public String autoCreateRefundTicket(ModelMap modelMap,long orderid, String ticketNo,
			Double rate, Double fee,String lcdCoin,String newOrderNo) {
		String str = "";
		TicketRequestVO ticketRequestVO = null;
		String ticketInfo = "";
		TicketInfoPO ticketInfoByTicketNo = null;
		String receiptCode = "";
		OrderMsgExtPO orderMsgExtPO = null;
		String reqNo = null;
		try {
			orderMsgExtPO = orderMsgExtDao.findMsgByOrderId(orderid);
			ticketRequestVO = new TicketRequestVO();
			double oldInPrice=0;
			//原票信息
			ticketInfoByTicketNo = ticketInfoDao.getTicketInfoByTicketNo(ticketNo);
			//List<InsuranceInfoVO> findInsByTicketNo = insuranceInfoService.findInsByTicketId(ticketInfoByTicketNo.getId());
			Map<String,Object> paramMap = new HashMap<String,Object>();
			paramMap.put("ticketId", ticketInfoByTicketNo.getId());
			paramMap.put("buyStatus", "1"); //1购保成功
			List<InsuranceInfoVO> findInsByTicketNo= insuranceInfoDao.findInsByTicketId(paramMap);
			if(findInsByTicketNo.size()>0){
				oldInPrice = findInsByTicketNo.get(0).getPrice();//原票保险金额
			}
			ticketRequestVO.setRequisitionCode(DateUtil.getTimeSequence("GNTP"));//退票申请单号
			ticketRequestVO.setProposerType("01");//退票
			ticketRequestVO.setIfOutDate("1");//加急
			ticketRequestVO.setExceptFee(0);//实际退款金额
			ticketRequestVO.setDeductcoin(fee);//扣畅达币
			ticketRequestVO.setLcdcoin(lcdCoin);
			ticketRequestVO.setRefundWay("2");//退款方式
			ticketRequestVO.setRefundType("0");
			ticketRequestVO.setNeedBill("0");//是否需要退票单
			ticketRequestVO.setPrintStatus("1");//退票单打印方式
			ticketRequestVO.setNeedRefundfee("1");//是否已退款(0：否，1：是)
			ticketRequestVO.setOrderId(orderid);//订单id
			ticketRequestVO.setNeedSms("1");//是否发送短信(0:否，1：是)
			ticketRequestVO.setSmsType1(new String[]{"0","1"});//给乘机人和订票人发送短信
			ticketRequestVO.setRemark("更低价推送订单，订单号:"+newOrderNo);
			ticketRequestVO.setInsurance((int)oldInPrice);
			//行程单返还方式
			if(orderMsgExtPO != null){
				String receiptGetType = orderMsgExtPO.getReceiptGetType();
				if("0".equals(receiptGetType)){
					ticketRequestVO.setReceiptReturnType("7");//不需要
					
				}else if("1".equals(receiptGetType) || "3".equals(receiptGetType)){
					ticketRequestVO.setReceiptReturnType("2");//邮寄或补打
				}
			}else{
				ticketRequestVO.setReceiptReturnType("5");//未打印
			}
			
			
			//获取该票的行程单号
			ReceiptPrintPO findByTicketNo = receiptPrintDao.findByTicketNo(ticketNo);
			if(findByTicketNo != null){
				receiptCode = findByTicketNo.getReceiptCode();
			}
			
			ticketInfo = ticketNo+","+rate+","+fee+",0,0,"+ticketInfoByTicketNo.getId()+","+ticketInfoByTicketNo.getPassengerName()+","+ticketInfoByTicketNo.getPayableAmount()+","+receiptCode+";";
			
			//提交退票申请单
			refundTicketSupport.submitRefundTicket(modelMap, ticketRequestVO, ticketInfo, orderid);
			if(modelMap.get("message")!= null && modelMap.get("message").toString().indexOf("成功")>0){
				reqNo = ticketRequestVO.getRequisitionCode();
			}
		} catch (Exception e) {
			reqNo = "";
			e.printStackTrace();
			return reqNo;
		}

		return reqNo;

	}
}