package cn.itkt.btsf.callcenter.refundment.vo;

import java.util.Date;

/**
 * 退款申请单
 * 
 * @author
 */
public class RefundMentFindDetilVO {
private String passenger;//乘客名称
private String ticketNo;//票号
private String orderNo;//订单编号
private String accountn;//支付账户
private String refundWay;//退款渠道(支付方式)
private Double ticketMoney;//票款
private Integer insurance;//保险
private Double rate;//退票费率
private Double fee;//废手续费
private Double refundCash;//退款金额
private Double refundCoin;//畅达币
private String proposerName;//操作人（申请人）
private Date saletime;//出票时间
private Date donetime;//退费时间
private String status;//退款状态
private String requisitionCode;//申请单号 
private Date proposerDate;/** 申请日期 **/
private Double totalAmount;//原交易金额合计
private Double refundAmount;//退款金额合计
private Integer trxcount;//退款笔数
private String remarks;//备注
public String getPassenger() {
	return passenger;
}

public RefundMentFindDetilVO() {
	super();
}

public void setPassenger(String passenger) {
	this.passenger = passenger;
}

public String getTicketNo() {
	return ticketNo;
}

public void setTicketNo(String ticketNo) {
	this.ticketNo = ticketNo;
}

public String getOrderNo() {
	return orderNo;
}

public void setOrderNo(String orderNo) {
	this.orderNo = orderNo;
}

public String getAccountn() {
	return accountn;
}

public void setAccountn(String accountn) {
	this.accountn = accountn;
}

public String getRefundWay() {
	return refundWay;
}

public void setRefundWay(String refundWay) {
	this.refundWay = refundWay;
}

public Double getTicketMoney() {
	return ticketMoney;
}

public void setTicketMoney(Double ticketMoney) {
	this.ticketMoney = ticketMoney;
}

public Integer getInsurance() {
	return insurance;
}

public void setInsurance(Integer insurance) {
	this.insurance = insurance;
}

public Double getRate() {
	return rate;
}

public void setRate(Double rate) {
	this.rate = rate;
}

public Double getFee() {
	return fee;
}

public void setFee(Double fee) {
	this.fee = fee;
}

public Double getRefundCash() {
	return refundCash;
}

public void setRefundCash(Double refundCash) {
	this.refundCash = refundCash;
}

public Double getRefundCoin() {
	return refundCoin;
}

public void setRefundCoin(Double refundCoin) {
	this.refundCoin = refundCoin;
}

public String getProposerName() {
	return proposerName;
}

public void setProposerName(String proposerName) {
	this.proposerName = proposerName;
}

public Date getSaletime() {
	return saletime;
}

public void setSaletime(Date saletime) {
	this.saletime = saletime;
}

public Date getDonetime() {
	return donetime;
}

public void setDonetime(Date donetime) {
	this.donetime = donetime;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public String getRequisitionCode() {
	return requisitionCode;
}

public void setRequisitionCode(String requisitionCode) {
	this.requisitionCode = requisitionCode;
}

public Date getProposerDate() {
	return proposerDate;
}

public void setProposerDate(Date proposerDate) {
	this.proposerDate = proposerDate;
}

public Double getTotalAmount() {
	return totalAmount;
}

public void setTotalAmount(Double totalAmount) {
	this.totalAmount = totalAmount;
}

public Double getRefundAmount() {
	return refundAmount;
}

public void setRefundAmount(Double refundAmount) {
	this.refundAmount = refundAmount;
}

public Integer getTrxcount() {
	return trxcount;
}

public void setTrxcount(Integer trxcount) {
	this.trxcount = trxcount;
}

public String getRemarks() {
	return remarks;
}

public void setRemarks(String remarks) {
	this.remarks = remarks;
}
}