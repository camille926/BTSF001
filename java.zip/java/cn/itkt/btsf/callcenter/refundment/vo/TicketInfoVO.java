package cn.itkt.btsf.callcenter.refundment.vo;

import java.io.Serializable;
import java.util.Date;


/**
 * 机票信息表 
 * @author codegen 2011-05-13 14:17:47 
 */
public class TicketInfoVO implements Serializable {

	/** serialVersionUID **/ 
	private static final long serialVersionUID = 1L;
	/** ID **/ 
	private long id;
	
    /** 电子客票号 **/ 
	private String ticketNo;
	
    /** PNR **/ 
	private String pnr;
	
    /** 是否国内航班,1 国内 2 国际 **/ 
	private String isNational;
	
    /** 乘客姓名 **/ 
	private String passengerName;
	
	//旅客证件号
	private String identityCardNo;
    /** 航空公司 **/ 
	private String airways;
	
    /** 航班号 **/ 
	private String airteamnum;
	
	/** 第二段航班号 **/ 
	private String airteamnum2;
	
    public String getIdentityCardNo() {
		return identityCardNo;
	}

	public void setIdentityCardNo(String identityCardNo) {
		this.identityCardNo = identityCardNo;
	}

	/** 机型 **/ 
	private String airplanetype;
	
	/** 第二段机型 **/ 
	private String airplanetype2;
	
    /** 舱位等级,Y,C,F,从舱位信息表中获取 **/ 
	private String cabinLevel;
	/** 第二段舱位等级,Y,C,F,从舱位信息表中获取 **/ 
	private String cabinLevel2;
	
    /** 票面价格 **/ 
	private double ticketPrice;
	
    /** 机建税 **/ 
	private double drometax;
	
    /** 燃油税 **/ 
	private double fueltax;
	
    /** 客票类型 0 BSP票 1 B2B票 **/ 
	private String tickettype;
	
    /** 客票状态,01未出票：订单录入后的默认航段状态；
02已出票：执行出票操作或录入出票信息后，状态为“已出票”；
03航班变动：航班变动发布后，状态为“航班变动”；
04自愿退票中：填写退票申请后，对应航段的状态为“自愿退票中”；
05非自愿退票中：填写退票申请后，对应航段的状态为“非自愿退票中”；
06升舱退票中：由升舱产生的退票，对应的航段状态为“升舱退票中”
07退票完成：对应的退票申请在财务退款完成后，航段状态为“退票完成”；
08废票处理中：填写废票申请后，对应航段的状态为“废票处理中”；
09废票完成：对应的废票申请在财务退款完成后，航段状态为“废票完成”；
10退款完成：退票、废票退款操作完成；
11改期处理中：填写改期申请后，对应航段的状态为“改期处理中”；
12改期完成：对应的改期申请执行“确认改期”后，航段状态为“改期完成”；
13升舱处理中：填写升舱申请后，对应航段的状态为“升舱处理中”；
14升舱完成：原升舱客票退票后，航段状态为“升舱完成”；
 **/ 
	private String ticketstate;
	
    /** 航程种类,01单程、02往返、03联程 **/ 
	private String flightType;
	
    /** 虚拟客票号 **/ 
	private String virtualTicketCode;
	
    /** 订单ID,关联订单表 **/ 
	private long orderId;
	
    /** 出票office号 **/ 
	private String saleoffice;
	
    /** 出票时间 **/ 
	private Date saletime;
	
    /** 是否已经出票（0 未出票 1 已经出票） **/ 
	private String ifsale;
	
    /** 是否已经打印行程单（0 未打印 1 已经打印） **/ 
	private String ifprint;
	
    /** 是否为特价航班;0特价 1非特价 **/ 
	private String isspecialflight;
	
    /** 应付金额 **/ 
	private double payableAmount;
	
    /** 已付金额 **/ 
	private double paidAmount;
	
    /** 支付方式,是否已经支付（0 未支付 1 已经支付 2部分支付） **/ 
	private String paymentType;
	
    /** 票价级别 **/ 
	private String ticketlevel;
	
    /** 票价折扣 **/ 
	private String ticketdiscount;
	
    /** 起飞时间 **/ 
	private Date takeofftime;
	/** 第二段起飞时间 **/ 
	private Date takeofftime2;
	
    /** 到达时间 **/ 
	private Date arrivetime;
	
	/** 第二段到达时间 **/ 
	private Date arrivetime2;
	
    /** 起飞地 **/ 
	private String takeofflocus;
	
	/** 第二段起飞地 **/ 
	private String takeofflocus2;
	
    /** 到达地 **/ 
	private String arrivelocus;
	
	/** 第二段到达地 **/ 
	private String arrivelocus2;
	/** 客票到期日**/
	private Date endtime;
	

	/** 起飞地 中文**/ 
	private String takeofflocusname;
	
	
	/** 第二段起飞地中文名称**/ 
	private String takeofflocusname2;
	
	/** 到达地 中文**/ 
	private String arrivelocusname; 
	
	/** 第二段到达地中文名称**/ 
	private String arrivelocusname2; 
	
	private Date endTime; //客票到期日

	/** 航段信息ID,关联航程表的ID **/ 
	private long routeId;
	
    /** 其他费用 **/ 
	private double otherFee;
	
    /** 机票总金额 不包括保险费用**/ 
	private double ticketTotalAmount;
	
    /** 退改签摘要 **/ 
	private String ruleSummary;
	
    /** 结算状态,0:未结算
	1:结算成功
	2:结算失败 **/ 
	private String clearState;
	
    /** 供应商ID **/ 
	private long supplierId;
	
    /** 政策ID **/ 
	private long policyId;
	
    /** 代理商ID **/ 
	private long agentId;
	
    /** 返佣规则ID **/ 
	private long ruleId;
	
    /** 调账单ID,关联调账单 **/ 
	private long eransferbillId;
	
    /** 删除标志,0正常 1已删除 **/ 
	private String deleteSign;
	
    /** 乘客ID,关联乘客信息表 **/ 
	private long passengerId;
	
    /** 出票终端机的ID **/ 
	private long atmId;
	
    /** 订票office号 **/ 
	private String orderOfficeno;
	
    /** 挂起/解挂状态，默认1正常  0挂起 **/ 
	private String suspendStatus;
	
    /** 呼叫中心订票购物车ID,关联购物车表 **/ 
	private long flightCartId;
	
    /** PNR的ID，通过接口从航信获得 **/ 
	private String pnrId;
	
    /** 一站式订单编号 **/ 
	private String linkoskyOrder;
	
   
	
    /** 关联国际机票订票意向订单表 **/ 
	private long intOrderId;
	
    /** 采购返点,从航空公司B2B购买的票和一站式平台购买的票的返点值 **/ 
	private double buyRebate;
	/**出票途径**/
	private String saleType;
	
	/**备注**/
	private String remark;
	
    /** 舱位 **/ 
	private String cabin;
	/** 第二段舱位 **/ 
	private String cabin2;
	/**
	 * 行程单号
	 */
	private String receiptCode;
	/** 保险份数  **/
	private long insuranceNumber;
	
    /** 保险金额  **/
	private double insuranceAmount;
	/**
	 * 历史id
	 */
	private String historyid;
	
	/**
	 * 原始票号
	 */
	private String oldTicketNo;
	private Double ticketPricePm;//票面价
	
	
	
	public Double getTicketPricePm() {
		return ticketPricePm;
	}

	public void setTicketPricePm(Double ticketPricePm) {
		this.ticketPricePm = ticketPricePm;
	}

	public String getOldTicketNo() {
		return oldTicketNo;
	}

	public void setOldTicketNo(String oldTicketNo) {
		this.oldTicketNo = oldTicketNo;
	}

	public String getAirteamnum2() {
		return airteamnum2;
	}

	public void setAirteamnum2(String airteamnum2) {
		this.airteamnum2 = airteamnum2;
	}

	public Date getTakeofftime2() {
		return takeofftime2;
	}

	public void setTakeofftime2(Date takeofftime2) {
		this.takeofftime2 = takeofftime2;
	}

	public Date getArrivetime2() {
		return arrivetime2;
	}

	public void setArrivetime2(Date arrivetime2) {
		this.arrivetime2 = arrivetime2;
	}

	public String getTakeofflocus2() {
		return takeofflocus2;
	}

	public void setTakeofflocus2(String takeofflocus2) {
		this.takeofflocus2 = takeofflocus2;
	}

	public String getArrivelocus2() {
		return arrivelocus2;
	}

	public void setArrivelocus2(String arrivelocus2) {
		this.arrivelocus2 = arrivelocus2;
	}

	public String getTakeofflocusname2() {
		return takeofflocusname2;
	}

	public void setTakeofflocusname2(String takeofflocusname2) {
		this.takeofflocusname2 = takeofflocusname2;
	}

	public String getArrivelocusname2() {
		return arrivelocusname2;
	}

	public void setArrivelocusname2(String arrivelocusname2) {
		this.arrivelocusname2 = arrivelocusname2;
	}

	public String getCabin2() {
		return cabin2;
	}

	public void setCabin2(String cabin2) {
		this.cabin2 = cabin2;
	}

	public String getHistoryid() {
		return historyid;
	}

	public void setHistoryid(String historyid) {
		this.historyid = historyid;
	}
	
	public long getInsuranceNumber() {
		return insuranceNumber;
	}

	public void setInsuranceNumber(long insuranceNumber) {
		this.insuranceNumber = insuranceNumber;
	}

	public double getInsuranceAmount() {
		return insuranceAmount;
	}

	public void setInsuranceAmount(double insuranceAmount) {
		this.insuranceAmount = insuranceAmount;
	}

	public String getReceiptCode() {
		return receiptCode;
	}

	public void setReceiptCode(String receiptCode) {
		this.receiptCode = receiptCode;
	}

	private String ticketRealState; //OpenForUse = 0 CheckIn = 1 Used = 2 Print = 3 Void = -1 Refund = -2 Suspended = -3 NoTicket = -4  Error = -5

	public long getId() {
		return id;
	}

	public Date getEndtime() {
		return endtime;
	}

	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getTicketNo() {
		return ticketNo;
	}

	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public String getIsNational() {
		return isNational;
	}

	public void setIsNational(String isNational) {
		this.isNational = isNational;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public String getAirways() {
		return airways;
	}

	public void setAirways(String airways) {
		this.airways = airways;
	}

	public String getAirteamnum() {
		return airteamnum;
	}

	public void setAirteamnum(String airteamnum) {
		this.airteamnum = airteamnum;
	}

	public String getAirplanetype() {
		return airplanetype;
	}

	public void setAirplanetype(String airplanetype) {
		this.airplanetype = airplanetype;
	}

	public String getCabinLevel() {
		return cabinLevel;
	}

	public void setCabinLevel(String cabinLevel) {
		this.cabinLevel = cabinLevel;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public double getDrometax() {
		return drometax;
	}

	public void setDrometax(double drometax) {
		this.drometax = drometax;
	}

	public double getFueltax() {
		return fueltax;
	}

	public void setFueltax(double fueltax) {
		this.fueltax = fueltax;
	}

	public String getTickettype() {
		return tickettype;
	}

	public void setTickettype(String tickettype) {
		this.tickettype = tickettype;
	}

	public String getTicketstate() {
		return ticketstate;
	}

	public void setTicketstate(String ticketstate) {
		this.ticketstate = ticketstate;
	}

	public String getFlightType() {
		return flightType;
	}

	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}

	public String getVirtualTicketCode() {
		return virtualTicketCode;
	}

	public void setVirtualTicketCode(String virtualTicketCode) {
		this.virtualTicketCode = virtualTicketCode;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getSaleoffice() {
		return saleoffice;
	}

	public void setSaleoffice(String saleoffice) {
		this.saleoffice = saleoffice;
	}

	public Date getSaletime() {
		return saletime;
	}

	public void setSaletime(Date saletime) {
		this.saletime = saletime;
	}

	public String getIfsale() {
		return ifsale;
	}

	public void setIfsale(String ifsale) {
		this.ifsale = ifsale;
	}

	public String getIfprint() {
		return ifprint;
	}

	public void setIfprint(String ifprint) {
		this.ifprint = ifprint;
	}

	public String getIsspecialflight() {
		return isspecialflight;
	}

	public void setIsspecialflight(String isspecialflight) {
		this.isspecialflight = isspecialflight;
	}

	public double getPayableAmount() {
		return payableAmount;
	}

	public void setPayableAmount(double payableAmount) {
		this.payableAmount = payableAmount;
	}

	public double getPaidAmount() {
		return paidAmount;
	}

	public void setPaidAmount(double paidAmount) {
		this.paidAmount = paidAmount;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getTicketlevel() {
		return ticketlevel;
	}

	public void setTicketlevel(String ticketlevel) {
		this.ticketlevel = ticketlevel;
	}

	public String getTicketdiscount() {
		return ticketdiscount;
	}

	public void setTicketdiscount(String ticketdiscount) {
		this.ticketdiscount = ticketdiscount;
	}

	public Date getTakeofftime() {
		return takeofftime;
	}

	public void setTakeofftime(Date takeofftime) {
		this.takeofftime = takeofftime;
	}

	public Date getArrivetime() {
		return arrivetime;
	}

	public void setArrivetime(Date arrivetime) {
		this.arrivetime = arrivetime;
	}

	public String getTakeofflocus() {
		return takeofflocus;
	}

	public void setTakeofflocus(String takeofflocus) {
		this.takeofflocus = takeofflocus;
	}

	public String getArrivelocus() {
		return arrivelocus;
	}

	public void setArrivelocus(String arrivelocus) {
		this.arrivelocus = arrivelocus;
	}
	

    public String getTakeofflocusname() {
		return takeofflocusname;
	}

	public void setTakeofflocusname(String takeofflocusname) {
		this.takeofflocusname = takeofflocusname;
	}

	public String getArrivelocusname() {
		return arrivelocusname;
	}

	public void setArrivelocusname(String arrivelocusname) {
		this.arrivelocusname = arrivelocusname;
	}

	public long getRouteId() {
		return routeId;
	}

	public void setRouteId(long routeId) {
		this.routeId = routeId;
	}

	public double getOtherFee() {
		return otherFee;
	}

	public void setOtherFee(double otherFee) {
		this.otherFee = otherFee;
	}

	public double getTicketTotalAmount() {
		return ticketTotalAmount;
	}

	public void setTicketTotalAmount(double ticketTotalAmount) {
		this.ticketTotalAmount = ticketTotalAmount;
	}

	public String getRuleSummary() {
		return ruleSummary;
	}

	public void setRuleSummary(String ruleSummary) {
		this.ruleSummary = ruleSummary;
	}

	public String getClearState() {
		return clearState;
	}

	public void setClearState(String clearState) {
		this.clearState = clearState;
	}

	public long getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(long supplierId) {
		this.supplierId = supplierId;
	}

	public long getPolicyId() {
		return policyId;
	}

	public void setPolicyId(long policyId) {
		this.policyId = policyId;
	}

	public long getAgentId() {
		return agentId;
	}

	public void setAgentId(long agentId) {
		this.agentId = agentId;
	}

	public long getRuleId() {
		return ruleId;
	}

	public void setRuleId(long ruleId) {
		this.ruleId = ruleId;
	}

	public long getEransferbillId() {
		return eransferbillId;
	}

	public void setEransferbillId(long eransferbillId) {
		this.eransferbillId = eransferbillId;
	}

	public String getDeleteSign() {
		return deleteSign;
	}

	public void setDeleteSign(String deleteSign) {
		this.deleteSign = deleteSign;
	}

	public long getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(long passengerId) {
		this.passengerId = passengerId;
	}

	public long getAtmId() {
		return atmId;
	}

	public void setAtmId(long atmId) {
		this.atmId = atmId;
	}

	public String getOrderOfficeno() {
		return orderOfficeno;
	}

	public void setOrderOfficeno(String orderOfficeno) {
		this.orderOfficeno = orderOfficeno;
	}

	public String getSuspendStatus() {
		return suspendStatus;
	}

	public void setSuspendStatus(String suspendStatus) {
		this.suspendStatus = suspendStatus;
	}

	public long getFlightCartId() {
		return flightCartId;
	}

	public void setFlightCartId(long flightCartId) {
		this.flightCartId = flightCartId;
	}

	public String getPnrId() {
		return pnrId;
	}

	public void setPnrId(String pnrId) {
		this.pnrId = pnrId;
	}

	public String getLinkoskyOrder() {
		return linkoskyOrder;
	}

	public void setLinkoskyOrder(String linkoskyOrder) {
		this.linkoskyOrder = linkoskyOrder;
	}

	public long getIntOrderId() {
		return intOrderId;
	}

	public void setIntOrderId(long intOrderId) {
		this.intOrderId = intOrderId;
	}

	public double getBuyRebate() {
		return buyRebate;
	}

	public void setBuyRebate(double buyRebate) {
		this.buyRebate = buyRebate;
	}

	public String getCabin() {
		return cabin;
	}

	public void setCabin(String cabin) {
		this.cabin = cabin;
	}

	public String getSaleType() {
		return saleType;
	}

	public void setSaleType(String saleType) {
		this.saleType = saleType;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getTicketRealState() {
		return ticketRealState;
	}

	public void setTicketRealState(String ticketRealState) {
		this.ticketRealState = ticketRealState;
	}

	public String getAirplanetype2() {
		return airplanetype2;
	}

	public void setAirplanetype2(String airplanetype2) {
		this.airplanetype2 = airplanetype2;
	}

	public String getCabinLevel2() {
		return cabinLevel2;
	}

	public void setCabinLevel2(String cabinLevel2) {
		this.cabinLevel2 = cabinLevel2;
	}
	
	
	
}