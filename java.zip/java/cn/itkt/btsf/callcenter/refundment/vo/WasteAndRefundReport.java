package cn.itkt.btsf.callcenter.refundment.vo;

import java.io.Serializable;
import java.util.Date;


public class WasteAndRefundReport implements Serializable{
	private String saleoffice;//office号
	private String 	saletype;//出票类型
	private Float atmId;//设备号
	private Integer passengerType;//旅客类型
	private String 	ticketNo;//电子客票号
	private String 	passengerName;//乘机人
	private String 	receiptCode;//行程单号
	private Date saletime;//出票时间
	private Date proposerDate;//退票时间
	private Date takeofftime;//起飞时间
	private String airWays;//航空公司
	private String Airteamnum;//航班号
	private String cabinLevel;//仓位
	private String takeofflocusname;//始发地
	private String arrivelocusname;//到达地
    /** 海航优惠前票面价确定中**/
	/**航程**/
	private Double ticketPrice;//票面价
	private Double drometax;//机场税
	private Double fueltax;//燃油费
//	private Double ticketTotalAmount;//     票总价     相加
	private Integer acountIns;//保险张数
	private Double price;//保险价格
	private Double deductCash;//退手续费
	private Double deductCoin;//退畅达币
	private String payType;//收款方式   结算方式
	private Double PaidAmount;//收款金额
	/**收款合计     到账金额            到账畅达币* 退款合计 * 出账金额*/
	private Double refundCoin;//退畅达币
	private String proposerType;//01退票、02废票
	private Double fee;//手续费
	
	private Double returnlcdfeeratio;//畅达币返佣
	private String refundWay;//退款方式
	private Double exceptFee;//退款金额  ***
	private String bankcardNumber;//银行卡号
	private String refundVoluntary;//是否自愿退票(自愿:0,非自愿:1)
	/**返点        代理费      供应商结算价      结算方式        出票单位      海航订单号         E付卡流水号  **/
	private String orderNo;//订单编号
	private String remark;//备注
	private Double ticketPricepm;//海航优惠前票面价
	private Double payableAmount;//收款合计
	private Double totalAmount;//退款合计 ==出账金额
	private Double refundPoin;//返点
	private Double dailifee;//代理费
	private Double balancepayable;//供应商结算价
	private String clearobjectName;//出票单位
	private String externalorderno;//海航订单号
	private String outside_Serialno;//E付卡流水号
	public String getSaleoffice() {
		return saleoffice;
	}
	public void setSaleoffice(String saleoffice) {
		this.saleoffice = saleoffice;
	}
	public String getSaletype() {
		return saletype;
	}
	public void setSaletype(String saletype) {
		this.saletype = saletype;
	}
	public Float getAtmId() {
		return atmId;
	}
	public void setAtmId(Float atmId) {
		this.atmId = atmId;
	}
	public Integer getPassengerType() {
		return passengerType;
	}
	public void setPassengerType(Integer passengerType) {
		this.passengerType = passengerType;
	}
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getPassengerName() {
		return passengerName;
	}
	
	public String getProposerType() {
		return proposerType;
	}
	public void setProposerType(String proposerType) {
		this.proposerType = proposerType;
	}
	public String getRefundVoluntary() {
		return refundVoluntary;
	}
	public void setRefundVoluntary(String refundVoluntary) {
		this.refundVoluntary = refundVoluntary;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public String getReceiptCode() {
		return receiptCode;
	}
	public void setReceiptCode(String receiptCode) {
		this.receiptCode = receiptCode;
	}
	public Date getSaletime() {
		return saletime;
	}
	public void setSaletime(Date saletime) {
		this.saletime = saletime;
	}
	public Date getProposerDate() {
		return proposerDate;
	}
	public void setProposerDate(Date proposerDate) {
		this.proposerDate = proposerDate;
	}
	public Date getTakeofftime() {
		return takeofftime;
	}
	public void setTakeofftime(Date takeofftime) {
		this.takeofftime = takeofftime;
	}
	public String getAirWays() {
		return airWays;
	}
	public void setAirWays(String airWays) {
		this.airWays = airWays;
	}
	public String getAirteamnum() {
		return Airteamnum;
	}
	public void setAirteamnum(String airteamnum) {
		Airteamnum = airteamnum;
	}
	public String getCabinLevel() {
		return cabinLevel;
	}
	public void setCabinLevel(String cabinLevel) {
		this.cabinLevel = cabinLevel;
	}
	public String getTakeofflocusname() {
		return takeofflocusname;
	}
	public void setTakeofflocusname(String takeofflocusname) {
		this.takeofflocusname = takeofflocusname;
	}
	public String getArrivelocusname() {
		return arrivelocusname;
	}
	public void setArrivelocusname(String arrivelocusname) {
		this.arrivelocusname = arrivelocusname;
	}
	public Double getTicketPrice() {
		return ticketPrice;
	}
	public void setTicketPrice(Double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}
	public Double getDrometax() {
		return drometax;
	}
	public void setDrometax(Double drometax) {
		this.drometax = drometax;
	}
	public Double getFueltax() {
		return fueltax;
	}
	public void setFueltax(Double fueltax) {
		this.fueltax = fueltax;
	}

	public Double getReturnlcdfeeratio() {
		return returnlcdfeeratio;
	}
	public void setReturnlcdfeeratio(Double returnlcdfeeratio) {
		this.returnlcdfeeratio = returnlcdfeeratio;
	}
	public Integer getAcountIns() {
		return acountIns;
	}
	public void setAcountIns(Integer acountIns) {
		this.acountIns = acountIns;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Double getDeductCash() {
		return deductCash;
	}
	public void setDeductCash(Double deductCash) {
		this.deductCash = deductCash;
	}
	public Double getDeductCoin() {
		return deductCoin;
	}
	public void setDeductCoin(Double deductCoin) {
		this.deductCoin = deductCoin;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public Double getPaidAmount() {
		return PaidAmount;
	}
	public void setPaidAmount(Double paidAmount) {
		PaidAmount = paidAmount;
	}
	public Double getRefundCoin() {
		return refundCoin;
	}
	public void setRefundCoin(Double refundCoin) {
		this.refundCoin = refundCoin;
	}
	public Double getFee() {
		return fee;
	}
	public void setFee(Double fee) {
		this.fee = fee;
	}
	public String getRefundWay() {
		return refundWay;
	}
	public void setRefundWay(String refundWay) {
		this.refundWay = refundWay;
	}
	public Double getExceptFee() {
		return exceptFee;
	}
	public void setExceptFee(Double exceptFee) {
		this.exceptFee = exceptFee;
	}
	public String getBankcardNumber() {
		return bankcardNumber;
	}
	public void setBankcardNumber(String bankcardNumber) {
		this.bankcardNumber = bankcardNumber;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
}
