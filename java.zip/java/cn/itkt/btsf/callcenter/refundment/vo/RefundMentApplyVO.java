package cn.itkt.btsf.callcenter.refundment.vo;

import java.util.Date;

/**
 * 退款申请单
 * 
 * @author
 */
public class RefundMentApplyVO {

	/** 自增列 **/
	private long id;

	/** 申请单号 **/
	private String requisitionCode;

	/** 支付渠道,0:银联，1:快钱,2:支付宝 **/
	private String refundWay;
	/** 交易数量 **/
	private Integer trxCount;

	/** 原交易总金额 **/
	private Double totalAmount;

	/** 退款总金额 **/
	private Double refundAmount;
	/** 申请人ID **/
	private Integer proposerId;//
	/** 申请人姓名 **/
	private String proposerName;

	/** 申请日期 **/
	private Date proposerDate;
	/** 标记退款时间 **/
	private Date markDate;

	/** 申请类型 **/
	private String proposerType;

	/** 申请开始日期 **/
	private String startDate;

	/** 申请结束日期 **/
	private String endDate;

	/** 备注 **/
	private String remarks;

	/** 状态，0:创建中，1:已提交，2:已寄出，3：已退款 **/
	private String status;

	/** 生成退款申请单退款记录ID列表 **/
	private String ids;
	// 添加的两个字段
	/** 退款开始日期 **/
	private String tstartDate;

	/** 退款结束日期 **/
	private String tendDate;

	/** 退废开始时间 **/
	private String doneStartDate;

	/** 退废结束时间 **/
	private String doneEndDate;
	private Integer startIndex;
	private Integer pageSize;
	
	public Integer getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getDoneStartDate() {
		return doneStartDate;
	}

	public void setDoneStartDate(String doneStartDate) {
		this.doneStartDate = doneStartDate;
	}

	public String getDoneEndDate() {
		return doneEndDate;
	}

	public Date getMarkDate() {
		return markDate;
	}

	public void setMarkDate(Date markDate) {
		this.markDate = markDate;
	}

	public void setDoneEndDate(String doneEndDate) {
		this.doneEndDate = doneEndDate;
	}

	/**
	 * 构造
	 */
	public RefundMentApplyVO() {
	}

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProposerType() {
		return proposerType;
	}

	public void setProposerType(String proposerType) {
		this.proposerType = proposerType;
	}

	public Integer getTrxCount() {
		return trxCount;
	}

	public void setTrxCount(Integer trxCount) {
		this.trxCount = trxCount;
	}

	public Integer getProposerId() {
		return proposerId;
	}

	public void setProposerId(Integer proposerId) {
		this.proposerId = proposerId;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getRequisitionCode() {
		return requisitionCode;
	}

	public void setRequisitionCode(String requisitionCode) {
		this.requisitionCode = requisitionCode;
	}

	public String getRefundWay() {
		return refundWay;
	}

	public void setRefundWay(String refundWay) {
		this.refundWay = refundWay;
	}

	public String getProposerName() {
		return proposerName;
	}

	public void setProposerName(String proposerName) {
		this.proposerName = proposerName;
	}

	public Date getProposerDate() {
		return proposerDate;
	}

	public void setProposerDate(Date proposerDate) {
		this.proposerDate = proposerDate;
	}

	public Double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(Double refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTstartDate() {
		return tstartDate;
	}

	public void setTstartDate(String tstartDate) {
		this.tstartDate = tstartDate;
	}

	public String getTendDate() {
		return tendDate;
	}

	public void setTendDate(String tendDate) {
		this.tendDate = tendDate;
	}

}