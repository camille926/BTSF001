package cn.itkt.btsf.callcenter.refundment.vo;

import java.io.Serializable;
import java.util.Date;


/**
 * 退款申请单表 
 * @author codegen 2013-02-21 14:44:34 
 */
public class RefundmentVO {

    /** 自增列 **/ 
	private double id;
	
    /** 退款申请单编号 **/ 
	private String requisitionCode;
	
    /** 退款渠道(1:银联，2:快钱,3:非原路径 4;大客户卡;5:汇付,6:畅达币;7:不退款) **/ 
	private String refundWay;
	
    /** 交易数量(客票张数) **/ 
	private double trxCount;
	
    /** 原交易总金额(客票所在订单支付总金额) **/ 
	private double totalAmount;
	
    /** 退款总金额(不包括畅达币) **/ 
	private double refundAmount;
	
    /** 申请人id **/ 
	private double proposerId;
	
    /** 申请人姓名 **/ 
	private String proposerName;
	
    /** 申请日期 **/ 
	private Date proposerDate;
	
    /** 退款申请单状态(0:已提交,1:退款成功,2:退款失败,3:已寄出) **/ 
	private String status;
	
    /** 标记退款时间 **/ 
	private Date markDate;
	
    /** 备注 **/ 
	private String remarks;
	

	/**
	 * 构造 
	 */
	public RefundmentVO() {
	}
	

	public double getId() {
		return id;
	}

	public void setId(double id) {
		this.id = id;
	}
	public String getRequisitionCode() {
		return requisitionCode;
	}

	public void setRequisitionCode(String requisitionCode) {
		this.requisitionCode = requisitionCode;
	}
	public String getRefundWay() {
		return refundWay;
	}

	public void setRefundWay(String refundWay) {
		this.refundWay = refundWay;
	}
	public double getTrxCount() {
		return trxCount;
	}

	public void setTrxCount(double trxCount) {
		this.trxCount = trxCount;
	}
	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public double getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(double refundAmount) {
		this.refundAmount = refundAmount;
	}
	public double getProposerId() {
		return proposerId;
	}

	public void setProposerId(double proposerId) {
		this.proposerId = proposerId;
	}
	public String getProposerName() {
		return proposerName;
	}

	public void setProposerName(String proposerName) {
		this.proposerName = proposerName;
	}
	public Date getProposerDate() {
		return proposerDate;
	}

	public void setProposerDate(Date proposerDate) {
		this.proposerDate = proposerDate;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	public Date getMarkDate() {
		return markDate;
	}

	public void setMarkDate(Date markDate) {
		this.markDate = markDate;
	}
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

}