package cn.itkt.btsf.callcenter.refundment.po;

import java.io.Serializable;
import java.util.Date;
public class RefundmentConditionPO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String ticketno;//客票票号
	private String proposerName;//操作人
	private String approver;//退废票审批人员 ,
	
	private Date saletime;//出票时间
	private Date startSaletime;
	private Date endSaletime;
	private Date receiptMarkTime;//行程单标记时间
	private Date startreceiptMarkTime;
	private Date endreceiptMarkTime;
	//etermTime ETERM操作日期暂时无
	//支付方式暂时无
	//操作人？
	private Date donetime;//退费日期 
	private Date startdonetime;
	private Date enddonetime;
	private String passenger;//乘机人姓名
	private String accountn;//支付账号 
	private Double ticketMone;//票款
	private Double rate;//退票费率
	private Double refundCash;//应退金额
	private Double refundCoin;//应退现金
	private String receiptReturnType;//行程单返回方式 
	private String receiptMarkStaff;//行程单标记人员 
	private String receiptCode;//行程单号
	private String requisitionCode;//退票申请单编号
	private String refundWay;//退款渠道
	private Integer startIndex;//分页
	private Integer pageSize;//分页
	

	public Date getStartSaletime() {
		return startSaletime;
	}

	public void setStartSaletime(Date startSaletime) {
		this.startSaletime = startSaletime;
	}

	public Date getEndSaletime() {
		return endSaletime;
	}

	public void setEndSaletime(Date endSaletime) {
		this.endSaletime = endSaletime;
	}

	public Date getStartreceiptMarkTime() {
		return startreceiptMarkTime;
	}

	public void setStartreceiptMarkTime(Date startreceiptMarkTime) {
		this.startreceiptMarkTime = startreceiptMarkTime;
	}

	public Date getEndreceiptMarkTime() {
		return endreceiptMarkTime;
	}

	public void setEndreceiptMarkTime(Date endreceiptMarkTime) {
		this.endreceiptMarkTime = endreceiptMarkTime;
	}

	public Date getStartdonetime() {
		return startdonetime;
	}

	public void setStartdonetime(Date startdonetime) {
		this.startdonetime = startdonetime;
	}

	public Date getEnddonetime() {
		return enddonetime;
	}

	public void setEnddonetime(Date enddonetime) {
		this.enddonetime = enddonetime;
	}

	public String getRefundWay() {
		return refundWay;
	}

	public void setRefundWay(String refundWay) {
		this.refundWay = refundWay;
	}

	public Integer getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public Double getTicketMone() {
		return ticketMone;
	}

	public void setTicketMone(Double ticketMone) {
		this.ticketMone = ticketMone;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	
	public Double getRefundCash() {
		return refundCash;
	}

	public void setRefundCash(Double refundCash) {
		this.refundCash = refundCash;
	}

	public Double getRefundCoin() {
		return refundCoin;
	}

	public void setRefundCoin(Double refundCoin) {
		this.refundCoin = refundCoin;
	}
	
	public String getRequisitionCode() {
		return requisitionCode;
	}
	public void setRequisitionCode(String requisitionCode) {
		this.requisitionCode = requisitionCode;
	}
	
	public String getPassenger() {
		return passenger;
	}
	public void setPassenger(String passenger) {
		this.passenger = passenger;
	}
	public String getTicketno() {
		return ticketno;
	}
	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}
	public void setProposerName(String proposerName) {
		this.proposerName = proposerName;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public Date getSaletime() {
		return saletime;
	}

	public void setSaletime(Date saletime) {
		this.saletime = saletime;
	}

	public Date getReceiptMarkTime() {
		return receiptMarkTime;
	}

	public void setReceiptMarkTime(Date receiptMarkTime) {
		this.receiptMarkTime = receiptMarkTime;
	}

	public Date getDonetime() {
		return donetime;
	}

	public void setDonetime(Date donetime) {
		this.donetime = donetime;
	}

	public String getAccountn() {
		return accountn;
	}

	public void setAccountn(String accountn) {
		this.accountn = accountn;
	}

	public String getReceiptReturnType() {
		return receiptReturnType;
	}

	public void setReceiptReturnType(String receiptReturnType) {
		this.receiptReturnType = receiptReturnType;
	}

	public String getReceiptMarkStaff() {
		return receiptMarkStaff;
	}

	public void setReceiptMarkStaff(String receiptMarkStaff) {
		this.receiptMarkStaff = receiptMarkStaff;
	}


	public String getReceiptCode() {
		return receiptCode;
	}

	public void setReceiptCode(String receiptCode) {
		this.receiptCode = receiptCode;
	}

	public String getProposerName() {
		return proposerName;
	}
	
}
