package cn.itkt.btsf.callcenter.refundment.controller;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import cn.itkt.btsf.callcenter.refundment.vo.RefundMentApplyVO;
import cn.itkt.btsf.callcenter.refundment.vo.RefundmentConditionVO;
@Controller
@RequestMapping("/callcenter/refundment")
public class RefundmentController {

	@Resource
	private RefundmentControllerSupport refundmentControllerSupport;
/**
 * 
 * @param modelMap
 * @param refundmentConditionVO    退款申请单制作查询
 * @param startIndex
 * @return
 */
	@RequestMapping("queryRefundment")
	public String queryRefundment(ModelMap modelMap,
			@ModelAttribute("refundmentConditionVO") RefundmentConditionVO refundmentConditionVO,
			@RequestParam(value = "startIndex", defaultValue = "0") int startIndex) {
		refundmentControllerSupport.fundRefundmentall(modelMap,
				refundmentConditionVO, startIndex);
		modelMap.addAttribute("tKTRefundInfoVO", refundmentConditionVO);
		return "/callcenter/refundment/refundMent";
	}
	/**
	 * 
	 * @param modelMap
	 * @param request
	 * @param clickAllValues    生成退款申请单查询
	 * @param ticketNoList
	 * @return
	 */
	@RequestMapping("createRefundment")
	public String createRefundment(ModelMap modelMap, HttpServletRequest request,
			String clickAllValues,String ticketNoList){
		refundmentControllerSupport.createRefund(modelMap, request,clickAllValues, ticketNoList);
		return "/callcenter/refundment/createRefundSingle";
	}
	/**
	 * 
	 * @param refundMentApplyVO  退款申请单插入
	 * @param modelMap
	 * @param request
	 * @return
	 */
	@RequestMapping("insertRefundment")
	public String insertRefundment(@ModelAttribute RefundMentApplyVO refundMentApplyVO, ModelMap modelMap, HttpServletRequest request) {
		String remarks = request.getParameter("remarks");
		refundMentApplyVO.setRefundWay(remarks);
		try {
			refundmentControllerSupport.insertRefund(refundMentApplyVO);
			return "success";
		}catch(Exception ex) {
			return "error";
		}
	}
	/**
	 * 
	 * @param modelMap
	 * @param refundMentApplyVO  退款申请单查询
	 * @param startIndex
	 * @param request
	 * @return
	 */
	@RequestMapping("queryRefundmented")
	public String queryRefundmented(ModelMap modelMap,@ModelAttribute RefundMentApplyVO refundMentApplyVO,@RequestParam(value ="startIndex",defaultValue="0")int startIndex,HttpServletRequest request){
		String ok = request.getParameter("ok");
		modelMap.addAttribute("ok", ok);
		modelMap.addAttribute("refundApplyVO", refundMentApplyVO);
		refundmentControllerSupport.queryRefundment(modelMap, refundMentApplyVO, startIndex);
		return "/callcenter/refundment/quenyRefundment";
	}
	/**
	 * 
	 * @param modelMap
	 * @param requisitionCode  通过退款申请单点超链接查询
	 * @return
	 */
	@RequestMapping("queryDetail")
	public String queryDetail(ModelMap modelMap,String requisitionCode){
		refundmentControllerSupport.queryDetail(modelMap, requisitionCode);
		return "/callcenter/refundment/refundSingleDetail";
	}
	/**
	 * 
	 * @param modelMap
	 * @param requisitionCode  删除退款申请单
	 * @return
	 */
	@RequestMapping("delApplayReq")
	public String delApplayReq(ModelMap modelMap,String requisitionCode){
		try {
			refundmentControllerSupport.delApplayReq(modelMap, requisitionCode);
			return "success";
		} catch (Exception e) {
			return "error";
		}
	}
}