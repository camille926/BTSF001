package cn.itkt.btsf.callcenter.refundment.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import cn.itkt.btsf.callcenter.refundment.service.RefundmentService;
import cn.itkt.btsf.callcenter.refundment.vo.RefundMentApplyVO;
import cn.itkt.btsf.callcenter.refundment.vo.RefundMentFindDetilVO;
import cn.itkt.btsf.callcenter.refundment.vo.RefundmentConditionVO;
import cn.itkt.btsf.sys.security.vo.UserVO;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.pagination.Pages;

@Service
public class RefundmentControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(RefundmentControllerSupport.class);
	
	@Resource
	private  RefundmentService  refundmentService;
	public void fundRefundmentall(ModelMap modelMap,RefundmentConditionVO refundmentConditionVO,int startIndex){
		Pages pages = new Pages(startIndex);
		pages.setPageSize(10);
		refundmentConditionVO.setStartIndex(startIndex);
		refundmentConditionVO.setPageSize(pages.getPageSize());
		List<RefundmentConditionVO> list = refundmentService.fundRefundment(refundmentConditionVO);
		modelMap.addAttribute("list", list);
		pages.setItems(list);
		int totalCount=refundmentService.count(refundmentConditionVO);
		pages.setTotalCount(totalCount);
		modelMap.addAttribute("page", pages);
	}
	public void createRefund(ModelMap modelMap, HttpServletRequest request,String clickAllValues,String ticketNoList) {
		Map<String,Object> map = new HashMap<String,Object>();
		if(clickAllValues != null && !"".equals(clickAllValues)){
			//如果全选，那么按照退款渠道来全选退款信息生成退款申请单
			map.put("type", "0");
			map.put("clickAllValues", clickAllValues);
		}else{
			//如果不是全选，那么按照勾选的票id来选择退款信息生成退款申请单
			map.put("type", "1");
			map.put("ticketNoList", ticketNoList);
		}
		List<RefundmentConditionVO>list = refundmentService.queryCreateRefund(map);
		modelMap.addAttribute("refundList", list);
		RefundMentApplyVO refundApplyVO = new RefundMentApplyVO();
		refundApplyVO.setRequisitionCode(cn.itkt.btsf.util.DateUtil.getTimeSequence("SQD"));
		UserVO loginUser = LoginUtil.getLoginUser(request);
		refundApplyVO.setProposerName(loginUser.getName());
		refundApplyVO.setProposerId(loginUser.getId());
		refundApplyVO.setProposerDate(new Date());
		Double ticketMoney = 0D;
		Double exceptFee = 0D;
		ticketNoList = "";
		Double payLcd = 0D;
		for (int i = 0; i < list.size(); i++) {
			payLcd+=list.get(i).getRefundCoin();
			exceptFee += list.get(i).getRefundCash();
			ticketNoList += list.get(i).getTicketno()+",";
		}
		refundApplyVO.setTotalAmount(exceptFee+payLcd);
		refundApplyVO.setRefundAmount(exceptFee);
		refundApplyVO.setTrxCount(list.size());
		refundApplyVO.setIds(ticketNoList);
		refundApplyVO.setRefundWay(list.get(0).getRefundWay());
		modelMap.addAttribute("refundApplyVO", refundApplyVO);
	}
	public void insertRefund(RefundMentApplyVO refundMentApplyVO) {
		Map<String, Object>map = new HashMap<String, Object>();
		try {
			refundMentApplyVO.setProposerDate(new Date());
			refundmentService.insertRefund(refundMentApplyVO);
			int refundReqId = refundmentService.refundMaxId();
			map.put("refundReqId", refundReqId);
			map.put("refundStatus", 01);
			map.put("requisitionCode",refundMentApplyVO.getRequisitionCode());
			refundmentService.upRefundReqid(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void queryRefundment(ModelMap modelMap,RefundMentApplyVO refundMentApplyVO,int startIndex) {
		Pages pages = new Pages(startIndex);
		pages.setPageSize(10);
		refundMentApplyVO.setStartIndex(startIndex);
		refundMentApplyVO.setPageSize(pages.getPageSize());
		List<RefundMentApplyVO>list=refundmentService.queryRefundment(refundMentApplyVO);
		modelMap.addAttribute("listRefund", list);
		pages.setItems(list);
		int totalCount=refundmentService.countRefundment(refundMentApplyVO);
		pages.setTotalCount(totalCount);
		modelMap.addAttribute("page", pages);
	}
	public void queryDetail(ModelMap modelMap,String requisitionCode) {
		Map<String,Object>map = new HashMap<String, Object>();
		map.put("requisitionCode", requisitionCode);
		List<RefundMentFindDetilVO> list = refundmentService.findDetail(map);
		modelMap.addAttribute("list", list);
	}
	public void delApplayReq(ModelMap modelMap,String requisitionCode) {
		Map<String, Object>map = new HashMap<String, Object>();
		map.put("requisitionCode", requisitionCode);
		refundmentService.delApplayReq(map);
		map.put("refundReqId","");
		map.put("refundStatus", 00);
		map.put("requisitionCode",requisitionCode);
		refundmentService.upRefundReqid(map);
	}
}