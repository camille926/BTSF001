package cn.itkt.btsf.callcenter.refundment.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

import cn.itkt.btsf.callcenter.refundment.po.RefundmentPO;
import cn.itkt.btsf.callcenter.refundment.dao.RefundmentDao;
import cn.itkt.btsf.callcenter.refundment.service.RefundmentService;
import cn.itkt.btsf.callcenter.refundment.vo.RefundMentApplyVO;
import cn.itkt.btsf.callcenter.refundment.vo.RefundMentFindDetilVO;
import cn.itkt.btsf.callcenter.refundment.vo.RefundmentConditionVO;

@Service
public class RefundmentServiceImpl implements RefundmentService {

	private static final Logger log = LoggerFactory.getLogger(RefundmentServiceImpl.class);
	
	@Resource
	private  RefundmentDao  refundmentDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return Refundment 
	 */
	public RefundmentPO find(Serializable id){
		return refundmentDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<RefundmentPO> 
	 */
	public List<RefundmentPO> findAll(){
		return refundmentDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(rollbackFor={Exception.class})
	public void create(RefundmentPO po) throws AppException{
		try{
			if( po != null )
				 refundmentDao.create(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(RefundmentPO po) throws AppException {
		try{
			if( po != null )
				 refundmentDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 refundmentDao.delete(id);
	}

	@Override
	public List<RefundmentConditionVO> fundRefundment(RefundmentConditionVO vo) {
		// TODO Auto-generated method stub
		return refundmentDao.fundRefundment(vo);
	}

	@Override
	public int count(RefundmentConditionVO vo) {
		// TODO Auto-generated method stub
		return refundmentDao.count(vo);
	}

	@Override
	public List<RefundmentConditionVO> queryCreateRefund(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return refundmentDao.queryCreateRefund(map);
	}

	@Override
	public boolean insertRefund(RefundMentApplyVO vo) {
		// TODO Auto-generated method stub
		return refundmentDao.insertRefund(vo);
	}

	@Override
	public List<RefundMentApplyVO> queryRefundment(RefundMentApplyVO vo) {
		// TODO Auto-generated method stub
		return refundmentDao.queryRefundment(vo);
	}

	@Override
	public int countRefundment(RefundMentApplyVO vo) {
		// TODO Auto-generated method stub
		return refundmentDao.countRefundment(vo);
	}

	@Override
	public List<RefundMentFindDetilVO> findDetail(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return refundmentDao.findDetail(map);
	}

	@Override
	public int refundMaxId() {
		// TODO Auto-generated method stub
		return refundmentDao.refundMaxId();
	}

	@Override
	public boolean upRefundReqid(Map<String, Object> map) {
		return refundmentDao.upRefundReqid(map);
	}

	@Override
	public boolean delApplayReq(Map<String, Object> map) {
		// TODO Auto-generated method stub
		return refundmentDao.delApplayReq(map);
	}

	@Override
	public List<String> getOfficeName() {
		// TODO Auto-generated method stub
		return refundmentDao.getOfficeName();
	}
}