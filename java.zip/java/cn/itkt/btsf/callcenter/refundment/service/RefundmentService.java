package cn.itkt.btsf.callcenter.refundment.service;

import java.io.Serializable;
import java.util.List;
import java.util.Date;
import java.util.Map;

import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

import cn.itkt.btsf.callcenter.refundment.po.RefundmentPO;
import cn.itkt.btsf.callcenter.refundment.vo.RefundMentApplyVO;
import cn.itkt.btsf.callcenter.refundment.vo.RefundMentFindDetilVO;
import cn.itkt.btsf.callcenter.refundment.vo.RefundmentConditionVO;

public interface RefundmentService {

	/**
	 * 查找单个 
	 * @param id 
	 * @return Refundment 
	 */
	public RefundmentPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<RefundmentPO> 
	 */
	public List<RefundmentPO> findAll();

	/**
	 * 创建 
	 * @param po
	 */
	public void create(RefundmentPO po) throws AppException;

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(RefundmentPO po) throws AppException;

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);

	/**
	 * 查询退款信息
	 */
    public List<RefundmentConditionVO>fundRefundment(RefundmentConditionVO vo);
    /**
     * 查询记录条数
     */
    public int count(RefundmentConditionVO vo);
    /**
     * 生成退款申请单查询
     */
    public List<RefundmentConditionVO> queryCreateRefund(Map<String,Object>map);
    /**
     * 插入退款申请单数据
     */
    public boolean insertRefund(RefundMentApplyVO vo);
    /**
	 * 查询退款申请单
	 */
    public List<RefundMentApplyVO> queryRefundment(RefundMentApplyVO vo);
    /**
     * 查询退款申请总记录
     */
    public int countRefundment(RefundMentApplyVO vo);
    /**
	 * 查询详细信息
	 */
    public List<RefundMentFindDetilVO> findDetail(Map<String,Object>map);
    /**
     * 查询最大ID退款票表
     */
    public int  refundMaxId();
    /**
     * 插入时修改退票表状态
     */
    public boolean upRefundReqid(Map<String, Object>map);
    /**
     * 根据申请单编号删除退款申请单
     */
    public boolean delApplayReq(Map<String, Object>map);
    /**
     * 报表查询
     * @return
     */
    public List<String> getOfficeName();
}