package cn.itkt.btsf.callcenter.refundandwaste.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


/**
 * 国内退废票申请表 
 * @author codegen 2013-02-21 15:25:30 
 */
public class RefundAndWasteTicketVO {

    /** ID **/ 
	private long id;
	
    /** 申请单编号 **/ 
	private String requisitionCode;
	
    /** 申请人ID **/ 
	private long proposerId;
	
    /** 申请人姓名,冗余字段 **/ 
	private String proposerName;
	
    /** 申请时间 **/ 
	private Date proposerDate;
	
    /** 申请类型,01退票、02废票 **/ 
	private String proposerType;
	
    /** 申请单状态:00已录入,01已审核,02已标记收到行程单,03已退票,04审核不通过,05已修改,06未标记收到行程单07已废票,08已注销 **/ 
	private String nodeName;
	
    /** 票ID **/ 
	private long ticketId;
	
    /** 票号 **/ 
	private String ticketNo;
	
	/** 订单id **/ 
	private String orderId;
	
    /** 工作流流程实例ID **/ 
	private String processId;
	
    /** 退款申请单id **/ 
	private long refundReqId;
	
    /** 退款方式 **/ 
	private String refundWay;
	
    /** 票款(票价+机建+燃油) **/ 
	private double ticketMoney;
	
    /** 手续费率 **/ 
	private double rate;
	
    /** 手续费(应扣现金+应扣畅达币) **/ 
	private double fee;
	
    /** 应退现金 **/ 
	private double refundCash;
	
    /** 应退畅达币 **/ 
	private String refundCoin;
	
    /** 应扣现金 **/ 
	private double deductCash;
	
    /** 应扣畅达币 **/ 
	private double deductCoin;
	
    /** 退保险金额 **/ 
	private double insurance;
	
    /** 是否发送短信0:否1:是 **/ 
	private String needSms;
	
    /** 是否需要退票单:0:否1:是 **/ 
	private String needBill;
	
    /** 行程单标记时间 **/ 
	private Date receiptMarkTime;
	
    /** 行程单标记人员 **/ 
	private String receiptMarkStaff;
	
    /** 行程单号 **/ 
	private String receiptCode;
	
    /** 行程单返还方式(1:遗失2:邮寄3:分公司代收4:未打印5:月结6:不需要代收7:其他) **/ 
	private String receiptReturnType;
	
    /** 退废票审批人员 **/ 
	private String approver;
	
    /** 邮寄/配送地址 **/ 
	private String billSendAddress;
	
    /** 邮编 **/ 
	private String billPostCode;
	
    /** 收件人 **/ 
	private String billRecipient;
	
    /** 邮寄方式，1快递 2挂号信 3平信 **/ 
	private String billPostType;
	
    /** 持卡人姓名 **/ 
	private String putcardName;
	
    /** 开户行所在地 **/ 
	private String opencardPlace;
	
    /** 卡号 **/ 
	private String bankcardNumber;
	
    /** 短信发送方式,0订票人 1乘机人 2其他 多选 **/ 
	private String smsType;
	
    /** 短信发送方式值为3时，其他人姓名 **/ 
	private String smsManname;
	
    /** 短信发送方式值为3时，其他人手机号 **/ 
	private String smsMannumber;
	
    /** 退票单打印状态, 1.未打印 2.已打印 **/ 
	private String printStatus;
	
    /** 是否加急0：不加急；1：加急 **/ 
	private String ifoutdate;
	
    /** 附件名称 **/ 
	private String fileName;
	
    /** 是否按退票处理(0:否,1:是) **/ 
	private String ifrefund;
	
    /** 是否全退畅达币(0:否1:是) **/ 
	private String needRefundfee;
	
    /** 旅客姓名 **/ 
	private String passenger;
	
    /** 是否自愿退票(自愿:0,非自愿:1) **/ 
	private String refundVoluntary;
	
    /** 备注 **/ 
	private String remark;
	
	/** 退款状态**/
	private String refundstatus;

	/**
	 * 构造 
	 */
	public RefundAndWasteTicketVO() {
	}
	
	public Map<String,Object> getRefundAndWasteTicketPOToMap() {
		Map<String, Object> propMap = new HashMap<String,Object>();
		propMap.put("rate", rate);
		propMap.put("fee", fee);
		propMap.put("refundVoluntary", refundVoluntary);
		propMap.put("deductCash", deductCash);
		propMap.put("deductCoin", deductCoin);
		propMap.put("refundCash", refundCash);
		propMap.put("refundCoin", refundCoin);
		propMap.put("refundWay", refundWay);
		return propMap;
	}
	
	public String getRequisitionCode() {
		return requisitionCode;
	}

	public void setRequisitionCode(String requisitionCode) {
		this.requisitionCode = requisitionCode;
	}
	public String getProposerName() {
		return proposerName;
	}

	public String getRefundstatus() {
		return refundstatus;
	}


	public void setRefundstatus(String refundstatus) {
		this.refundstatus = refundstatus;
	}


	public void setProposerName(String proposerName) {
		this.proposerName = proposerName;
	}
	public Date getProposerDate() {
		return proposerDate;
	}

	public void setProposerDate(Date proposerDate) {
		this.proposerDate = proposerDate;
	}
	public String getProposerType() {
		return proposerType;
	}

	public void setProposerType(String proposerType) {
		this.proposerType = proposerType;
	}
	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}
	public String getTicketNo() {
		return ticketNo;
	}

	public String getRefundCoin() {
		return refundCoin;
	}


	public void setRefundCoin(String refundCoin) {
		this.refundCoin = refundCoin;
	}


	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	
	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public long getProposerId() {
		return proposerId;
	}


	public void setProposerId(long proposerId) {
		this.proposerId = proposerId;
	}


	public long getTicketId() {
		return ticketId;
	}


	public void setTicketId(long ticketId) {
		this.ticketId = ticketId;
	}


	public long getRefundReqId() {
		return refundReqId;
	}


	public void setRefundReqId(long refundReqId) {
		this.refundReqId = refundReqId;
	}


	public String getRefundWay() {
		return refundWay;
	}

	public void setRefundWay(String refundWay) {
		this.refundWay = refundWay;
	}
	public double getTicketMoney() {
		return ticketMoney;
	}

	public void setTicketMoney(double ticketMoney) {
		this.ticketMoney = ticketMoney;
	}
	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}
	public double getFee() {
		return fee;
	}

	public void setFee(double fee) {
		this.fee = fee;
	}
	public double getRefundCash() {
		return refundCash;
	}

	public void setRefundCash(double refundCash) {
		this.refundCash = refundCash;
	}


	public double getDeductCash() {
		return deductCash;
	}

	public void setDeductCash(double deductCash) {
		this.deductCash = deductCash;
	}
	public double getDeductCoin() {
		return deductCoin;
	}

	public void setDeductCoin(double deductCoin) {
		this.deductCoin = deductCoin;
	}
	public double getInsurance() {
		return insurance;
	}

	public void setInsurance(double insurance) {
		this.insurance = insurance;
	}
	public String getNeedSms() {
		return needSms;
	}

	public void setNeedSms(String needSms) {
		this.needSms = needSms;
	}
	public String getNeedBill() {
		return needBill;
	}

	public void setNeedBill(String needBill) {
		this.needBill = needBill;
	}
	public Date getReceiptMarkTime() {
		return receiptMarkTime;
	}

	public void setReceiptMarkTime(Date receiptMarkTime) {
		this.receiptMarkTime = receiptMarkTime;
	}
	public String getReceiptMarkStaff() {
		return receiptMarkStaff;
	}

	public void setReceiptMarkStaff(String receiptMarkStaff) {
		this.receiptMarkStaff = receiptMarkStaff;
	}
	public String getReceiptCode() {
		return receiptCode;
	}

	public void setReceiptCode(String receiptCode) {
		this.receiptCode = receiptCode;
	}
	public String getReceiptReturnType() {
		return receiptReturnType;
	}

	public void setReceiptReturnType(String receiptReturnType) {
		this.receiptReturnType = receiptReturnType;
	}
	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}
	public String getBillSendAddress() {
		return billSendAddress;
	}

	public void setBillSendAddress(String billSendAddress) {
		this.billSendAddress = billSendAddress;
	}
	public String getBillPostCode() {
		return billPostCode;
	}

	public void setBillPostCode(String billPostCode) {
		this.billPostCode = billPostCode;
	}
	public String getBillRecipient() {
		return billRecipient;
	}

	public void setBillRecipient(String billRecipient) {
		this.billRecipient = billRecipient;
	}
	public String getBillPostType() {
		return billPostType;
	}

	public void setBillPostType(String billPostType) {
		this.billPostType = billPostType;
	}
	public String getPutcardName() {
		return putcardName;
	}

	public void setPutcardName(String putcardName) {
		this.putcardName = putcardName;
	}
	public String getOpencardPlace() {
		return opencardPlace;
	}

	public void setOpencardPlace(String opencardPlace) {
		this.opencardPlace = opencardPlace;
	}
	public String getBankcardNumber() {
		return bankcardNumber;
	}

	public void setBankcardNumber(String bankcardNumber) {
		this.bankcardNumber = bankcardNumber;
	}
	public String getSmsType() {
		return smsType;
	}

	public void setSmsType(String smsType) {
		this.smsType = smsType;
	}
	public String getSmsManname() {
		return smsManname;
	}

	public void setSmsManname(String smsManname) {
		this.smsManname = smsManname;
	}
	public String getSmsMannumber() {
		return smsMannumber;
	}

	public void setSmsMannumber(String smsMannumber) {
		this.smsMannumber = smsMannumber;
	}
	public String getPrintStatus() {
		return printStatus;
	}


	public void setPrintStatus(String printStatus) {
		this.printStatus = printStatus;
	}


	public String getIfoutdate() {
		return ifoutdate;
	}

	public void setIfoutdate(String ifoutdate) {
		this.ifoutdate = ifoutdate;
	}
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getIfrefund() {
		return ifrefund;
	}

	public void setIfrefund(String ifrefund) {
		this.ifrefund = ifrefund;
	}
	public String getNeedRefundfee() {
		return needRefundfee;
	}

	public void setNeedRefundfee(String needRefundfee) {
		this.needRefundfee = needRefundfee;
	}
	public String getPassenger() {
		return passenger;
	}

	public void setPassenger(String passenger) {
		this.passenger = passenger;
	}
	public String getRefundVoluntary() {
		return refundVoluntary;
	}

	public void setRefundVoluntary(String refundVoluntary) {
		this.refundVoluntary = refundVoluntary;
	}
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}