package cn.itkt.btsf.callcenter.refundandwaste.vo;

public class ApplicationVO {
	//退废方式
	public static final String REFUND = "01";//退票
	public static final String WASTE = "02";//废票
	
	//退废申请单是否打印
	public static final String UNPRINT = "1";//未打印
	public static final String PRINT = "2";//已打印
	
	//退废申请单状态
	public static final String NODE_NAME_SUBMIT = "00";//已提交
	public static final String NODE_NAME_CANCEL = "00";//注销
	
	//退废申请单是否加急
	public static final String NOTOUTDATE = "0";//不加急
	public static final String ISOUTDATE = "1";//加急
	
	//退废申请单流程图KEY
	public static final String STARTPROCESSKEY_REFUND = "InternalRefundTicket";//国内退票
	public static final String STARTPROCESSKEY_WASTE = "InternalWasteTicket";//国内废票
	
	//退废申请单历史记录结果
	public static final String RESULT_START = "06";//启动
	public static final String RESULT_UPDATE = "07";//修改
	public static final String RESULT_CANCEL = "11";//注销
	
	//退票申请单历史审批记录任务名称
	public static final String TASKNAME_RECORDED = "录入";//已录入
	public static final String TASKNAME_RETURNLCDCOIN = "全退畅达币";//全退畅达币
	public static final String TASKNAME_CANCEL = "注销";//注销
	public static final String TASKNAME_UPDATE = "修改";//修改
	
	//流程审批记录建议值
	public static final String ADVICE_START = "已启动审批流程";//启动
	public static final String ADVICE_LCDCOINNUM = "(退畅达币数量)";//退畅达币数量
	
	//退款处理人
	public static final String AUTHORNAME_SYSTEMAUTO = "系统自动";//系统自动
	
	//退废原因
	public static final String REFUNDSEASON_VOLUNTARY = "0";//自愿
	public static final String REFUNDSEASON_UNVOLUNTARY = "1";//非自愿
	
	//申请单处理结果提示内容
	public static final String SUBMIT_SUCCESS = "申请单提交成功";//申请单提交提示成功
	public static final String APPROVAL_SUCCESS = "审批提交成功";//审批提交成功
	public static final String APPROVAL_FAIL = "审批提交失败";//审批提交失败
	public static final String CANCEL_SUCCESS = "注销申请单成功";//注销申请单成功
	public static final String CANCEL_FAIL = "注销申请单失败";//注销申请单失败
	public static final String UPDATE_SUCCESS = "申请单修改成功";//申请单提交修改成功
	public static final String UPDATE_FAIL = "申请单修改失败";//申请单提交修改失败
	
	//订单支付方式
	public static final String PAY_TRUST = "TRUST";//授信支付
	public static final String PAY_COIN = "COIN";//畅达币支付
	
	//支付流水支付方式
	public static final String PAYMENT_COIN = "22";//畅达币支付
	
	//退废申请单退款方式
	public static final String REFUNDTYPE_ORG = "0";//按付款方式退款
	public static final String REFUNDTYPE_UNORG = "1";//非原路径
	public static final String REFUNDTYPE_UNREFUND = "2";//不退款
	public static final String REFUNDTYPE_ALLCOIN = "3";//全退畅达币
	
	//现金退款方式
	public static final String CASHREFUNDTYPE_UNORG = "3";//非原路径
	public static final String CASHREFUNDTYPE_UNREFUND = "7";//不退款
	
	
	
}
