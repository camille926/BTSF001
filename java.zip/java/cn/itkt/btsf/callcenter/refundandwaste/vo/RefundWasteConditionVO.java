package cn.itkt.btsf.callcenter.refundandwaste.vo;

import java.io.Serializable;
import java.util.Date;

import org.jbpm.api.task.Task;

public class RefundWasteConditionVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;//申请单id
	private String requisitionCode;//退票申请单编号
	private String nodename;//退票申请单状态
	private String orderNo;//订单编号
	private String passenger;//乘机人姓名
	private String ticketno;//客票票号
	private String orderId;//客票ID
	private String takeofftimeStart;//乘机日期
	private Date takeofftime;
	private String takeofftimeend;//乘机日期
	private String takeofflocus;//出发城市
	private String airteamnum;//航班号
	private String arrivelocus;//目的城市
	private String cabinLevel;//舱位
	private String clearobjectName;//客户名称
	private Date proposerDate;//退票申请时间
	private String proposerName;//退票申请人
	private String identityCardNo;//证件号码
	private Double mobile;//手机号码
	private Integer channer;//订单来源
	private String pnr;//
	private Integer clearobjectType;//客户类型
	private String createtimeStart;//订单日期
	private Date createtime;
	private String createtimeend;//订单日期
	private Integer clearobjectId;//会员编号
	private Integer saletype;//出票途径
	private Integer returndstatus;//退款状态
	private String proposerType;//退票或者废票01退票、02废票
	private String bt3;
	private Integer startIndex;//分页
	private Integer pageSize;//分页
	private String jbpmId;//jbpmId
	private Task task;;//任务
	private String processId;
	private String stase;//根据该字段查询主管修改信息
	/**
	 * 导出数据所需要的新字段
	 */
	private Double drometax;//机建税 DROMETAX
	private Double fueltax;//燃油税FUELTAX
	private Double ticketPrice;//票面价
	private Double ticketMone;//票款
	private Double insurance;//保险
	private Double fee;//退票费
	private Double rate;//退票费率
	private Double deductCoin;//应扣畅达币
	private Double refundCash;//应退金额
	private Double refundCoin;//应退现金
	private Double deductCash;//应扣现金
	public Double getDrometax() {
		return drometax;
	}

	public Double getDeductCash() {
		return deductCash;
	}

	public void setDeductCash(Double deductCash) {
		this.deductCash = deductCash;
	}

	public void setDrometax(Double drometax) {
		this.drometax = drometax;
	}

	public Double getFueltax() {
		return fueltax;
	}

	public void setFueltax(Double fueltax) {
		this.fueltax = fueltax;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(Double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}

	public Double getTicketMone() {
		return ticketMone;
	}

	public void setTicketMone(Double ticketMone) {
		this.ticketMone = ticketMone;
	}

	public Double getInsurance() {
		return insurance;
	}

	public void setInsurance(Double insurance) {
		this.insurance = insurance;
	}

	public Double getFee() {
		return fee;
	}

	public void setFee(Double fee) {
		this.fee = fee;
	}

	public Double getRate() {
		return rate;
	}

	public void setRate(Double rate) {
		this.rate = rate;
	}

	public Double getDeductCoin() {
		return deductCoin;
	}

	public void setDeductCoin(Double deductCoin) {
		this.deductCoin = deductCoin;
	}

	public Double getRefundCash() {
		return refundCash;
	}

	public void setRefundCash(Double refundCash) {
		this.refundCash = refundCash;
	}

	public Double getRefundCoin() {
		return refundCoin;
	}

	public void setRefundCoin(Double refundCoin) {
		this.refundCoin = refundCoin;
	}

	public String getStase() {
		return stase;
	}

	public void setStase(String stase) {
		this.stase = stase;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public Task getTask() {
		return task;
	}

	public void setTask(Task task) {
		this.task = task;
	}

	public String getJbpmId() {
		return jbpmId;
	}

	public void setJbpmId(String jbpmId) {
		this.jbpmId = jbpmId;
	}

	public Integer getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getBt3() {
		return bt3;
	}

	public void setBt3(String bt3) {
		this.bt3 = bt3;
	}

	public String getProposerType() {
		return proposerType;
	}

	public void setProposerType(String proposerType) {
		this.proposerType = proposerType;
	}

	public RefundWasteConditionVO(){
		
	}
	
	public String getIdentityCardNo() {
		return identityCardNo;
	}

	public void setIdentityCardNo(String identityCardNo) {
		this.identityCardNo = identityCardNo;
	}

	public Double getMobile() {
		return mobile;
	}

	public void setMobile(Double mobile) {
		this.mobile = mobile;
	}

	public Integer getChanner() {
		return channer;
	}

	public void setChanner(Integer channer) {
		this.channer = channer;
	}

	public String getPnr() {
		return pnr;
	}

	public Date getTakeofftime() {
		return takeofftime;
	}

	public void setTakeofftime(Date takeofftime) {
		this.takeofftime = takeofftime;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public Integer getClearobjectType() {
		return clearobjectType;
	}

	public void setClearobjectType(Integer clearobjectType) {
		this.clearobjectType = clearobjectType;
	}
	public Integer getClearobjectId() {
		return clearobjectId;
	}

	public void setClearobjectId(Integer clearobjectId) {
		this.clearobjectId = clearobjectId;
	}

	public Integer getSaletype() {
		return saletype;
	}

	public void setSaletype(Integer saletype) {
		this.saletype = saletype;
	}

	public Integer getReturndstatus() {
		return returndstatus;
	}

	public void setReturndstatus(Integer returndstatus) {
		this.returndstatus = returndstatus;
	}

	public String getRequisitionCode() {
		return requisitionCode;
	}
	public void setRequisitionCode(String requisitionCode) {
		this.requisitionCode = requisitionCode;
	}
	public String getNodename() {
		return nodename;
	}
	public void setNodename(String nodename) {
		this.nodename = nodename;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getPassenger() {
		return passenger;
	}
	public void setPassenger(String passenger) {
		this.passenger = passenger;
	}
	public String getTicketno() {
		return ticketno;
	}
	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}

	public String getTakeofftimeStart() {
		return takeofftimeStart;
	}

	public void setTakeofftimeStart(String takeofftimeStart) {
		this.takeofftimeStart = takeofftimeStart;
	}

	public String getTakeofftimeend() {
		return takeofftimeend;
	}

	public void setTakeofftimeend(String takeofftimeend) {
		this.takeofftimeend = takeofftimeend;
	}

	public String getCreatetimeStart() {
		return createtimeStart;
	}

	public void setCreatetimeStart(String createtimeStart) {
		this.createtimeStart = createtimeStart;
	}

	public String getCreatetimeend() {
		return createtimeend;
	}

	public void setCreatetimeend(String createtimeend) {
		this.createtimeend = createtimeend;
	}

	public String getTakeofflocus() {
		return takeofflocus;
	}
	public void setTakeofflocus(String takeofflocus) {
		this.takeofflocus = takeofflocus;
	}
	public String getAirteamnum() {
		return airteamnum;
	}
	public void setAirteamnum(String airteamnum) {
		this.airteamnum = airteamnum;
	}
	public String getArrivelocus() {
		return arrivelocus;
	}
	public void setArrivelocus(String arrivelocus) {
		this.arrivelocus = arrivelocus;
	}
	public String getCabinLevel() {
		return cabinLevel;
	}
	public void setCabinLevel(String cabinLevel) {
		this.cabinLevel = cabinLevel;
	}
	
	public String getClearobjectName() {
		return clearobjectName;
	}
	public void setClearobjectName(String clearobjectName) {
		this.clearobjectName = clearobjectName;
	}
	public Date getProposerDate() {
		return proposerDate;
	}
	public void setProposerDate(Date proposerDate) {
		this.proposerDate = proposerDate;
	}
	public String getProposerName() {
		return proposerName;
	}
	public void setProposerName(String proposerName) {
		this.proposerName = proposerName;
	}
	
}
