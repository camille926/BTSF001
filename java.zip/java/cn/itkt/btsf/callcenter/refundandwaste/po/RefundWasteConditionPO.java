package cn.itkt.btsf.callcenter.refundandwaste.po;

import java.io.Serializable;
import java.util.Date;

public class RefundWasteConditionPO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String requisitionCode;//退票申请单编号
	private String nodename;//退票申请单状态
	private String orderNo;//订单编号
	private String passenger;//乘机人姓名
	private String ticketno;//客票票号
	private Date takeofftimeStart;//乘机日期
	private Date takeofftime;
	private Date takeofftimeend;//乘机日期
	private String takeofflocus;//出发城市
	private String airteamnum;//航班号
	private String arrivelocus;//目的城市
	private String cabinLevel;//舱位
	private String clearobjectName;//客户名称
	private Date proposerDate;//退票申请时间
	private String proposerName;//退票申请人
	private String identityCardNo;//证件号码
	private Double mobile;//手机号码
	private Integer channer;//订单来源
	private String pnr;//
	private Integer clearobjectType;//客户类型
	private Date createtimeStart;//订单日期
	private Date createtime;
	private Date createtimeend;//订单日期
	private Integer clearobjectId;//会员编号
	private Integer saletype;//出票途径
	private Integer returndstatus;//退款状态
	private String proposerType;//退票或者废票01退票、02废票
	private String bt3;
	private Integer startIndex;
	private Integer pageSize;
	
	public String getBt3() {
		return bt3;
	}

	public void setBt3(String bt3) {
		this.bt3 = bt3;
	}

	public Integer getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(Integer startIndex) {
		this.startIndex = startIndex;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getProposerType() {
		return proposerType;
	}

	public void setProposerType(String proposerType) {
		this.proposerType = proposerType;
	}

	public RefundWasteConditionPO(){
		
	}
	
	public String getIdentityCardNo() {
		return identityCardNo;
	}

	public void setIdentityCardNo(String identityCardNo) {
		this.identityCardNo = identityCardNo;
	}

	public Double getMobile() {
		return mobile;
	}

	public void setMobile(Double mobile) {
		this.mobile = mobile;
	}

	public Integer getChanner() {
		return channer;
	}

	public void setChanner(Integer channer) {
		this.channer = channer;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public Integer getClearobjectType() {
		return clearobjectType;
	}

	public void setClearobjectType(Integer clearobjectType) {
		this.clearobjectType = clearobjectType;
	}

	public Integer getClearobjectId() {
		return clearobjectId;
	}

	public void setClearobjectId(Integer clearobjectId) {
		this.clearobjectId = clearobjectId;
	}

	public Integer getSaletype() {
		return saletype;
	}

	public void setSaletype(Integer saletype) {
		this.saletype = saletype;
	}

	public Integer getReturndstatus() {
		return returndstatus;
	}

	public void setReturndstatus(Integer returndstatus) {
		this.returndstatus = returndstatus;
	}

	public String getRequisitionCode() {
		return requisitionCode;
	}
	public void setRequisitionCode(String requisitionCode) {
		this.requisitionCode = requisitionCode;
	}
	public String getNodename() {
		return nodename;
	}
	
	public Date getTakeofftime() {
		return takeofftime;
	}

	public void setTakeofftime(Date takeofftime) {
		this.takeofftime = takeofftime;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public void setNodename(String nodename) {
		this.nodename = nodename;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getPassenger() {
		return passenger;
	}
	public void setPassenger(String passenger) {
		this.passenger = passenger;
	}
	public String getTicketno() {
		return ticketno;
	}
	public void setTicketno(String ticketno) {
		this.ticketno = ticketno;
	}
	
	public Date getTakeofftimeStart() {
		return takeofftimeStart;
	}

	public void setTakeofftimeStart(Date takeofftimeStart) {
		this.takeofftimeStart = takeofftimeStart;
	}

	public Date getTakeofftimeend() {
		return takeofftimeend;
	}

	public void setTakeofftimeend(Date takeofftimeend) {
		this.takeofftimeend = takeofftimeend;
	}

	public Date getCreatetimeStart() {
		return createtimeStart;
	}

	public void setCreatetimeStart(Date createtimeStart) {
		this.createtimeStart = createtimeStart;
	}

	public Date getCreatetimeend() {
		return createtimeend;
	}

	public void setCreatetimeend(Date createtimeend) {
		this.createtimeend = createtimeend;
	}

	public String getTakeofflocus() {
		return takeofflocus;
	}
	public void setTakeofflocus(String takeofflocus) {
		this.takeofflocus = takeofflocus;
	}
	public String getAirteamnum() {
		return airteamnum;
	}
	public void setAirteamnum(String airteamnum) {
		this.airteamnum = airteamnum;
	}
	public String getArrivelocus() {
		return arrivelocus;
	}
	public void setArrivelocus(String arrivelocus) {
		this.arrivelocus = arrivelocus;
	}
	public String getCabinLevel() {
		return cabinLevel;
	}
	public void setCabinLevel(String cabinLevel) {
		this.cabinLevel = cabinLevel;
	}
	
	public String getClearobjectName() {
		return clearobjectName;
	}
	public void setClearobjectName(String clearobjectName) {
		this.clearobjectName = clearobjectName;
	}
	public Date getProposerDate() {
		return proposerDate;
	}
	public void setProposerDate(Date proposerDate) {
		this.proposerDate = proposerDate;
	}
	public String getProposerName() {
		return proposerName;
	}
	public void setProposerName(String proposerName) {
		this.proposerName = proposerName;
	}
	
}
