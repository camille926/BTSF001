package cn.itkt.btsf.callcenter.refundandwaste.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;

import javax.sql.DataSource;

import cn.itkt.btsf.util.DateUtil;
import cn.itkt.btsf.util.JBPMUtil;
import cn.itkt.btsf.util.LoginUtil;

public class updateRefundReqInfo {
	protected DataSource dataSource;

	public DataSource getDataSource() {
		return dataSource;
	}
	public void updateRefundReqInfo(long reqId,String node) {
		String sysDate = DateUtil.dateToString(new Date(),"yyyy-MM-dd HH:mm:ss");
		Connection con = null;
		PreparedStatement ps = null;
		try{
			DataSource data = (DataSource)JBPMUtil.getBean("dataSource");
			con = data.getConnection();
			if("审核".equals(node)){
				ps = con.prepareStatement("update BTSF_SYS_TICKET_REFUND set APPROVER='"+LoginUtil.getLoginUser().getName()+"' where ID="+reqId);
				
			}else if("标记收到行程单".equals(node)){
				ps = con.prepareStatement("update BTSF_SYS_TICKET_REFUND set RECEIPT_MARK_STAFF='" +LoginUtil.getLoginUser().getName() + "',RECEIPT_MARK_TIME=to_date('"+ sysDate +"','yyyy-mm-dd hh24:mi:ss') where ID="+reqId);
			}else if("确认退票".equals(node)){
				ps = con.prepareStatement("update BTSF_SYS_TICKET_REFUND set DONE_TIME=to_date('" +sysDate + "','yyyy-mm-dd hh24:mi:ss') where ID="+reqId);
			}
			ps.executeUpdate();
			ps.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
