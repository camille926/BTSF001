package cn.itkt.btsf.callcenter.refundandwaste.service.impl;

import org.jbpm.api.jpdl.DecisionHandler;
import org.jbpm.api.model.OpenExecution;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.service.webservice.InsuranceCancelHandler;
import cn.itkt.btsf.sys.common.AbstractWebserviceInvoker;
import cn.itkt.btsf.sys.common.constant.WebServiceConstant;

public class RefundInsurance implements DecisionHandler{
	@Override
	public String decide(OpenExecution execution) {
		try {
			TicketInfoPO po = (TicketInfoPO)execution.getVariable("ticketInfo");
			double insurancePrice = Double.parseDouble(execution.getVariable("insurancePrice").toString());
			if(po != null && insurancePrice > 0){
				AbstractWebserviceInvoker invoker = new InsuranceCancelHandler();
				invoker.invoke(WebServiceConstant.getInsuranceEndpoint(), "cancleTicketInsure", 
						WebServiceConstant.getQname(), new String[]{po.getTicketNo()+";04"});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "true";
	}
}
