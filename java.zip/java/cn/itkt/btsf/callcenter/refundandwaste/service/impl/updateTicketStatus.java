package cn.itkt.btsf.callcenter.refundandwaste.service.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.sql.DataSource;

import cn.itkt.btsf.util.JBPMUtil;

public class updateTicketStatus {
	protected DataSource dataSource;

	public DataSource getDataSource() {
		return dataSource;
	}
	public void updateTicketState(String ticketNo,String status) {
		
		Connection con = null;
		PreparedStatement ps = null;
		try{
			DataSource data = (DataSource)JBPMUtil.getBean("dataSource");
			con = data.getConnection();
			ps = con.prepareStatement("update BTSF_SYS_TICKET_INFO set TICKETSTATE='"+status+"' where TICKET_NO='"+ticketNo+"'");
			ps.executeUpdate();
			ps.close();
			con.close();
		} catch(Exception e) {
			e.printStackTrace();
		} 
	}
}
