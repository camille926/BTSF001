package cn.itkt.btsf.callcenter.refundandwaste.service.impl;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.jbpm.api.task.Task;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;
import cn.itkt.btsf.callcenter.refundandwaste.po.RefundAndWasteTicketPO;
import cn.itkt.btsf.callcenter.refundandwaste.po.RefundWasteConditionPO;
import cn.itkt.btsf.callcenter.refundandwaste.dao.RefundAndWasteTicketDao;
import cn.itkt.btsf.callcenter.refundandwaste.service.RefundAndWasteTicketService;
import cn.itkt.btsf.callcenter.refundandwaste.vo.ApplicationVO;
import cn.itkt.btsf.callcenter.refundandwaste.vo.RefundAndWasteTicketVO;
import cn.itkt.btsf.callcenter.refundandwaste.vo.RefundWasteConditionVO;
import cn.itkt.btsf.phone.returnticket.po.ReturnTicketPO;
import cn.itkt.btsf.sys.adjustable.po.ApprovalHistoryPO;
import cn.itkt.btsf.sys.cc.national.dao.TicketInfoDao;
import cn.itkt.btsf.sys.enums.TicketStatusEnum;
import cn.itkt.btsf.sys.pay.dao.PayJournalDao;
import cn.itkt.btsf.sys.pay.po.PayJournalPO;
import cn.itkt.btsf.sys.security.vo.UserVO;
import cn.itkt.btsf.util.JBPMUtil;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.btsf.sys.cc.national.po.TicketRequestPO;
import cn.itkt.btsf.sys.cc.national.service.ChangeTicketService;
import cn.itkt.btsf.sys.cc.national.service.TicketService;
import cn.itkt.btsf.sys.cc.national.vo.RefundOrderInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.RefundTicketInfoVO;
import cn.itkt.btsf.sys.common.constant.ConstantUtil;

@Service
public class RefundAndWasteTicketServiceImpl implements RefundAndWasteTicketService {

	private static final Logger log = LoggerFactory.getLogger(RefundAndWasteTicketServiceImpl.class);
	
	@Resource
	private  RefundAndWasteTicketDao  refundAndWasteTicketDao;
	@Resource
	private TicketInfoDao ticketInfoDao;
	@Resource
	private ChangeTicketService changeTicketService;
	@Resource
	private PayJournalDao payJournalDao;
	

	/**
	 * 查找单个 
	 * @param id 
	 * @return RefundAndWasteTicket 
	 */
	public RefundAndWasteTicketPO find(Serializable id){
		return refundAndWasteTicketDao.find(id);	
	}

	/**
	 * 查找所有 
	 * @return List<RefundAndWasteTicketPO> 
	 */
	public List<RefundAndWasteTicketPO> findAll(){
		return refundAndWasteTicketDao.findAll();	
	}

	/**
	 * 创建 
	 * @param po 
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public RefundAndWasteTicketPO createOrUpdate(RefundAndWasteTicketVO vo) throws AppException{
		RefundAndWasteTicketPO po = new RefundAndWasteTicketPO();
		SysUtil.cloneObject(vo, po);
		getRefundMoneyType(po);//为现金退款方式赋值
		
		try{
			if(po.getId() == 0){
				po.setProposerId(LoginUtil.getLoginUser().getId());
				po.setProposerDate(new Date());
				po.setProposerName(LoginUtil.getLoginUser().getName());
				po.setPrintStatus(ApplicationVO.UNPRINT);
				po.setNodeName(ApplicationVO.NODE_NAME_SUBMIT);
				po.setIfoutdate(ApplicationVO.NOTOUTDATE);
				refundAndWasteTicketDao.create(po);
				
			}else{
				refundAndWasteTicketDao.update(po);
			}
		}catch(Exception e){
			e.printStackTrace();
			throw new AppException("err.test.001");
		}	
		return po;
	}

	/**
	 * 根据退款渠道和支付方式为现金退款方式赋值
	 * @param po
	 */
	private void getRefundMoneyType(RefundAndWasteTicketPO po){
		String refundMoneyType = "";
		
		if(po.getRefundWay().equals(ApplicationVO.REFUNDTYPE_ORG)){//原路径
			//支付流水信息
			List<PayJournalPO> payJournalList = payJournalDao.findPayByOrderId(po.getOrderId());
			for (PayJournalPO payJournalPO : payJournalList) {
				if(!payJournalPO.getPaymentType().equals(ApplicationVO.PAYMENT_COIN)){
					refundMoneyType = ConstantUtil.getDictionaryValue(ConstantUtil.PayTypeToRefundType_, payJournalPO.getPaymentType());
				}
			}

		}else if(po.getRefundWay().equals(ApplicationVO.REFUNDTYPE_UNORG)){//非原路径
			refundMoneyType = ApplicationVO.CASHREFUNDTYPE_UNORG;
			
		}else if(po.getRefundWay().equals(ApplicationVO.REFUNDTYPE_UNREFUND)){//不退款
			refundMoneyType = ApplicationVO.CASHREFUNDTYPE_UNREFUND;
			
		}else if(po.getRefundWay().equals(ApplicationVO.REFUNDTYPE_ALLCOIN)){//全退畅达币
			refundMoneyType = ConstantUtil.getDictionaryValue(ConstantUtil.PayTypeToRefundType_, ApplicationVO.PAYMENT_COIN);
			
		}
		po.setRefundMoneyType(refundMoneyType);
	}
	
	/**
	 * 修改 
	 * @param po
	 */
	@Transactional(rollbackFor={Exception.class})
	public void update(RefundAndWasteTicketPO po) throws AppException {
		try{
			if( po != null )
				 refundAndWasteTicketDao.update(po);
		}catch(Exception e){
			log.error(e.getMessage());
			throw new AppException("err.test.001");
		}	
	}

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id){
		 refundAndWasteTicketDao.delete(id);
	}

	@Override
	public boolean checkTicketStatus(String ticketNo) {
		boolean flag = false;
		try {
			int checkTiketStatus = refundAndWasteTicketDao.checkTiketStatus(ticketNo);
			if(checkTiketStatus > 0){
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public boolean isAllRefundLcdcoin(RefundAndWasteTicketVO refundAndWasteTicketVO){
		boolean flag = false;
		//如果应退金额等于0并且应退畅达币大于0，那么就是全退畅达币
		if(refundAndWasteTicketVO.getRefundCash() == 0 && Integer.parseInt(refundAndWasteTicketVO.getRefundCoin()) > 0)
			flag = true;
		
		return flag;
	}

	@Override
	public boolean updateTicketState(RefundAndWasteTicketVO refundAndWasteTicketVO) {
		boolean flag = false;
		try {
			Map<String, Object> map = new HashMap<String, Object>();
			if(ApplicationVO.REFUND.equals(refundAndWasteTicketVO.getProposerType())){
				map.put("ticketState", ApplicationVO.REFUNDSEASON_VOLUNTARY.equals(refundAndWasteTicketVO.getRefundVoluntary()) ? TicketStatusEnum.VOLUNTEER_REFUND_TKT_PROCESSING.getValue() : TicketStatusEnum.UN_VOLUNTEER_REFUND_TKT_PROCESSING.getValue());
			}else{
				map.put("ticketState", TicketStatusEnum.INVALID_TICKET_PROCESSING.getValue());
			}
			
			map.put("ticketNo", refundAndWasteTicketVO.getTicketNo());
			ticketInfoDao.updateTicketStatus(map);
			flag = true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	/**
	 * 注销退票申请单
	 */
	@Override
	public boolean deleteOrderById(String reqCode) throws AppException {
		boolean flag = false;
		try {
			//查询该退票申请单是否已启动流程，如果启动流程则结束该流程并更改申请单的状态
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("requisitionCode", reqCode);
			List<RefundAndWasteTicketPO> list = refundAndWasteTicketDao.findByMap(map);
			
			if(list.size() > 0){
				RefundAndWasteTicketPO refundAndWasteTicketPO = list.get(0);
				if(refundAndWasteTicketPO.getProcessId() != null && !"".equals(refundAndWasteTicketPO.getProcessId())){
					JBPMUtil.deleteProcessInstanceById(refundAndWasteTicketPO.getProcessId());//删除审批工作流
				}
				
				refundAndWasteTicketPO.setNodeName(ApplicationVO.NODE_NAME_CANCEL);//修改申请单状态
				this.update(refundAndWasteTicketPO);
				
				//修改票状态为已出票
				map.put("ticketState", TicketStatusEnum.DRAW_TICKET.getValue());
				map.put("ticketNo", refundAndWasteTicketPO.getTicketNo());
				ticketInfoDao.updateTicketStatus(map);
				
				//解挂客票
				changeTicketService.lockTicket("1", refundAndWasteTicketPO.getTicketNo());
				
				flag = true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw new AppException(e.getMessage());
		}
		
		return flag;
	}

	@Override
	public List<RefundWasteConditionVO> findallWasteticket(RefundWasteConditionVO po) {
		return refundAndWasteTicketDao.findallWasteticket(po);
	}

	@Override
	public int account(RefundWasteConditionVO po) {
		// TODO Auto-generated method stub
		return refundAndWasteTicketDao.account(po);
	}
	@Override
	public Pages<RefundWasteConditionVO> getNdoTask(RefundWasteConditionVO vo, UserVO user,String assignee,int startIndex) throws AppException {
		StringBuffer jbpmId = new StringBuffer();
		List<RefundWasteConditionVO> tList = null;
		Pages<RefundWasteConditionVO> page = new Pages<RefundWasteConditionVO>(startIndex,10);
		List<RefundWasteConditionVO> tasklist = new ArrayList<RefundWasteConditionVO>();
		List<Task> ndoTask = JBPMUtil.getNdoTask(assignee);//获得当前节点的待办任务
		if(ndoTask.size() > 0){
			jbpmId.append("'"+ndoTask.get(0).getExecutionId()+"'");
		}
		
		for (int i=1; i<ndoTask.size(); i++) {
			jbpmId.append(",'"+ndoTask.get(i).getExecutionId()+"'");
		}
		vo.setJbpmId(jbpmId.toString());
		if(ndoTask.size()>0){
			tList = refundAndWasteTicketDao.findallWasteticket(vo);
			for (int i=0;i<tList.size();i++) {
				
				for (Task task : ndoTask) {
					RefundWasteConditionVO requestMixture = tList.get(i);
					if(requestMixture.getProcessId().equals(task.getExecutionId())){
						requestMixture.setTask(task);
						tasklist.add(requestMixture);
					}
				}
				
			}
		}
		page.setItems(tasklist);
		page.setTotalCount(JBPMUtil.getNdoTaskCount(assignee));
		return page;
	}
	@Override
	public List<ApprovalHistoryPO> getHistoryApprovalList(String requisitionId)
			throws AppException {
		List<ApprovalHistoryPO> approvalHistoryPO  = new ArrayList<ApprovalHistoryPO>();
		try {
		 approvalHistoryPO  = refundAndWasteTicketDao.getHistoryApprovalList(requisitionId);
		 //审批结果转换
		for (ApprovalHistoryPO approvalHistoryPO2 : approvalHistoryPO) {
			String result = approvalHistoryPO2.getResult();
			approvalHistoryPO2.setResult(ConstantUtil.getDictionaryValue("24", result));
		}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AppException(e.getMessage());
		}
		return approvalHistoryPO;
	}
	@Override
	public List<RefundOrderInfoVO> getAboutOrderInfo(long orderId)
			throws AppException {
		List<RefundOrderInfoVO> aboutorderList = new ArrayList<RefundOrderInfoVO>();
		
		//获取当前订单信息
		 List<RefundTicketInfoVO> ticketInfoByOrderId = refundAndWasteTicketDao.getTicketInfoByOrderId2(orderId);
		if(ticketInfoByOrderId.size() > 0 ){
				//循环票信息
				for (RefundTicketInfoVO refundTicketInfoVO2 : ticketInfoByOrderId) {
					Map<String,Object> map = new HashMap<String,Object>();
					map.put("passengerName", refundTicketInfoVO2.getPassengerName());
					map.put("identityCard", refundTicketInfoVO2.getIdentityCard());
					map.put("takeofflocus", refundTicketInfoVO2.getTakeofflocus());
					map.put("arrivelocus", refundTicketInfoVO2.getArrivelocus());
					map.put("takeofftime1", cn.itkt.util.DateUtil.addDays(refundTicketInfoVO2.getTakeofftime(),-30));
					map.put("takeofftime2", cn.itkt.util.DateUtil.addDays(refundTicketInfoVO2.getTakeofftime(),30));
					//获取相关订单
					List<RefundOrderInfoVO> list = refundAndWasteTicketDao.findAboutOrder(map);
					for (RefundOrderInfoVO refundOrderInfoVO2 : list) {
						//if(refundOrderInfoVO2.getId() != refundTicketInfoVO2.getOrderId()){
							aboutorderList.add(refundOrderInfoVO2);
						//}
					}
				}
			
			
		}
		
		return aboutorderList;
	}

	@Override
	public List wasteAndRequestFee(String requisitionId) {
		// TODO Auto-generated method stub
		return refundAndWasteTicketDao.wasteAndRequestFee(requisitionId);
	}

	@Override
	public String checkAgain(Long ticketId) {
		// TODO Auto-generated method stub
		return refundAndWasteTicketDao.checkAgain(ticketId);
	}
}