package cn.itkt.btsf.callcenter.refundandwaste.dao;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.taglibs.standard.tag.el.fmt.ParseDateTag;
import org.springframework.web.servlet.view.document.AbstractExcelView;
import cn.itkt.btsf.callcenter.refundandwaste.vo.RefundWasteConditionVO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.po.TicketReqCdatePO;
import cn.itkt.btsf.sys.cc.national.vo.TicketInfoVO;
import cn.itkt.btsf.sys.common.constant.ConstantUtil;
import cn.itkt.btsf.util.DateUtil;

public class ExportReportAndWaste extends AbstractExcelView {
	@Override
	protected void buildExcelDocument(Map<String,Object> model, HSSFWorkbook workbook,HttpServletRequest request,HttpServletResponse response) throws Exception{
		String type = (String)model.get("type");
		List<RefundWasteConditionVO> rList = null;
		List<TicketReqCdatePO> rList1 = null;
		
		if("03".equals(type)){
			rList1 = (List<TicketReqCdatePO>)model.get("rList");
		}else{
			rList = (List<RefundWasteConditionVO>)model.get("rList");
		}
		HSSFSheet sheet = null;
		
		if("01".equals(type)){
			sheet = workbook.createSheet("退票申请单维护列表");
			sheet.setDefaultColumnWidth(20);
			setText(getCell(sheet,0,0),"序号");
			setText(getCell(sheet,0,1),"退票申请单编号");//requisitionCode
			setText(getCell(sheet,0,2),"退票申请单状态");//退票申请单状态
			setText(getCell(sheet,0,3),"订单编号");//订单编号
			setText(getCell(sheet,0,4),"乘机人姓名");//乘机人姓名
			setText(getCell(sheet,0,5),"客票票号");//客票票号
			//新添的字段
			setText(getCell(sheet,0,6),"机建费");
			setText(getCell(sheet,0,7),"燃油费");
			setText(getCell(sheet,0,8),"票面价");
			setText(getCell(sheet,0,9),"合计");
			setText(getCell(sheet,0,10),"保险");
			setText(getCell(sheet,0,11),"应扣退票费");
			setText(getCell(sheet,0,12),"退票费率");
			setText(getCell(sheet,0,13),"应扣畅达币");
			setText(getCell(sheet,0,13),"应扣现金");
			setText(getCell(sheet,0,14),"应退金额");
			setText(getCell(sheet,0,15),"应退畅达币");
			
			setText(getCell(sheet,0,16),"乘机日期");
			setText(getCell(sheet,0,17),"出发城市");
			setText(getCell(sheet,0,18),"目的城市");
			setText(getCell(sheet,0,19),"航班号");
			setText(getCell(sheet,0,20),"舱位");
			setText(getCell(sheet,0,21),"客户名称");
			setText(getCell(sheet,0,22),"退票申请人");
			setText(getCell(sheet,0,23),"退票申请时间");
			
		}else if("02".equals(type)){
			sheet = workbook.createSheet("废票申请单维护列表");
			sheet.setDefaultColumnWidth(20);
			setText(getCell(sheet,0,0),"序号");
			setText(getCell(sheet,0,1),"废票申请单编号");
			setText(getCell(sheet,0,2),"废票申请单状态");
			setText(getCell(sheet,0,3),"订单编号");
			setText(getCell(sheet,0,4),"乘机人姓名");
			setText(getCell(sheet,0,5),"客票票号");
			
			//新添的字段
			setText(getCell(sheet,0,6),"机建费");
			setText(getCell(sheet,0,7),"燃油费");
			setText(getCell(sheet,0,8),"票面价");
			setText(getCell(sheet,0,9),"合计");
			setText(getCell(sheet,0,10),"保险");
			setText(getCell(sheet,0,11),"应扣退票费");
			setText(getCell(sheet,0,12),"退票费率");
			setText(getCell(sheet,0,13),"应扣畅达币");
			setText(getCell(sheet,0,14),"应退金额");
			setText(getCell(sheet,0,15),"应退畅达币");
			
			setText(getCell(sheet,0,16),"乘机日期");
			setText(getCell(sheet,0,17),"出发城市");
			setText(getCell(sheet,0,18),"目的城市");
			setText(getCell(sheet,0,19),"航班号");
			setText(getCell(sheet,0,20),"舱位");
			setText(getCell(sheet,0,21),"客户名称");
			setText(getCell(sheet,0,22),"废票申请人");
			setText(getCell(sheet,0,23),"废票申请时间");
			
		}else if("03".equals(type)){
			sheet = workbook.createSheet("改期申请单维护列表");
			sheet.setDefaultColumnWidth(20);
			setText(getCell(sheet,0,0),"序号");
			setText(getCell(sheet,0,1),"改期编号");
			setText(getCell(sheet,0,2),"订单编号");
			setText(getCell(sheet,0,3),"乘机人姓名");
			setText(getCell(sheet,0,4),"客票票号");
			setText(getCell(sheet,0,5),"乘机日期");
			setText(getCell(sheet,0,6),"出发城市");
			setText(getCell(sheet,0,7),"目的城市");
			setText(getCell(sheet,0,8),"航班号");
			setText(getCell(sheet,0,9),"舱位");
			setText(getCell(sheet,0,10),"客户名称");
			setText(getCell(sheet,0,11),"改期记录人");
			setText(getCell(sheet,0,12),"改期记录时间");
		}else if("04".equals(type)){
			sheet = workbook.createSheet("升舱申请单维护列表");
			sheet.setDefaultColumnWidth(20);
			setText(getCell(sheet,0,0),"序号");
			setText(getCell(sheet,0,1),"升舱申请单编号");
			setText(getCell(sheet,0,2),"升舱申请单状态");
			setText(getCell(sheet,0,3),"订单编号");
			setText(getCell(sheet,0,4),"乘机人姓名");
			setText(getCell(sheet,0,5),"客票票号");
			setText(getCell(sheet,0,6),"乘机日期");
			setText(getCell(sheet,0,7),"出发城市");
			setText(getCell(sheet,0,8),"目的城市");
			setText(getCell(sheet,0,9),"航班号");
			setText(getCell(sheet,0,10),"舱位");
			setText(getCell(sheet,0,11),"客户名称");
			setText(getCell(sheet,0,12),"升舱申请人");
			setText(getCell(sheet,0,13),"升舱申请时间");
		}
		
		
		
		
		//RequestMixtureVO vo = null;
		RefundWasteConditionVO po = null;
		TicketInfoVO ticketInfoVO = null;
		int i = 0;
		if(!"03".equals(type)){
			
			if("01".equals(type) || "02".equals(type)){
				for(int j=0;j<rList.size();j++){
					po = rList.get(j);
					int n = rList.size();
					setText(getCell(sheet,i+1,0),String.valueOf(i+1));
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,1),po.getRequisitionCode());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,2),ConstantUtil.getDictionaryValue("34", po.getNodename()));
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,3),po.getOrderNo());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,4),po.getPassenger());
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,5),po.getTicketno());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,6),po.getDrometax()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,7),po.getFueltax()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,8),po.getTicketPrice()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,9),po.getTicketMone()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,10),po.getInsurance()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,11),po.getFee()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,12),po.getRate()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,13),po.getDeductCoin()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,14),po.getDeductCash()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,15),po.getRefundCash()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,15),po.getRefundCoin()+"");
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,16),DateUtil.dateToString(po.getTakeofftime(), "yyyy-MM-dd HH:mm"));
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,17),po.getTakeofflocus());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,18),po.getArrivelocus());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,19),po.getAirteamnum());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,20),po.getCabinLevel());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,21),po.getClearobjectName());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,22),po.getProposerName());
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					setText(getCell(sheet,i+1,23),DateUtil.dateToString(po.getProposerDate(), "yyyy-MM-dd HH:mm"));
					
					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
					i+=n;
				}
			}else{
				for(RefundWasteConditionVO vo : rList){
//					//vo = rList.get(i);
//					int n = vo.getTicketInfoPO().size();
//					setText(getCell(sheet,i+1,0),String.valueOf(i+1));
//					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
//					
//					setText(getCell(sheet,i+1,1),vo.getRequisitionCode());
//					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
//					
//					setText(getCell(sheet,i+1,2),ConstantUtil.getDictionaryValue("34", vo.getNodeName()));
//					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
//					
//					setText(getCell(sheet,i+1,3),vo.getOrderNo());
//					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
//					for(int j = 1 ;j<=n;j++){
//						po = vo.getTicketInfoPO().get(j-1);
//						setText(getCell(sheet,i+j,4),po.getPassengerName());
//						setText(getCell(sheet,i+j,5),po.getTicketNo());
//						setText(getCell(sheet,i+j,6),DateUtil.dateToString(po.getTakeofftime(), "yyyy-MM-dd HH:mm"));
//						setText(getCell(sheet,i+j,7),po.getTakeofflocusname());
//						setText(getCell(sheet,i+j,8),po.getArrivelocusname());
//						setText(getCell(sheet,i+j,9),po.getAirteamnum());
//						setText(getCell(sheet,i+j,10),po.getCabin());
//					}
//					setText(getCell(sheet,i+1,11),vo.getCustomerName());
//					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
//					setText(getCell(sheet,i+1,12),vo.getProposerName());
//					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
//					setText(getCell(sheet,i+1,13),DateUtil.dateToString(vo.getProposerDate(), "yyyy-MM-dd HH:mm"));
//					sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
//					i+=n;
//				}
			}
			}
			}else{
		for(TicketReqCdatePO vo : rList1){
			int n = vo.getTicketVOlist().size();
			setText(getCell(sheet,i+1,0),String.valueOf(i+1));
			sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
			
			setText(getCell(sheet,i+1,1),vo.getRequisitionCode());
			sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
			
			setText(getCell(sheet,i+1,2),vo.getOrderNo());
			sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
			for(int j = 1 ;j<=n;j++){
				ticketInfoVO = vo.getTicketVOlist().get(j-1);
				setText(getCell(sheet,i+j,3),ticketInfoVO.getPassengerName());
				setText(getCell(sheet,i+j,4),ticketInfoVO.getTicketNo());
				setText(getCell(sheet,i+j,5),DateUtil.dateToString(ticketInfoVO.getTakeofftime(), "yyyy-MM-dd HH:mm"));
				setText(getCell(sheet,i+j,6),ticketInfoVO.getTakeofflocusname());
				setText(getCell(sheet,i+j,7),ticketInfoVO.getArrivelocusname());
				setText(getCell(sheet,i+j,8),ticketInfoVO.getAirteamnum());
				setText(getCell(sheet,i+j,9),ticketInfoVO.getCabin());
			}
			setText(getCell(sheet,i+1,10),vo.getCustomerName());
			sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
			setText(getCell(sheet,i+1,11),vo.getRecordName());
			sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
			setText(getCell(sheet,i+1,12),DateUtil.dateToString(vo.getRecordDate(), "yyyy-MM-dd HH:mm"));
			sheet.addMergedRegion(new CellRangeAddress((i+1),(i+n),0,0));
			i+=n;
		}
	}
	}
}

