package cn.itkt.btsf.callcenter.refundandwaste.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Date;
import java.util.Map;

import cn.itkt.btsf.callcenter.refundandwaste.po.RefundAndWasteTicketPO;
import cn.itkt.btsf.callcenter.refundandwaste.po.RefundWasteConditionPO;
import cn.itkt.btsf.callcenter.refundandwaste.vo.RefundWasteConditionVO;
import cn.itkt.btsf.phone.returnticket.po.ReturnTicketPO;
import cn.itkt.btsf.sys.adjustable.po.ApprovalHistoryPO;
import cn.itkt.btsf.sys.cc.national.vo.RefundOrderInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.RefundTicketInfoVO;

/**
 * 国内退废票申请表 
 * @author codegen 2013-02-21 15:25:30 
 */
public interface RefundAndWasteTicketDao {

	/**
	 * 查找单个 
	 * @param id 
	 * @return RefundAndWasteTicket 
	 */
	public RefundAndWasteTicketPO find(Serializable id);

	/**
	 * 查找所有 
	 * @return List<RefundAndWasteTicketPO> 
	 */
	public List<RefundAndWasteTicketPO> findAll();
	
	/**
	 * 创建 
	 * @param po 
	 */
	public void create(RefundAndWasteTicketPO po);

	/**
	 * 修改 
	 * @param po 
	 */
	public void update(RefundAndWasteTicketPO po);

	/**
	 * 删除 
	 * @param id 
	 */
	public void delete(Serializable id);
	
	/**
	 * 检查是否符合退票或者废票要求
	 * @return true通过 false不通过
	 */
	public int checkTiketStatus(String ticketNo);
	
	/**
	 * 根据条件查询申请单
	 * @param map
	 * @return
	 */
	public List<RefundAndWasteTicketPO> findByMap(Map<String,Object> map);
	
	/**
	 * 查找所以退废票信息
	 */
	public List<RefundWasteConditionVO> findallWasteticket(RefundWasteConditionVO po);
	/**
	 * 查询退废票总记录
	 * 
	 */
	public int account(RefundWasteConditionVO po) ;
	/**
	 * 查询代办任务
	 */
   public List<RefundWasteConditionVO> findRequest(RefundWasteConditionVO po);
   /**
	 * 根据申请单号历史审批记录
	 * @param requisitionId
	 * @return
	 */
	public List<ApprovalHistoryPO> getHistoryApprovalList(String requisitionId);
	/**
	 * 根据订单id获取票信息
	 * @param orderId
	 * @return
	 */
	public List<RefundTicketInfoVO> getTicketInfoByOrderId2(long orderId);
	/**
	 * 根据条件查询票信息
	 * @param map
	 * @return
	 */
	public List<RefundOrderInfoVO> findAboutOrder(Map<String,Object> map);
	/**
	 * 查询退费票信息
	 */
	public List wasteAndRequestFee(String requisitionId);
	/**
	 * 判断是否已退票
	 */
	public String checkAgain(Long ticketId);
}