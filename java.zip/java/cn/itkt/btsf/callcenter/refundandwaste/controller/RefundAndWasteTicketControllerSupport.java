package cn.itkt.btsf.callcenter.refundandwaste.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.annotation.Resource;
import org.jbpm.api.TaskService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import cn.itkt.exception.AppException;
import cn.itkt.exception.SysException;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;
import cn.itkt.btsf.callcenter.refundandwaste.po.RefundAndWasteTicketPO;
import cn.itkt.btsf.callcenter.refundandwaste.po.RefundWasteConditionPO;
import cn.itkt.btsf.callcenter.refundandwaste.vo.ApplicationVO;
import cn.itkt.btsf.callcenter.refundandwaste.vo.RefundAndWasteTicketVO;
import cn.itkt.btsf.callcenter.refundandwaste.vo.RefundWasteConditionVO;
import cn.itkt.btsf.callcenter.refundandwaste.service.RefundAndWasteTicketService;
import cn.itkt.btsf.phone.ticketrate.service.TicketRateService;
import cn.itkt.btsf.phone.users.service.PhoneCoinService;
import cn.itkt.btsf.sys.adjustable.po.ApprovalHistoryPO;
import cn.itkt.btsf.sys.adjustable.service.ApprovalHistoryService;
import cn.itkt.btsf.sys.adjustable.vo.ApprovalHistoryVO;
import cn.itkt.btsf.sys.baseinfo.po.BusinessParameterPO;
import cn.itkt.btsf.sys.baseinfo.service.BusinessParameterService;
import cn.itkt.btsf.sys.cc.national.controller.OrderManageControllerSupport;
import cn.itkt.btsf.sys.cc.national.dao.PsrInfoDao;
import cn.itkt.btsf.sys.cc.national.po.OrderInfoPO;
import cn.itkt.btsf.sys.cc.national.po.PsrInfoPO;
import cn.itkt.btsf.sys.cc.national.po.TicketInfoPO;
import cn.itkt.btsf.sys.cc.national.service.ChangeTicketService;
import cn.itkt.btsf.sys.cc.national.service.InsuranceInfoService;
import cn.itkt.btsf.sys.cc.national.service.OrderInfoService;
import cn.itkt.btsf.sys.cc.national.service.OrderManageService;
import cn.itkt.btsf.sys.cc.national.service.TicketService;
import cn.itkt.btsf.sys.cc.national.vo.InsuranceInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.MessageVO;
import cn.itkt.btsf.sys.cc.national.vo.OrderCcextVO;
import cn.itkt.btsf.sys.cc.national.vo.OrderInfoVO;
import cn.itkt.btsf.sys.cc.national.vo.RefundOrderInfoVO;
import cn.itkt.btsf.sys.common.constant.ConstantUtil;
import cn.itkt.btsf.sys.enums.ReceiptReturnTypeEnum;
import cn.itkt.btsf.sys.enums.RefundSendMessage;
import cn.itkt.btsf.sys.message.service.MessageContants;
import cn.itkt.btsf.sys.message.service.ReplaceTemplateService;
import cn.itkt.btsf.sys.message.vo.MessageSendingVO;
import cn.itkt.btsf.sys.message.vo.ValueNameConstant;
import cn.itkt.btsf.sys.pay.po.PayJournalPO;
import cn.itkt.btsf.sys.pay.service.PayJournalService;
import cn.itkt.btsf.sys.security.vo.UserVO;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.btsf.util.JBPMUtil;
import cn.itkt.btsf.util.LoginUtil;

@Service
public class RefundAndWasteTicketControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(RefundAndWasteTicketControllerSupport.class);
	@Resource
	private BusinessParameterService businessParameterService;
	@Resource
	private  RefundAndWasteTicketService  refundAndWasteTicketService;
	@Resource
	private OrderInfoService orderInfoService;
	@Resource
	private PayJournalService payJournalService;
	@Resource
	private OrderManageService orderManageService;
	@Resource
	private TicketService ticketService;
	@Resource
	private ApprovalHistoryService approvalHistoryService;
	@Resource
	private ReplaceTemplateService replaceTemplateService;
	@Resource
	private PsrInfoDao psrInfoDao;
	@Resource
	private PhoneCoinService phoneCoinService;
	@Resource
	private InsuranceInfoService insuranceInfoService;
	@Resource
	private ChangeTicketService changeTicketService;
	@Resource
	private TicketRateService ticketRateService;
	@Resource
	private OrderManageControllerSupport orderManageControllerSupport;
	
	
	
	/**
	 * 申请退票或废票页面
	 * @param appId 申请单id
	 * @return
	 */
	public void applicate(ModelMap modelMap, long ticketId, String appType){
		this.getBasicInfoInit(modelMap, ticketId,appType);
		String proposerType = refundAndWasteTicketService.checkAgain(ticketId);
		modelMap.addAttribute("proposerType",proposerType);
		this.createAppNo(modelMap, appType);
	}
	
	/**
	 * 提交退票和废票申请单
	 * @param modelMap
	 * @param refundAndWasteTicketVO
	 */
	@Transactional(rollbackFor=Exception.class)
	public void submit(ModelMap modelMap, RefundAndWasteTicketVO refundAndWasteTicketVO){
		try {
			
			//检查该票是否符合退票条件
			if(!refundAndWasteTicketService.checkTicketStatus(refundAndWasteTicketVO.getTicketNo())){
				throwException(modelMap,"Refund_001");
			}
			
			//保存申请单信息
			RefundAndWasteTicketPO refundAndWasteTicketPO = refundAndWasteTicketService.createOrUpdate(refundAndWasteTicketVO);
			
			//启动流程实例
			String processKey = startProcess(refundAndWasteTicketPO);

			//修改申请单
			refundAndWasteTicketPO.setProcessId(processKey);
			refundAndWasteTicketService.update(refundAndWasteTicketPO);
			
			//退畅达币
			this.returnLcdcoin(refundAndWasteTicketPO);
			
			//新增历史审批记录
			insertHistoryRecord(new String[]{refundAndWasteTicketPO.getProcessId(),ApplicationVO.TASKNAME_RECORDED,refundAndWasteTicketPO.getRequisitionCode(),
					ApplicationVO.RESULT_START,ApplicationVO.ADVICE_START,""});
			
			//修改客票状态
			refundAndWasteTicketService.updateTicketState(refundAndWasteTicketVO);
			
			//发送短信
			this.sendMessage(refundAndWasteTicketPO);
			
			modelMap.addAttribute("application", refundAndWasteTicketVO);
			modelMap.addAttribute("message", ApplicationVO.SUBMIT_SUCCESS);
		} catch (Exception e) {
			e.printStackTrace();
			throwException(modelMap,"Refund_002");
		}
	}
	
	
	
	/**
	 * 修改退票和废票申请单
	 * @param modelMap
	 * @param refundAndWasteTicketVO
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void doUpdate(ModelMap modelMap, RefundAndWasteTicketVO refundAndWasteTicketVO, String taskId){
		TaskService taskService = JBPMUtil.getTaskService();
		modelMap.addAttribute("message", ApplicationVO.UPDATE_FAIL);
		try {
			//对比退废票信息修改前后的变化
			String advice = this.equelsRefundInfoByUpdate(refundAndWasteTicketVO);
			
			//修改申请单信息
			RefundAndWasteTicketPO refundAndWasteTicketPO = refundAndWasteTicketService.createOrUpdate(refundAndWasteTicketVO);
			
			//新增历史审批记录
			boolean insertHistoryRecord = insertHistoryRecord(new String[]{refundAndWasteTicketPO.getProcessId(),ApplicationVO.TASKNAME_UPDATE,refundAndWasteTicketPO.getRequisitionCode(),
					ApplicationVO.RESULT_UPDATE,advice,""});
			
			//处理任务
			if(insertHistoryRecord){
				taskService.completeTask(taskId,"true");
				modelMap.addAttribute("message", ApplicationVO.UPDATE_SUCCESS);
			}
//			taskService.completeTask(taskId,"true");
		} catch (Exception e) {
			e.printStackTrace();
			throwException(modelMap,"Refund_002");
		}
	}
	
	/**
	 * 对比退废票信息修改前后的变化
	 * @param refundAndWasteTicketVO 之后的数据
	 * @return
	 */
	private String equelsRefundInfoByUpdate(RefundAndWasteTicketVO newVO){
		StringBuffer sb = new StringBuffer();
		RefundAndWasteTicketPO orgPO = refundAndWasteTicketService.find(newVO.getId());
		Map<String, Object> orgMap = orgPO.getRefundAndWasteTicketPOToMap();
		Map<String, Object> newMap = newVO.getRefundAndWasteTicketPOToMap();
		
		Map<String,String> strMap = new HashMap<String,String>();
		strMap.put("rate", "退票费率");
		strMap.put("fee", "退票手续费");
		strMap.put("refundVoluntary", "原因");
		strMap.put("deductCash", "应扣现金");
		strMap.put("deductCoin", "应扣畅达币");
		strMap.put("refundCash", "应退现金");
		strMap.put("refundCoin", "应退畅达币");
		strMap.put("refundWay", "退款方式");
		
		Set<Entry<String, String>> entrySet = strMap.entrySet();
		for (Entry<String, String> entry : entrySet) {
			String orgStr = orgMap.get(entry.getKey()).toString();
			String newStr = newMap.get(entry.getKey()).toString();
			if(!orgStr.equals(newStr)){
				if(entry.getKey().equals("refundWay")){
					sb.append(entry.getValue() + ":由" + ConstantUtil.getDictionaryValue(ConstantUtil.RefundWayBill_, orgStr) +"改为" + ConstantUtil.getDictionaryValue(ConstantUtil.RefundWayBill_, newStr) + "； ");
				}else{
					sb.append(entry.getValue() + ":由" + orgStr +"改为" + newStr + "； ");
				}
				
			}
		}
		
		return sb.toString();
	}
	
	
	/**
	 * 显示审批申请单页面
	 * @param modelMap
	 * @param reqId
	 */
	public void approvalPage(ModelMap modelMap, long reqId, String taskId){
		getBasicInfo(modelMap, reqId, taskId);
	}
	
	private void throwException(ModelMap modelMap, String code) {
		SysException sysException = new SysException(code);
		modelMap.addAttribute("message", sysException.getMessage());
		throw sysException;
	}
	
	/**
	 * 申请单提交时，发送短消息
	 */
	public void sendMessage(RefundAndWasteTicketPO refundAndWasteTicketPO){
		String noreplace= "";
		MessageSendingVO  po = new MessageSendingVO();
		po.setCommport("/dev/ttyS0");//端口
		po.setState("0");//状态
		po.setSendlevel(0);
		po.setSmstype(MessageContants.SMS_REFUND_POST);
		
		//如果退票申请单中的是否发送短信选择的是“是”，那么发送短信
		if("1".equals(refundAndWasteTicketPO.getNeedSms())){
			String[] sms_type = SysUtil.ifNull(refundAndWasteTicketPO.getSmsType()).split(",");
			//-------------------------------发送行程单短信-----------------------------------
			if(!ReceiptReturnTypeEnum.UnNeed.equals(refundAndWasteTicketPO.getReceiptReturnType())){
				//循环要发送短信的对象类型，1：订票人2乘机人 3其他 多选
				for (String type : sms_type) {
					po.setContent(noreplace);//内容
					
					if(RefundSendMessage.OrderPerson.equals(type)){//0：订票人
						//获得结算对象信息
						OrderCcextVO ext=orderManageService.findOrderExtInfo(refundAndWasteTicketPO.getOrderId());
						po.setSender(ValueNameConstant.sendCompany);
						po.setReceiver(SysUtil.ifNull(ext.getBookTicketTel()));//手机号
						
					}else if(RefundSendMessage.Passager.equals(type)){//1乘机人
						PsrInfoPO findPsrInfoByTicketId = psrInfoDao.findPsrInfoByTicketId(refundAndWasteTicketPO.getTicketNo());
						po.setSender(ValueNameConstant.sendCompany);
						po.setReceiver(SysUtil.ifNull(findPsrInfoByTicketId.getMobile()));//手机号
					}else{//2其他
						po.setSender(ValueNameConstant.sendCompany);//接受人姓名
						po.setReceiver(SysUtil.ifNull(refundAndWasteTicketPO.getSmsMannumber()));//手机号
						
					}
					replaceTemplateService.ReplaceTemplateContent(null, MessageVO.sendReceiptMessage(), "1", po);//插入短信发送表
					
				}
			}
			//----------------------------------------------------------------------------------
			//--------------------------------------发送退票短信---------------------------------
				MessageVO vo = new MessageVO();
				vo.setTicketNo(refundAndWasteTicketPO.getTicketNo());
				vo.setRefundWay(refundAndWasteTicketPO.getRefundWay());
				OrderInfoPO orderInfoPO = orderInfoService.find(refundAndWasteTicketPO.getOrderId());
				
				//掌上航旅会员不发此短信
				if(!"04".equals(orderInfoPO.getClearobjectType())){
					//循环要发送短信的对象类型，0：乘机人1订票人 2其他 多选
					for (String type : sms_type) {
						po.setContent(vo.sendRefundMessage());//内容
						
						if("0".equals(type)){//0：乘机人
							PsrInfoPO findPsrInfoByTicketId = psrInfoDao.findPsrInfoByTicketId(refundAndWasteTicketPO.getTicketNo());
							po.setSender(ValueNameConstant.sendCompany);
							po.setReceiver(SysUtil.ifNull(findPsrInfoByTicketId.getMobile()));//手机号
							
						}else if("1".equals(type)){//1订票人
							//获得结算对象信息
							OrderCcextVO ext=orderManageService.findOrderExtInfo(refundAndWasteTicketPO.getOrderId());
							po.setSender(ValueNameConstant.sendCompany);
							po.setReceiver(SysUtil.ifNull(ext.getBookTicketTel()));//手机号
							
						}else{//2其他
							po.setSender(ValueNameConstant.sendCompany);
							po.setReceiver(SysUtil.ifNull(refundAndWasteTicketPO.getSmsMannumber()));//手机号
							
						}
						replaceTemplateService.ReplaceTemplateContent(null, vo.sendRefundMessage(), "1", po);//插入短信发送表
						
					}
				}
			//------------------------------------------------------------------------------------
			
		}
		
		//---------------------------------------往呼叫中心手机上发短信-------------------------------------
		MessageVO message = new MessageVO();
		message.setTicketNo(refundAndWasteTicketPO.getTicketNo());
		noreplace = message.sendNoticMessage();
		
		po.setContent(noreplace);
		po.setSender(ValueNameConstant.sendCompany);
		po.setReceiver(ValueNameConstant.message_receipt_mobile1);
		replaceTemplateService.ReplaceTemplateContent(null, noreplace, "1", po);//插入短信发送表
		
		po.setReceiver(ValueNameConstant.message_receipt_mobile2);
		replaceTemplateService.ReplaceTemplateContent(null, noreplace, "1", po);//插入短信发送表
		//----------------------------------------------------------------------------------------------------
	}
	
	/**
	 * 全退畅达币
	 * @param refundAndWasteTicketPO
	 * @return
	 */
	private boolean returnLcdcoin(RefundAndWasteTicketPO refundAndWasteTicketPO){
		boolean flag =false;
		String refundCoin = refundAndWasteTicketPO.getRefundCoin()==null || "".equals(refundAndWasteTicketPO.getRefundCoin()) ? "0" : refundAndWasteTicketPO.getRefundCoin();
		//获得订单信息
		OrderInfoPO orderInfoPO = orderManageService.find(refundAndWasteTicketPO.getOrderId());
		boolean refundLcdCoin = phoneCoinService.refundLcdCoin(orderInfoPO.getClearobjectId().toString(), refundCoin, refundAndWasteTicketPO.getTicketId(), "05");
		//新增退畅达币记录
		boolean insertHistoryRecord = insertHistoryRecord(new String[]{refundAndWasteTicketPO.getProcessId(),ApplicationVO.TASKNAME_RETURNLCDCOIN,refundAndWasteTicketPO.getRequisitionCode(),
				ApplicationVO.RESULT_START,refundCoin+ApplicationVO.ADVICE_LCDCOINNUM,ApplicationVO.AUTHORNAME_SYSTEMAUTO});
		if(refundLcdCoin && insertHistoryRecord) 
			flag = true;
			
		return flag;
	}
	
	/**
	 * 新增历史审批记录(启动流程)
	 * @param 数组
	 * 0:流程实例id, 1:任务名称, 2:退票或废票申请单编号, 3:审批结果, 4:审批意见, 5:操作人
	 * @return
	 */
	private boolean insertHistoryRecord(String[] str) {
		ApprovalHistoryVO approvalHistoryVO = new ApprovalHistoryVO();
		approvalHistoryVO.setExecutionid(SysUtil.ifNull(str[0]));
		approvalHistoryVO.setTaskname(SysUtil.ifNull(str[1]));
		approvalHistoryVO.setBusinesscode(SysUtil.ifNull(str[2]));
		approvalHistoryVO.setResult(SysUtil.ifNull(str[3]));
		approvalHistoryVO.setAdvice(SysUtil.ifNull(str[4]));
		approvalHistoryVO.setAuthorname(SysUtil.ifNull(str[5]));
		return approvalHistoryService.saveAdvice(approvalHistoryVO);
	}

	
	/**
	 * 启动审批流程实例
	 * @param refundAndWasteTicketVO
	 * @return
	 */
	private String startProcess(RefundAndWasteTicketPO refundAndWasteTicketPO) {
		String key = ApplicationVO.STARTPROCESSKEY_REFUND;
		
		//订单信息
		OrderInfoPO orderInfo = orderInfoService.find(refundAndWasteTicketPO.getOrderId());
		
		Map<String, Object> map = new HashMap<String, Object>();
		String receiptReturnType = refundAndWasteTicketPO.getReceiptReturnType();
		map.put("isReturnReceiption", ReceiptReturnTypeEnum.UnNeed.getValue().equals(receiptReturnType) || ReceiptReturnTypeEnum.UnPrint.getValue().equals(receiptReturnType) ? "false" : "true");
		map.put("reqId", refundAndWasteTicketPO.getId());
		map.put("ticketInfo", ticketService.findTicketInfoPOByTicketNo(refundAndWasteTicketPO.getTicketNo()));
		map.put("ticketNo", refundAndWasteTicketPO.getTicketNo());
		map.put("orderIdHU", SysUtil.ifNull(orderInfo.getExternalorderno()));
		map.put("insurancePrice", refundAndWasteTicketPO.getInsurance());
		if(refundAndWasteTicketPO.getProposerType().equals(ApplicationVO.WASTE)){
			key = ApplicationVO.STARTPROCESSKEY_WASTE;
		}
		return JBPMUtil.startProcess(key, map);
	}
	
	
	
	/**
	 * 退票或废票申请单页面信息
	 * 初始化申请页面时调用
	 * 包括客票信息、订单信息、支付流水信息、订单支付流水号、结算对象信息、申请单类型
	 * @param orderId
	 */
	private void getBasicInfoInit(ModelMap modelMap,long ticketId, String appType){
		try {
		//客票信息
		TicketInfoPO ticketInfoPO = ticketService.find(ticketId);
		
		//获取保单信息
		getInsuranceInfo(modelMap, ticketInfoPO);
		
		getInitInfo(modelMap, appType, ticketInfoPO);
		
		//初始化退款设置
		this.initRefundType(modelMap);
		
		//通过票号获得退票费率和手续费
		Map<String, Integer> refundRateByAirlinesAndSpace = ticketRateService.getRefundRateByAirlinesAndSpace(ticketInfoPO.getTicketNo());
		
		modelMap.addAttribute("ticketInfo", ticketInfoPO);
		modelMap.addAttribute("rate", refundRateByAirlinesAndSpace.get("rate"));
		modelMap.addAttribute("fee", refundRateByAirlinesAndSpace.get("fee"));
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void initRefundType(ModelMap modelMap){
		String value = "0";
		OrderInfoVO orderInfo = (OrderInfoVO)modelMap.get("orderAll");
		if(ApplicationVO.PAY_TRUST.equals(orderInfo.getPayType())){
			value = "2";
		}else if(ApplicationVO.PAY_COIN.equals(orderInfo.getPayType())){
			value = "3";
		}
		modelMap.put("InitRefundType", value);
	}
	
	/**
	 * 退票或废票申请单页面信息
	 * 查看和审批申请页面时调用
	 * 包括客票信息、订单信息、支付流水信息、订单支付流水号、结算对象信息、申请单类型
	 * @param orderId
	 */
	private void getBasicInfo(ModelMap modelMap,long reqId, String taskId){
		try {
		//获取申请单信息
		RefundAndWasteTicketPO refundAndWasteTicketPO = refundAndWasteTicketService.find(reqId);
		
		//客票信息
		TicketInfoPO ticketInfoPO = ticketService.find(refundAndWasteTicketPO.getTicketId());
		
		//获取初始化信息
		getInitInfo(modelMap, refundAndWasteTicketPO.getProposerType(), ticketInfoPO);
		
		refundAndWasteTicketPO.setTask(JBPMUtil.getTaskService().getTask(taskId));
		
		modelMap.addAttribute("ticketInfo", ticketInfoPO);
		modelMap.addAttribute("refundAndWasteTicketPO", refundAndWasteTicketPO);
		modelMap.addAttribute("historyApproval", approvalHistoryService.getHistoryApprovalList(refundAndWasteTicketPO.getRequisitionCode()));//获取历史审批记录
		modelMap.addAttribute("historyNodeName", JBPMUtil.getActivityTaskNameByExeId(refundAndWasteTicketPO.getProcessId()));//获取流程灯信息
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 获取支付信息、结算对象信息、订单信息
	 * @param modelMap
	 * @param appType
	 * @param ticketInfoPO
	 */
	private void getInitInfo(ModelMap modelMap, String appType,
			TicketInfoPO ticketInfoPO) {
		//支付流水信息
		List<PayJournalPO> payJournalList = payJournalService.findPayByOrderId(String.valueOf(ticketInfoPO.getOrderId()));

		//获取下拉框和值数组
		this.getSelectValueInfo(modelMap);
		
		modelMap.addAttribute("appType", appType);
		modelMap.addAttribute("payJournalNo", this.getPayJournalNo(payJournalList));
		modelMap.addAttribute("ext",orderManageService.findOrderExtInfo(ticketInfoPO.getOrderId()));//获得结算对象信息
		modelMap.addAttribute("orderAll", orderInfoService.findOrderDetailById(ticketInfoPO.getOrderId()));//订单信息
		modelMap.addAttribute("payJournallist", payJournalList);
	}

	/**
	 * 获取保险信息
	 * @param modelMap
	 * @param ticketInfoPO
	 */
	private void getInsuranceInfo(ModelMap modelMap, TicketInfoPO ticketInfoPO) {
		List<InsuranceInfoVO> InsuranceInfoVO = insuranceInfoService.findInsByTicketNo(ticketInfoPO.getTicketNo());
		if(InsuranceInfoVO.size() > 0){
			double compareTime = cn.itkt.util.DateUtil.compareTime(new Date(),ticketInfoPO.getTakeofftime()) ;
			if(compareTime > 30 && InsuranceInfoVO.get(0).getPrice()>0){
				modelMap.put("InsAmount", 1);//保险过期
			}else{
				modelMap.put("InsAmount", InsuranceInfoVO.get(0).getPrice());
			}
		}
	}
	
	/**
	 * 自动生成退票申请单或者废票申请单的申请单号
	 * @param appType
	 * @return
	 */
	private void createAppNo(ModelMap modelMap, String appType){
		String head = appType.equals(ApplicationVO.REFUND) ? "GNTP" : "GNFP";
		modelMap.addAttribute("RequisitionCode", DateUtil.getTimeSequence(head));
	}
	
	/**
	 * 获取代号的含义值
	 * @param modelMap
	 */
	private void getSelectValueInfo(ModelMap modelMap){
		modelMap.addAttribute("refundWay_", ConstantUtil.getDictionary(ConstantUtil.refundWay_));
		modelMap.addAttribute("receiptReturnType_", ConstantUtil.getDictionary(ConstantUtil.receiptReturnType_));
		modelMap.addAttribute("smsType_", ConstantUtil.getDictionary(ConstantUtil.smsType_));
		modelMap.addAttribute("billSendType_", ConstantUtil.getDictionary(ConstantUtil.billSendType_));
		modelMap.addAttribute("billPostType_", ConstantUtil.getDictionary(ConstantUtil.billPostType_));
		modelMap.addAttribute("refundWayList", ConstantUtil.getDictionary(ConstantUtil.payType_));
		modelMap.addAttribute("ticketstate", ConstantUtil.getDictionary(ConstantUtil.ticketState_));
	}
	/**
	 * 获取支付流水号,以2个空格相隔
	 * @param list
	 * @return
	 */
	private String getPayJournalNo(List<PayJournalPO> list){
		String serialno = "";
		try {
			for (PayJournalPO payJournalPO : list) {
				serialno += payJournalPO.getSerialno() + "   ";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return serialno;
	}
	
	public void findallWasteticket(ModelMap modelMap,RefundWasteConditionVO vo,int startIndex,String  proposerType) {
		Pages pages = new Pages(startIndex);
		pages.setPageSize(10);
		vo.setStartIndex(startIndex);
		vo.setPageSize(pages.getPageSize());
		vo.setProposerType(proposerType);
		try {
			//查询票信息
			List<RefundWasteConditionVO> list = refundAndWasteTicketService.findallWasteticket(vo);
			modelMap.addAttribute("list",list);
			int totalCount = refundAndWasteTicketService.account(vo);
			pages.setItems(list);
			pages.setTotalCount(totalCount);
			modelMap.addAttribute("page", pages);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * 审批任务
	 * @param modelMap
	 * @param approvalHistoryVO
	 */
	public void approval(ModelMap modelMap, ApprovalHistoryVO approvalHistoryVO){
		try {
			TaskService taskService = JBPMUtil.getTaskService();
			//新增历史审批记录
			boolean insertHistoryRecord = insertHistoryRecord(new String[]{approvalHistoryVO.getExecutionid(),approvalHistoryVO.getTaskname(),approvalHistoryVO.getBusinesscode(),
					approvalHistoryVO.getResult(),approvalHistoryVO.getAdvice(),""});
			
			//处理任务
			if(insertHistoryRecord){
				taskService.completeTask(approvalHistoryVO.getTaskid(), approvalHistoryVO.getTransationName());
				modelMap.addAttribute("message", ApplicationVO.APPROVAL_SUCCESS);
			}
			
		} catch (Exception e) {
			modelMap.addAttribute("message", ApplicationVO.APPROVAL_FAIL);
			e.printStackTrace();
		}
	}
	
	/**
	 * 挂起和解挂客票
	 * @param ticketNo
	 * @param lockType
	 * @return
	 */
	public void lockAndUnLockTicket(ModelMap modelMap, String ticketNo, String lockType){
		//0：挂起 1：解挂
		modelMap.put("message", "操作失败!");
		//黑屏挂起解挂
		if(changeTicketService.lockTicket(lockType, ticketNo)){
			modelMap.put("message", "操作成功!");
		}
	}

	/**
	 * 注销申请单
	 * @param modelMap
	 * @param approvalHistoryVO
	 */
	public void deleteReqByProcess(ModelMap modelMap, ApprovalHistoryVO approvalHistoryVO){
		//记录注销操作
		boolean insertHistoryRecord = this.insertHistoryRecord(new String[]{approvalHistoryVO.getExecutionid(),ApplicationVO.TASKNAME_CANCEL, approvalHistoryVO.getBusinesscode(),
				ApplicationVO.RESULT_CANCEL,approvalHistoryVO.getAdvice(),""});
		
		//注销申请单
		boolean flag = refundAndWasteTicketService.deleteOrderById(approvalHistoryVO.getBusinesscode());
		
		if(insertHistoryRecord && flag){
			modelMap.addAttribute("message", ApplicationVO.CANCEL_SUCCESS);
		}else{
			modelMap.addAttribute("message", ApplicationVO.CANCEL_FAIL);
		}
	}
	
	@Transactional(rollbackFor=Exception.class)
	public void getNdoTask(ModelMap modelMap,RefundWasteConditionVO vo,int startIndex,String assignee,String  proposerType){
		Pages<RefundWasteConditionVO> list = null;
		UserVO loginUser = LoginUtil.getLoginUser();
	    vo.setStartIndex(startIndex);
	    vo.setPageSize(10);
	    vo.setProposerType(proposerType);
		//获取订单信息
		try {
			//获取当前菜单的待办任务
			list =  refundAndWasteTicketService.getNdoTask(vo, loginUser,assignee,startIndex);
			modelMap.addAttribute("userid", loginUser.getId());
			modelMap.addAttribute("assignee", assignee);
			modelMap.addAttribute("list", list);
			modelMap.addAttribute("page", list);
			modelMap.addAttribute("channelTypeMap", ConstantUtil.getDictionary("15"));
			modelMap.addAttribute("saleTypeMap", ConstantUtil.getDictionary("6"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Transactional(rollbackFor=Exception.class)
	public void exportManager(ModelMap modelMap,RefundWasteConditionVO queryVO,String type) {
		queryVO.setProposerType(type);
		List<RefundWasteConditionVO> list = refundAndWasteTicketService.findallWasteticket(queryVO);
		modelMap.addAttribute("rList",list);
		modelMap.addAttribute("type", type);
	}
	public void upAllfee(ModelMap modelMap,RefundAndWasteTicketVO vo) {
		RefundAndWasteTicketPO po  = new RefundAndWasteTicketPO();
		po.setDeductCash(vo.getDeductCash());//应扣现金
		po.setDeductCoin(vo.getDeductCoin());//应扣畅达币
		po.setRefundCash(vo.getRefundCash());//应退现金
		po.setRefundCoin(vo.getRefundCoin());//应退畅达币
		po.setRate(vo.getRate());//应扣退票费率
		po.setFee(vo.getFee());//应扣退票费
		refundAndWasteTicketService.update(po);
	}
	/**
	 * 根据订单id获取订单
	 * @param orderId
	 */
	@Transactional(rollbackFor=Exception.class)
	public void getOrderById(ModelMap modelMap,long orderId){
		//获得订单信息
		OrderInfoVO orderAll = orderInfoService.findOrderDetailById(orderId);
		List<PayJournalPO> payList = payJournalService.findPayByOrderId(String.valueOf(orderId));
		//支付流水号
		String payNo = "";
		//支付方式
		String payType = "";
		payType = ConstantUtil.getDictionaryValue("35",orderAll.getPayType() );
		if(orderAll != null){
			for (PayJournalPO payJournalPO : payList) {
				payNo += payJournalPO.getSerialno() +"   ";
			}
			orderAll.setPayNo(payNo);
			orderAll.setPaymentType(payType);
		}
		//获得结算对象信息
		//订单信息
		OrderInfoPO order=orderManageService.findOrderByOrderNo(orderAll.getOrderNo());
		orderManageControllerSupport.findOrderDetail(order.getOrderNo(), modelMap, "query");
		OrderCcextVO ext=orderManageService.findOrderExtInfo(order);
		modelMap.addAttribute("ext",ext);
		modelMap.addAttribute("orderAll", orderAll);
	}
	/**
	 * 获取退款信息
	 */
	@Transactional(rollbackFor=Exception.class)
	public void getRequestAndWaste(ModelMap modelMap,String requisitionId){
		List<RefundAndWasteTicketPO>list=refundAndWasteTicketService.wasteAndRequestFee(requisitionId);
		RefundAndWasteTicketPO refundWasteConditionVO = new RefundAndWasteTicketPO();
		String requisitionCode="";
		for(int i=0;i<list.size();i++){
			refundWasteConditionVO = list.get(i);
			requisitionCode=refundWasteConditionVO.getRequisitionCode();
		}
		
		modelMap.addAttribute("requisitionCode", requisitionCode);
		modelMap.addAttribute("list", list);
	}
	/**
	 * 获取历史审批记录
	 * @param requisitionId
	 */
	public void getHistoryApprovalList(ModelMap modelMap,String requisitionId){
		List<ApprovalHistoryPO> approvalHistoryPO = new ArrayList<ApprovalHistoryPO>();
		String historyNodeName = "";
		try {
			//历史审批记录
			approvalHistoryPO = refundAndWasteTicketService.getHistoryApprovalList(requisitionId);
			
			//节点流程灯
			if(approvalHistoryPO.size() > 0){
				historyNodeName = JBPMUtil.getActivityTaskNameByExeId(approvalHistoryPO.get(0).getExecutionid());
			}
			
		} catch (AppException e) {
			e.printStackTrace();
		}
		modelMap.addAttribute("historyNodeName", historyNodeName);
		modelMap.addAttribute("historyApproval", approvalHistoryPO);
	}
	/**
	 * 获取相关订单信息
	 * @param orderId
	 */
	public void getAboutOrderInfo(ModelMap modelMap,long orderId){
		List<RefundOrderInfoVO> refundOrderInfoVO = new ArrayList<RefundOrderInfoVO>();
		try {
			refundOrderInfoVO = refundAndWasteTicketService.getAboutOrderInfo(orderId);
			//获取即将到期客票有效期
			List<BusinessParameterPO> poList = businessParameterService.findBusinessParameterAll();
			if(poList.size()>0){
				modelMap.addAttribute("invalid", poList.get(0).getTicketInvalidDate());
			}else{
				modelMap.addAttribute("invalid", 0);
			}
		} catch (AppException e) {
			e.printStackTrace();
		}
		modelMap.addAttribute("ticketstate",  ConstantUtil.getDictionary("25"));//客票状态
		modelMap.put("aboutOrder", refundOrderInfoVO);
	}
}