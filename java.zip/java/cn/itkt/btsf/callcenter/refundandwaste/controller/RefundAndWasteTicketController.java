package cn.itkt.btsf.callcenter.refundandwaste.controller;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.annotation.Resource;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import cn.itkt.exception.AppException;
import cn.itkt.btsf.callcenter.refundandwaste.vo.RefundAndWasteTicketVO;
import cn.itkt.btsf.callcenter.refundandwaste.vo.RefundWasteConditionVO;
import cn.itkt.btsf.sys.adjustable.vo.ApprovalHistoryVO;
import cn.itkt.btsf.sys.cc.national.vo.RefundTicketVO;
import cn.itkt.btsf.sys.common.constant.ConstantUtil;


@Controller
@RequestMapping("/callcenter/refundandwasteticket")
public class RefundAndWasteTicketController {

	@Resource
	private  RefundAndWasteTicketControllerSupport  refundAndWasteTicketControllerSupport;

	/**
	 * 申请退票或废票页面初始化
	 * @param ticketId 客票id
	 * @param appType 申请单类型: 退票:refund, 废票:waste
	 * @return
	 */
	@RequestMapping("/applicateRefundAndWaste")
	public String applicate(ModelMap modelMap, long ticketId, String appType){
		refundAndWasteTicketControllerSupport.applicate(modelMap, ticketId, appType);
		return "/callcenter/refundticket/application";
	}
	
	/**
	 * 提交退票和废票申请单
	 * @param modelMap
	 * @param refundAndWasteTicketVO
	 */
	@RequestMapping("/submit")
	public ModelAndView submit(ModelMap modelMap, @ModelAttribute("refundAndWasteTicketVO")RefundAndWasteTicketVO refundAndWasteTicketVO){
		refundAndWasteTicketControllerSupport.submit(modelMap, refundAndWasteTicketVO);
		return new ModelAndView("jsonView",modelMap);
	}
	
	/**
	 * 显示审批申请单页面
	 * @param modelMap
	 * @param reqId
	 * @return
	 */
	@RequestMapping("/approvalPage")
	public String approvalPage(ModelMap modelMap, long reqId, String taskId){
		refundAndWasteTicketControllerSupport.approvalPage(modelMap, reqId, taskId);
		return "/callcenter/refundticket/approval";
	}
	
	/**
	 * 显示修改申请单页面
	 * @param modelMap
	 * @param reqId
	 * @return
	 */
	@RequestMapping("/updatePage")
	public String updatePage(ModelMap modelMap, long reqId, String taskId){
		refundAndWasteTicketControllerSupport.approvalPage(modelMap, reqId, taskId);
		return "/callcenter/refundticket/update";
	}
	
	/**
	 * 修改申请单页面
	 * @param modelMap
	 * @param reqId
	 * @return
	 */
	@RequestMapping("/update")
	public ModelAndView update(ModelMap modelMap, @ModelAttribute("refundAndWasteTicketVO")RefundAndWasteTicketVO refundAndWasteTicketVO, String taskId){
		refundAndWasteTicketControllerSupport.doUpdate(modelMap, refundAndWasteTicketVO, taskId);
		return new ModelAndView("jsonView",modelMap);
	}
	
	
	/**
	 * 审批申请单操作
	 * @param modelMap
	 * @param reqId
	 * @return
	 */
	@RequestMapping("/doApproval")
	public ModelAndView approval(ModelMap modelMap, @ModelAttribute("approvalHistoryVO") ApprovalHistoryVO approvalHistoryVO){
		refundAndWasteTicketControllerSupport.approval(modelMap, approvalHistoryVO);
		return new ModelAndView("jsonView",modelMap);
	}
	
	/**
	 * 获取待办任务
	 * @param modelMap
	 * @param reqId
	 * @return
	 */
	@RequestMapping("/todoList")
	public ModelAndView todoList(ModelMap modelMap, @RequestParam(value = "startIndex", defaultValue = "0") int startIndex,String assignee){
		return new ModelAndView("jsonView",modelMap);
	}
	
	
	/**
	 * 注销退票申请单
	 * @param modelMap
	 * @return
	 */
	@RequestMapping("/cancelApplication")
	public ModelAndView deleteReqByProcess(ModelMap modelMap, @ModelAttribute("approvalHistoryVO") ApprovalHistoryVO approvalHistoryVO){
		refundAndWasteTicketControllerSupport.deleteReqByProcess(modelMap, approvalHistoryVO);
		return new ModelAndView("jsonView",modelMap);
	}
	
	@RequestMapping("/RefundTicketandWasteList")
	public String RefundTicketManagerList(ModelMap modelMap,@ModelAttribute RefundWasteConditionVO wasteandrefundvo,@RequestParam(value = "startIndex", defaultValue = "0") int startIndex,String  proposerType){
		refundAndWasteTicketControllerSupport.findallWasteticket(modelMap,wasteandrefundvo,startIndex,proposerType);
		modelMap.addAttribute("reVO",wasteandrefundvo);
		modelMap.addAttribute("channelTypeMap",ConstantUtil.getDictionary("15"));
		modelMap.addAttribute("saleTicket",ConstantUtil.getDictionary("6"));
		return "/callcenter/refundticket/quertlist";
	}
	@RequestMapping("/findRefundTicketlist")
	public String findRefundTicketlist(ModelMap modelMap,@ModelAttribute RefundWasteConditionVO wasteandrefundvo,@RequestParam(value = "startIndex", defaultValue = "0") int startIndex,String assignee,String  proposerType){
		refundAndWasteTicketControllerSupport.getNdoTask(modelMap,wasteandrefundvo, startIndex,assignee,proposerType);
		modelMap.addAttribute("reVO",wasteandrefundvo);
		modelMap.addAttribute("assignee",assignee);
		modelMap.addAttribute("channelTypeMap",ConstantUtil.getDictionary("15"));
		modelMap.addAttribute("saleTicket",ConstantUtil.getDictionary("6"));
		return "/callcenter/refundticket/listAll";
	}
	
	/**
	 * 挂起和解挂客票
	 * @param ticketNo 票号
	 * @param lockType 0：挂起  1：解挂
	 * @return
	 */
	@RequestMapping("/lockAndUnLockTicket")
	public ModelAndView lockAndUnLockTicket(ModelMap modelMap,@RequestParam String ticketNo,@RequestParam String lockType) throws AppException{
		refundAndWasteTicketControllerSupport.lockAndUnLockTicket(modelMap, ticketNo,lockType);
		return new ModelAndView("jsonView",modelMap);
	}


	/**
	 * 注册指定日期格式的日期属性编辑器
	 * 
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		formater.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formater, true));
	}
	/**
	 * 导出获取废票维护列表
	 * @param modelMap
	 * @param queryVO
	 * @return
	 */
	@RequestMapping(value="export.xls")
	public String exportManager(ModelMap modelMap,@ModelAttribute RefundWasteConditionVO queryVO,@RequestParam String type){
		refundAndWasteTicketControllerSupport.exportManager(modelMap, queryVO,type);
		return "exportReportAndWaste";
		
	}
	/**
	 * 主管（修改流程）修改
	 */
	@RequestMapping(value="upAllfee")
	public void upAllfee(ModelMap modelMap,@ModelAttribute RefundAndWasteTicketVO vo){
		refundAndWasteTicketControllerSupport.upAllfee(modelMap, vo);
	}
	@RequestMapping("/showRequest")
	@Transactional(rollbackFor=Exception.class)
	public String showRequest(ModelMap modelMap,@RequestParam String requisitionId,@RequestParam long orderId){
		refundAndWasteTicketControllerSupport.getOrderById(modelMap, orderId);//获取订单信息
		refundAndWasteTicketControllerSupport.getRequestAndWaste(modelMap, requisitionId);//获取退票申请单信息(新表)
		refundAndWasteTicketControllerSupport.getHistoryApprovalList(modelMap, requisitionId);//获取历史审批记录
		refundAndWasteTicketControllerSupport.getAboutOrderInfo(modelMap, orderId);//获得相关订单
		modelMap.addAttribute("action", "show");//ddddddddddddddddddddddd
		return "/callcenter/refundticket/detail";
	}
}