package cn.itkt.btsf.rentcar.export;

import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import cn.itkt.btsf.rentcar.controller.RentCarControllerSupport;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

import com.sun.xml.internal.messaging.saaj.packaging.mime.internet.MimeUtility;

public class RentCarExcel extends AbstractExcelView {

	@Override
	protected void buildExcelDocument(Map<String, Object> arg0, HSSFWorkbook Workbook, HttpServletRequest arg2, HttpServletResponse arg3) throws Exception {
		String filename = "";
		DecimalFormat df = new DecimalFormat("########0.00");
		DecimalFormat dfFloor = new DecimalFormat("########0.00");// 畅达币全 整数
		String terminalid = "callcenter;callcenter:" + (cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
		HSSFSheet sheet = Workbook.createSheet("神州结算");
		HSSFSheet sheet2 = Workbook.createSheet("畅达币结算");
		sheet.setDefaultColumnWidth(20);
		sheet2.setDefaultColumnWidth(20);
		// 设置表头
		setText(getCell(sheet, 0, 0), "序号");
		setText(getCell(sheet, 0, 1), "预定日期");
		setText(getCell(sheet, 0, 2), "订单编号");
		setText(getCell(sheet, 0, 3), "神州订单号");
		setText(getCell(sheet, 0, 4), "订单来源");
		setText(getCell(sheet, 0, 5), "客户类型");
		setText(getCell(sheet, 0, 6), "会员名称");
		setText(getCell(sheet, 0, 7), "会员电话");
		setText(getCell(sheet, 0, 8), "订单状态");
		setText(getCell(sheet, 0, 9), "取车门店");
		setText(getCell(sheet, 0, 10), "还车门店");
		setText(getCell(sheet, 0, 11), "取车时间");
		setText(getCell(sheet, 0, 12), "还车时间");
		setText(getCell(sheet, 0, 13), "租期");
		setText(getCell(sheet, 0, 14), "车辆信息");
		setText(getCell(sheet, 0, 15), "总租金");
		setText(getCell(sheet, 0, 16), "操作人");
		setText(getCell(sheet, 0, 17), "取车人姓名");
		setText(getCell(sheet, 0, 18), "取车人手机");
		setText(getCell(sheet, 0, 19), "证件类型");
		setText(getCell(sheet, 0, 20), "证件号码");

		setText(getCell(sheet, 0, 30), "订单总金额"); // 现有八项服务+其它
		setText(getCell(sheet, 0, 31), "神州结算金额");
		setText(getCell(sheet, 0, 32), "神州返佣率");
		setText(getCell(sheet, 0, 33), "神州返佣金额");
		setText(getCell(sheet, 0, 34), "备注");

		setText(getCell(sheet2, 0, 0), "序号");
		setText(getCell(sheet2, 0, 1), "预定日期");
		setText(getCell(sheet2, 0, 2), "订单编号");
		setText(getCell(sheet2, 0, 3), "神州订单号");
		setText(getCell(sheet2, 0, 4), "订单来源");
		setText(getCell(sheet2, 0, 5), "客户类型");
		setText(getCell(sheet2, 0, 6), "会员名称");
		setText(getCell(sheet2, 0, 7), "会员电话");
		setText(getCell(sheet2, 0, 8), "订单状态");
		setText(getCell(sheet2, 0, 9), "取车门店");
		setText(getCell(sheet2, 0, 10), "还车门店");
		setText(getCell(sheet2, 0, 11), "取车时间");
		setText(getCell(sheet2, 0, 12), "还车时间");
		setText(getCell(sheet2, 0, 13), "租期");
		setText(getCell(sheet2, 0, 14), "车辆信息");
		setText(getCell(sheet2, 0, 15), "总租金");
		setText(getCell(sheet2, 0, 16), "操作人");
		setText(getCell(sheet2, 0, 17), "取车人姓名");
		setText(getCell(sheet2, 0, 18), "取车人手机");
		setText(getCell(sheet2, 0, 19), "证件类型");
		setText(getCell(sheet2, 0, 20), "证件号码");

		setText(getCell(sheet2, 0, 30), "订单总金额");
		setText(getCell(sheet2, 0, 31), "可返畅达币总金额");
		setText(getCell(sheet2, 0, 32), "畅达币返佣率");
		setText(getCell(sheet2, 0, 33), "返畅达币金额");
		setText(getCell(sheet2, 0, 34), "备注");
		// 其余服务算为其它
		setText(getCell(sheet, 0, 29), "其它");
		setText(getCell(sheet2, 0, 29), "其它");

		// 获取维护服务信息
		int k = 21; // 服务开始列
		Map<String, String> extAllMap = new HashMap<String, String>();// 全部服务信息(服务维护)
		Map<String, String> extCheckMap = new HashMap<String, String>();// 已选服务
		//查询维护服务信息
		String[][] serviceExt=(String[][]) arg0.get("ServicesExt");
		for (int i = 1; i < serviceExt.length; i++) {
			extAllMap.put(serviceExt[i][1], serviceExt[i][2]);
			if ("1".equals(serviceExt[i][7]))//是否已选
				extCheckMap.put(serviceExt[i][1], serviceExt[i][2]);
			setText(getCell(sheet, 0, k), serviceExt[i][2]);
			setText(getCell(sheet2, 0, k), serviceExt[i][2]);
			k++;
		}

		// 获取活动信息
		// Double per = Double.valueOf(arg0.get("PER").toString());// 百分比
		// Double Immovable =
		// Double.valueOf(arg0.get("IMMOVABLE").toString());// 固定值

		// 获取数据
		Pages page = (Pages) arg0.get("page");
		List<HashMap<String, String>> list0 = (List<HashMap<String, String>>) page.getItems();	

		if (list0 != null && list0.size() > 0) {
			for (int i = 0; i < list0.size(); i++) {
				Double szServiceMoney = 0D;// 神州服务费用 目前只有八项
				Double Other = 0D;// 其它服务费用
				HashMap<String, String> hashMap = list0.get(i);
				// 同步租车订单数据
				// RentCarServiceHandler.instance().synOrderInfo(terminalid,
				// hashMap.get("ORDERNO").toString(),
				// hashMap.get("ID").toString());
				// 填充数据

				setText(getCell(sheet, (i + 1), 0), String.valueOf(SysUtil.ifNull(i + 1)));
				setText(getCell(sheet, (i + 1), 1), String.valueOf(SysUtil.ifNull(hashMap.get("ADDTIME"))));
				setText(getCell(sheet, (i + 1), 2), String.valueOf(SysUtil.ifNull(hashMap.get("LCDORDERNO"))));
				setText(getCell(sheet, (i + 1), 3), String.valueOf(SysUtil.ifNull(hashMap.get("ORDERNO"))));
				if (hashMap.get("SOURCE") != null && !"".equals(hashMap.get("SOURCE")))
					setText(getCell(sheet, (i + 1), 4), String.valueOf(SysUtil.ifNull(switchsource(hashMap.get("SOURCE").toString()))));
				if (hashMap.get("MEMBERID") != null && !"".equals(hashMap.get("MEMBERID")))
					setText(getCell(sheet, (i + 1), 5), "掌上航旅");
				else
					setText(getCell(sheet, (i + 1), 5), "散客");
				setText(getCell(sheet, (i + 1), 6), String.valueOf(SysUtil.ifNull(hashMap.get("PNAME"))));
				setText(getCell(sheet, (i + 1), 7), String.valueOf(SysUtil.ifNull(hashMap.get("PTELEPHONE"))));
				setText(getCell(sheet, (i + 1), 8), String.valueOf(SysUtil.ifNull(hashMap.get("ORDERSTATUS"))));
				setText(getCell(sheet, (i + 1), 9), String.valueOf(SysUtil.ifNull(hashMap.get("FROMSTORE"))));
				setText(getCell(sheet, (i + 1), 10), String.valueOf(SysUtil.ifNull(hashMap.get("TOSTORE"))));
				setText(getCell(sheet, (i + 1), 11), String.valueOf(SysUtil.ifNull(hashMap.get("FROMDATE"))));
				setText(getCell(sheet, (i + 1), 12), String.valueOf(SysUtil.ifNull(hashMap.get("TODATE"))));
				// System.out.println(hashMap.get("ID"));
				setText(getCell(sheet, (i + 1), 13),
						RentCarControllerSupport.compare(String.valueOf(SysUtil.ifNull(hashMap.get("FROMDATE"))), String.valueOf(SysUtil.ifNull(hashMap.get("TODATE")))).toString()
								+ "天");
				setText(getCell(sheet, (i + 1), 14), String.valueOf(SysUtil.ifNull(hashMap.get("CARTYPE") == null ? "个性车（不指定车型）" : hashMap.get("CARTYPE").toString())));
				setText(getCell(sheet, (i + 1), 15), String.valueOf(SysUtil.ifNull(hashMap.get("TOTALCARRENTMONEY"))));
				setText(getCell(sheet, (i + 1), 16), String.valueOf(SysUtil.ifNull(hashMap.get("UNAME"))));
				setText(getCell(sheet, (i + 1), 17), String.valueOf(SysUtil.ifNull(hashMap.get("USERNAME"))));
				setText(getCell(sheet, (i + 1), 18), String.valueOf(SysUtil.ifNull(hashMap.get("PHONENO"))));
				if (hashMap.get("IDCARDTYPE") != null && !"".equals(hashMap.get("IDCARDTYPE")))
					setText(getCell(sheet, (i + 1), 19), switchIdType(String.valueOf(SysUtil.ifNull(hashMap.get("IDCARDTYPE")))));
				setText(getCell(sheet, (i + 1), 20), String.valueOf(SysUtil.ifNull(hashMap.get("IDCARD"))));
				setText(getCell(sheet, (i + 1), 34), String.valueOf(SysUtil.ifNull(hashMap.get("COMMENTS"))));// 备注
				setText(getCell(sheet, (i + 1), 30), StrFormat(SysUtil.ifNull(hashMap.get("TOTALORDERPRICE"))));

				// 取订单服务信息
				String serviceStr =  hashMap.get("Services");//未拆分服务
				if(StringUtils.isNotBlank(serviceStr)){
					List<String> servicelist =serviceSplit(serviceStr);//拆分服务
					Map<String, String> serviceMap = new HashMap<String, String>();// 订单服务信息
					for (int ij = 0; ij < servicelist.size(); ij++) {
						String ServiceCode = null;
						String []service=servicelist.get(ij).split(";");
						if (service[4] != null && service[0] != null) {
							ServiceCode = service[4];// 服务编码
							String ServiceName = service[0];// 服务名
							String Price = service[1];// 服务费用
							serviceMap.put(ServiceName, StrFormat(Price));
							// 七项服务中不包含当前订单服务时添加到其它
							if (extAllMap.get(ServiceCode) == null)
								Other += Double.valueOf(Price);
						}
					}
					for (int ii = 21; ii < 29; ii++) {
						String CellName = getCell(sheet, 0, ii).getStringCellValue();// 表格服务名
						String p = serviceMap.get(CellName);
						// 未确定编码 测试用 订单中的三基费用
						if ("日租金".equals(CellName.trim())) {
							setText(getCell(sheet, (i + 1), ii), hashMap.get("TOTALCARRENTMONEY").toString());
							setText(getCell(sheet2, (i + 1), ii), hashMap.get("TOTALCARRENTMONEY").toString());
						} else if ("必选保险费用".equals(CellName.trim())) {
							setText(getCell(sheet, (i + 1), ii), hashMap.get("INSURANCEFEE").toString());
							setText(getCell(sheet2, (i + 1), ii), hashMap.get("INSURANCEFEE").toString());
						} else if ("手续费".equals(CellName.trim())) {
							setText(getCell(sheet, (i + 1), ii), hashMap.get("SERVICEFEE").toString());
							setText(getCell(sheet2, (i + 1), ii), hashMap.get("SERVICEFEE").toString());
						} else {
							setText(getCell(sheet, (i + 1), ii), serviceMap.get(CellName));
							setText(getCell(sheet2, (i + 1), ii), serviceMap.get(CellName));
						}
						if (StringUtils.isNotBlank(getCell(sheet, (i + 1), ii).getStringCellValue()))
							szServiceMoney += Double.valueOf(getCell(sheet, (i + 1), ii).getStringCellValue());
					}
				} else {
					for (int ii = 21; ii < 29; ii++) {
						String CellName = getCell(sheet, 0, ii).getStringCellValue();// 表格服务名
						// 未确定编码 测试用 订单中的三基费用
						if ("日租金".equals(CellName.trim())) {
							setText(getCell(sheet, (i + 1), ii), hashMap.get("TOTALCARRENTMONEY").toString());
							setText(getCell(sheet2, (i + 1), ii), hashMap.get("TOTALCARRENTMONEY").toString());
						} else if ("必选保险费用".equals(CellName.trim())) {
							setText(getCell(sheet, (i + 1), ii), hashMap.get("INSURANCEFEE").toString());
							setText(getCell(sheet2, (i + 1), ii), hashMap.get("INSURANCEFEE").toString());
						} else if ("手续费".equals(CellName.trim())) {
							setText(getCell(sheet, (i + 1), ii), hashMap.get("SERVICEFEE").toString());
							setText(getCell(sheet2, (i + 1), ii), hashMap.get("SERVICEFEE").toString());
						}
						if (StringUtils.isNotBlank(getCell(sheet, (i + 1), ii).getStringCellValue()))
							szServiceMoney += Double.valueOf(getCell(sheet, (i + 1), ii).getStringCellValue());
					}
				}
				// 其它金额
				setText(getCell(sheet, (i + 1), 29), Double.valueOf(Other).toString());
				setText(getCell(sheet2, (i + 1), 29), Double.valueOf(Other).toString());
				// 当前订单是否已结算 , “同城异店还车、其它、订单总金额、神州结算金额（默认空，当导入神州报表后添加）
				String isChange = hashMap.get("IS_CHANGE").toString();
				if (isChange != null && !"0".equals(isChange)) {
					szServiceMoney = Double.valueOf(hashMap.get("SETTLE_RETURN_MONEY").toString());
					setText(getCell(sheet, (i + 1), 23 + 8), df.format(szServiceMoney));
				} else {
					setText(getCell(sheet, (i + 1), 31), null);// 神州结算金额
				}

				setText(getCell(sheet, (i + 1), 24 + 8), "0.06");// 目前神州返佣率 6%
				if (isChange != null && !"0".equals(isChange)) {
					Double v = Double.valueOf(getCell(sheet, (i + 1), 23 + 8).getStringCellValue());
					if (v != null && v != 0)
						setText(getCell(sheet, (i + 1), 25 + 8), df.format(v * 0.06));// 神州返佣金额
				}
				// 第二张报表
				setText(getCell(sheet2, (i + 1), 0), String.valueOf(SysUtil.ifNull(i + 1)));
				setText(getCell(sheet2, (i + 1), 1), String.valueOf(SysUtil.ifNull(hashMap.get("ADDTIME"))));
				setText(getCell(sheet2, (i + 1), 2), String.valueOf(SysUtil.ifNull(hashMap.get("LCDORDERNO"))));
				setText(getCell(sheet2, (i + 1), 3), String.valueOf(SysUtil.ifNull(hashMap.get("ORDERNO"))));
				if (hashMap.get("SOURCE") != null && !"".equals(hashMap.get("SOURCE")))
					setText(getCell(sheet2, (i + 1), 4), String.valueOf(SysUtil.ifNull(switchsource(hashMap.get("SOURCE").toString()))));
				if (hashMap.get("MEMBERID") != null && !"".equals(hashMap.get("MEMBERID")))
					setText(getCell(sheet2, (i + 1), 5), "掌上航旅");
				else
					setText(getCell(sheet2, (i + 1), 5), "散客");
				setText(getCell(sheet2, (i + 1), 6), String.valueOf(SysUtil.ifNull(hashMap.get("PNAME"))));
				setText(getCell(sheet2, (i + 1), 7), String.valueOf(SysUtil.ifNull(hashMap.get("PTELEPHONE"))));
				setText(getCell(sheet2, (i + 1), 8), String.valueOf(SysUtil.ifNull(hashMap.get("ORDERSTATUS"))));
				setText(getCell(sheet2, (i + 1), 9), String.valueOf(SysUtil.ifNull(hashMap.get("FROMSTORE"))));
				setText(getCell(sheet2, (i + 1), 10), String.valueOf(SysUtil.ifNull(hashMap.get("TOSTORE"))));
				setText(getCell(sheet2, (i + 1), 11), String.valueOf(SysUtil.ifNull(hashMap.get("FROMDATE"))));
				setText(getCell(sheet2, (i + 1), 12), String.valueOf(SysUtil.ifNull(hashMap.get("TODATE"))));
				setText(getCell(sheet2, (i + 1), 13),
						RentCarControllerSupport.compare(String.valueOf(SysUtil.ifNull(hashMap.get("FROMDATE"))), String.valueOf(SysUtil.ifNull(hashMap.get("TODATE")))).toString()
								+ "天");
				setText(getCell(sheet2, (i + 1), 14), String.valueOf(SysUtil.ifNull(hashMap.get("CARTYPE") == null ? "个性车（不指定车型）" : hashMap.get("CARTYPE").toString())));
				setText(getCell(sheet2, (i + 1), 15), String.valueOf(SysUtil.ifNull(hashMap.get("TOTALCARRENTMONEY"))));
				setText(getCell(sheet2, (i + 1), 16), String.valueOf(SysUtil.ifNull(hashMap.get("UNAME"))));
				setText(getCell(sheet2, (i + 1), 17), String.valueOf(SysUtil.ifNull(hashMap.get("USERNAME"))));
				setText(getCell(sheet2, (i + 1), 18), String.valueOf(SysUtil.ifNull(hashMap.get("PHONENO"))));
				if (hashMap.get("IDCARDTYPE") != null && !"".equals(hashMap.get("IDCARDTYPE")))
					setText(getCell(sheet2, (i + 1), 19), switchIdType(String.valueOf(SysUtil.ifNull(hashMap.get("IDCARDTYPE")))));
				setText(getCell(sheet2, (i + 1), 20), String.valueOf(SysUtil.ifNull(hashMap.get("IDCARD"))));
				setText(getCell(sheet2, (i + 1), 34), String.valueOf(SysUtil.ifNull(hashMap.get("COMMENTS"))));// 备注
				setText(getCell(sheet2, (i + 1), 30), StrFormat(SysUtil.ifNull(hashMap.get("TOTALORDERPRICE"))));
				if (hashMap.get("MEMBERID") != null && !"".equals(hashMap.get("MEMBERID"))) { // 散客不返畅达币
					String rate = null, rateValue = null;
					// 原始返佣金额
					String LCD = String.valueOf(SysUtil.ifNull(hashMap.get("LCD")));
					boolean falg = false;
					if (hashMap.get("LCDRATE") != null)
						rate = hashMap.get("LCDRATE").toString();// 返点
					// rateValue = hashMap.get("LCDVALUE").toString();// 返值
					// 车辆租金和必选保险费用两项和为返畅达币总金额
					      //setText(getCell(sheet2, (i + 1), 23 + 8),
							//dfFloor.format(switchToFloor(switchData(hashMap.get("TOTALCARRENTMONEY").toString()) + switchData(hashMap.get("INSURANCEFEE").toString()))));
					// 当前订单是否已结算
					isChange = hashMap.get("IS_CHANGE").toString();
					if (isChange != null && !"0".equals(isChange) ) { 
						//String adJust = hashMap.get("ADJUST_LCD").toString();
						//if (!"0".equals(adJust))
							// 已结算订单 可返畅达币为结算后金额
							//setText(getCell(sheet2, (i + 1), 23 + 8), hashMap.get("SETTLE_RETURN_MONEY").toString());
						setText(getCell(sheet2, (i + 1), 23 + 8), hashMap.get("LCD_MONEY").toString());
						falg = true;
					}
					if (StringUtils.isNotBlank(rate)) {
						setText(getCell(sheet2, (i + 1), 24 + 8), Double.valueOf(rate) * 100 + "%");// 目前租车返利率
						if (falg) {
							LCD = dfFloor.format(Double.valueOf(rate) * Double.valueOf(hashMap.get("SETTLE_RETURN_MONEY").toString()));
						}
					} else
						setText(getCell(sheet2, (i + 1), 24 + 8), "1%");// 目前租车返利率
					setText(getCell(sheet2, (i + 1), 25 + 8), LCD);// 神州返佣金额
				} else {
					setText(getCell(sheet2, (i + 1), 23 + 8), "0");
					setText(getCell(sheet2, (i + 1), 24 + 8), "0");
					setText(getCell(sheet2, (i + 1), 25 + 8), "0");
				}
			}
		}

		// 设置下载时客户端Excel的名称
		filename = "租车结算报表-" + DateUtil.dateToString((new Date())) + ".xls";

		filename = this.encodeFilename(filename, arg2);// 处理中文文件名
		arg3.setContentType("application/vnd.ms-excel");
		arg3.setHeader("Content-disposition", "attachment;filename=" + filename);
		OutputStream ouputStream = arg3.getOutputStream();
		Workbook.write(ouputStream);
		ouputStream.flush();
		ouputStream.close();

	}

	/**
	 * 订单来源
	 * 
	 * @param arg0
	 * @return
	 */
	public static String switchsource(String v) {
		int value = Integer.valueOf(v);
		String result = "";
		switch (value) {
		case 2:
			result = "网站";
			break;
		case 1:
			result = "掌上航旅";
			break;
		case 3:
			result = "终端设备";
			break;
		case 4:
			result = "呼叫中心";
			break;
		case 5:
			result = "海航";
			break;
		case 6:
			result = "中科软商户";
			break;
		case 7:
			result = "银联商务总部";
			break;
		case 8:
			result = "银联商务北京";
			break;

		}
		return result;
	}

	/**
	 * 订单状态
	 * 
	 * @param arg0
	 * @return
	 */
	public static String swittatus(String v) {
		int value = Integer.valueOf(v);
		String result = "";
		switch (value) {
		case 1:
			result = "已预订";
			break;
		case 2:
			result = "租赁中";
			break;
		case 3:
			result = "已完成";
			break;
		case 4:
			result = "已取消";
			break;

		}
		return result;
	}

	/**
	 * 证件类型
	 * 
	 * @param arg0
	 * @return
	 */
	public static String switchIdType(String v) {
		int value = Integer.valueOf(v);
		String result = "";
		switch (value) {
		case 10:
			result = "身份证/驾驶证";
			break;
		case 11:
			result = "台湾";
			break;
		case 12:
			result = "港澳";
			break;
		case 13:
			result = "外籍护照";
			break;
		case 14:
			result = "军官证";
			break;

		}
		return result;
	}

	/**
	 * String 转Double
	 * 
	 * @param arg0
	 * @return
	 */
	public static Double switchData(String v) {
		Double result = 0D;
		if (StringUtils.isNotBlank(v))
			result = Double.valueOf(v);
		return result;
	}
	/**
	 * String 格式化
	 * 
	 * @param arg0
	 * @return
	 */
	public static String StrFormat(String v) {
		String result ="";
		DecimalFormat df = new DecimalFormat("########0.00");
		if (StringUtils.isNotBlank(v)){
			result = df.format(Double.valueOf(v));
		 
		}
		return result;
	}

	public static Double switchToFloor(Double v) {
		if (v != null)
			return Math.floor(v);
		else
			return 0D;
	}
	/**
	 * 增值服务名 +“;” + 总价 +“;”+单位+”;”+描述+”+code
	 * 
	 * @param service
	 * @return 
	 */
	private List<String> serviceSplit(String service) {
		String result = null;
		List list=new ArrayList<String>();
		if (StringUtils.isNotBlank(service)) {
			String[] args1 = service.split("\\+");
			for (int i = 0; i < args1.length; i++) {
				result= args1[i];
				if(StringUtils.isBlank(result))
				   list.add("");
				else
				   list.add(result);
			}
		}
		return list;
	}
	/**
	 * 设置下载文件中文件的名称
	 * 
	 * @param filename
	 * @param request
	 * @return
	 */
	public static String encodeFilename(String filename, HttpServletRequest request) {
		/**
		 * 获取客户端浏览器和操作系统信息 在IE浏览器中得到的是：User-Agent=Mozilla/4.0 (compatible; MSIE
		 * 6.0; Windows NT 5.1; SV1; Maxthon; Alexa Toolbar)
		 * 在Firefox中得到的是：User-Agent=Mozilla/5.0 (Windows; U; Windows NT 5.1;
		 * zh-CN; rv:1.7.10) Gecko/20050717 Firefox/1.0.6
		 */
		String agent = request.getHeader("USER-AGENT");
		try {
			if ((agent != null) && (-1 != agent.indexOf("MSIE"))) {
				String newFileName = URLEncoder.encode(filename, "UTF-8");
				newFileName = newFileName.replace("+", "%20");
				if (newFileName.length() > 150) {
					newFileName = new String(filename.getBytes("GB2312"), "ISO8859-1");
					newFileName = newFileName.replace("+", "%20");
				}
				return newFileName;
			}
			if ((agent != null) && (-1 != agent.indexOf("Mozilla")))
				return MimeUtility.encodeText(filename, "UTF-8", "B");

			return filename;
		} catch (Exception ex) {
			return filename;
		}
	}

}
