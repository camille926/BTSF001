package cn.itkt.btsf.rentcar.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.naming.LinkLoopException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.record.formula.functions.T;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.multipart.MultipartFile;

import cn.itkt.btsf.phone.users.po.PhoneCoinDetailsPO;
import cn.itkt.btsf.phone.users.po.PhoneCoinPO;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.phone.users.service.PhoneCoinDetailsService;
import cn.itkt.btsf.phone.users.service.PhoneCoinService;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.rentcar.po.RentCarChangePO;
import cn.itkt.btsf.rentcar.po.RentCarOrderPO;
import cn.itkt.btsf.rentcar.po.RentCarPO;
import cn.itkt.btsf.rentcar.po.RentCarServiceExtPO;
import cn.itkt.btsf.rentcar.po.RentCarTypesPO;
import cn.itkt.btsf.rentcar.service.RentCarService;
import cn.itkt.btsf.rentcar.service.webservice.RentCarServiceHandler;
import cn.itkt.btsf.sys.security.vo.UserVO;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.btsf.util.ExcelPoiUtils;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.btsf.util.PinyinConversionUtils;
import cn.itkt.exception.AppException;
import cn.itkt.pagination.Pages;

import com.opensymphony.oscache.util.StringUtil;

@Service
public class RentCarControllerSupport {

	private static final Logger log = LoggerFactory.getLogger(RentCarControllerSupport.class);
	private static String terminal = "callcenter;callcenter:" + (cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
	// 一小时
	private static final long MS_EVERY_DAY = 1000 * 60 * 60;
	private static final long MS_HALF_DAY = 1000 * 60 * 30;
	@Resource
	private RentCarService rentCarService;
	@Resource
	private PhoneCoinService phoneCoinService;
	@Resource
	private PhoneCoinDetailsService phoneCoinDetailsService;
	@Resource
	private  PhoneUsersService  phoneUsersService;

	/**
	 * 查询城市列表
	 * 
	 * @param modelMap
	 * @return
	 */
	public StringBuffer CityList(ModelMap modelMap) {
		StringBuffer datas = new StringBuffer("Vcity.allCity=[");
		Map<String, String> cityMap = new HashMap();
		// 热门城市
		String[] hotcity = { "北京", "上海", "广州", "深圳", "杭州", "武汉", "成都", "沈阳", "厦门", "长沙", "西安", "南京", "重庆", "三亚", "昆明", "哈尔滨" };
		try {
			String cityInfo[][] = RentCarServiceHandler.instance().getCityInfo(terminal, "");
			int total = 0;
			for (int i = 0; i < hotcity.length; i++) {
				// 处理多音字
				if ("长沙".equals(hotcity[i])) {
					datas.append("'" + hotcity[i] + "|changsha|cs'");
					datas.append(",");
					cityMap.put(hotcity[i], hotcity[i]);
				} else if ("重庆".equals(hotcity[i])) {
					datas.append("'" + hotcity[i] + "|chongqing|cq'");
					datas.append(",");
					cityMap.put(hotcity[i], hotcity[i]);
				} else if ("厦门".equals(hotcity[i])) {
					datas.append("'" + hotcity[i] + "|xiamen|xm'");
					datas.append(",");
					cityMap.put(hotcity[i], hotcity[i]);
				} else {
					String pinyin = PinyinConversionUtils.getPingYin(hotcity[i]);
					String pinyinhead = PinyinConversionUtils.getPinYinHeadChar(hotcity[i]);
					datas.append("'" + hotcity[i] + "|" + pinyin + "|" + pinyinhead + "'");
					datas.append(",");
					cityMap.put(hotcity[i], hotcity[i]);
				}
			}
			if ("0".equals(cityInfo[0][0])) {
				for (int i = 1; i < cityInfo.length; i++) {
					String cityName = cityInfo[i][1];
					// 过滤
					if (cityMap.get(cityName) != null) {
						total++;
						continue;
					}
					if ("长春".equals(cityName)) {
						datas.append("'" + cityName + "|changchun|cc'");
					} else {
						String pinyin = PinyinConversionUtils.getPingYin(cityName);
						String pinyinhead = PinyinConversionUtils.getPinYinHeadChar(cityName);
						datas.append("'" + cityName + "|" + pinyin + "|" + pinyinhead + "'");
					}
					total++;
					if (total < cityInfo.length - 1)
						datas.append(",");
				}
			} else
				log.error(cityInfo[0][1]);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
		if (datas.toString().endsWith(","))
			datas = new StringBuffer(datas.toString().substring(0, datas.toString().length() - 1));
		datas.append("]");
		return datas;
	}

	/**
	 * 查询城市编码
	 * 
	 * @param modelMap
	 * @return
	 */
	public void searchCityCode(ModelMap modelMap, RentCarPO bean) {
		String Code = getCityCode(bean.getCityname());
		bean.setCityname(bean.getTocityname());
		String toCode = getCityCode(bean.getCityname());
		modelMap.addAttribute("tocityCode", toCode);
		modelMap.addAttribute("cityCode", Code);
	}

	/**
	 * 查询城市区域列表
	 * 
	 * @param modelMap
	 * @return
	 */
	public StringBuffer searchRegionList(ModelMap modelMap, RentCarPO bean) {
		StringBuffer datas = new StringBuffer("");
		List<String> list2 = new ArrayList<String>();// 门店信息
		String cityCode = "";// 门店区ID
		try {
			cityCode = getCityCode(bean.getCityname());
			String districtList[][] = RentCarServiceHandler.instance().getDistrict(terminal, cityCode, "");
			String storeList[][] = RentCarServiceHandler.instance().queryStoreByCityCode(terminal, cityCode);
			// 遍历数据
			if ("0".equals(districtList[0][0])) {
				list2.add(" {id:-1, pId:-2, name:\"门店列表\" ,open:true,t:\"门店列表\"}");
				for (int i = 1; i < districtList.length; i++) {
					list2.add("{id:\"" + districtList[i][0] + "\",pId:\"-1\",name:\"" + districtList[i][2] + "\",checkid:\"0\",t:\"" + districtList[i][2] + "\"}");
				}
				for (int j = 1; j < storeList.length; j++) {
					list2.add("{id:\"" + storeList[j][2] + "\",pId:\"" + storeList[j][0] + "\",name:\"" + storeList[j][1] + "\",checkid:\"" + storeList[j][2] + "\",t:\""
							+ storeList[j][7] + " 营业时间" + storeList[j][4] + "-" + storeList[j][5] + "\",from:\"" + storeList[j][4] + "\",to:\"" + storeList[j][5]
							+ "\",storetype:\"" + storeList[j][6] + "\",telephone:\"" + storeList[j][8] + "\",citycode:\"" + cityCode + "\"}");
				}
			} else {
				log.error(districtList[0][1]);
				list2.add(" {id:-1, pId:-2, name:\"无门店信息\" ,open:true,t:\"无门店信息\"}");
			}
			for (int tt = 0; tt < list2.size(); tt++) {
				datas.append(list2.get(tt));
				if (tt < list2.size() - 1)
					datas.append("||");
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
		return datas;
	}

	/**
	 * 根据区域编码查询门店详情
	 * 
	 * @param modelMap
	 * @param fromdiscode
	 * @param todiscode
	 */
	public void storeInfo(ModelMap modelMap, String fromdiscode, String fromCode, String todiscode, String toCode) {
		// 取车门店信息
		Map<String, Object> store = getStroeCode(fromdiscode, fromCode);
		modelMap.put("fromStoreInfo", store);
		// 取车与还车门店相同
		if (fromCode.equals(toCode))
			modelMap.put("toStoreInfo", store);
		else
			modelMap.put("toStoreInfo", getStroeCode(todiscode, toCode));
	}

	/**
	 * 改变订单服务信息
	 * 
	 * @param model
	 * @param reqs
	 */
	public void changeService(ModelMap model, Map<String, Object> reqs) {
		String terminalId = terminal;
		String fromCityCode = reqs.get("citycode").toString();
		String toCityCode = reqs.get("tocitycode").toString();
		String fromStoreCode = reqs.get("fromcode").toString();
		String toStroeCode = reqs.get("tocode").toString();
		String fromDate = reqs.get("startdate") + " " + reqs.get("fromdate");
		String toDate = reqs.get("enddate") + " " + reqs.get("todate");
		String modeCode = "1";
		modeCode = reqs.get("carTypeCode").toString();// 车型编码
		String serviceIds = null;
		if (reqs.get("serviceIds") != null && !"".equals(reqs.get("serviceIds")))
			serviceIds = reqs.get("serviceIds").toString();// 已选服务 回显
		String[][] additionalServices;
		try {
			additionalServices = RentCarServiceHandler.instance().getAdditionalServices(terminalId, fromCityCode, toCityCode, fromStoreCode, toStroeCode, fromDate, toDate,
					modeCode);
			if (!"0".equals(additionalServices[0][0])) {
				model.put("result", false);
				log.error(additionalServices[0][1]);
			} else {
				model.put("result", true);
				List<Map<String, String>> list = new ArrayList<Map<String, String>>();
				for (int i = 1; i < additionalServices.length; i++) {
					Map<String, String> map = new HashMap<String, String>();
					map.put("serviceId", additionalServices[i][0]);
					map.put("serviceName", additionalServices[i][1]);
					map.put("price", additionalServices[i][2]);
					map.put("unit", additionalServices[i][3]);
					map.put("description", additionalServices[i][4]);
					map.put("chooseType", additionalServices[i][5]);
					map.put("totalPrice", additionalServices[i][6]);
					map.put("amount", additionalServices[i][7]);
					if (StringUtils.isNotBlank(serviceIds)) {
						String[] checkid = serviceIds.split(",");
						for (int j = 0; j < checkid.length; j++) {
							if (checkid[j].equals(map.get("serviceId")))
								map.put("checked", "checked");
						}
					}
					list.add(map);
				}
				model.put("serivces", list);
			}
		} catch (RemoteException e) {
			model.put("result", false);
			e.printStackTrace();
		}
	}

	/**
	 * 查询租车品牌 级别
	 * 
	 * @param modelMap
	 * @return
	 */
	public void searchCarBrand(ModelMap modelMap) {
		List<RentCarTypesPO> cartypelist = new ArrayList<RentCarTypesPO>();// 门店车辆品牌列表
		List<RentCarPO> carlist = new ArrayList<RentCarPO>();// 门店车辆级别列表
		List<RentCarPO> goldlist = new ArrayList<RentCarPO>();// 门店车辆租金列表
		try {
			// 查询车辆级别品牌信息
			String[][] strs = RentCarServiceHandler.instance().getBrandList(terminal);
			RentCarTypesPO typebean = new RentCarTypesPO();
			if ("0".equals(strs[0][0])) {
				for (int i = 1; i < strs.length; i++) {
					typebean = new RentCarTypesPO();
					typebean.setCarTypeCode(strs[i][0]);
					typebean.setCarTypeName(strs[i][1]);
					cartypelist.add(typebean);
				}
			} else
				log.error(strs[0][1]);
			// 查询车辆级别信息
			String[][] levelstrs = RentCarServiceHandler.instance().getModeLeveList(terminal);
			RentCarPO carbean = new RentCarPO();
			if ("0".equals(levelstrs[0][0])) {
				for (int i = 1; i < levelstrs.length; i++) {
					carbean = new RentCarPO();
					carbean.setLevelcode(levelstrs[i][0]);
					carbean.setLevel(levelstrs[i][1]);
					carlist.add(carbean);
				}
			} else
				log.error(strs[0][1] + getTraceInfo());
			// 查询车辆租金信息
			String[][] goldstrs;
			goldstrs = RentCarServiceHandler.instance().getPriceIntervalList(terminal);
			RentCarPO goldbean = new RentCarPO();
			if ("0".equals(goldstrs[0][0])) {
				for (int i = 1; i < goldstrs.length; i++) {
					goldbean = new RentCarPO();
					goldbean.setRentalcode(goldstrs[i][0]);
					goldbean.setRental(goldstrs[i][1]);
					goldlist.add(goldbean);
				}
			} else
				log.error(goldstrs[0][1]);
			modelMap.addAttribute("cartypes", cartypelist);
			modelMap.addAttribute("carlevels", carlist);
			modelMap.addAttribute("cargolds", goldlist);
		} catch (RemoteException e) {
			e.printStackTrace();
		}

	}

	/**
	 * 查询租车列表
	 * 
	 * @param modelMap
	 * @return
	 */
	public void searchCarList(ModelMap modelMap, RentCarPO bean) {
		List<RentCarTypesPO> datalist = new ArrayList<RentCarTypesPO>();
		RentCarTypesPO cartypebean = new RentCarTypesPO();
		Map<String,Object> levelmap = getLevel();
		// 查询车辆信息
		try {
			String pattern = "yyyy-MM-dd";
			int dayCount = 0;
			String Code = getCityCode(bean.getCityname());// 查询城市编码
			String[][] carList = RentCarServiceHandler.instance().getSelfDriveCarTypes(terminal, Code, bean.getFromcode(), bean.getStartdate() + " " + bean.getFromdate(),
					bean.getTocode(), bean.getEnddate() + " " + bean.getTodate(), "1", bean.getBrand(), bean.getLevel(), bean.getRental());
			dayCount = (int) ((DateUtil.stringToDate(bean.getEnddate(), pattern).getTime() - DateUtil.stringToDate(bean.getStartdate(), pattern).getTime()) / (24 * 60 * 60 * 1000));
			if (bean.getTodate().compareTo(bean.getFromdate()) > 0) {
				dayCount++;
			}
			if (carList != null && carList.length > 0) {
				if (carList[0][0] != null && "0".equals(carList[0][0])) {
					for (int i = 1; i < carList.length; i++) {
						cartypebean = new RentCarTypesPO();
						cartypebean.setCarTypeCode(carList[i][0]);
						cartypebean.setCarTypeName(carList[i][1]);
						cartypebean.setSeatQuantity(carList[i][2]);
						cartypebean.setInsurancefee(carList[i][3]);// 基本险
						cartypebean.setCreditCardAuthorization(carList[i][4]);// 预授权
						cartypebean.setImage(carList[i][5]);// 图片地址
						cartypebean.setIsFirstMode(carList[i][6]);// 是否第一个车型
						cartypebean.setModeLevel(carList[i][7]);// 车型级别
						cartypebean.setPrice(carList[i][8]);// 标准均价
						cartypebean.setModeLevelName((String) levelmap.get(carList[i][7]));// 车级别名称
						cartypebean.setDayPrice(getDayPrice(carList[i][10], dayCount, bean.getStartdate()));// 每天的价格
						cartypebean.setLeveType(carList[i][11]);// 级别类型
						//套餐
						cartypebean.setPackageTotalPrice(carList[i][12]);//
						cartypebean.setPackagePrice(carList[i][13]);//
						cartypebean.setDiscount(carList[i][14]);//
						cartypebean.setPackageDescription(carList[i][15]);//
						datalist.add(cartypebean);
					}
				} else {
					log.error(carList[0][1]);
					modelMap.addAttribute("errorMsg", carList[0][1]);
				}
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
		modelMap.addAttribute("datas", datalist);
	}

	/**
	 * 处理日均价
	 * 
	 * @param dp
	 * @param dayCount
	 * @param curDate
	 * @return
	 */
	private String getDayPrice(String dp, int dayCount, String curDate) {
		String[] dayPrice = new String[dayCount];
		if (StringUtil.isEmpty(dp))
			return "";
		String[] dayp = dp.split(",");
		Date today = null;
		try {
			today = DateUtil.stringToDate_Time2(curDate);
		} catch (ParseException e1) {
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(today);
		int wk = cal.get(Calendar.DAY_OF_WEEK);
		/**
		 * 返回的数据,是从周一开始的至少十五天,比如说查询10~12号的车,10号是周三,那么数据从8号开始返回,因此,
		 * 数据从第三个开始取并往后等到三个(下标为2) 15天以下从当前日期的周一返回 15以上返回真实数据
		 */

		int index = wk == 1 ? 6 : wk - 2;// 周日～周六返回依次为1~7
		if (dayCount > 15)
			index = 0;
		for (int j = 0; index < dayp.length && j < dayCount; index++, j++) {
			dayPrice[j] = dayp[index];
		}
		StringBuffer sb = new StringBuffer();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sdf2 = new SimpleDateFormat("MM月dd日");
		for (int i = 0; i < dayPrice.length; i += 3) {
			try {
				String day1 = sdf2.format((cn.itkt.util.DateUtil.addDays(sdf.parse(curDate), i)));
				sb.append(day1).append("  ");
				if ((i + 1) < dayPrice.length) {
					String day2 = sdf2.format((cn.itkt.util.DateUtil.addDays(sdf.parse(curDate), i + 1)));
					sb.append(day2).append("  ");
					if ((i + 2) < dayPrice.length) {
						String day3 = sdf2.format((cn.itkt.util.DateUtil.addDays(sdf.parse(curDate), i + 2)));
						sb.append(day3).append("&#13;  ");
					} else {
						sb.append("&#13;  ");
					}
				} else {
					sb.append("&#13;  ");
				}

				sb.append(genFixedLenStr(dayPrice[i] + "元", 11));
				if ((i + 1) < dayPrice.length) {
					sb.append(genFixedLenStr(dayPrice[i + 1] + "元", 11));
					if ((i + 2) < dayPrice.length) {
						sb.append(genFixedLenStr(dayPrice[i + 2] + "元", 11)).append("&#13;&#13;");
					} else {
						sb.append("&#13;");
					}
				} else {
					sb.append("&#13;");
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	/**
	 * 查询订单
	 * 
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @param page
	 * @param
	 */
	public List<HashMap<String, String>> SearchOrderList(ModelMap modelMap, int startIndex, RentCarOrderPO bean, Pages<T> page, HttpServletRequest request) {
		List<HashMap<String, String>> temList = new ArrayList<HashMap<String,String>>();
		String serviceExt[][];
		String orderList[][]=new String [10][20];
		String orderDetail[][];
		int totalCount=0;
		try {
			// type=init报表结算
			String type = request.getParameter("type");
			Pages<HashMap<String, String>> pages = new Pages<HashMap<String, String>>(startIndex);
			if(page.getPageSize() == 10)
			    orderList=searchAllOrderList(String.valueOf(startIndex/10+1), bean);//控制分页，传递查询参数
			else
				orderList=searchAllOrderList(null, bean);//查询所租车有记录
			//订单查询与订单结算
			if("0".equals(orderList[0][0])){
                    totalCount=Integer.parseInt(orderList[0][2]);//总数
                    int m=0;
					for (int j = 1; j < orderList.length; j++) {
						LinkedHashMap<String, String> hashMap =new LinkedHashMap<String, String>();
						if("0".equals(orderList[j][0]) || orderList[j][1] == null || "".equals(orderList[j][1])) {
							continue;
						}else {
							m++;
							orderDetail=searchOrderByNo(orderList[j][1]);//根据神州订单号查询详情
							//订单结算
							if (StringUtils.isNotBlank(type)) {
									// 获取维护服务信息
									Map<String, Object> eMap = new HashMap<String, Object>();
									Map<String, String> extAllMap = new HashMap<String, String>();// 全部服务信息(畅达币维护)
									Map<String, String> extCheckMap = new HashMap<String, String>();// 已选服务（畅达币维护）
									String[][] extlist = serviceExt = RentCarServiceHandler.instance().queryServiceExt(terminal, "");//查询服务维护信息
									if ("0".equals(extlist[0][0])) {
										for (int jj = 0; jj < extlist.length; jj++) {
											extAllMap.put(extlist[jj][1], extlist[jj][2]);
											if ("1".equals(extlist[jj][7]))
												extCheckMap.put(extlist[jj][1], extlist[jj][2]);
										}
									}
							// 查询神州结算前金额
										Double orderOldMoney = 0D;// 神州服务费用 目前只有八项
										if("0".equals(orderDetail[0][0])&&StringUtils.isNotBlank(orderDetail[0][34])){
											List<String> serviceList=serviceSplit(orderDetail[0][34]);//订单服务 以;号分隔   增值服务名 +“;”  + 总价 +“;”+单位+”;”+描述+ code” 
											if (serviceList.size() > 0) {
												for (int ij = 0; ij < serviceList.size(); ij++) {
													String []service=serviceList.get(ij).split(";");
													if (service[4] != null && service[0] != null) {
														String ServiceCode = service[4];// 服务编码
														String Price = service[1];// 服务费用
														// 七项服务中包含当前订单服务
														if (extAllMap.get(ServiceCode) != null) {
															orderOldMoney += Double.valueOf(Price);
														}
													}
												}
											}
										}else
											log.error(orderDetail[0][1]);
								// 日租金+保险+服务费
								if (orderList[j][10] != null && orderList[j][12] != null&& orderList[j][13] != null) {
									Double value=Double.valueOf(orderList[j][10]) + Double.valueOf(orderList[j][12])+ Double.valueOf(orderList[j][13]);
									orderOldMoney += value;
								}
							 hashMap.put("orderOldMoney", String.valueOf(orderOldMoney));// 原结算金额
								
							}
						}
						
					    hashMap.put("ORDERNO", orderList[j][1]);
					    hashMap.put("FROMDATE", orderList[j][3]);
					    hashMap.put("TODATE", orderList[j][4]);
					    hashMap.put("SOURCE", orderList[j][17]);
					    hashMap.put("ORDERSTATUS", orderList[j][14]);
					    if(StringUtils.isNotBlank(orderDetail[0][2]));
					    hashMap.put("USERNAME", orderDetail[0][2]);
					     if(StringUtils.isNotBlank(orderDetail[0][15]));
					    hashMap.put("CARNAME", orderDetail[0][15]);
					    if(StringUtils.isNotBlank(orderDetail[0][16]))
					    hashMap.put("CARTYPE", orderDetail[0][16]);
					    if(StringUtils.isNotBlank(orderDetail[0][18]))
					    hashMap.put("ADDTIME", orderDetail[0][18]);
					    if(StringUtils.isNotBlank(orderDetail[0][19]))
					    hashMap.put("LCDORDERNO", orderDetail[0][19]);
					    if(StringUtils.isNotBlank(orderDetail[0][30]))
					    hashMap.put("MEMBERID", orderDetail[0][30]);
					    if(StringUtils.isNotBlank(orderDetail[0][10]))
					    hashMap.put("TOTALORDERPRICE", orderDetail[0][10]);//总金额
					    if(StringUtils.isNotBlank(orderDetail[0][12])&&StringUtils.isNotBlank(orderDetail[0][13]))
					    hashMap.put("LCDMONEY", String.valueOf(Double.valueOf(orderDetail[0][12])+Double.valueOf(orderDetail[0][11])));//车辆租金和必选保险费用两项和为返畅达币总金额
					   
					    if(StringUtils.isNotBlank(orderDetail[0][25])){
					        hashMap.put("IS_CHANGE", orderDetail[0][25]);
					        hashMap.put("LCD_MONEY", orderDetail[0][28]);//可返畅达币总金额=第一次结算总金额
					    }
					    else
					    	hashMap.put("IS_CHANGE", "0");
					    if(StringUtils.isNotBlank(orderDetail[0][32]))
					       hashMap.put("ADJUST_LCD", orderDetail[0][32]);
					    if(StringUtils.isNotBlank(orderDetail[0][27]))
					      hashMap.put("SETTLE_RETURN_MONEY", orderDetail[0][27]);
					    hashMap.put("TOTALCARRENTMONEY", orderDetail[0][11]);//日租金
					    hashMap.put("INSURANCEFEE", orderDetail[0][12]);//基本保险
					    hashMap.put("SERVICEFEE", orderDetail[0][13]);//服务费
					    hashMap.put("SOURCE", orderList[j][17]);
					    hashMap.put("IDCARDTYPE", orderDetail[0][35]);//证件类型
					    hashMap.put("IDCARD", orderDetail[0][33]);//证件号
					    hashMap.put("COMMENTS", orderDetail[0][20]);//备注
					    hashMap.put("LCD", orderDetail[0][38]);//LCD
					    hashMap.put("LCDRATE", orderDetail[0][36]);//返佣率
					    hashMap.put("LCDVALUE", orderDetail[0][37]);//返佣金
					    hashMap.put("FROMSTORE",orderDetail[0][7]);//门店信息
					    hashMap.put("TOSTORE",orderDetail[0][9]);
					  //后台下单人ID
					    if(StringUtils.isNotBlank(orderDetail[0][21])){
					    	 String name=rentCarService.selectOpeName(orderDetail[0][21]);
						    hashMap.put("UNAME", name);//后台下单人员名称
					    }
					    if(StringUtils.isNotBlank(orderDetail[0][30])){
					        hashMap.put("USERID", orderDetail[0][30]);//userId
					        PhoneUsersPO phoneUser=phoneUsersService.find(orderDetail[0][30]);//查询会员信息
					        hashMap.put("PNAME", phoneUser.getName());
					        hashMap.put("PTELEPHONE", phoneUser.getTelephone());
					    }
					    temList.add(m-1, hashMap);
					}
			}
			// 报表结算
			if (page.getPageSize() != 10) {
				String Per = "";// 百分比
				String Immovable = "";// 计算值
				// 查询本地选畅达币维护
				serviceExt=RentCarServiceHandler.instance().queryServiceExt(terminal, null);
				modelMap.put("ServicesExt", serviceExt);
				// 查询本地租车活动信息(同一组取优先级较高，不同组活动值累加 计算方式（01:百分比；02:固定金额）)
				List<HashMap<String, Object>> activityList = rentCarService.searchActivty();
				if (activityList.size() > 0) {
					for (int k = 0; k < activityList.size(); k++) {
						HashMap<String, Object> activityMap = activityList.get(k);
						Per = activityMap.get("PER").toString();
						Immovable = activityMap.get("IMMOVABLE").toString();
					}
				}
				modelMap.put("PER", Per);
				modelMap.put("IMMOVABLE", Immovable);
				// 查询本地当前订单所有服务 
				for (int j = 0; j < temList.size(); j++) {
					String allService=null;
					HashMap<String, String> hashMap = temList.get(j);
					orderDetail=searchOrderByNo(hashMap.get("ORDERNO").toString());//根据神州订单号查询详情
					if("0".equals(orderDetail[0][0])&&StringUtils.isNotBlank(orderDetail[0][34]))
						allService=orderDetail[0][34];
					hashMap.put("Services", allService);
					temList.remove(j); // 移除旧数据
					temList.add(j, hashMap);

				}
				
			}
			pages.setItems(temList);
			pages.setTotalCount(totalCount);
			modelMap.addAttribute("page", pages);
			modelMap.addAttribute("bean", bean);
			modelMap.addAttribute("list", "list");

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}
		return temList;
	}

	/**
	 * 根据订单号查询订单详情
	 * 
	 * @param modelMap
	 * @param OrdrId 神州订单号
	 *          
	 * @throws ParseException
	 */
	public void searchOrderById(ModelMap modelMap, String OrderId) {
		String orderDetail[][];
		String orderList[][];
		
		HashMap<String, String> hashMap =new HashMap<String, String>();
		HashMap<String, String> serviceMap =new HashMap<String, String>();
		List<HashMap<String, String>> temList = new ArrayList<HashMap<String,String>>();
		List<HashMap<String, String>> ServiceList =new ArrayList<HashMap<String,String>>();
		RentCarOrderPO bean=new RentCarOrderPO();
		
		// 查询订单详情
		try {
			orderDetail=searchOrderByNo(OrderId);
			if ("0".equals(orderDetail[0][0])) {
				    bean.setLcdOrderNo(orderDetail[0][19]);//神舟订单号
				   orderList=searchAllOrderList("1", bean);//控制分页，传递查询参数 明细中信息不完整，根据订单号查询
				String begintime = orderDetail[0][4];//取车时间
				String endtime = orderDetail[0][5];//还车时间
				Double rentdate = compare(begintime, endtime);
				// 总租金中去掉超时费,服务费
				if (StringUtils.isNotBlank(orderDetail[0][34])) {
				        List<String> serviceList=serviceSplit(orderDetail[0][34]);//订单服务 以;号分隔   增值服务名 +“;”  + 总价 +“;”+单位+”;”+描述+ code” 
						for (int ij = 0; ij < serviceList.size(); ij++) {
							serviceMap =new HashMap<String, String>();//初始
							String []service=serviceList.get(ij).split(";");
							if(service.length>=5){
								if (!"".equals(service[4])  && !"".equals(service[0])) {
									String name=service[0];//服务名称
									String ServiceCode = service[4];// 服务编码
									String Price = service[1];// 服务费用
									serviceMap.put("SERVICENAME",name );
									serviceMap.put("TOTALPRICE", Price);
									if ("400".equals(ServiceCode))
										modelMap.addAttribute("minus", Price);
								}
						}else{
									//处理神州返回CODE为空
									String name=service[0];//服务名称
									String Price = service[1];// 服务费用
									serviceMap.put("SERVICENAME",name );
									serviceMap.put("TOTALPRICE", Price);
								}
							ServiceList.add(serviceMap);
						}
					}
				// 查询是否存在订单结算调整信息
				String [][]change=searchChange(orderDetail[0][17],null,"1");//根据订单ID查询结算变更信息
				if ("0".equals(change[0][0])&&change.length>1) {
					List<RentCarChangePO> changeList=new ArrayList<RentCarChangePO>();
					RentCarChangePO changeBean=new RentCarChangePO();
					for(int i=1;i<change.length;i++){
					changeBean=new RentCarChangePO();
					String operName=rentCarService.selectOpeName(change[i][5]);
					changeBean.setCarType(change[i][2]);//车型
					changeBean.setOrderNo(operName);//调整人名称
					changeBean.setAddTime(DateUtil.stringTo_Date_Time4(change[i][4]));//添加时间
					changeBean.setOrderMoney(change[i][7]);//调整金额
					changeBean.setToDate(change[i][3]);//还车时间
					changeList.add(changeBean);
					}
					modelMap.addAttribute("changeList",changeList);
				}
				    hashMap.put("ORDERNO", orderDetail[0][3]);//神舟订单号
				    hashMap.put("FROMDATE", orderDetail[0][4]);//取车时间
				    hashMap.put("TODATE", orderDetail[0][5]);//还车时间
				    hashMap.put("ORDERSTATUS", orderDetail[0][14]);//订单状态
				    if(StringUtils.isNotBlank(orderDetail[0][2]));
				    hashMap.put("USERNAME", orderDetail[0][2]);//取车人
				     if(StringUtils.isNotBlank(orderDetail[0][15]));
				    hashMap.put("CARNAME", orderDetail[0][15]);//车辆信息
				    if(StringUtils.isNotBlank(orderDetail[0][16]))
				    hashMap.put("CARTYPE", orderDetail[0][16]);
				    if(StringUtils.isNotBlank(orderDetail[0][18]))
				    hashMap.put("ADDTIME", orderDetail[0][18]);//订单添加时间
				    if(StringUtils.isNotBlank(orderDetail[0][19]))
				    hashMap.put("LCDORDERNO", orderDetail[0][19]);//LCD号
				    if(StringUtils.isNotBlank(orderDetail[0][30])){
				        hashMap.put("MEMBERID", orderDetail[0][30]);//userId
				        hashMap.put("USERID", orderDetail[0][30]);//userId
				        PhoneUsersPO phoneUser=phoneUsersService.find(orderDetail[0][30]);//查询会员信息
				        hashMap.put("PNAME", phoneUser.getName());
				        hashMap.put("PCALL", phoneUser.getTelephone());
				    }
				    //后台下单人ID
				    if(StringUtils.isNotBlank(orderDetail[0][29])){
				    	String name=rentCarService.selectOpeName(orderDetail[0][29]);
					    hashMap.put("ONAME", name);//后台下单人员名称
				    }
				    //取消下单人ID
				    if(StringUtils.isNotBlank(orderDetail[0][22])){
				    	String name=rentCarService.selectOpeName(orderDetail[0][22]);
				    	hashMap.put("CNAME", name);//后台下单人员名称
				    	hashMap.put("CANCELTIME", orderDetail[0][23]);//后台下单人员名称
				    }
				    
				    if(StringUtils.isNotBlank(orderDetail[0][10]))
				    hashMap.put("TOTALORDERPRICE", orderDetail[0][10]);//总金额
				    if(StringUtils.isNotBlank(orderDetail[0][12])&&StringUtils.isNotBlank(orderDetail[0][13]))
				    hashMap.put("LCDMONEY", String.valueOf(Double.valueOf(orderDetail[0][12])+Double.valueOf(orderDetail[0][11])));//车辆租金和必选保险费用两项和为返畅达币总金额
				   
				    if(StringUtils.isNotBlank(orderDetail[0][25])){
				        hashMap.put("IS_CHANGE", orderDetail[0][25]);//是否已结算
				        hashMap.put("LCD_MONEY", orderDetail[0][28]);//可返畅达币总金额
				    }
				    else
				    	hashMap.put("IS_CHANGE", "0");
				    if(StringUtils.isNotBlank(orderDetail[0][32]))
				       hashMap.put("ADJUST_LCD", orderDetail[0][32]);//调整畅达币
				    if(StringUtils.isNotBlank(orderDetail[0][27]))
				      hashMap.put("SETTLE_RETURN_MONEY", orderDetail[0][27]);//结算后金额
				    hashMap.put("FROMSTORE",orderDetail[0][7]);//门店信息
				    hashMap.put("TOSTORE",orderDetail[0][9]);
				    hashMap.put("TOTALCARRENTMONEY", orderDetail[0][11]);//日租金
				    hashMap.put("INSURANCEFEE", orderDetail[0][12]);//基本保险
				    hashMap.put("SERVICEFEE", orderDetail[0][13]);//服务费
				    hashMap.put("IDCARDNUMBER", orderDetail[0][33]);//证件号
				    hashMap.put("USERCARDTYPE", orderDetail[0][35]);//证件类型
				    hashMap.put("COMMENTS", orderDetail[0][20]);//备注
				    //从查询订单接口中查询
				    hashMap.put("PHONENO", orderList[1][2]);//电话
				    hashMap.put("CHANNELTYPE", orderList[1][17]);//订单来源
				    if(StringUtils.isNotBlank(orderDetail[0][21])){
				    String name=rentCarService.selectOpeName(orderDetail[0][21]);
				    hashMap.put("BNAME", name);//修改备注人员名称
				    }
				    
				temList.add(hashMap);
				modelMap.addAttribute("rentdate", Math.floor(rentdate)>=7?"7":Math.floor(rentdate));
				modelMap.addAttribute("servicebean", ServiceList);
			    modelMap.addAttribute("orderbean", temList);
			}else
				log.error(orderDetail[0][1]);
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 修改订单备注
	 * 
	 * @param modelMap
	 * @param teamInfoId
	 *            班组Id
	 */

	public String updateRemark(String orderId, String remark) {
		String result = "success";
		try {
			String[][] updateOrder;
			UserVO loginuser = LoginUtil.getLoginUser();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			updateOrder = RentCarServiceHandler.instance().updateOrderInfoCommons("", orderId, remark,String.valueOf(loginuser.getId()));
			if ("0".equals(updateOrder[0][0]))
				result += "||" + loginuser.getName() + "||" + format.format(new Date());
			else
				result = "failed";
		} catch (AppException e) {
			this.log.error("修改租车订单备注失败!");
			result = "failed";
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 同步订单
	 * 
	 * @param modelMap
	 * @param teamInfoId
	 *            班组Id
	 */

	public String synOrder(String orderNo, String orderId) {
		String result = "";
		try {
			String[][] synOrder;
			// 同步订单 0:成功-99999：其他错误 -11113: 服务器报异常
			synOrder = RentCarServiceHandler.instance().synOrderInfo(orderNo, orderId);
			if ("0".equals(synOrder[0][0]))
				result = "success";
			else
				result = "failed||" + synOrder[0][1];
		} catch (AppException e) {
			result = "failed";
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 取消订单（ 离取车时间不足6小时时无法取消订单）
	 * 
	 * @param id
	 *            订单orderId
	 * @return
	 */
	public String cancelOrder(String orderNo, String todate, String orderId) {
		String result = "";
		boolean flag = true;
		try {
			String[][] canOrder;
			UserVO loginuser = LoginUtil.getLoginUser();
			if (flag) {
				// 取消订单 0:成功-99999：其他错误 -11113: 服务器报异常
				canOrder = RentCarServiceHandler.instance().cancelSelfDriveOrder(terminal, orderNo, longToString(loginuser.getId()));
				if ("0".equals(canOrder[0][0])) {
					result = "success||" + canOrder[0][1];
				} else
					result = "failed||" + canOrder[0][1];
			}
		} catch (AppException e) {
			result = "failed";
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 首租验证
	 * 
	 * @return
	 */
	public void checkUserInfo(ModelMap modelMap, Map<String, String> reqs) {
		String userName = reqs.get("realName");
		String cardType = reqs.get("IDType");
		String cardNo = reqs.get("realID");
		String phone = reqs.get("realPhone");
		String deptType = reqs.get("fromstroetype");
		try {
			String[][] userInfo = RentCarServiceHandler.instance().checkUserInfo( "",userName, cardNo, phone, deptType);
			if (userInfo != null && "0".equals(userInfo[0][0])) {
				modelMap.put("result", "0");
			}else {
				modelMap.put("message", userInfo[0][1]);
			}
		} catch (RemoteException e) {
			e.printStackTrace();
			modelMap.put("result", "调用接口异常");
		}
	}

	/**
	 * 计算预订单金额接口
	 * 
	 * @param modelMap
	 * @param reqs
	 */
	public void calcCarOrderPrice(ModelMap modelMap, Map<String, String> reqs,RentCarPO po) {
		String terminalId = terminal;// 自助终端编号(可空)
		String cityCode = nullToString(reqs.get("citycode"));// 取车城市名称(非空)
		String toCityCode = nullToString(reqs.get("tocitycode"));// 还车城市名称(非空)
		String fromDate = nullToString(reqs.get("startdate")) + " " + nullToString(reqs.get("fromdate"));// 取车时间(非空,yyyy-MM-dd
		String toDate = nullToString(reqs.get("enddate") + " " + reqs.get("todate"));// 还车时间(非空)
		String fromStoreCode = nullToString(reqs.get("fromcode"));// 取车门店编号(非空)
		String toStoreCode = nullToString(reqs.get("tocode"));// 还车门店编号(非空)
		String activityCode = nullToString(reqs.get("activityCode"));// 优惠活动编码(可空)
		String serviceId = nullToString(reqs.get("serviceIds"));// 增值服务信息(可空)
		String vehicleLevel = nullToString(reqs.get("levelcode"));// 车级别(可空)
		String modeCode = nullToString(reqs.get("carTypeCode"));// 车型编号
		String leveType = nullToString(reqs.get("leveType"));// 级别类型
		String isSelectPackage="on".equals(po.getIsSelectPackage())?"1":"0";//套餐
		try {
			String[][] calcCarOrderPrice = RentCarServiceHandler.instance().calcCarOrderPrice(terminalId, cityCode, toCityCode, fromDate, toDate, fromStoreCode, toStoreCode,
					activityCode, serviceId, vehicleLevel, modeCode, leveType,isSelectPackage);
			if ("0".equals(calcCarOrderPrice[0][0])) {
				modelMap.put("result", "0");
				modelMap.put("totalCarRentMoney", calcCarOrderPrice[0][2]);// 租车费用总额
				modelMap.put("insuranceFee", calcCarOrderPrice[0][3]);// 保险费用
				modelMap.put("serviceFee", calcCarOrderPrice[0][4]);// 服务费用
				modelMap.put("mile", calcCarOrderPrice[0][5]);// 可用里程
				modelMap.put("otherCityReturnCarFee", calcCarOrderPrice[0][6]);// 异地还车费用
				modelMap.put("creditCardAuthorization", calcCarOrderPrice[0][7]);// 信用卡预授权
				modelMap.put("totalOrderPrice", calcCarOrderPrice[0][8]);// 预订总金额
				modelMap.put("rentPeriod", calcCarOrderPrice[0][9]);// 租期
				modelMap.put("moneySummary", calcCarOrderPrice[0][10]);// 租车时间内的价格×天数描述
				modelMap.put("overMilePrice", calcCarOrderPrice[0][11]);// 超里程费用
				modelMap.put("overTimePrice", calcCarOrderPrice[0][12]);// 超时费用
				modelMap.put("services", calcCarOrderPrice[0][13]);// 增值服务信息
				modelMap.put("lcdlate", calcCarOrderPrice[0][14]);// 返畅达币点数
				modelMap.put("lcdvalue", calcCarOrderPrice[0][15]);// 返畅达币数
				modelMap.put("lcdtotal", calcCarOrderPrice[0][16]);// 最终返畅达币数
				// System.out.println(Arrays.toString(calcCarOrderPrice[0]));
			} else {
				modelMap.put("result", calcCarOrderPrice[0][0]);
				modelMap.put("message", calcCarOrderPrice[0][1]);
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 预定接口
	 * 
	 * @param modelMap
	 * @param reqs
	 */
	public void addSelfDriveOrder(ModelMap modelMap, Map<String, String> reqs,RentCarPO carPo) {
		UserVO loginuser = LoginUtil.getLoginUser();
		String terminalId = terminal;// 自助终端编号(可空)
		String operaterid = longToString(loginuser.getId());// OPERATORUSERID
		String carType = nullToString(reqs.get("carTypeCode"));// 车型编号(非空)
		String fromDate = nullToString(reqs.get("startdate")) + " " + nullToString(reqs.get("fromdate"));// 取车时间(非空,yyyy-MM-dd
		String fromCity = nullToString(reqs.get("cityname"));// 取车城市名称(非空)
		String fromStore = nullToString(reqs.get("fromcode"));// 取车门店编号(非空)
		String toDate = nullToString(reqs.get("enddate") + " " + reqs.get("todate"));// 还车时间(非空)
		String toCity = nullToString(reqs.get("tocityname"));// 还车城市名称(非空)
		String toStore = nullToString(reqs.get("tocode"));// 还车门店编号(非空)
		String activityCode = nullToString(reqs.get("activityCode"));// 优惠活动编码(可空)
		String serviceId = nullToString(reqs.get("serviceIds"));// 增值服务信息(可空)
		String vehicleLevel = nullToString(reqs.get("levelcode"));// 车级别(可空)
		String userId = nullToString(reqs.get("custId"));// 用户Id(非空)
		String userName = nullToString(reqs.get("realName"));// 预订人姓名(可空)
		String idCardNo = nullToString(reqs.get("realID"));// 证件号码(非空)
		String mobile = nullToString(reqs.get("realPhone"));// 电话(非空)
		String userType = nullToString("04");// 会员类型(非空)：00：个人会员，01：企业会员，02：VIP，03：合作商户，04：移动商旅会员05:散客
		String leveType = nullToString(reqs.get("leveType"));// 级别类型
		if ("".equals(userId))
			userType = "05";
		String channel = nullToString("4");// 订单来源(可空)//渠道类型 1手机,2 B2C, 3终端,4后台
		String comments = nullToString(reqs.get("comments"));// 订单备注(非空)
		String deptType = nullToString(reqs.get("fromstroetype"));// 门店类型(可空)
		String cardType = nullToString(reqs.get("IDType"));// 证件类型(非空)
		String lcdlate = nullToString(reqs.get("lcdlate"));// 返点
		String lcdvalue = nullToString(reqs.get("lcdvalue"));// 返值
		String lcdtotal = nullToString(reqs.get("lcdtotal"));// 返畅达币数
		String isSelectPackage="on".equals(carPo.getIsSelectPackage())?"1":"0";//
		try {
			String[][] addSelfDriveOrder = RentCarServiceHandler.instance().addSelfDriveOrder(terminalId, carType, fromDate, fromCity, fromStore, toDate, toCity, toStore,
					activityCode, serviceId, vehicleLevel, userId, userName, idCardNo, mobile, userType, channel, comments, deptType, cardType, operaterid, leveType,lcdlate,lcdvalue,isSelectPackage);
			if ("0".equals(addSelfDriveOrder[0][0])) {
				modelMap.put("result", "0");
				modelMap.put("orderIDSZ", addSelfDriveOrder[0][2]);// 神州订单号
				modelMap.put("orderID", addSelfDriveOrder[0][3]);// 本地订单号
				modelMap.put("userId", userId);// 会员ID 可以为空 （散客）
				modelMap.put("addUserId", loginuser.getId());// 添加订单ID
				//String dayPrice = reqs.get("dayPrice");// 日价格
				//po.setDailyPrice(dayPrice);
				//po.setLcdOrderNo(addSelfDriveOrder[0][3]);
				//rentCarService.updateDailyPrice(po);
			} else {
				modelMap.put("result", addSelfDriveOrder[0][0]);
				modelMap.put("message", URLEncoder.encode(addSelfDriveOrder[0][1], "UTF-8"));
				// 预定失败保存用户信息
				Set<String> reqKeys = reqs.keySet();
				for (String rk : reqKeys) {
					modelMap.put(rk, URLEncoder.encode(reqs.get(rk).toString(), "UTF-8"));
				}
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 验证异地还车费用
	 * 
	 * @param fromcode
	 * @param tocode
	 * @return
	 */
	public String citySpaceFee(String fromCityCode, String toCityCode) {
		String result = "success||0";
		try {
			// 接口作废
			/*String[][] carFee;
			carFee = RentCarServiceHandler.instance().citySpaceFee(terminal, fromCityCode, toCityCode);
			if ("0".equals(carFee[0][0]))
				result = "success||" + carFee[0][2];
			else
				result = "failed||" + carFee[0][1];*/
		} catch (AppException e) {
			result = "failed||0";
		} 
		return result;
	}

	/**
	 * 租车返畅达币维护
	 * 
	 * @param modelMap
	 * @return
	 */
	public void searchServiceExt(ModelMap modelMap, HttpServletResponse response) {
		try {
			String[][] serviceExt;
			RentCarServiceExtPO po = new RentCarServiceExtPO();
			Map<String, Object> eMap = new HashMap<String, Object>();
			List<RentCarServiceExtPO> temList = new ArrayList<RentCarServiceExtPO>();
			eMap.put("v", "");
			serviceExt = RentCarServiceHandler.instance().queryServiceExt(terminal, "");
			if ("0".equals(serviceExt[0][0])) {
				for (int i = 1; i < serviceExt.length; i++) {
					po = new RentCarServiceExtPO();
					po.setId(Long.valueOf(serviceExt[i][0]));
					po.setServiceId(serviceExt[i][1]);
					po.setServiceName(serviceExt[i][2]);
					if (StringUtils.isNotBlank(serviceExt[i][5]))
						po.setChooseType(serviceExt[i][5]);
					po.setIsChecked(Long.valueOf(serviceExt[i][7].toString()));
					temList.add(po);
				}
			}
			modelMap.addAttribute("bean", temList);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 修改租车返畅达币维护
	 * 
	 * @param modelMap
	 * @return
	 */
	public String updateSearchServiceExt(ModelMap modelMap, HttpServletResponse response, RentCarServiceExtPO bean) {
		String result = "";
		try {
			String[][] serviceExt;
			String[] idlist = bean.getServiceId().split(",");
			for (int i = 0; i < idlist.length; i++) {
				String[] idv = idlist[i].split(":");
				serviceExt = RentCarServiceHandler.instance().updateServiceExt(terminal, idv[0], idv[1]);
				if ("0".equals(serviceExt[0][0]))
					result = "success";
				else
					result = "failed";
			}
		} catch (Exception e) {
			result = "failed";
		}
		return result;
	}

	/**
	 * 计算租期 （超4小时计1天租期） 最小租期为1天 //租期只取整数 不足一小时按超时服务
	 * 
	 * @param begintime
	 * @param endtime
	 * @return
	 * @throws ParseException
	 */
	public static Double compare(String begintime, String endtime) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		Date beginDate = format.parse(begintime);
		Date endDate = format.parse(endtime);
		Long more = 0L;
		Double datas = 0D;
		boolean flag = false;// 半小时标识
		long beginTime = beginDate.getTime();
		long endTime = endDate.getTime();
		Long betweenDays = (endTime - beginTime) / MS_EVERY_DAY;
		Long halfbetweenDays = (endTime - beginTime) / MS_HALF_DAY;
		Long halfmore = halfbetweenDays % 2;
		halfbetweenDays = halfbetweenDays / 2;
		if (halfmore == 1 && halfbetweenDays != 0)
			flag = true;
		more = betweenDays % 24;
		if (flag)
			more += 1;
		betweenDays = betweenDays / 24;
		datas = betweenDays + 0D;
		if (betweenDays == 0)
			datas = 1D;
		if (betweenDays >= 1 && more < 5) {
			if (more == 1)
				datas = betweenDays + 0.2;
			else if (more == 2)
				datas = betweenDays + 0.4;
			else if (more == 3)
				datas = betweenDays + 0.6;
			else if (more == 4)
				datas = betweenDays + 0.8;
		}
		if (more >= 5)
			datas = betweenDays + 1D;
		return datas;
	}

	public void setRentCarInfo(ModelMap modelMap, RentCarPO po) {
		modelMap.put("cityname", po.getCityname());
		modelMap.put("tocityname", po.getTocityname());
		modelMap.put("citycode", po.getCitycode());
		modelMap.put("tocitycode", po.getTocitycode());
		modelMap.put("districtname", po.getDistrictname());
		modelMap.put("fromstore", po.getFromstore());
		modelMap.put("fromcode", po.getFromcode());
		modelMap.put("tostore", po.getTostore());
		modelMap.put("tocode", po.getTocode());
		modelMap.put("startdate", po.getStartdate());
		modelMap.put("fromdate", po.getFromdate());
		modelMap.put("enddate", po.getEnddate());
		modelMap.put("todate", po.getTodate());
		modelMap.put("level", po.getLevel());
		modelMap.put("levelcode", po.getLevelcode());
		modelMap.put("brand", po.getBrand());
		modelMap.put("rental", po.getRental());
		modelMap.put("rentalcode", po.getRentalcode());
		modelMap.put("rentdate", po.getRentdate());
		modelMap.put("carmessage", po.getCarmessage());
		modelMap.put("isStartNight", po.getIsStartNight());
		modelMap.put("isEndNight", po.getIsEndNight());
		modelMap.put("isdiffer", po.getIsdiffer());
		modelMap.put("fromstroetype", po.getFromstroetype());
		modelMap.put("tostroetype", po.getTostroetype());
		modelMap.put("fromcall", po.getFromcall());
		modelMap.put("tocall", po.getTocall());
		modelMap.put("fromaddress", po.getFromaddress());
		modelMap.put("toaddress", po.getToaddress());
	}

	/**
	 * 导入写在EXCEL表格里的信息
	 * 
	 * @param modelMap
	 * @return
	 * @throws AppException
	 */
	public String importExcel(HttpServletResponse response, ModelMap modelMap, Set<MultipartFile> mfs, boolean type) throws IOException, AppException {
		// modelMap.remove("rentcarList");// 移去旧数据
		String result;
		String[][] serviceExt;
		String[][] orderDetail;
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		if (mfs != null) {
			Iterator<MultipartFile> ite = mfs.iterator();
			MultipartFile multipartFile = null;
			JSONArray jsonArray = new JSONArray();//存储数据
			JSONArray lessJsonArray = new JSONArray();//存储缺单数据
			
			while (ite.hasNext()) {
				multipartFile = ite.next();
				break; // 只有一个文件，所以直接跳出
			}
			try {
				if (multipartFile != null) {
					InputStream io = multipartFile.getInputStream();
					List<List<Object>> dataList = ExcelPoiUtils.getExcelData(io, 1, type, false);// 取第二个表单数据
					List<RentCarOrderPO> datalist = new ArrayList();// 记录
					RentCarOrderPO bean = new RentCarOrderPO();
					RentCarChangePO po = new RentCarChangePO();
					UserVO loginuser = LoginUtil.getLoginUser();
					Long userid = new Long(loginuser.getId());// 当前操作员ID
					StringBuffer strs = new StringBuffer("");// 订单结算金额
					for (int i = 1; i < dataList.size(); i++) {
						Double orderOldMoney = 0D;// 神州服务费用 目前只有七项
						Double orderLcdMoney = 0D;// 可返畅达币费用 目前只有 租金+保险
						JSONObject obj = new JSONObject();
						JSONObject obj2 = new JSONObject();
						bean = new RentCarOrderPO();
						po = new RentCarChangePO();
						po.setAddUserId(userid);
						po.setAddTime(new Date());
						if (!"订单号".equals(dataList.get(0).get(0).toString())) {
							obj.put("error", "error");
							jsonArray.add(obj);
							break;
						}
						if (dataList.get(i).get(1) != null) {
							if (dataList.get(i).get(0).toString().trim() == null || "".equals(dataList.get(i).get(0).toString().trim()))
								break;
							else
								bean.setOrderNo(dataList.get(i).get(0).toString().trim());// 神州订单号
							po.setOrderNo(bean.getOrderNo());
						}
						if (dataList.get(i).get(1) != null)
							bean.setUserName(dataList.get(i).get(1).toString().trim());// 会员姓名
						if (dataList.get(i).get(2) != null)
							bean.setCarType(dataList.get(i).get(2).toString().trim());// 车辆型号
						if (dataList.get(i).get(3) != null)
							bean.setPrestarttime(dataList.get(i).get(3).toString().trim().replace('：', ':'));// 预订时间
						if (dataList.get(i).get(4) != null)
							bean.setFromDate(dataList.get(i).get(4).toString().trim().replace('：', ':'));// 取车日期
						if (dataList.get(i).get(5) != null)
							bean.setToDate(dataList.get(i).get(5).toString().trim().replace('：', ':'));// 还车日期
						if (dataList.get(i).get(6) != null) {
							bean.setOrderStatus(dataList.get(i).get(6).toString().trim());// 合同状态
							if (!"首结帐完成".equals(bean.getOrderStatus()))
								continue;
						}
						if (dataList.get(i).get(7) != null)
							bean.setSettleMoney(dataList.get(i).get(7).toString().trim());// 结算金额
						// 获取维护服务信息
						Map<String, Object> eMap = new HashMap<String, Object>();
						Map<String, HashMap<String, Object>> extAllMap = new HashMap<String, HashMap<String, Object>>();// 全部服务信息(畅达币维护)
						Map<String, HashMap<String, Object>> extCheckMap = new HashMap<String, HashMap<String, Object>>();// 已选服务（畅达币维护）
						serviceExt = RentCarServiceHandler.instance().queryServiceExt(terminal, "");// 畅达币维护暂时未使用todo

						// 查询本地数据
						orderDetail =searchOrderByNo(bean.getOrderNo());//查询订单详情
						if ("0".equals(orderDetail[0][0])) {
							obj2.put("lcdOrderNo", orderDetail[0][19]);//LCD订单号
							obj2.put("orderNo", orderDetail[0][3]);//神舟订单号
							obj2.put("name", orderDetail[0][2]);//取车人
							if (orderDetail[0][16] != null)
								obj2.put("type", orderDetail[0][16]);//车型
							else
								obj2.put("type", orderDetail[0][15]); //车名

							if (orderDetail[0][18] != null)
								obj2.put("pretime", orderDetail[0][18]);//预订时间
							if (orderDetail[0][4] != null)
								obj2.put("fromtime", orderDetail[0][4]);
							if (orderDetail[0][5] != null)
								obj2.put("totime", orderDetail[0][5]);
							obj2.put("status", StringUtils.isNotBlank(orderDetail[0][14])?orderDetail[0][14]:"已结算");// 订单状态 为空为补录数据
							// obj2.put("money",
							// List.get(0).get("RETURN_MONEY"));

							// 查询神州结算前金额与可返畅达币金额
							// 订单下所有服务信息
							if (StringUtils.isNotBlank(orderDetail[0][34])) {
						        List<String> serviceList=serviceSplit(orderDetail[0][34]);//订单服务 以;号分隔   增值服务名 +“;”  + 总价 +“;”+单位+”;”+描述+ code” 
								for (int ij = 0; ij < serviceList.size(); ij++) {
									String []service=serviceList.get(ij).split(";");
									if (!"".equals(service[4])  && !"".equals(service[0])) {
										String name=service[0];//服务名称
										String ServiceCode = service[4];// 服务编码
										String Price = service[1];// 服务费用
										// 七项服务中包含当前订单服务
										if (extAllMap.get(ServiceCode) != null)
											orderOldMoney += Double.valueOf(Price);
									}
								}
							}
							// 日租金+保险+服务费
							if (orderDetail[0][11] != null &&orderDetail[0][12] != null) {
								 orderOldMoney += Double.valueOf(orderDetail[0][11]) + Double.valueOf(orderDetail[0][12])
										+ Double.valueOf(orderDetail[0][13]);
								if (orderDetail[0][30] != null)// 散客
									orderLcdMoney = Double.valueOf(orderDetail[0][11]) + Double.valueOf(orderDetail[0][12]);
							}
							po.setOrderInfoId(Long.valueOf(orderDetail[0][17]));// 订单明细表ID
							if(StringUtils.isNotBlank(orderDetail[0][28]))
							       po.setOrderLcdMoney(orderDetail[0][28]);//可返畅达币金额
							po.setOrderOldMoney("0");//原结算金额 初始结算为0
							po.setOrderMoney(bean.getSettleMoney());//EXCEL结算金额
							po.setCarType(bean.getCarType());//EXCEL车型
							int index = bean.getToDate().lastIndexOf(":");
							po.setToDate(bean.getToDate().substring(0, index));
							// 更新订单表返佣金、返畅达币金额
							RentCarServiceHandler.instance().updateOrderInfo(terminal, longToString(po.getOrderInfoId()), po.getOrderOldMoney(), po.getOrderLcdMoney(), po.getAdjust_lcd(),longToString(po.getId()));
							//判断是否结算过
							if (StringUtils.isNotBlank(orderDetail[0][27]))
								orderOldMoney = Double.valueOf(orderDetail[0][27] );// 如何已结算过的金额不为空订单取结算后的金额
							obj2.put("money", orderOldMoney);
							// 对比字段 车型、取车时间、金额
							if (orderDetail[0][16] != null)
								if (comparestr(orderDetail[0][16] == null ? orderDetail[0][15] : orderDetail[0][16].toString(),
										bean.getCarType())) {
									obj2.put("istype", "1");// 对比不同
								}
							if (orderDetail[0][5]!= null)
								if (comparestr(orderDetail[0][5], po.getToDate())) {
									obj2.put("isto", "1");// 对比不同
								}
							if (orderOldMoney != 0)
								if (comparestr(longToString(orderOldMoney.intValue()), bean.getSettleMoney())) {
									obj2.put("ismoney", "1");// 对比不同
								}
							strs.append(po.getOrderNo()).append("||").append(bean.getSettleMoney());// 神舟订单号||结算后金额
							//添加已存在的结算订单并添加  可重复导入结算
							RentCarServiceHandler.instance().saveOrderChange(terminal, longToString(po.getOrderInfoId()), po.getCarType(), po.getToDate(), po.getOrderMoney(),
									po.getOrderNo(), "0", longToString(po.getAddUserId()));

							jsonArray.add(obj2);
							obj.put("lcdOrderNo", "");
							obj.put("orderNo", bean.getOrderNo());
							obj.put("name", bean.getUserName());
							obj.put("type", bean.getCarType());
							obj.put("pretime", bean.getPrestarttime().toString());
							obj.put("fromtime", bean.getFromDate().toString());
							obj.put("totime", bean.getToDate().substring(0, index));
							obj.put("status", bean.getOrderStatus());
							obj.put("money", bean.getSettleMoney());
							jsonArray.add(obj);
							if (i < dataList.size() - 1)
								strs.append(";");
						}else{
							//自动添加缺单记录
							RentCarServiceHandler.instance().sysOrderInfoByOrderNo(terminal, bean.getOrderNo(), bean.getUserName(), bean.getCarType(), bean.getPrestarttime(), bean.getFromDate(), bean.getToDate(), bean.getSettleMoney());
							int index = bean.getToDate().lastIndexOf(":");
							obj.put("isLess", "1");//缺少标记
							obj.put("lcdOrderNo", "");
							obj.put("orderNo", bean.getOrderNo());
							obj.put("name", bean.getUserName());
							obj.put("type", bean.getCarType());
							obj.put("pretime", bean.getPrestarttime().toString());
							obj.put("fromtime", bean.getFromDate().toString());
							obj.put("totime", bean.getToDate().substring(0, index));
							obj.put("status", bean.getOrderStatus());
							obj.put("money", bean.getSettleMoney());
							lessJsonArray.add(obj);//添加记录  
							obj.put("isLess", "2");
							lessJsonArray.add(obj);//添加本地空记录
						}
					}
					modelMap.addAttribute("orderMoney", strs);
				}
			} catch (RuntimeException e) {
				e.printStackTrace();
			} finally {
			}
			if("[]".equals(lessJsonArray.toString()))
				result=jsonArray.toString();
			else
				result=lessJsonArray.toString().replace("]", ",")+jsonArray.toString().replace("[", "");//缺单记录优先显示
			return result;
		} else {
			throw new AppException("parse.excel.exception");
		}

	}

	/**
	 * 
	 * @param modelMap
	 * @return
	 * @throws AppException
	 */
	public String updateChange(ModelMap modelMap, String orderMoney) {
		String result = "success";
		String orderChange[][];
		String Change[][];
		String orderDetail[][];
		UserVO loginuser = LoginUtil.getLoginUser();
		Long userid = new Long(loginuser.getId());// 当前操作员ID
		String userId = null; // 手机会员ID散客为空
		String orderId="";//订单ID
		String orderLcdMoney="";//可返畅达币总金额=第一次结算金额
		RentCarChangePO po = new RentCarChangePO();
		PhoneCoinPO coinBean = new PhoneCoinPO();
		PhoneCoinDetailsPO coinDetail = new PhoneCoinDetailsPO();
		po.setAddUserId(userid);
		// 查询未更新结算报表
		try {
			orderChange =searchChange(null, longToString(userid), "0");//根据当前用户查询结算未更新数据
			if ("0".equals(orderChange[0][0])) {
				for (int i = 1; i < orderChange.length; i++) {
					String orderCarType;
					po = new RentCarChangePO();
					coinBean = new PhoneCoinPO();
					coinDetail = new PhoneCoinDetailsPO();
					String lcdRate = null, lcdValue = null;
					String id = orderChange[i][0];// ID
					String orderInfoId = orderChange[i][1];// 明细ID
					String adduser = orderChange[i][5];// 操作人ID
					String orderNewMoney = orderChange[i][7];// 订单结算金额
					String orderNo = orderChange[i][8];// 神舟订单号
					orderDetail=searchOrderByNo(orderNo);//查询本地订单数据
					 orderId = orderDetail[0][17];// 订单ID
					String isChange = orderDetail[0][25];// 是否已结算
					
					po.setId(Long.valueOf(id));
					po.setAddUserId(Long.valueOf(adduser));
					po.setAddTime(new Date());
						if (orderDetail[0][16] != null)
							orderCarType = orderDetail[0][16];// 车型
						else
							orderCarType = orderDetail[0][15];// 车型(个性车（不指定车型)
						String orderTodate = orderDetail[0][5];// 取车时间
						if ("1".equals(isChange) && orderDetail[0][27] != null){
						    orderLcdMoney = orderDetail[0][28];// 可返畅达币金额
						}
						if (orderDetail[0][36] != null)
							lcdRate = orderDetail[0][36];// 活动维护率
						else
							lcdRate = "0";
						if (orderDetail[0][37]!= null)
							lcdValue = orderDetail[0][37];//活动维护金额
						if (orderDetail[0][30] != null)
							userId = orderDetail[0][30];
					

					/**
					 *只添加第一次结算后的畅达币信息且必须为航旅会员
					 *操作畅达币明细
					 */
					if (StringUtils.isNotBlank(userId)&&(StringUtils.isBlank(isChange)||"0".equals(isChange))) {
						orderLcdMoney=orderNewMoney;//第一次结算值=可返畅达币  
						coinBean = phoneCoinService.findByUserId(userId);// 该用户的畅达币信息
						if (lcdRate != null) {
							coinDetail.setCoinaccountid(coinBean.getId());// 关联账户ID
							coinDetail.setExchangetime(new Date());
							coinDetail.setExchangetype("21");// 租车调整
							coinDetail.setOperator(longToString(userid));// 当前操作员
							//原需求中计算畅达币公式取消。
							Long lcdResult = CalculationNew(orderNewMoney, lcdRate);
							if (lcdResult.intValue() != 0) {
								if (lcdResult > 0)
									coinDetail.setReceiptscoin(lcdResult.intValue());// 收入
								else {
									lcdResult = lcdResult * -1;
									coinDetail.setPaycoin(lcdResult.intValue()); // 支出
								}
								coinDetail.setOrderId(Long.valueOf(orderId));// 订单ID
								phoneCoinDetailsService.create(coinDetail);// 更新畅达币明细
								coinBean.setLcdcoin(longToString(lcdResult.intValue()));
								rentCarService.updateCoin(coinBean);// 更新畅达币可用金额
							}
							// 更新订单表
							po.setAdjust_lcd(lcdResult.toString());//结算畅达币变化值
						}
					} else {
						po.setAdjust_lcd("0");// 结算畅达币变化值
					}
					po.setOrderInfoId(Long.valueOf(orderInfoId));
					RentCarServiceHandler.instance().updateOrderInfo(terminal, longToString(po.getOrderInfoId()), po.getOrderOldMoney(), po.getOrderLcdMoney(), po.getAdjust_lcd(),
							longToString(po.getId()));

					/**
					 * 更新订单表后更新变更表
					 */
					po.setCarType(orderCarType);// 存订单历史表中数据
					po.setToDate(orderTodate);
					
					//更新订单变更表状态
					RentCarServiceHandler.instance().updateOrderChange(terminal, longToString(po.getId()), longToString(po.getAddUserId()), po.getCarType(), po.getToDate());
					//多次导入神州报表，则订单总金额=多次结算金额的和   结算订单进行二次结算，可返畅达币总金额不变。
					Change =searchChange(orderId, longToString(userid), "1");//根据当前用户查询结算已更新数据
					if ("0".equals(Change[0][0])) {
						Double totalMoney=0D;
						for (int j = 1; j < Change.length; j++) {
							totalMoney+= Double.valueOf(Change[j][7]);// 订单结算金额
						}
						RentCarServiceHandler.instance().updateOrderInfoByOrderId(null, orderId, "0", String.valueOf(totalMoney), orderLcdMoney);
					}
				}
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * 获取车辆级别
	 * 
	 * @return
	 */
	public Map<String,Object> getLevel() {
		String[][] levelstrs;
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			levelstrs = RentCarServiceHandler.instance().getModeLeveList(terminal);
			RentCarPO carbean = new RentCarPO();
			if ("0".equals(levelstrs[0][0])) {
				for (int i = 1; i < levelstrs.length; i++) {
					carbean = new RentCarPO();
					carbean.setLevelcode(levelstrs[i][0]);
					carbean.setLevel(levelstrs[i][1]);
					map.put(levelstrs[i][0], levelstrs[i][1]);
				}
			} else
				log.error(levelstrs[0][1]);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return map;
	}

	/**
	 * 根据门店编码查询门店信息
	 * 
	 * @param storeCode
	 * @param disCode
	 *            区域编码
	 * @return
	 */
	public Map<String, Object> getStroeCode(String disCode, String storeCode) {
		String[][] storeList;
		Map<String, Object> map = new HashMap<String, Object>();
		try {
			storeList = RentCarServiceHandler.instance().getStoreByDistrictCode(terminal, "", disCode);
			if ("0".equals(storeList[0][0])) {
				for (int i = 1; i < storeList.length; i++) {
					if (storeCode.equals(storeList[i][0])) {
						map.put("FROMTIME", storeList[i][3]);
						map.put("TOTIME", storeList[i][4]);
						map.put("ADDRESS", storeList[i][2]);
						map.put("TELEPHONE", storeList[i][3]);// todo电话
					}
				}
			} else
				log.error(storeList[0][1]);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return map;
	}

	/**
	 * 通过城市名查询编码
	 * 
	 * @param cityName
	 * @return
	 */
	public String getCityCode(String cityName) {
		String[][] cityInfo;
		String result = "0";
		try {
			cityInfo = RentCarServiceHandler.instance().getCityInfo(terminal, "");
			if ("0".equals(cityInfo[0][0])) {
				for (int i = 1; i < cityInfo.length; i++) {
					if (cityInfo[i][1].equals(cityName))
						result = cityInfo[i][0];
				}
			} else
				log.error(cityInfo[0][1]);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 查询所有租车订单
	 * @param indexPage
	 * map 查询条件
	 * @return
	 */
	private String[][] searchAllOrderList(String indexPage,RentCarOrderPO bean){
		String orderList[][] = null;
		String operId=null;
		try {
			if(bean==null)
				bean=new RentCarOrderPO();//导出EXCEL初始化
			else if(StringUtils.isNotBlank(bean.getOperator()))
			    operId=rentCarService.selectOpeNameById(bean.getOperator());
			orderList=RentCarServiceHandler.instance().orderListQuery(terminal,
					                StringUtils.isNotBlank(bean.getPrestarttime())?bean.getPrestarttime():null,
							        StringUtils.isNotBlank(bean.getPreendtime())?bean.getPreendtime():null, 
									StringUtils.isNotBlank(bean.getOrderStatus())?bean.getOrderStatus():null,
					                null, indexPage,
					                StringUtils.isNotBlank(bean.getUserName())?bean.getUserName():null,
							        StringUtils.isNotBlank(bean.getMobile())?bean.getMobile():null,
									StringUtils.isNotBlank(bean.getIdCardNo())?bean.getIdCardNo():null,
									StringUtils.isNotBlank(bean.getLcdOrderNo())?bean.getLcdOrderNo().toUpperCase():null,
									StringUtils.isNotBlank(bean.getSource())?bean.getSource():null,
								    StringUtils.isNotBlank(bean.getOrderNo())?bean.getOrderNo():null,
									StringUtils.isNotBlank(bean.getCarType())?bean.getCarType():null,
									StringUtils.isNotBlank(bean.getFromstarttime())?bean.getFromstarttime():null,
									StringUtils.isNotBlank(bean.getFromendtime())?bean.getFromendtime():null,
									StringUtils.isNotBlank(bean.getTostarttime())?bean.getTostarttime():null,
									StringUtils.isNotBlank(bean.getToendtime())?bean.getToendtime():null,
					                      operId);
		if("0".equals(orderList[0][0])){
			return orderList;
		}else
			log.error(orderList[0][1]);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return orderList;
	}
	/**
	 * 根据订单号查询租车订单
	 * @param indexPage
	 * @return
	 */
	private String[][] searchOrderByNo(String orderNo){
		String orderinfo[][] = null;
		try {
			orderinfo=RentCarServiceHandler.instance().queryOrderInfoByOrderNo(terminal, null, orderNo);
			if("0".equals(orderinfo[0][0])){
				return orderinfo;
			}else
				log.error(orderinfo[0][1]);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return orderinfo;
	}
	/**
	 * 查询变更信息
	 * @param indexPage
	 * @return
	 */
	private String[][] searchChange(String orderId,String operId,String isCheck){
		String change[][] = null;
		try {
			change=RentCarServiceHandler.instance().queryOrderChang(null, operId, isCheck, orderId);
			if("0".equals(change[0][0])){
				return change;
			}else
				log.error(change[0][1]);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return change;
	}

	/**
	 * 对比字段
	 * 
	 * @param str1
	 * @param str2
	 * @return
	 */
	public static boolean comparestr(String str1, String str2) {
		boolean flag = true;
		if (StringUtils.isNotBlank(str1) && StringUtils.isNotBlank(str2))
			if (str1.equals(str2))
				flag = false;
		return flag;
	}

	/**
	 * 空转为字符串
	 * 
	 * @param obj
	 * @return
	 */
	private String nullToString(Object obj) {
		if (obj == null)
			return "";
		else
			return obj.toString();
	}

	/**
	 * long 转String
	 * 
	 * @param v
	 * @return
	 */
	private String longToString(long v) {
		if (v > 0) {
			return String.valueOf(v);
		} else {
			return null;
		}
	}

	/**
	 * 按长度补充字符串
	 * 
	 * @param s
	 * @param len
	 * @return
	 */
	private String genFixedLenStr(String s, int len) {
		StringBuffer sb = new StringBuffer(s);
		while (sb.length() < len) {
			sb.append(" ");
		}
		return sb.toString();
	}

	/**
	 * 增值服务名 +“;” + 总价 +“;”+单位+”;”+描述+” code
	 * 
	 * @param service
	 * @return 
	 */
	private List<String> serviceSplit(String service) {
		String result = null;
		List list=new ArrayList<String>();
		if (StringUtils.isNotBlank(service)) {
			String[] args1 = service.split("\\+");
			for (int i = 0; i < args1.length; i++) {
				result= args1[i];
				if(StringUtils.isBlank(result))
				   list.add("");
				else
				   list.add(result);
			}
		}
		return list;
	}


	//原公式作废
	public static Long CalculationNew(String str1, String str2) {
		Long result = null;
		if (str1 != null && str2 != null) {
			result = new Double(Math.floor(Double.valueOf(str1) * Double.valueOf(str2))).longValue();
		}
		return result;
	}
	/**
	 * 多次结算金额的和
	 * @param oldMoney
	 * @param newMoney
	 * @return
	 */
	public static String sumMoney(String oldMoney,String newMoney){
		String result="0";
		if (oldMoney != null && newMoney != null) {
		     Double v=Double.valueOf(oldMoney)+Double.valueOf(newMoney);
		     result=String.valueOf(v);
		}
		return result;
	}
	/**
	 * 错误信息提示
	 * @return
	 */
	public String getTraceInfo() {
		StringBuffer sb = new StringBuffer();

		StackTraceElement[] stacks = new Throwable().getStackTrace();
		int stacksLen = stacks.length;
		sb.append("class: ").append(stacks[1].getClassName()).append("; method: ").append(stacks[1].getMethodName()).append("; number: ").append(stacks[1].getLineNumber());

		return sb.toString();
	}

}