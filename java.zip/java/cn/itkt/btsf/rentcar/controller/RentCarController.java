package cn.itkt.btsf.rentcar.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.btsf.rentcar.po.RentCarOrderPO;
import cn.itkt.btsf.rentcar.po.RentCarPO;
import cn.itkt.btsf.rentcar.po.RentCarServiceExtPO;
import cn.itkt.btsf.sys.popscreen.vo.IncomingCallerVO;
import cn.itkt.btsf.util.DateUtil;
import cn.itkt.btsf.util.UploadController;
import cn.itkt.pagination.Pages;
import cn.itkt.util.SysUtil;

/**
 * 
 * @author wy
 * 
 * @version 1.0
 */

@Controller
@RequestMapping("/rentCar")
// @SessionAttributes("orderMoney")
// 放到Session属性列表中，以便这个属性可以跨请求访问
public class RentCarController {

	private static final Logger log = LoggerFactory.getLogger(RentCarController.class);
	// 一小时
	private static final long MS_EVERY_DAY = 1000 * 60 * 60;
	private static final long MS_HALF_DAY = 1000 * 60 * 30;
	@Resource
	private RentCarControllerSupport rentcarSupport;
	private UploadController uploader = new UploadController();
	RentCarPO bean = new RentCarPO();

	/**
	 * 租车订单查询初始化
	 */
	@RequestMapping(value = "/selectCar")
	public String selectCar(ModelMap modelMap, HttpServletResponse response, HttpServletRequest request, RentCarPO bean, @RequestParam Map<String, String> reqs) {
		String nowdate = DateUtil.getNDate(new Date(), 0);// 当前日期 默认值日期为后一天；
		// String enddate = DateUtil.getNDate(new Date(), 2);
		StringBuffer datas = rentcarSupport.CityList(modelMap);
		this.rentcarSupport.searchCarBrand(modelMap);
		modelMap.addAttribute("bean", bean);
		modelMap.put("datas", datas);
		modelMap.put("nowdate", nowdate);
		modelMap.putAll(reqs);
		if (StringUtils.isBlank(reqs.get("IDType")))
			modelMap.put("IDType", reqs.get("cardtype"));// 从填写订单返回
		// modelMap.put("enddate", enddate);
		// 带入弹屏用户信息
		String incomingId = (String) request.getParameter("incomingKey");
		if (incomingId != null && !"".equals(incomingId)) {
			Map<String, IncomingCallerVO> incomingMap = (Map<String, IncomingCallerVO>) request.getSession().getAttribute("incomingId");
			if (incomingMap != null) {
				IncomingCallerVO vo = incomingMap.get(incomingId);
				modelMap.put("custName", vo.getCustomerName());
				modelMap.put("custId", vo.getCustomerId());
				modelMap.put("custTel", vo.getCustomerTel());
				modelMap.put("custType", vo.getCustomerType());
			} else {
				modelMap.put("custType", "0");
			}
		}
		return "rentCar/selectCar";
	}

	/**
	 * 租车查询
	 */
	@RequestMapping(value = "/searchList")
	public String searchList(ModelMap modelMap, HttpServletResponse response, @ModelAttribute RentCarPO bean, @RequestParam Map<String, String> reqs) {
		rentcarSupport.storeInfo(modelMap, bean.getFromdiscode(), bean.getFromcode(), bean.getTodiscode(), bean.getTocode());
		modelMap.addAttribute("rentcarbean", bean);
		this.rentcarSupport.searchCarList(modelMap, bean);
		// this.rentcarSupport.searchCityCode(modelMap, bean);
		modelMap.putAll(reqs);
		return "rentCar/searchList";
	}

	/**
	 * 填写订单
	 * 
	 * @param modelMap
	 * @param request
	 * @param carTypeCode
	 * @param eveGold
	 * @param response
	 * @param po
	 * @return
	 */
	@RequestMapping(value = "/orderWrite")
	public String orderWrite(ModelMap modelMap, RentCarPO po, @RequestParam Map<String, String> reqs) {
		String carTypeCode = reqs.get("carTypeCode");
		int eveGold = Integer.parseInt(reqs.get("eveGold"));
		modelMap.putAll(reqs);
		rentcarSupport.storeInfo(modelMap, po.getFromdiscode(), po.getFromcode(), po.getTodiscode(), po.getTocode());
		rentcarSupport.setRentCarInfo(modelMap, po);
		modelMap.put("rentCar", po);
		modelMap.put("carTypeCode", carTypeCode);
		// 计算预订单金额接口
		rentcarSupport.calcCarOrderPrice(modelMap, reqs,po);// 只供查询租金用
		modelMap.put("totalGold", modelMap.get("totalCarRentMoney").toString());
		// 回显服务
		Set<String> reqKeys = reqs.keySet();
		StringBuffer serviceIds = new StringBuffer();
		String oldserviceId = reqs.get("serviceIds");// 已选服务ID 以‘，’分隔
		if (StringUtils.isBlank(oldserviceId)) {
			for (String rk : reqKeys) {
				if (rk.startsWith("serviceIds_")) {
					String serviceId = rk.substring(rk.indexOf('_') + 1);
					serviceIds.append(serviceId).append('&');
				}
			}
			if (serviceIds.length() > 0) {
				serviceIds.deleteCharAt(serviceIds.length() - 1);
			}
		} else
			serviceIds.append(oldserviceId);
		modelMap.put("serviceIds", serviceIds.toString());
		/*
		 * Set<String> keySet = reqs.keySet(); Map<String, String> services =
		 * new HashMap<String, String>(); for (String key : keySet) { if
		 * (key.startsWith("serviceIds_")) { services.put(key, reqs.get(key)); }
		 * } modelMap.put("services", services);
		 */
		return "rentCar/orderWrite";
	}

	/**
	 * 首租验证
	 */
	@RequestMapping(value = "/checkUserInfo")
	public ModelAndView checkUserInfo(ModelMap modelMap, @RequestParam Map<String, String> reqs) {
		rentcarSupport.checkUserInfo(modelMap, reqs);
		return new ModelAndView("jsonView");
	}

	/**
	 * 选择服务changeService
	 */
	@RequestMapping(value = "/changeService")
	public String changeService(ModelMap modelMap, HttpServletRequest request, @RequestParam Map<String, Object> reqs) {
		rentcarSupport.changeService(modelMap, reqs);
		modelMap.putAll(reqs);
		return "rentCar/changeService";
	}

	/**
	 * 订单核实
	 */
	@RequestMapping(value = "/orderVerify")
	public String orderVerify(ModelMap modelMap, @RequestParam Map<String, String> reqs, RentCarPO po) {
		modelMap.putAll(reqs);
		Set<String> reqKeys = reqs.keySet();
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		StringBuffer serviceIds = new StringBuffer();
		for (String rk : reqKeys) {
			if (rk.startsWith("serviceIds_")) {
				Map<String, String> map = new HashMap<String, String>();
				String serviceId = rk.substring(rk.indexOf('_') + 1);
				map.put("serviceId", serviceId);
				serviceIds.append(serviceId).append('&');
				String[] info = reqs.get(rk).toString().split("\\|");
				map.put("serviceName", info[0]);
				map.put("price", info[1]);
				map.put("unit", info[2]);
				list.add(map);
			}
		}
		rentcarSupport.storeInfo(modelMap, reqs.get("fromdiscode"), reqs.get("fromcode"), reqs.get("todiscode"), reqs.get("tocode"));
		modelMap.put("serviceList", list);
		if (serviceIds.length() > 0) {
			serviceIds.deleteCharAt(serviceIds.length() - 1);
		}
		reqs.put("serviceIds", serviceIds.toString());
		modelMap.put("serviceIds", serviceIds.toString());
		// 计算预订单金额接口
		rentcarSupport.calcCarOrderPrice(modelMap, reqs,po);
		return "rentCar/orderVerify";
	}

	/**
	 * 预定成功
	 */
	@RequestMapping(value = "/orderSuccessView")
	public ModelAndView orderSuccess(ModelMap modelMap, @RequestParam Map<String, String> reqs, RentCarPO po) {
		rentcarSupport.addSelfDriveOrder(modelMap, reqs,po);
		return new ModelAndView("redirect:/rentCar/orderSuccess", modelMap);
	}

	/**
	 * 
	 * 查询订单信息
	 * 
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/initlist")
	public String initlist(ModelMap modelMap, @RequestParam(value = "startIndex", defaultValue = "0") int startIndex, RentCarOrderPO bean, HttpServletRequest request) {
		Pages page = new Pages(startIndex);
		this.rentcarSupport.SearchOrderList(modelMap, startIndex, bean, page, request);// 查询租车列表
		return "rentCar/checkOrder";
	}

	/**
	 * 
	 * 租车订单详情
	 * 
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/edit")
	public String edit(ModelMap modelMap,String orderId) {
		this.rentcarSupport.searchOrderById(modelMap, orderId);
		modelMap.addAttribute("orderId", orderId);
		return "rentCar/orderEdit";
	}

	/**
	 * ajax获得取车城市
	 * 
	 * @throws Exception
	 */
	@RequestMapping(value = "/getcity")
	public void getcity(ModelMap modelMap, HttpServletResponse response) throws Exception {
		StringBuffer datas = new StringBuffer("北京|beijingshi|bjs,天津|tianjinshi|tjs");
		response.setCharacterEncoding("utf-8");
		response.getWriter().print(datas.toString());
	}

	/**
	 * ajax获得取车城市门店
	 * 
	 * @throws Exception
	 */
	@RequestMapping(value = "/ajaxStore")
	public void ajaxStore(ModelMap modelMap, HttpServletResponse response, String cityname) throws Exception {
		bean.setCityname(cityname);
		StringBuffer datas = new StringBuffer();
		datas = this.rentcarSupport.searchRegionList(modelMap, bean);
		response.setCharacterEncoding("utf-8");
		response.getWriter().print(datas.toString());
	}

	/**
	 * ajax获得异地还车服务费用
	 * 
	 * @throws Exception
	 */
	@RequestMapping(value = "/ajaxSpaceFee")
	public void ajaxcitySpaceFee(ModelMap modelMap, HttpServletResponse response, String cityname, String tocityname) throws Exception {
		String datas = new String();
		bean.setCityname(cityname);
		bean.setTocityname(tocityname);
		this.rentcarSupport.searchCityCode(modelMap, bean);
		String fromCityCode = (String) modelMap.get("cityCode");
		String toCityCode = (String) modelMap.get("tocityCode");
		datas = this.rentcarSupport.citySpaceFee(fromCityCode, toCityCode);
		response.setCharacterEncoding("utf-8");
		response.getWriter().print(datas);
	}

	/**
	 * 导出订单报表
	 * 
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value = "/exportrentcar")
	public String exportRentcar(ModelMap modelMap, String startDate, String endDate, @RequestParam(value = "startIndex", defaultValue = "0") int startIndex, RentCarOrderPO bean,
			HttpServletRequest request) {
		Pages page = new Pages(0); // 报表不需要分页，
		page.setPageSize(999999999);
		this.rentcarSupport.SearchOrderList(modelMap, startIndex, bean, page, request);// 查询租车列表
		return "exportRentExcel";
	}

	/**
	 * 根据订单号同步订单
	 * 
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @param orderId神州订单号
	 * @return
	 */
	@RequestMapping(value = "/synOrder")
	public void synOrder(ModelMap modelMap, String startDate, HttpServletResponse response, String endDate, String orderNo, String orderId, HttpServletRequest request) {
		try {
			// 神租订单号为空时同步所有订单
			String datas = "success";
			if (orderNo != null && !"".equals(orderNo))
				datas = this.rentcarSupport.synOrder(orderNo, null);
			else {
				RentCarOrderPO bean = new RentCarOrderPO();
				Pages page = new Pages(0); // 报表不需要分页，
				page.setPageSize(999999999);
				List<HashMap<String, String>> temList = this.rentcarSupport.SearchOrderList(modelMap, 0, bean, page, request);// 查询租车列表
				for (int i = 0; i < temList.size(); i++) {
					this.rentcarSupport.synOrder(temList.get(i).get("ORDERNO").toString(), null);
				}
			}
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(datas.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 根据订单号取消订单
	 * 
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @param orderId订单号
	 * @param Id
	 *            主健ID
	 * @return
	 */
	@RequestMapping(value = "/cancelOrder")
	public void cancelOrder(ModelMap modelMap, String startDate, HttpServletResponse response, String orderId, String todate, String Id) {
		try {
			String datas = this.rentcarSupport.cancelOrder(orderId, todate, Id);
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(datas.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 修改备注
	 * 
	 * @param modelMap
	 * @param startDate
	 * @param endDate
	 * @param orderId订单号
	 * @return
	 */
	@RequestMapping(value = "/updateremark")
	public void updateremark(ModelMap modelMap, HttpServletResponse response, String remark, String orderId) {
		try {
			String datas = this.rentcarSupport.updateRemark(orderId, remark);
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(datas.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 初始租车返畅达币维护
	 * 
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/serviceext")
	public String serviceext(ModelMap modelMap, HttpServletResponse response) {
		this.rentcarSupport.searchServiceExt(modelMap, response);
		return "rentCar/serviceExt";
	}

	/**
	 * 租车返畅达币维护
	 * 
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/updateserviceext")
	public void updateserviceext(ModelMap modelMap, HttpServletResponse response, String serviceId, RentCarServiceExtPO bean) {
		try {
			bean.setServiceId(serviceId);
			String datas = this.rentcarSupport.updateSearchServiceExt(modelMap, response, bean);
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(datas.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 导入租车订单结算
	 * 
	 * @param modelMap
	 * @param request
	 * @param response
	 * @param type
	 * @param filetype
	 *            1 :07版
	 * @return
	 */
	@RequestMapping(value = "/settleOrder")
	public String importSettleOrder(ModelMap modelMap, @RequestParam(value = "startIndex", defaultValue = "0") int startIndex, HttpServletRequest request,
			HttpServletResponse response, String type, String filetype, RentCarOrderPO bean) {
		Set<MultipartFile> mfs = uploader.getFileSet(request);
		if ("init".equals(type)) {
			try {
				Pages page = new Pages(startIndex);
				this.rentcarSupport.SearchOrderList(modelMap, startIndex, bean, page, request);// 查询租车列表
			} catch (Exception e) {
				log.error(e.getMessage());
				e.printStackTrace();
			}
		}
		return "rentCar/orderSettle";
	}

	/**
	 * 结算报表更新操作
	 * 
	 * @param modelMap
	 * @param type
	 * @param filetype
	 */
	@RequestMapping(value = "/updateOrder")
	public void updateOrder(ModelMap modelMap, HttpServletResponse response, String orderMoney) {
		try {
			String datas = this.rentcarSupport.updateChange(modelMap, orderMoney);
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(datas);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		}
	}

	/**
	 * 导入租车订单结算
	 * 
	 * @param modelMap
	 * @param request
	 * @param response
	 * @param type
	 * @param filetype
	 *            1 :支持07版
	 * @return
	 */
	@RequestMapping(value = "/importOrder")
	public void importOrder(ModelMap modelMap, HttpServletRequest request, HttpServletResponse response, String type, String filetype) {
		Set<MultipartFile> mfs = uploader.getFileSet(request);
		if (!"init".equals(type)) {
			try {
				boolean flag = false;
				if ("1".equals(filetype))
					flag = true;
				String data = rentcarSupport.importExcel(response, modelMap, mfs, flag);
				SysUtil.render(response, data);
			} catch (Exception e) {
				log.error(e.getMessage());
				e.printStackTrace();
			}
		}
	}

	/**
	 * 
	 * 计算租期 （超4小时计1天租期） 最小租期为1天 超一小时按一小时处理
	 * 
	 * @param begintime
	 * @param endtime
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping(value = "/ajaxrentdate")
	public static void compare(ModelMap modelMap, HttpServletResponse response, String begintime, String endtime) throws ParseException {
		try {
			Double datas = 0D;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			Date beginDate = format.parse(begintime);
			Date endDate = format.parse(endtime);
			Long more = 0L;
			boolean flag = false;// 半小时标识
			long beginTime = beginDate.getTime();
			long endTime = endDate.getTime();
			Long betweenDays = (endTime - beginTime) / MS_EVERY_DAY;
			Long halfbetweenDays = (endTime - beginTime) / MS_HALF_DAY;
			Long halfmore = halfbetweenDays % 2;
			halfbetweenDays = halfbetweenDays / 2;
			if (halfmore == 1 && halfbetweenDays != 0)
				flag = true;
			more = betweenDays % 24;
			if (flag)
				more += 1;
			betweenDays = betweenDays / 24;
			datas = betweenDays + 0D;
			if (betweenDays == 0)
				datas = 1D;
			if (betweenDays >= 1 && more < 5) {
				if (more == 1)
					datas = betweenDays + 0.2;
				else if (more == 2)
					datas = betweenDays + 0.4;
				else if (more == 3)
					datas = betweenDays + 0.6;
				else if (more == 4)
					datas = betweenDays + 0.8;
			}
			if (more >= 5)
				datas = betweenDays + 1D;
			response.setCharacterEncoding("utf-8");
			response.getWriter().print(String.valueOf(datas));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
