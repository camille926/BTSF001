package cn.itkt.btsf.rentcar.po;

import java.io.Serializable;

/**
 * 租车优惠活动及服务
 * 
 * @author wy 2012-10-17
 */
public class RentCarServicePO implements Serializable {

	/** serialVersionUID **/
	private static final long serialVersionUID = 1L;

	/** 主键 **/
	private long id;
	/** 订单详情ID **/
	private String orderinfoId;
	/** 服务名称 **/
	private String serviceName;
	/** 服务编码 **/
	private String serviceCode;
	/** 1标识服务 2 标识优惠活务 **/
	private String flag;
	/** 金额 **/
	private String totalPrice;
	/** 单位 **/
	private String unit;
	/** 操作时间 **/
	private String addtime;
	/** 服务描述 **/
	private String servicedesc;

	/** default constructor */
	public RentCarServicePO() {
	}

	/** full constructor */
	public RentCarServicePO(long id, String orderinfoId, String serviceName, String serviceCode, String flag, String totalPrice, String unit, String addtime, String servicedesc) {
		this.id = id;
		this.orderinfoId = orderinfoId;
		this.serviceName = serviceName;
		this.serviceCode = serviceCode;
		this.flag = flag;
		this.totalPrice = totalPrice;
		this.unit = unit;
		this.addtime = addtime;
		this.servicedesc = servicedesc;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getOrderinfoId() {
		return orderinfoId;
	}

	public void setOrderinfoId(String orderinfoId) {
		this.orderinfoId = orderinfoId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getAddtime() {
		return addtime;
	}

	public void setAddtime(String addtime) {
		this.addtime = addtime;
	}

	public String getServicedesc() {
		return servicedesc;
	}

	public void setServicedesc(String servicedesc) {
		this.servicedesc = servicedesc;
	}

}