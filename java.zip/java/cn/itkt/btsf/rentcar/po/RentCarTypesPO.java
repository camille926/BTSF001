package cn.itkt.btsf.rentcar.po;

import java.io.Serializable;

/**
 * 租车信息
 * 
 * @author wy 2012-10-17
 */
public class RentCarTypesPO implements Serializable {

	/** serialVersionUID **/
	private static final long serialVersionUID = 1L;

	/** 主键 **/
	private long id;
	/** 车型编码 **/
	private String carTypeCode;
	/** 车型名称 **/
	private String carTypeName;
	/** 可乘人数（座位数） **/
	private String seatQuantity;
	/** 保险费 **/
	private String insurancefee;
	/** 预授权 **/
	private String creditCardAuthorization;
	/** 手续费 **/
	private String serviceFee;
	/** 超时费 **/
	private String overTimeFee;
	/** 有无库存 **/
	private String available;
	/** 手动,自动 **/
	private String gear;
	/** 厢数 **/
	private String carriage;
	/** 排量 **/
	private String displaceMent;
	/** 图片 **/
	private String image;
	/** 查询时间段的首日单价 **/
	private String firstDayPrice;
	/** 周一到周四的价格 **/
	private String oneTofourPrice;
	/** 周五到周日的价格 **/
	private String fiveToSevenPrice;
	/** 7天套餐价格 **/
	private String setMealPriceSeve;
	/** 30天套餐价格 **/
	private String setMealPriceThir;
	/** 是否支付预定金 **/
	private String isPrepaid;

	/** 是否第一个车型 当为1时表示当前级别的第一个车型，0时不为第一个车型 **/
	private String isFirstMode;
	/** 车型级别 **/
	private String modeLevel;
	/** 车辆级别名称 **/
	private String modeLevelName;
	/** 标准均价 **/
	private String price;
	/** 每天价格 **/
	private String dayPrice;
	/** 级别类型 **/
	private String leveType;
	
	/** 套餐总价 **/
	private String packageTotalPrice;
	/** 套餐均价 **/
	private String packagePrice;
	/** 折扣 **/
	private String discount;
	/** 套餐描述 **/
	private String packageDescription;
	private String isSelectPackage;//是否选择套餐

	public String getDayPrice() {
		return dayPrice;
	}

	public void setDayPrice(String dayPrice) {
		this.dayPrice = dayPrice;
	}

	/** default constructor */
	public RentCarTypesPO() {
	}

	/** full constructor */
	public RentCarTypesPO(long id, String carTypeCode, String carTypeName, String seatQuantity, String insurancefee, String creditCardAuthorization, String serviceFee,
			String overTimeFee, String available, String gear, String carriage, String displaceMent, String image, String firstDayPrice, String oneTofourPrice,
			String fiveToSevenPrice, String setMealPriceSeve, String setMealPriceThir, String isPrepaid) {
		this.id = id;
		this.carTypeCode = carTypeCode;
		this.carTypeName = carTypeName;
		this.seatQuantity = seatQuantity;
		this.insurancefee = insurancefee;
		this.creditCardAuthorization = creditCardAuthorization;
		this.serviceFee = serviceFee;
		this.overTimeFee = overTimeFee;
		this.available = available;
		this.gear = gear;
		this.carriage = carriage;
		this.displaceMent = displaceMent;
		this.image = image;
		this.firstDayPrice = firstDayPrice;
		this.oneTofourPrice = oneTofourPrice;
		this.fiveToSevenPrice = fiveToSevenPrice;
		this.setMealPriceSeve = setMealPriceSeve;
		this.setMealPriceThir = setMealPriceThir;
		this.isPrepaid = isPrepaid;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCarTypeCode() {
		return carTypeCode;
	}

	public void setCarTypeCode(String carTypeCode) {
		this.carTypeCode = carTypeCode;
	}

	public String getCarTypeName() {
		return carTypeName;
	}

	public void setCarTypeName(String carTypeName) {
		this.carTypeName = carTypeName;
	}

	public String getSeatQuantity() {
		return seatQuantity;
	}

	public void setSeatQuantity(String seatQuantity) {
		this.seatQuantity = seatQuantity;
	}

	public String getInsurancefee() {
		return insurancefee;
	}

	public void setInsurancefee(String insurancefee) {
		this.insurancefee = insurancefee;
	}

	public String getCreditCardAuthorization() {
		return creditCardAuthorization;
	}

	public void setCreditCardAuthorization(String creditCardAuthorization) {
		this.creditCardAuthorization = creditCardAuthorization;
	}

	public String getServiceFee() {
		return serviceFee;
	}

	public void setServiceFee(String serviceFee) {
		this.serviceFee = serviceFee;
	}

	public String getOverTimeFee() {
		return overTimeFee;
	}

	public void setOverTimeFee(String overTimeFee) {
		this.overTimeFee = overTimeFee;
	}

	public String getAvailable() {
		return available;
	}

	public void setAvailable(String available) {
		this.available = available;
	}

	public String getGear() {
		return gear;
	}

	public void setGear(String gear) {
		this.gear = gear;
	}

	public String getCarriage() {
		return carriage;
	}

	public void setCarriage(String carriage) {
		this.carriage = carriage;
	}

	public String getDisplaceMent() {
		return displaceMent;
	}

	public void setDisplaceMent(String displaceMent) {
		this.displaceMent = displaceMent;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getFirstDayPrice() {
		return firstDayPrice;
	}

	public void setFirstDayPrice(String firstDayPrice) {
		this.firstDayPrice = firstDayPrice;
	}

	public String getOneTofourPrice() {
		return oneTofourPrice;
	}

	public void setOneTofourPrice(String oneTofourPrice) {
		this.oneTofourPrice = oneTofourPrice;
	}

	public String getFiveToSevenPrice() {
		return fiveToSevenPrice;
	}

	public void setFiveToSevenPrice(String fiveToSevenPrice) {
		this.fiveToSevenPrice = fiveToSevenPrice;
	}

	public String getSetMealPriceSeve() {
		return setMealPriceSeve;
	}

	public void setSetMealPriceSeve(String setMealPriceSeve) {
		this.setMealPriceSeve = setMealPriceSeve;
	}

	public String getSetMealPriceThir() {
		return setMealPriceThir;
	}

	public void setSetMealPriceThir(String setMealPriceThir) {
		this.setMealPriceThir = setMealPriceThir;
	}

	public String getIsPrepaid() {
		return isPrepaid;
	}

	public void setIsPrepaid(String isPrepaid) {
		this.isPrepaid = isPrepaid;
	}

	public String getIsFirstMode() {
		return isFirstMode;
	}

	public void setIsFirstMode(String isFirstMode) {
		this.isFirstMode = isFirstMode;
	}

	public String getModeLevel() {
		return modeLevel;
	}

	public void setModeLevel(String modeLevel) {
		this.modeLevel = modeLevel;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getModeLevelName() {
		return modeLevelName;
	}

	public void setModeLevelName(String modeLevelName) {
		this.modeLevelName = modeLevelName;
	}

	public String getLeveType() {
		return leveType;
	}

	public void setLeveType(String leveType) {
		this.leveType = leveType;
	}

	public String getPackageTotalPrice() {
		return packageTotalPrice;
	}

	public void setPackageTotalPrice(String packageTotalPrice) {
		this.packageTotalPrice = packageTotalPrice;
	}

	public String getPackagePrice() {
		return packagePrice;
	}

	public void setPackagePrice(String packagePrice) {
		this.packagePrice = packagePrice;
	}

	public String getDiscount() {
		return discount;
	}

	public void setDiscount(String discount) {
		this.discount = discount;
	}

	public String getPackageDescription() {
		return packageDescription;
	}

	public void setPackageDescription(String packageDescription) {
		this.packageDescription = packageDescription;
	}

	public String getIsSelectPackage() {
		return isSelectPackage;
	}

	public void setIsSelectPackage(String isSelectPackage) {
		this.isSelectPackage = isSelectPackage;
	}


}