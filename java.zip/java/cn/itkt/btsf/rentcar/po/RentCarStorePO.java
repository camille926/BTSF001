package cn.itkt.btsf.rentcar.po;

import java.io.Serializable;

/**
 * 租车门店
 * 
 * @author wy 2012-10-17
 */
public class RentCarStorePO implements Serializable {

	/** serialVersionUID **/
	private static final long serialVersionUID = 1L;

	/** 主键 **/
	private long id;
	/** 区ID **/
	private String disid;
	/** 门店编号 **/
	private String storecode;
	/** 门店名称 **/
	private String storename;
	/** 门店开始营业时间 **/
	private String fromtime;
	/** 门店结束营业时间 **/
	private String totime;
	/** 开业或停业 值为1：开业；值为2：停业 **/
	private String servicestatus;
	/** 纬度 **/
	private String latitude;
	/** 经度 **/
	private String longitude;
	/** 交通线路 **/
	private String trafficroute;
	/** 地址 **/
	private String address;
	/** 电话 **/
	private String telephone;
	/** 添加时间 **/
	private String addtime;
	/** 门店类型 **/
	private String deptype;

	/** 仅查询使用 **/

	public RentCarStorePO() {

	}

	public RentCarStorePO(long id, String disid, String storecode, String storename, String fromtime, String totime, String servicestatus, String latitude, String longitude,
			String trafficroute, String address, String telephone, String addtime, String deptype) {
		super();
		this.id = id;
		this.disid = disid;
		this.storecode = storecode;
		this.storename = storename;
		this.fromtime = fromtime;
		this.totime = totime;
		this.servicestatus = servicestatus;
		this.latitude = latitude;
		this.longitude = longitude;
		this.trafficroute = trafficroute;
		this.address = address;
		this.telephone = telephone;
		this.addtime = addtime;
		this.deptype = deptype;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDisid() {
		return disid;
	}

	public void setDisid(String disid) {
		this.disid = disid;
	}

	public String getStorecode() {
		return storecode;
	}

	public void setStorecode(String storecode) {
		this.storecode = storecode;
	}

	public String getStorename() {
		return storename;
	}

	public void setStorename(String storename) {
		this.storename = storename;
	}

	public String getFromtime() {
		return fromtime;
	}

	public void setFromtime(String fromtime) {
		this.fromtime = fromtime;
	}

	public String getTotime() {
		return totime;
	}

	public void setTotime(String totime) {
		this.totime = totime;
	}

	public String getServicestatus() {
		return servicestatus;
	}

	public void setServicestatus(String servicestatus) {
		this.servicestatus = servicestatus;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getTrafficroute() {
		return trafficroute;
	}

	public void setTrafficroute(String trafficroute) {
		this.trafficroute = trafficroute;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getAddtime() {
		return addtime;
	}

	public void setAddtime(String addtime) {
		this.addtime = addtime;
	}

	public String getDeptype() {
		return deptype;
	}

	public void setDeptype(String deptype) {
		this.deptype = deptype;
	}

}