package cn.itkt.btsf.rentcar.po;

import java.io.Serializable;
import java.util.Date;

/**
 * 订单结算变动
 * 
 * @author wy 2012-10-17
 */
public class RentCarChangePO implements Serializable {

	/** serialVersionUID **/
	private static final long serialVersionUID = 1L;
	/** 主键 **/
	private long id;
	private long orderInfoId;// 订单明细表ID
	private String carType;// 车型
	private String toDate;// 还车时间
	private Date addTime;// 添加时间
	private long addUserId; // 当前操作员ID
	private String orderOldMoney;// 神州订单原始返佣金额
	private String orderMoney;// 神州结算金额
	private String orderLcdMoney;// 可返畅达币总金额
	private String orderNo;// 神舟订单号
	private char isUpdate;// 是否已更新 1：已更新 0：未更新
	private String adjust_lcd;// 结算畅达币变化值

	/** default constructor */
	public RentCarChangePO() {
	}

	public long getId() {
		return id;
	}

	/** full constructor */
	public RentCarChangePO(long id, long orderInfoId, String carType, String toDate, Date addTime, long addUserId) {
		this.id = id;
		this.orderInfoId = orderInfoId;
		this.carType = carType;
		this.toDate = toDate;
		this.addTime = addTime;
		this.addUserId = addUserId;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getOrderInfoId() {
		return orderInfoId;
	}

	public void setOrderInfoId(long orderInfoId) {
		this.orderInfoId = orderInfoId;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public Date getAddTime() {
		return addTime;
	}

	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}

	public long getAddUserId() {
		return addUserId;
	}

	public void setAddUserId(long addUserId) {
		this.addUserId = addUserId;
	}

	public String getOrderMoney() {
		return orderMoney;
	}

	public void setOrderMoney(String orderMoney) {
		this.orderMoney = orderMoney;
	}

	public char getIsUpdate() {
		return isUpdate;
	}

	public void setIsUpdate(char isUpdate) {
		this.isUpdate = isUpdate;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getOrderOldMoney() {
		return orderOldMoney;
	}

	public void setOrderOldMoney(String orderOldMoney) {
		this.orderOldMoney = orderOldMoney;
	}

	public String getOrderLcdMoney() {
		return orderLcdMoney;
	}

	public void setOrderLcdMoney(String orderLcdMoney) {
		this.orderLcdMoney = orderLcdMoney;
	}

	public String getAdjust_lcd() {
		return adjust_lcd;
	}

	public void setAdjust_lcd(String adjust_lcd) {
		this.adjust_lcd = adjust_lcd;
	}

}