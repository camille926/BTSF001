package cn.itkt.btsf.rentcar.po;

import java.io.Serializable;

/**
 * 租车返畅达币维护
 * 
 * @author wy 2012-11-2
 */
public class RentCarServiceExtPO implements Serializable {

	/** serialVersionUID **/
	private static final long serialVersionUID = 1L;

	/** 主键 **/
	private long id;
	/** 服务编码 **/
	private String serviceId;
	/** 服务名称 **/
	private String serviceName;
	/** 价格 **/
	private String price;
	/** 单位 **/
	private String Unit;
	/** 选择类型 ‘1’ 必须‘2’ 不能选‘3’ 可选 **/
	private String chooseType;
	/** 描述 **/
	private String description;
	/** 是否赠送畅达币 **/
	private char isGiveLcd;

	/** 是否选择 **/
	private Long isChecked;

	/** 最后操作时间 **/
	private String endTime;

	/** default constructor */
	public RentCarServiceExtPO() {
	}

	/** full constructor */
	public RentCarServiceExtPO(long id, String serviceId, String serviceName, String price, String unit, String chooseType, String description, char isGiveLcd) {
		this.id = id;
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.price = price;
		Unit = unit;
		this.chooseType = chooseType;
		this.description = description;
		this.isGiveLcd = isGiveLcd;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getUnit() {
		return Unit;
	}

	public void setUnit(String unit) {
		Unit = unit;
	}

	public String getChooseType() {
		return chooseType;
	}

	public void setChooseType(String chooseType) {
		this.chooseType = chooseType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public char getIsGiveLcd() {
		return isGiveLcd;
	}

	public void setIsGiveLcd(char isGiveLcd) {
		this.isGiveLcd = isGiveLcd;
	}

	public Long getIsChecked() {
		return isChecked;
	}

	public void setIsChecked(Long isChecked) {
		this.isChecked = isChecked;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}