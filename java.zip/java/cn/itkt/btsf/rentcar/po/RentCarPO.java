package cn.itkt.btsf.rentcar.po;

import java.io.Serializable;

/**
 * 租车管理
 * 
 * @author wy 2012-10-17
 */
public class RentCarPO implements Serializable {

	/** serialVersionUID **/
	private static final long serialVersionUID = 1L;

	/** 主键 **/
	private long id;
	/** 城市名称 **/
	private String cityname;
	/** 还车城市名称 **/
	private String tocityname;
	/** 城市编码 **/
	private String citycode;
	private String tocitycode;
	/** 取车城市区域编码 **/
	private String fromdiscode;
	/** 还车城市区域编码 **/
	private String todiscode;
	/** 城市区域名称 **/
	private String districtname;
	/** 取车门店 **/
	private String fromstore;
	private String fromcode;
	/** 还车门店 **/
	private String tostore;
	private String tocode;
	/** 取车时间 yyyy-MM-dd **/
	private String startdate;
	/** 取车时间 HH:mm **/
	private String fromdate;
	/** 取车时间 yyyy-MM-dd **/
	private String enddate;
	/** 还车时间 HH:mm **/
	private String todate;
	/** 级别 **/
	private String level;
	private String levelcode;
	/** 品牌 **/
	private String brand;
	/** 租金 **/
	private String rental;
	private String rentalcode;
	/** 租期 **/
	private String rentdate;
	private String rentdd;// 租期 只用于显示 *天*小时
	/** 车辆信息 **/
	private String carmessage;
	/** 夜间服务次数 50元/次 **/
	/** 是否有夜间服务 1：夜间服务 **/
	private Integer isStartNight;
	private Integer isEndNight;
	/** 是否有异地还车 **/
	private String isdiffer;

	/** 门店点与店标识 **/
	private String fromstroetype;
	private String tostroetype;
	// 门店电话
	private String fromcall;
	private String tocall;
	private String fromaddress;
	private String toaddress;
	// 门店营业时间
	private String from;
	private String to;
	//基本保险
	private String insurancefee;
	
	private String isSelectPackage;//是否选择套餐

	public String getIsSelectPackage() {
		return isSelectPackage;
	}

	public void setIsSelectPackage(String isSelectPackage) {
		this.isSelectPackage = isSelectPackage;
	}

	/** default constructor */
	public RentCarPO() {
	}

	/** full constructor */
	public RentCarPO(long id, String cityname, String citycode, String districtname, String fromstore, String tostore, String fromdate, String todate, String level, String brand,
			String rental, String rentdate) {
		super();
		this.id = id;
		this.cityname = cityname;
		this.citycode = citycode;
		this.districtname = districtname;
		this.fromstore = fromstore;
		this.tostore = tostore;
		this.fromdate = fromdate;
		this.todate = todate;
		this.level = level;
		this.brand = brand;
		this.rental = rental;
		this.rentdate = rentdate;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getTocityname() {
		return tocityname;
	}

	public void setTocityname(String tocityname) {
		this.tocityname = tocityname;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	public String getDistrictname() {
		return districtname;
	}

	public void setDistrictname(String districtname) {
		this.districtname = districtname;
	}

	public String getFromstore() {
		return fromstore;
	}

	public void setFromstore(String fromstore) {
		this.fromstore = fromstore;
	}

	public String getTostore() {
		return tostore;
	}

	public void setTostore(String tostore) {
		this.tostore = tostore;
	}

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public String getEnddate() {
		return enddate;
	}

	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}

	public String getFromdate() {
		return fromdate;
	}

	public void setFromdate(String fromdate) {
		this.fromdate = fromdate;
	}

	public String getTodate() {
		return todate;
	}

	public void setTodate(String todate) {
		this.todate = todate;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getRental() {
		return rental;
	}

	public void setRental(String rental) {
		this.rental = rental;
	}

	public String getRentdate() {
		return rentdate;
	}

	public void setRentdate(String rentdate) {
		this.rentdate = rentdate;
	}

	public String getCarmessage() {
		return carmessage;
	}

	public void setCarmessage(String carmessage) {
		this.carmessage = carmessage;
	}

	public String getTocitycode() {
		return tocitycode;
	}

	public void setTocitycode(String tocitycode) {
		this.tocitycode = tocitycode;
	}

	public String getFromcode() {
		return fromcode;
	}

	public void setFromcode(String fromcode) {
		this.fromcode = fromcode;
	}

	public String getTocode() {
		return tocode;
	}

	public void setTocode(String tocode) {
		this.tocode = tocode;
	}

	public String getLevelcode() {
		return levelcode;
	}

	public void setLevelcode(String levelcode) {
		this.levelcode = levelcode;
	}

	public String getRentalcode() {
		return rentalcode;
	}

	public void setRentalcode(String rentalcode) {
		this.rentalcode = rentalcode;
	}

	public String getIsdiffer() {
		return isdiffer;
	}

	public void setIsdiffer(String isdiffer) {
		this.isdiffer = isdiffer;
	}

	public Integer getIsStartNight() {
		return isStartNight;
	}

	public void setIsStartNight(Integer isStartNight) {
		this.isStartNight = isStartNight;
	}

	public Integer getIsEndNight() {
		return isEndNight;
	}

	public void setIsEndNight(Integer isEndNight) {
		this.isEndNight = isEndNight;
	}

	public String getFromstroetype() {
		return fromstroetype;
	}

	public void setFromstroetype(String fromstroetype) {
		this.fromstroetype = fromstroetype;
	}

	public String getTostroetype() {
		return tostroetype;
	}

	public void setTostroetype(String tostroetype) {
		this.tostroetype = tostroetype;
	}

	public String getFromcall() {
		return fromcall;
	}

	public void setFromcall(String fromcall) {
		this.fromcall = fromcall;
	}

	public String getTocall() {
		return tocall;
	}

	public void setTocall(String tocall) {
		this.tocall = tocall;
	}

	public String getFromaddress() {
		return fromaddress;
	}

	public void setFromaddress(String fromaddress) {
		this.fromaddress = fromaddress;
	}

	public String getToaddress() {
		return toaddress;
	}

	public void setToaddress(String toaddress) {
		this.toaddress = toaddress;
	}

	public String getRentdd() {
		return rentdd;
	}

	public void setRentdd(String rentdd) {
		this.rentdd = rentdd;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getFromdiscode() {
		return fromdiscode;
	}

	public void setFromdiscode(String fromdiscode) {
		this.fromdiscode = fromdiscode;
	}

	public String getTodiscode() {
		return todiscode;
	}

	public void setTodiscode(String todiscode) {
		this.todiscode = todiscode;
	}

	public String getInsurancefee() {
		return insurancefee;
	}

	public void setInsurancefee(String insurancefee) {
		this.insurancefee = insurancefee;
	}

}