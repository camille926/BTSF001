package cn.itkt.btsf.rentcar.po;

import java.io.Serializable;

/**
 * 租车订单信息
 * 
 * @author wy 2012-10-17
 */
public class RentCarOrderPO implements Serializable {

	/** serialVersionUID **/
	private static final long serialVersionUID = 1L;

	/** 主键 **/
	private long id;
	/** 用户名 **/
	private String userName;
	/** 订单号（神州） **/
	private String orderNo;
	/** 证件类型 **/
	private String idCardType;
	/** 证件号 **/
	private String idCardNo;
	/** 驾驶证号 **/
	private String drivingLicenceNo;
	/** 手机号 **/
	private String mobile;
	/** 邮箱 **/
	private String email;
	/** 地址 **/
	private String address;
	/** 起始时间 **/
	private String fromDate;
	/** 结束时间 **/
	private String toDate;
	/** 租车省份 **/
	private String fromProvince;
	/** 租车城市 **/
	private String fromCity;
	/** 租车门店编号 **/
	private String fromStore;
	/** 还车省份 **/
	private String toProvince;
	/** 还车城市 **/
	private String toCity;
	/** 还车门店编号 **/
	private String toStore;
	/** 车型编码 **/
	private String carType;
	/** 订单备注 **/
	private String comments;
	/** 订单租金总金额 **/
	private String totalCarRentMoney;
	/** 预订单总金额 **/
	private String totalOrderPrice;
	/** 保险费用 **/
	private String insuranceFee;
	/** 服务费用 **/
	private String serviceFee;
	/** 订单状态 **/
	private String orderStatus;
	/** 送车上门地址 **/
	private String fromAddr;
	/** 上门取车地址 **/
	private String returnAddr;
	/** 订单最后修改时间 **/
	private String updateTime;
	/** 隆畅达订单号 **/
	private String lcdOrderNo;
	/** 订单取消时间 **/
	private String cancelTime;
	/** 取消订单人ID **/
	private String cancelOrderId;
	/** 日价格 **/
	private String dailyPrice;

	/** 以下属性仅查询用 **/
	/** 订单号（隆畅达） **/
	private String orderId;
	/** 订单来源 **/
	private String source;
	/** 会员号码 **/
	private String memberId;
	/** 取车时间 **/
	private String fromstarttime;
	/**  **/
	private String fromendtime;
	/** 还车时间 **/
	private String tostarttime;
	/**  **/
	private String toendtime;
	/** 预定时间 **/
	private String prestarttime;
	/**  **/
	private String preendtime;
	/** 操作人 **/
	private String operator;
	/** 可返畅达币 **/
	private String lcdGold;
	/** 车型名称 **/
	private String carName;
	// 报表结算时使用
	/** 结算金额 **/
	private String settleMoney;
	/** 是否存差异 **/
	private String isDifference;

	/** default constructor */
	public RentCarOrderPO() {
	}

	/** full constructor */
	public RentCarOrderPO(long id, String userName, String orderNo, String idCardType, String idCardNo, String drivingLicenceNo, String mobile, String email, String address,
			String fromDate, String toDate, String fromProvince, String fromCity, String fromStore, String toProvince, String toCity, String toStore, String carType,
			String comments, String totalCarRentMoney, String totalOrderPrice, String insuranceFee, String serviceFee, String orderStatus, String fromAddr, String returnAddr) {
		this.id = id;
		this.userName = userName;
		this.orderNo = orderNo;
		this.idCardType = idCardType;
		this.idCardNo = idCardNo;
		this.drivingLicenceNo = drivingLicenceNo;
		this.mobile = mobile;
		this.email = email;
		this.address = address;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.fromProvince = fromProvince;
		this.fromCity = fromCity;
		this.fromStore = fromStore;
		this.toProvince = toProvince;
		this.toCity = toCity;
		this.toStore = toStore;
		this.carType = carType;
		this.comments = comments;
		this.totalCarRentMoney = totalCarRentMoney;
		this.totalOrderPrice = totalOrderPrice;
		this.insuranceFee = insuranceFee;
		this.serviceFee = serviceFee;
		this.orderStatus = orderStatus;
		this.fromAddr = fromAddr;
		this.returnAddr = returnAddr;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getIdCardType() {
		return idCardType;
	}

	public void setIdCardType(String idCardType) {
		this.idCardType = idCardType;
	}

	public String getIdCardNo() {
		return idCardNo;
	}

	public void setIdCardNo(String idCardNo) {
		this.idCardNo = idCardNo;
	}

	public String getDrivingLicenceNo() {
		return drivingLicenceNo;
	}

	public void setDrivingLicenceNo(String drivingLicenceNo) {
		this.drivingLicenceNo = drivingLicenceNo;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getFromProvince() {
		return fromProvince;
	}

	public void setFromProvince(String fromProvince) {
		this.fromProvince = fromProvince;
	}

	public String getFromCity() {
		return fromCity;
	}

	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}

	public String getFromStore() {
		return fromStore;
	}

	public void setFromStore(String fromStore) {
		this.fromStore = fromStore;
	}

	public String getToProvince() {
		return toProvince;
	}

	public void setToProvince(String toProvince) {
		this.toProvince = toProvince;
	}

	public String getToCity() {
		return toCity;
	}

	public void setToCity(String toCity) {
		this.toCity = toCity;
	}

	public String getToStore() {
		return toStore;
	}

	public void setToStore(String toStore) {
		this.toStore = toStore;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getTotalCarRentMoney() {
		return totalCarRentMoney;
	}

	public void setTotalCarRentMoney(String totalCarRentMoney) {
		this.totalCarRentMoney = totalCarRentMoney;
	}

	public String getTotalOrderPrice() {
		return totalOrderPrice;
	}

	public void setTotalOrderPrice(String totalOrderPrice) {
		this.totalOrderPrice = totalOrderPrice;
	}

	public String getInsuranceFee() {
		return insuranceFee;
	}

	public void setInsuranceFee(String insuranceFee) {
		this.insuranceFee = insuranceFee;
	}

	public String getServiceFee() {
		return serviceFee;
	}

	public void setServiceFee(String serviceFee) {
		this.serviceFee = serviceFee;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public String getFromAddr() {
		return fromAddr;
	}

	public void setFromAddr(String fromAddr) {
		this.fromAddr = fromAddr;
	}

	public String getReturnAddr() {
		return returnAddr;
	}

	public void setReturnAddr(String returnAddr) {
		this.returnAddr = returnAddr;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getFromstarttime() {
		return fromstarttime;
	}

	public void setFromstarttime(String fromstarttime) {
		this.fromstarttime = fromstarttime;
	}

	public String getFromendtime() {
		return fromendtime;
	}

	public void setFromendtime(String fromendtime) {
		this.fromendtime = fromendtime;
	}

	public String getTostarttime() {
		return tostarttime;
	}

	public void setTostarttime(String tostarttime) {
		this.tostarttime = tostarttime;
	}

	public String getToendtime() {
		return toendtime;
	}

	public void setToendtime(String toendtime) {
		this.toendtime = toendtime;
	}

	public String getPrestarttime() {
		return prestarttime;
	}

	public void setPrestarttime(String prestarttime) {
		this.prestarttime = prestarttime;
	}

	public String getPreendtime() {
		return preendtime;
	}

	public void setPreendtime(String preendtime) {
		this.preendtime = preendtime;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public String getLcdGold() {
		return lcdGold;
	}

	public void setLcdGold(String lcdGold) {
		this.lcdGold = lcdGold;
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public String getLcdOrderNo() {
		return lcdOrderNo;
	}

	public void setLcdOrderNo(String lcdOrderNo) {
		this.lcdOrderNo = lcdOrderNo;
	}

	public String getCancelTime() {
		return cancelTime;
	}

	public void setCancelTime(String cancelTime) {
		this.cancelTime = cancelTime;
	}

	public String getCancelOrderId() {
		return cancelOrderId;
	}

	public void setCancelOrderId(String cancelOrderId) {
		this.cancelOrderId = cancelOrderId;
	}

	public String getDailyPrice() {
		return dailyPrice;
	}

	public void setDailyPrice(String dailyPrice) {
		this.dailyPrice = dailyPrice;
	}

	public String getSettleMoney() {
		return settleMoney;
	}

	public void setSettleMoney(String settleMoney) {
		this.settleMoney = settleMoney;
	}

	public String getIsDifference() {
		return isDifference;
	}

	public void setIsDifference(String isDifference) {
		this.isDifference = isDifference;
	}

}