package cn.itkt.btsf.rentcar.service.impl;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.phone.users.po.PhoneCoinPO;
import cn.itkt.btsf.rentcar.dao.RentCarDao;
import cn.itkt.btsf.rentcar.po.RentCarChangePO;
import cn.itkt.btsf.rentcar.po.RentCarOrderPO;
import cn.itkt.btsf.rentcar.po.RentCarPO;
import cn.itkt.btsf.rentcar.po.RentCarServiceExtPO;
import cn.itkt.btsf.rentcar.po.RentCarStorePO;
import cn.itkt.btsf.rentcar.service.RentCarService;

@Service
public class RentCarImpl implements RentCarService {

	private static final Logger log = LoggerFactory.getLogger(RentCarImpl.class);

	@Resource
	private RentCarDao RentCarDao;

	/**
	 * 查找单个
	 * 
	 * @param id
	 * @return RentCar
	 */
	public RentCarPO find(Serializable id) {
		return RentCarDao.find(id);
	}

	/**
	 * 查找所有
	 * 
	 * @return List<RentCarPO>
	 */
	public List<RentCarPO> findAll() {
		return RentCarDao.findAll();
	}

	@Override
	public List<RentCarPO> findAllCarCity() {
		return RentCarDao.findAllCarCity();
	}

	/**
	 * 查找城市编码
	 * 
	 * @return List<RentCarPO>
	 */
	public String findCityCode(RentCarPO po) {
		return RentCarDao.findCityCode(po);
	}

	@Override
	public List<RentCarPO> findARegionbycity(RentCarPO po) {
		return RentCarDao.findARegionbycity(po);
	}

	@Override
	public List<RentCarStorePO> findStorebyRegion(RentCarStorePO po) {
		return RentCarDao.findStorebyRegion(po);
	}

	@Override
	public int OrderListCount(Map<String, Object> map) {
		return RentCarDao.OrderListCount(map);
	}

	@Override
	public List<HashMap<String, Object>> searchAllOrders(Map<String, Object> map) {
		return RentCarDao.searchAllOrders(map);
	}

	@Override
	public void updateCarRemark(RentCarOrderPO po) {
		RentCarDao.updateCarRemark(po);
	}

	/**
	 * 取消订单
	 */
	public void cancelOrder(RentCarOrderPO po) {
		RentCarDao.cancelOrder(po);
	}

	/**
	 * 租车日价格
	 */
	public void updateDailyPrice(RentCarOrderPO po) {
		RentCarDao.updateDailyPrice(po);
	}

	/**
	 * 查询门店详情
	 * 
	 * @return List<RentCarPO>
	 */
	public Map<String, String> findStorebyCode(String storeCode) {
		return RentCarDao.findStorebyCode(storeCode);
	}

	public List<HashMap<String, Object>> SearchOrderById(Map<String, Object> map) {
		return RentCarDao.SearchOrderById(map);
	}

	public List<HashMap<String, Object>> SearchOrderServiceById(Map<String, Object> map) {
		return RentCarDao.SearchOrderServiceById(map);
	}

	public List<HashMap<String, Object>> searchServiceExt(Map<String, Object> map) {
		return RentCarDao.searchServiceExt(map);
	}

	@Override
	public void updateServiceExt(RentCarServiceExtPO po) {
		RentCarDao.updateServiceExt(po);
	}

	/**
	 * 报表结算获取本地所有服务
	 * 
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> searchSZService() {
		return RentCarDao.searchSZService();
	}

	/**
	 * 报表结算获活动信息
	 * 
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> searchActivty() {
		return RentCarDao.searchActivty();
	}

	/**
	 * 报表结算根据订单号查询订单
	 * 
	 * @return List<RentCarPO>
	 */
	public List<HashMap<String, Object>> findOrderbyNo(String orderNo) {
		return RentCarDao.findOrderbyNo(orderNo);
	}

	/**
	 * 创建报表结算变更
	 * 
	 * @param po
	 */
	public void create(RentCarChangePO po) {
		RentCarDao.create(po);
	}

	/**
	 * 查询订单结算变动
	 * 
	 * @return List<RentCarChangePO>
	 */
	public List<HashMap<String, Object>> findOrderChange(RentCarChangePO po) {
		return RentCarDao.findOrderChange(po);
	}

	/**
	 * 根据订单明细ID查询订单结算变动和结算操作人
	 * 
	 * @return List<RentCarChangePO>
	 */
	public List<HashMap<String, Object>> findChangeByOrderinfoId(RentCarChangePO po) {
		return RentCarDao.findChangeByOrderinfoId(po);
	}

	/**
	 * 修改订单结算变动
	 * 
	 * @param po
	 * @return
	 */
	public void updateChange(RentCarChangePO po) {
		RentCarDao.updateChange(po);
	}

	/**
	 * 结算后修改订单信息
	 * 
	 * @param po
	 * @return
	 */
	public void updateCarOrder(RentCarChangePO po) {
		RentCarDao.updateCarOrder(po);
	}

	/**
	 * 结算后修改畅达币信息
	 * 
	 * @param po
	 * @return
	 */
	public void updateCoin(PhoneCoinPO po) {
		RentCarDao.updateCoin(po);
	}

	/**
	 * 删除已导的结算订单
	 * 
	 * @return List<RentCarPO>
	 */
	public void deleteByOrderId(Long orderInfoId) {
		RentCarDao.deleteByOrderId(orderInfoId);
	}

	@Override
	public String selectOpeNameById(String name) {
		return RentCarDao.selectOpeNameById(name);
	}

	@Override
	public String selectOpeName(String id) {
		return RentCarDao.selectOpeName(id);
	}
}