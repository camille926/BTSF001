package cn.itkt.btsf.rentcar.service;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.phone.users.po.PhoneCoinPO;
import cn.itkt.btsf.rentcar.po.RentCarChangePO;
import cn.itkt.btsf.rentcar.po.RentCarOrderPO;
import cn.itkt.btsf.rentcar.po.RentCarPO;
import cn.itkt.btsf.rentcar.po.RentCarServiceExtPO;
import cn.itkt.btsf.rentcar.po.RentCarStorePO;

public interface RentCarService {

	/**
	 * 查找单个
	 * 
	 * @param id
	 * @return RentCar
	 */
	public RentCarPO find(Serializable id);

	/**
	 * 查找所有
	 * 
	 * @return List<RentCarPO>
	 */
	public List<RentCarPO> findAll();

	/**
	 * 查找城市列表
	 * 
	 * @return List<RentCarPO>
	 */
	public List<RentCarPO> findAllCarCity();

	/**
	 * 查找城市编码
	 * 
	 * @return List<RentCarPO>
	 */
	public String findCityCode(RentCarPO po);

	/**
	 * 查找区域列表
	 * 
	 * @return List<RentCarPO>
	 */
	public List<RentCarPO> findARegionbycity(RentCarPO po);

	/**
	 * 查找区域下门店列表
	 * 
	 * @return List<RentCarPO>
	 */
	public List<RentCarStorePO> findStorebyRegion(RentCarStorePO po);

	/**
	 * 查找订单列表
	 * 
	 * @return List<RentCarOrderPO>
	 */
	public List<HashMap<String, Object>> searchAllOrders(Map<String, Object> map);

	/**
	 * 订单列表count
	 * 
	 * @param map
	 * @return
	 */
	public int OrderListCount(Map<String, Object> map);

	/**
	 * 修改订单备注
	 * 
	 * @param map
	 * @return
	 */
	public void updateCarRemark(RentCarOrderPO po);

	/**
	 * 取消订单
	 * 
	 * @param map
	 * @return
	 */
	public void cancelOrder(RentCarOrderPO po);

	/**
	 * 租车日价格
	 * 
	 * @param map
	 * @return
	 */
	public void updateDailyPrice(RentCarOrderPO po);

	/**
	 * 查询订单详情
	 * 
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> SearchOrderById(Map<String, Object> map);

	/**
	 * 查询订单服务
	 * 
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> SearchOrderServiceById(Map<String, Object> map);

	/**
	 * 查询门店详情
	 * 
	 * @return List<RentCarPO>
	 */
	public Map<String, String> findStorebyCode(String storeCode);

	/**
	 * 租车返畅达币维护
	 * 
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> searchServiceExt(Map<String, Object> map);

	/**
	 * 修改畅达币维护
	 * 
	 * @param map
	 * @return
	 */
	public void updateServiceExt(RentCarServiceExtPO po);

	/**
	 * 报表结算获取本地所有服务
	 * 
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> searchSZService();

	/**
	 * 报表结算获取活动信息
	 * 
	 * @param map
	 * @return
	 */
	public List<HashMap<String, Object>> searchActivty();

	/**
	 * 报表结算根据订单号查询订单
	 * 
	 * @return List<RentCarPO>
	 */
	public List<HashMap<String, Object>> findOrderbyNo(String orderNo);

	/**
	 * 创建报表结算变更
	 * 
	 * @param po
	 */
	public void create(RentCarChangePO po);

	/**
	 * 查询订单结算变动
	 * 
	 * @return List<RentCarChangePO>
	 */
	public List<HashMap<String, Object>> findOrderChange(RentCarChangePO po);

	/**
	 * 根据订单明细ID查询订单结算变动和结算操作人
	 * 
	 * @return List<RentCarChangePO>
	 */
	public List<HashMap<String, Object>> findChangeByOrderinfoId(RentCarChangePO po);

	/**
	 * 修改订单结算变动
	 * 
	 * @param po
	 * @return
	 */
	public void updateChange(RentCarChangePO po);

	/**
	 * 结算后修改订单信息
	 * 
	 * @param po
	 * @return
	 */
	public void updateCarOrder(RentCarChangePO po);

	/**
	 * 结算后修改畅达币信息
	 * 
	 * @param po
	 * @return
	 */
	public void updateCoin(PhoneCoinPO po);

	/**
	 * 删除已导的结算订单
	 * 
	 * @return List<RentCarPO>
	 */
	public void deleteByOrderId(Long orderInfoId);
	
	/**
	 * 查询用户ID
	 * 
	 * @param map
	 * @return
	 */
	public String selectOpeNameById(String name);
	/**
	 * 查询用户名
	 * 
	 * @param map
	 * @return
	 */
	public String selectOpeName(String id);
}