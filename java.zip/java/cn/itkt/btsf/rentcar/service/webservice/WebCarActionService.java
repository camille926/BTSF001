/**
 * WebCarActionService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.rentcar.service.webservice;

public interface WebCarActionService extends javax.xml.rpc.Service {
	public java.lang.String getWEBRENTCARSERVICEAddress();

	public cn.itkt.btsf.rentcar.service.webservice.WebCarAction getWEBRENTCARSERVICE() throws javax.xml.rpc.ServiceException;

	public cn.itkt.btsf.rentcar.service.webservice.WebCarAction getWEBRENTCARSERVICE(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
