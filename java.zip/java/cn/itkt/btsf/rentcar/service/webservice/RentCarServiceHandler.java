package cn.itkt.btsf.rentcar.service.webservice;

import java.net.URL;

import org.apache.axis.message.PrefixedQName;
import org.apache.axis.message.SOAPHeaderElement;

import cn.itkt.btsf.sys.common.constant.WebServiceConstant;
import cn.itkt.car.controller.web.impl.WebCarControllerImplServiceSoapBindingStub;

public class RentCarServiceHandler {
	private static WebCarControllerImplServiceSoapBindingStub sb;
	private static String terminal = "callcenter;callcenter:" + (cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
	static {
		try {
			URL url = new URL(WebServiceConstant.getRentCarPoint());
			org.apache.axis.client.Service service = new org.apache.axis.client.Service();
			SOAPHeaderElement head = new SOAPHeaderElement(new PrefixedQName(new javax.xml.namespace.QName("http://www.itkt.cn/", "authentication")));
			head.setActor(null);
			head.addChildElement("systemID").addTextNode(terminal);
			sb = new WebCarControllerImplServiceSoapBindingStub(url, service);
			sb.setHeader(head);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static WebCarControllerImplServiceSoapBindingStub instance() {
		return sb;
	}
}
