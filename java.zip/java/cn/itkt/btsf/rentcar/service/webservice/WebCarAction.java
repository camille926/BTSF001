/**
 * WebCarAction.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.rentcar.service.webservice;

public interface WebCarAction extends java.rmi.Remote {
	public java.lang.String[][] getDistrict(java.lang.String terminalId, java.lang.String cityCode, java.lang.String datatime) throws java.rmi.RemoteException;

	public java.lang.String[][] getSelfDriveCarTypes(java.lang.String terminalId, java.lang.String cityCode, java.lang.String storeCode, java.lang.String fromDate,
			java.lang.String toStoreCode, java.lang.String toDate, java.lang.String pageIndex, java.lang.String brandId, java.lang.String modeLeveId, java.lang.String privceId)
			throws java.rmi.RemoteException;

	public java.lang.String[][] getAdditionalServices(java.lang.String terminalId, java.lang.String fromCityCode, java.lang.String toCityCode, java.lang.String fromStoreCode,
			java.lang.String toStroeCode, java.lang.String fromDate, java.lang.String toDate, java.lang.String modeCode) throws java.rmi.RemoteException;

	public java.lang.String[][] getPreferenceActivity(java.lang.String terminalId, java.lang.String startTime, java.lang.String endTime, java.lang.String fromCityCode,
			java.lang.String modeCode) throws java.rmi.RemoteException;

	public java.lang.String[][] calcCarOrderPrice(java.lang.String terminalId, java.lang.String cityCode, java.lang.String toCityCode, java.lang.String fromDate,
			java.lang.String toDate, java.lang.String fromStoreCode, java.lang.String toStoreCode, java.lang.String activityCode, java.lang.String serviceId,
			java.lang.String vehicleLevel, java.lang.String modeCode, java.lang.String leveType) throws java.rmi.RemoteException;

	public java.lang.String[][] addSelfDriveOrder(java.lang.String terminalId, java.lang.String carType, java.lang.String fromDate, java.lang.String fromCity,
			java.lang.String fromStore, java.lang.String toDate, java.lang.String toCity, java.lang.String toStore, java.lang.String activityCode, java.lang.String serviceId,
			java.lang.String vehicleLevel, java.lang.String userId, java.lang.String userName, java.lang.String idCardNo, java.lang.String mobile, java.lang.String userType,
			java.lang.String channel, java.lang.String comments, java.lang.String deptType, java.lang.String cardType, java.lang.String addOrderUserId, java.lang.String leveType)
			throws java.rmi.RemoteException;

	public java.lang.String[][] orderListQuery(java.lang.String terminalId, java.lang.String fromDate, java.lang.String toDate, java.lang.String userId,
			java.lang.String orderState, java.lang.String nGoToPage, java.lang.String channeltype) throws java.rmi.RemoteException;

	public java.lang.String[][] cancelSelfDriveOrder(java.lang.String terminalId, java.lang.String orderNo) throws java.rmi.RemoteException;

	public java.lang.String[][] getCityInfo(java.lang.String terminalId, java.lang.String datatime) throws java.rmi.RemoteException;

	public java.lang.String[][] getStoreByDistrict(java.lang.String terminalId, java.lang.String datatime, java.lang.String areCode) throws java.rmi.RemoteException;

	public java.lang.String[][] getBrandList(java.lang.String terminalId) throws java.rmi.RemoteException;

	public java.lang.String[][] getModeLeveList(java.lang.String terminalId) throws java.rmi.RemoteException;

	public java.lang.String[][] getPriceIntervalList(java.lang.String terminalId) throws java.rmi.RemoteException;

	public java.lang.String[][] synOrderInfo(java.lang.String terminalId, java.lang.String orderNo, java.lang.String orderId) throws java.rmi.RemoteException;

	public java.lang.String[][] citySpaceFee(java.lang.String terminalId, java.lang.String fromCityCode, java.lang.String toCityCode) throws java.rmi.RemoteException;

	public java.lang.String[][] checkUserInfo(java.lang.String terminalId, java.lang.String userName, java.lang.String cardType, java.lang.String cardNo, java.lang.String phone,
			java.lang.String deptType) throws java.rmi.RemoteException;

	public java.lang.String[][] queryOrderList(java.lang.String terminalId, java.lang.String orderStatue, java.lang.String channel, java.lang.String userId,
			java.lang.String pageIdex) throws java.rmi.RemoteException;

	public java.lang.String[][] queryOrderInfo(java.lang.String terminalId, java.lang.String orderStatue, java.lang.String orderNo) throws java.rmi.RemoteException;

	public java.lang.String[][] queryStoreByCityCode(java.lang.String terminalId, java.lang.String cityCode) throws java.rmi.RemoteException;

	public java.lang.String[][] queryCoinByUserNo(java.lang.String userId) throws java.rmi.RemoteException;
}
