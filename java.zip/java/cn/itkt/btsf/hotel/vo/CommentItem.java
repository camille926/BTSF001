/**
 * CommentItem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class CommentItem  implements java.io.Serializable {
    private java.lang.String commentDateTime;

    private java.lang.String content;

    private java.lang.String hotelId;

    private java.lang.String recommendType;

    private java.lang.String userName;

    public CommentItem() {
    }

    public CommentItem(
           java.lang.String commentDateTime,
           java.lang.String content,
           java.lang.String hotelId,
           java.lang.String recommendType,
           java.lang.String userName) {
           this.commentDateTime = commentDateTime;
           this.content = content;
           this.hotelId = hotelId;
           this.recommendType = recommendType;
           this.userName = userName;
    }


    /**
     * Gets the commentDateTime value for this CommentItem.
     * 
     * @return commentDateTime
     */
    public java.lang.String getCommentDateTime() {
        return commentDateTime;
    }


    /**
     * Sets the commentDateTime value for this CommentItem.
     * 
     * @param commentDateTime
     */
    public void setCommentDateTime(java.lang.String commentDateTime) {
        this.commentDateTime = commentDateTime;
    }


    /**
     * Gets the content value for this CommentItem.
     * 
     * @return content
     */
    public java.lang.String getContent() {
        return content;
    }


    /**
     * Sets the content value for this CommentItem.
     * 
     * @param content
     */
    public void setContent(java.lang.String content) {
        this.content = content;
    }


    /**
     * Gets the hotelId value for this CommentItem.
     * 
     * @return hotelId
     */
    public java.lang.String getHotelId() {
        return hotelId;
    }


    /**
     * Sets the hotelId value for this CommentItem.
     * 
     * @param hotelId
     */
    public void setHotelId(java.lang.String hotelId) {
        this.hotelId = hotelId;
    }


    /**
     * Gets the recommendType value for this CommentItem.
     * 
     * @return recommendType
     */
    public java.lang.String getRecommendType() {
        return recommendType;
    }


    /**
     * Sets the recommendType value for this CommentItem.
     * 
     * @param recommendType
     */
    public void setRecommendType(java.lang.String recommendType) {
        this.recommendType = recommendType;
    }


    /**
     * Gets the userName value for this CommentItem.
     * 
     * @return userName
     */
    public java.lang.String getUserName() {
        return userName;
    }


    /**
     * Sets the userName value for this CommentItem.
     * 
     * @param userName
     */
    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CommentItem)) return false;
        CommentItem other = (CommentItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.commentDateTime==null && other.getCommentDateTime()==null) || 
             (this.commentDateTime!=null &&
              this.commentDateTime.equals(other.getCommentDateTime()))) &&
            ((this.content==null && other.getContent()==null) || 
             (this.content!=null &&
              this.content.equals(other.getContent()))) &&
            ((this.hotelId==null && other.getHotelId()==null) || 
             (this.hotelId!=null &&
              this.hotelId.equals(other.getHotelId()))) &&
            ((this.recommendType==null && other.getRecommendType()==null) || 
             (this.recommendType!=null &&
              this.recommendType.equals(other.getRecommendType()))) &&
            ((this.userName==null && other.getUserName()==null) || 
             (this.userName!=null &&
              this.userName.equals(other.getUserName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCommentDateTime() != null) {
            _hashCode += getCommentDateTime().hashCode();
        }
        if (getContent() != null) {
            _hashCode += getContent().hashCode();
        }
        if (getHotelId() != null) {
            _hashCode += getHotelId().hashCode();
        }
        if (getRecommendType() != null) {
            _hashCode += getRecommendType().hashCode();
        }
        if (getUserName() != null) {
            _hashCode += getUserName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CommentItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.CommentItem", "CommentItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commentDateTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commentDateTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("content");
        elemField.setXmlName(new javax.xml.namespace.QName("", "content"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recommendType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "recommendType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
