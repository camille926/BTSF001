package cn.itkt.btsf.hotel.vo;

import java.io.Serializable;

/**
 * 类: ContactVo <br>
 * 描述: 联系人Vo <br>
 * 作者: 王鹏 wangpeng@itkt.com <br>
 * 时间: 2013-2-25 下午2:04:26
 */
public class ContactVo implements Serializable {

	private static final long serialVersionUID = -6509747564411686049L;

	/** 名称 */
	private String name;
	/** 性别 */
	private String sex;
	/** 证件类型 */
	private String cardType;
	/** 证件号码 */
	private String cardNumber;
	/** 电话 */
	private String tell;
	/** 邮箱 */
	private String email;

	/**
	 * 返回: the name <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public String getName() {
		return name;
	}

	/**
	 * 参数: name to set the name <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 返回: the sex <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public String getSex() {
		return sex;
	}

	/**
	 * 参数: sex to set the sex <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public void setSex(String sex) {
		this.sex = sex;
	}

	/**
	 * 返回: the cardType <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * 参数: cardType to set the cardType <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	/**
	 * 返回: the cardNumber <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public String getCardNumber() {
		return cardNumber;
	}

	/**
	 * 参数: cardNumber to set the cardNumber <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * 返回: the tell <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public String getTell() {
		return tell;
	}

	/**
	 * 参数: tell to set the tell <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public void setTell(String tell) {
		this.tell = tell;
	}

	/**
	 * 返回: the email <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * 参数: email to set the email <br>
	 * 时间: 2013-2-25 下午2:04:23
	 */
	public void setEmail(String email) {
		this.email = email;
	}
}
