/**
 * HotelCityInfoVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelCityInfoVo  implements java.io.Serializable {
    private java.lang.String cityCode;

    private java.lang.String cityEnglishName;

    private java.lang.String cityName;

    private java.lang.String cityPinyin;

    private java.lang.String cityPyfw;

    private java.lang.String cityShowFlag;

    private java.lang.String cityflag;

    private java.lang.String id;

    public HotelCityInfoVo() {
    }

    public HotelCityInfoVo(
           java.lang.String cityCode,
           java.lang.String cityEnglishName,
           java.lang.String cityName,
           java.lang.String cityPinyin,
           java.lang.String cityPyfw,
           java.lang.String cityShowFlag,
           java.lang.String cityflag,
           java.lang.String id) {
           this.cityCode = cityCode;
           this.cityEnglishName = cityEnglishName;
           this.cityName = cityName;
           this.cityPinyin = cityPinyin;
           this.cityPyfw = cityPyfw;
           this.cityShowFlag = cityShowFlag;
           this.cityflag = cityflag;
           this.id = id;
    }


    /**
     * Gets the cityCode value for this HotelCityInfoVo.
     * 
     * @return cityCode
     */
    public java.lang.String getCityCode() {
        return cityCode;
    }


    /**
     * Sets the cityCode value for this HotelCityInfoVo.
     * 
     * @param cityCode
     */
    public void setCityCode(java.lang.String cityCode) {
        this.cityCode = cityCode;
    }


    /**
     * Gets the cityEnglishName value for this HotelCityInfoVo.
     * 
     * @return cityEnglishName
     */
    public java.lang.String getCityEnglishName() {
        return cityEnglishName;
    }


    /**
     * Sets the cityEnglishName value for this HotelCityInfoVo.
     * 
     * @param cityEnglishName
     */
    public void setCityEnglishName(java.lang.String cityEnglishName) {
        this.cityEnglishName = cityEnglishName;
    }


    /**
     * Gets the cityName value for this HotelCityInfoVo.
     * 
     * @return cityName
     */
    public java.lang.String getCityName() {
        return cityName;
    }


    /**
     * Sets the cityName value for this HotelCityInfoVo.
     * 
     * @param cityName
     */
    public void setCityName(java.lang.String cityName) {
        this.cityName = cityName;
    }


    /**
     * Gets the cityPinyin value for this HotelCityInfoVo.
     * 
     * @return cityPinyin
     */
    public java.lang.String getCityPinyin() {
        return cityPinyin;
    }


    /**
     * Sets the cityPinyin value for this HotelCityInfoVo.
     * 
     * @param cityPinyin
     */
    public void setCityPinyin(java.lang.String cityPinyin) {
        this.cityPinyin = cityPinyin;
    }


    /**
     * Gets the cityPyfw value for this HotelCityInfoVo.
     * 
     * @return cityPyfw
     */
    public java.lang.String getCityPyfw() {
        return cityPyfw;
    }


    /**
     * Sets the cityPyfw value for this HotelCityInfoVo.
     * 
     * @param cityPyfw
     */
    public void setCityPyfw(java.lang.String cityPyfw) {
        this.cityPyfw = cityPyfw;
    }


    /**
     * Gets the cityShowFlag value for this HotelCityInfoVo.
     * 
     * @return cityShowFlag
     */
    public java.lang.String getCityShowFlag() {
        return cityShowFlag;
    }


    /**
     * Sets the cityShowFlag value for this HotelCityInfoVo.
     * 
     * @param cityShowFlag
     */
    public void setCityShowFlag(java.lang.String cityShowFlag) {
        this.cityShowFlag = cityShowFlag;
    }


    /**
     * Gets the cityflag value for this HotelCityInfoVo.
     * 
     * @return cityflag
     */
    public java.lang.String getCityflag() {
        return cityflag;
    }


    /**
     * Sets the cityflag value for this HotelCityInfoVo.
     * 
     * @param cityflag
     */
    public void setCityflag(java.lang.String cityflag) {
        this.cityflag = cityflag;
    }


    /**
     * Gets the id value for this HotelCityInfoVo.
     * 
     * @return id
     */
    public java.lang.String getId() {
        return id;
    }


    /**
     * Sets the id value for this HotelCityInfoVo.
     * 
     * @param id
     */
    public void setId(java.lang.String id) {
        this.id = id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelCityInfoVo)) return false;
        HotelCityInfoVo other = (HotelCityInfoVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cityCode==null && other.getCityCode()==null) || 
             (this.cityCode!=null &&
              this.cityCode.equals(other.getCityCode()))) &&
            ((this.cityEnglishName==null && other.getCityEnglishName()==null) || 
             (this.cityEnglishName!=null &&
              this.cityEnglishName.equals(other.getCityEnglishName()))) &&
            ((this.cityName==null && other.getCityName()==null) || 
             (this.cityName!=null &&
              this.cityName.equals(other.getCityName()))) &&
            ((this.cityPinyin==null && other.getCityPinyin()==null) || 
             (this.cityPinyin!=null &&
              this.cityPinyin.equals(other.getCityPinyin()))) &&
            ((this.cityPyfw==null && other.getCityPyfw()==null) || 
             (this.cityPyfw!=null &&
              this.cityPyfw.equals(other.getCityPyfw()))) &&
            ((this.cityShowFlag==null && other.getCityShowFlag()==null) || 
             (this.cityShowFlag!=null &&
              this.cityShowFlag.equals(other.getCityShowFlag()))) &&
            ((this.cityflag==null && other.getCityflag()==null) || 
             (this.cityflag!=null &&
              this.cityflag.equals(other.getCityflag()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCityCode() != null) {
            _hashCode += getCityCode().hashCode();
        }
        if (getCityEnglishName() != null) {
            _hashCode += getCityEnglishName().hashCode();
        }
        if (getCityName() != null) {
            _hashCode += getCityName().hashCode();
        }
        if (getCityPinyin() != null) {
            _hashCode += getCityPinyin().hashCode();
        }
        if (getCityPyfw() != null) {
            _hashCode += getCityPyfw().hashCode();
        }
        if (getCityShowFlag() != null) {
            _hashCode += getCityShowFlag().hashCode();
        }
        if (getCityflag() != null) {
            _hashCode += getCityflag().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelCityInfoVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCityInfoVo", "HotelCityInfoVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityEnglishName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityEnglishName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityPinyin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityPinyin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityPyfw");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityPyfw"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityShowFlag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityShowFlag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityflag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityflag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
