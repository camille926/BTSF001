/**
 * HotelProvinceVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelProvinceVo  implements java.io.Serializable {
    private cn.itkt.btsf.hotel.vo.HotelCityInfoVo[] hotelCityInfoVo;

    private java.lang.String province;

    private java.lang.String provinceCode;

    public HotelProvinceVo() {
    }

    public HotelProvinceVo(
           cn.itkt.btsf.hotel.vo.HotelCityInfoVo[] hotelCityInfoVo,
           java.lang.String province,
           java.lang.String provinceCode) {
           this.hotelCityInfoVo = hotelCityInfoVo;
           this.province = province;
           this.provinceCode = provinceCode;
    }


    /**
     * Gets the hotelCityInfoVo value for this HotelProvinceVo.
     * 
     * @return hotelCityInfoVo
     */
    public cn.itkt.btsf.hotel.vo.HotelCityInfoVo[] getHotelCityInfoVo() {
        return hotelCityInfoVo;
    }


    /**
     * Sets the hotelCityInfoVo value for this HotelProvinceVo.
     * 
     * @param hotelCityInfoVo
     */
    public void setHotelCityInfoVo(cn.itkt.btsf.hotel.vo.HotelCityInfoVo[] hotelCityInfoVo) {
        this.hotelCityInfoVo = hotelCityInfoVo;
    }


    /**
     * Gets the province value for this HotelProvinceVo.
     * 
     * @return province
     */
    public java.lang.String getProvince() {
        return province;
    }


    /**
     * Sets the province value for this HotelProvinceVo.
     * 
     * @param province
     */
    public void setProvince(java.lang.String province) {
        this.province = province;
    }


    /**
     * Gets the provinceCode value for this HotelProvinceVo.
     * 
     * @return provinceCode
     */
    public java.lang.String getProvinceCode() {
        return provinceCode;
    }


    /**
     * Sets the provinceCode value for this HotelProvinceVo.
     * 
     * @param provinceCode
     */
    public void setProvinceCode(java.lang.String provinceCode) {
        this.provinceCode = provinceCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelProvinceVo)) return false;
        HotelProvinceVo other = (HotelProvinceVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.hotelCityInfoVo==null && other.getHotelCityInfoVo()==null) || 
             (this.hotelCityInfoVo!=null &&
              java.util.Arrays.equals(this.hotelCityInfoVo, other.getHotelCityInfoVo()))) &&
            ((this.province==null && other.getProvince()==null) || 
             (this.province!=null &&
              this.province.equals(other.getProvince()))) &&
            ((this.provinceCode==null && other.getProvinceCode()==null) || 
             (this.provinceCode!=null &&
              this.provinceCode.equals(other.getProvinceCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHotelCityInfoVo() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHotelCityInfoVo());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHotelCityInfoVo(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProvince() != null) {
            _hashCode += getProvince().hashCode();
        }
        if (getProvinceCode() != null) {
            _hashCode += getProvinceCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelProvinceVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelProvinceVo", "HotelProvinceVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelCityInfoVo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelCityInfoVo"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCityInfoVo", "HotelCityInfoVo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("province");
        elemField.setXmlName(new javax.xml.namespace.QName("", "province"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("provinceCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "provinceCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
