/**
 * PopularCityRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class PopularCityRequest  implements java.io.Serializable {
    private java.util.Calendar checkInDate;

    private java.util.Calendar checkOutDate;

    private java.lang.String[] cityIds;

    private java.lang.String terminalId;

    public PopularCityRequest() {
    }

    public PopularCityRequest(
           java.util.Calendar checkInDate,
           java.util.Calendar checkOutDate,
           java.lang.String[] cityIds,
           java.lang.String terminalId) {
           this.checkInDate = checkInDate;
           this.checkOutDate = checkOutDate;
           this.cityIds = cityIds;
           this.terminalId = terminalId;
    }


    /**
     * Gets the checkInDate value for this PopularCityRequest.
     * 
     * @return checkInDate
     */
    public java.util.Calendar getCheckInDate() {
        return checkInDate;
    }


    /**
     * Sets the checkInDate value for this PopularCityRequest.
     * 
     * @param checkInDate
     */
    public void setCheckInDate(java.util.Calendar checkInDate) {
        this.checkInDate = checkInDate;
    }


    /**
     * Gets the checkOutDate value for this PopularCityRequest.
     * 
     * @return checkOutDate
     */
    public java.util.Calendar getCheckOutDate() {
        return checkOutDate;
    }


    /**
     * Sets the checkOutDate value for this PopularCityRequest.
     * 
     * @param checkOutDate
     */
    public void setCheckOutDate(java.util.Calendar checkOutDate) {
        this.checkOutDate = checkOutDate;
    }


    /**
     * Gets the cityIds value for this PopularCityRequest.
     * 
     * @return cityIds
     */
    public java.lang.String[] getCityIds() {
        return cityIds;
    }


    /**
     * Sets the cityIds value for this PopularCityRequest.
     * 
     * @param cityIds
     */
    public void setCityIds(java.lang.String[] cityIds) {
        this.cityIds = cityIds;
    }


    /**
     * Gets the terminalId value for this PopularCityRequest.
     * 
     * @return terminalId
     */
    public java.lang.String getTerminalId() {
        return terminalId;
    }


    /**
     * Sets the terminalId value for this PopularCityRequest.
     * 
     * @param terminalId
     */
    public void setTerminalId(java.lang.String terminalId) {
        this.terminalId = terminalId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PopularCityRequest)) return false;
        PopularCityRequest other = (PopularCityRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.checkInDate==null && other.getCheckInDate()==null) || 
             (this.checkInDate!=null &&
              this.checkInDate.equals(other.getCheckInDate()))) &&
            ((this.checkOutDate==null && other.getCheckOutDate()==null) || 
             (this.checkOutDate!=null &&
              this.checkOutDate.equals(other.getCheckOutDate()))) &&
            ((this.cityIds==null && other.getCityIds()==null) || 
             (this.cityIds!=null &&
              java.util.Arrays.equals(this.cityIds, other.getCityIds()))) &&
            ((this.terminalId==null && other.getTerminalId()==null) || 
             (this.terminalId!=null &&
              this.terminalId.equals(other.getTerminalId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCheckInDate() != null) {
            _hashCode += getCheckInDate().hashCode();
        }
        if (getCheckOutDate() != null) {
            _hashCode += getCheckOutDate().hashCode();
        }
        if (getCityIds() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCityIds());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCityIds(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTerminalId() != null) {
            _hashCode += getTerminalId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PopularCityRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.PopularCityRequest", "PopularCityRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkInDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkInDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkOutDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkOutDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityIds");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityIds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminalId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "terminalId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
