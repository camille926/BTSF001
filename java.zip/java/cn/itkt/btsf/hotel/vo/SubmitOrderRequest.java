package cn.itkt.btsf.hotel.vo;

import java.io.Serializable;
import java.util.List;

/**
 * 类: SubmitOrderRequest <br>
 * 描述: 提交订单请求对象 <br>
 * 作者: 王鹏 wangpeng@itkt.com <br>
 * 时间: 2013-2-26 下午2:57:00
 */
public class SubmitOrderRequest implements Serializable {

	private static final long serialVersionUID = -9192103959710373474L;

	/** 终端ID */
	private String terminalId;
	/** 酒店ID */
	private String hotelId;
	/** 房间ID */
	private String roomId;
	/** 入住时间 */
	private String checkInDate;
	/** 离店时间 */
	private String checkOutDate;
	/** 最早到达时间 */
	private String arrivalEarlyTime;
	/** 最晚到达时间 */
	private String arrivalLateTime;
	/** 联系人信息列表 */
	private List<ContactVo> contactVos;
	/** 信用卡信息对象 */
	private cn.itkt.btsf.hotel.po.CreditCardVo creditCardVo;
	/** 客人名称列表 */
	private List<String> guestNames;
	/** 价格信息对象 */
	private RatePlanVo ratePlanVo;
	/** 会员类型 **/
	private String userType;
	/** 会员ID **/
	private String userId;
	/** 反馈酒店 */
	private String noteToHotel;
	/** 反馈艺龙 */
	private String noteToElong;
	/** 标识 */
	private String flag;
	/** 操作人 */
	private String operator;
	/** 备注 */
	private String remark;

	/**
	 * 返回: the terminalId <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getTerminalId() {
		return terminalId;
	}

	/**
	 * 参数: terminalId to set the terminalId <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	/**
	 * 返回: the hotelId <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getHotelId() {
		return hotelId;
	}

	/**
	 * 参数: hotelId to set the hotelId <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	/**
	 * 返回: the roomId <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getRoomId() {
		return roomId;
	}

	/**
	 * 参数: roomId to set the roomId <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}

	/**
	 * 返回: the checkInDate <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getCheckInDate() {
		return checkInDate;
	}

	/**
	 * 参数: checkInDate to set the checkInDate <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}

	/**
	 * 返回: the checkOutDate <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getCheckOutDate() {
		return checkOutDate;
	}

	/**
	 * 参数: checkOutDate to set the checkOutDate <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	/**
	 * 返回: the arrivalEarlyTime <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getArrivalEarlyTime() {
		return arrivalEarlyTime;
	}

	/**
	 * 参数: arrivalEarlyTime to set the arrivalEarlyTime <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setArrivalEarlyTime(String arrivalEarlyTime) {
		this.arrivalEarlyTime = arrivalEarlyTime;
	}

	/**
	 * 返回: the arrivalLateTime <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getArrivalLateTime() {
		return arrivalLateTime;
	}

	/**
	 * 参数: arrivalLateTime to set the arrivalLateTime <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setArrivalLateTime(String arrivalLateTime) {
		this.arrivalLateTime = arrivalLateTime;
	}

	/**
	 * 返回: the contactVos <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public List<ContactVo> getContactVos() {
		return contactVos;
	}

	/**
	 * 参数: contactVos to set the contactVos <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setContactVos(List<ContactVo> contactVos) {
		this.contactVos = contactVos;
	}

	/**
	 * 返回: the creditCardVo <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public cn.itkt.btsf.hotel.po.CreditCardVo getCreditCardVo() {
		return creditCardVo;
	}

	/**
	 * 参数: creditCardVo to set the creditCardVo <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setCreditCardVo(cn.itkt.btsf.hotel.po.CreditCardVo creditCardVo) {
		this.creditCardVo = creditCardVo;
	}

	/**
	 * 返回: the guestNames <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public List<String> getGuestNames() {
		return guestNames;
	}

	/**
	 * 参数: guestNames to set the guestNames <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setGuestNames(List<String> guestNames) {
		this.guestNames = guestNames;
	}

	/**
	 * 返回: the ratePlanVo <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public RatePlanVo getRatePlanVo() {
		return ratePlanVo;
	}

	/**
	 * 参数: ratePlanVo to set the ratePlanVo <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setRatePlanVo(RatePlanVo ratePlanVo) {
		this.ratePlanVo = ratePlanVo;
	}

	/**
	 * 返回: the userType <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getUserType() {
		return userType;
	}

	/**
	 * 参数: userType to set the userType <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setUserType(String userType) {
		this.userType = userType;
	}

	/**
	 * 返回: the userId <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * 参数: userId to set the userId <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * 返回: the noteToHotel <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getNoteToHotel() {
		return noteToHotel;
	}

	/**
	 * 参数: noteToHotel to set the noteToHotel <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setNoteToHotel(String noteToHotel) {
		this.noteToHotel = noteToHotel;
	}

	/**
	 * 返回: the noteToElong <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getNoteToElong() {
		return noteToElong;
	}

	/**
	 * 参数: noteToElong to set the noteToElong <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setNoteToElong(String noteToElong) {
		this.noteToElong = noteToElong;
	}

	/**
	 * 返回: the flag <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getFlag() {
		return flag;
	}

	/**
	 * 参数: flag to set the flag <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setFlag(String flag) {
		this.flag = flag;
	}

	/**
	 * 返回: the operator <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getOperator() {
		return operator;
	}

	/**
	 * 参数: operator to set the operator <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}

	/**
	 * 返回: the remark <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public String getRemark() {
		return remark;
	}

	/**
	 * 参数: remark to set the remark <br>
	 * 时间: 2013-2-25 下午3:13:12
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
}
