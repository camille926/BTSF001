/**
 * RelateOrderVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class RelateOrderVo  implements java.io.Serializable {
    private java.lang.String newOrderId;

    private java.lang.String oldOrderId;

    public RelateOrderVo() {
    }

    public RelateOrderVo(
           java.lang.String newOrderId,
           java.lang.String oldOrderId) {
           this.newOrderId = newOrderId;
           this.oldOrderId = oldOrderId;
    }


    /**
     * Gets the newOrderId value for this RelateOrderVo.
     * 
     * @return newOrderId
     */
    public java.lang.String getNewOrderId() {
        return newOrderId;
    }


    /**
     * Sets the newOrderId value for this RelateOrderVo.
     * 
     * @param newOrderId
     */
    public void setNewOrderId(java.lang.String newOrderId) {
        this.newOrderId = newOrderId;
    }


    /**
     * Gets the oldOrderId value for this RelateOrderVo.
     * 
     * @return oldOrderId
     */
    public java.lang.String getOldOrderId() {
        return oldOrderId;
    }


    /**
     * Sets the oldOrderId value for this RelateOrderVo.
     * 
     * @param oldOrderId
     */
    public void setOldOrderId(java.lang.String oldOrderId) {
        this.oldOrderId = oldOrderId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RelateOrderVo)) return false;
        RelateOrderVo other = (RelateOrderVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.newOrderId==null && other.getNewOrderId()==null) || 
             (this.newOrderId!=null &&
              this.newOrderId.equals(other.getNewOrderId()))) &&
            ((this.oldOrderId==null && other.getOldOrderId()==null) || 
             (this.oldOrderId!=null &&
              this.oldOrderId.equals(other.getOldOrderId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNewOrderId() != null) {
            _hashCode += getNewOrderId().hashCode();
        }
        if (getOldOrderId() != null) {
            _hashCode += getOldOrderId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RelateOrderVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RelateOrderVo", "RelateOrderVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("newOrderId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "newOrderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oldOrderId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "oldOrderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
