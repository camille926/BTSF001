/**
 * ELONGWEBHOTELSERVICESoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class ELONGWEBHOTELSERVICESoapBindingStub extends org.apache.axis.client.Stub implements cn.itkt.btsf.hotel.vo.ElongWebHotelService {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[25];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findBtsfHotelBasicBrand");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminalId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandsVo", "HotelBrandsVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelBrandsVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findBtsfHotelBasicBrandReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findCityInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminalId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelRegionVo", "HotelRegionVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelRegionVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findCityInfoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findHotelDistrict");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminalId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "citycode"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelDistrictsVo", "HotelDistrictsVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelDistrictsVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findHotelDistrictReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findHotelLandMark");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminalId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "citycode"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelLandMarksVo", "HotelLandMarksVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelLandMarksVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findHotelLandMarkReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getHotelBrandsVoByCity");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminalId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "citycode"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandsVo", "HotelBrandsVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelBrandsVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getHotelBrandsVoByCityReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findHotelCommsVo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminalId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "citycode"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCommsVo", "HotelCommsVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelCommsVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findHotelCommsVoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findHotelQueryResultVO");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "hotelListQueryRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelListQueryRequest", "HotelListQueryRequest"), cn.itkt.btsf.hotel.vo.HotelListQueryRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelQueryResultVO", "HotelQueryResultVO"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelQueryResultVO.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findHotelQueryResultVOReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findOneHotelQueryResultVO");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "hotelListQueryRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelOneQueryRequest", "HotelOneQueryRequest"), cn.itkt.btsf.hotel.vo.HotelOneQueryRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelQueryResultVO", "HotelQueryResultVO"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelQueryResultVO.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findOneHotelQueryResultVOReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getHotelProductVouchVo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "orderVouchRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelProductVouchRequest", "HotelProductVouchRequest"), cn.itkt.btsf.hotel.vo.HotelProductVouchRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelProductVouchVo", "HotelProductVouchVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelProductVouchVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getHotelProductVouchVoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getHotelOrderVo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "orderRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelOrderRequest", "HotelOrderRequest"), cn.itkt.btsf.hotel.vo.HotelOrderRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderVo", "HotelOrderVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelOrderVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getHotelOrderVoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findPopularCity");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "cityRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.PopularCityRequest", "PopularCityRequest"), cn.itkt.btsf.hotel.vo.PopularCityRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.PopularCitysVo", "PopularCitysVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.PopularCitysVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findPopularCityReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRoomReserveInfoVo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "reserveRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.RoomReserveRequest", "RoomReserveRequest"), cn.itkt.btsf.hotel.vo.RoomReserveRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RoomReserveInfoVo", "RoomReserveInfoVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.RoomReserveInfoVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getRoomReserveInfoVoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("gethotelOrderDetailList");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "orderRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.QueryOrderListRequest", "QueryOrderListRequest"), cn.itkt.btsf.hotel.vo.QueryOrderListRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderDetailsVo", "HotelOrderDetailsVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelOrderDetailsVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "gethotelOrderDetailListReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getHotelEconomicsVO");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "economicsRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.EconomicsRequest", "EconomicsRequest"), cn.itkt.btsf.hotel.vo.EconomicsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelEconomicsVO", "HotelEconomicsVO"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelEconomicsVO.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getHotelEconomicsVOReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getSimpleBrandBycityId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "economicsRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.EconomicsRequest", "EconomicsRequest"), cn.itkt.btsf.hotel.vo.EconomicsRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelEconomicsVO", "HotelEconomicsVO"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelEconomicsVO.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getSimpleBrandBycityIdReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getRelateOrders");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "relateOrderRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.RelateOrderRequest", "RelateOrderRequest"), cn.itkt.btsf.hotel.vo.RelateOrderRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RelateOrdersVo", "RelateOrdersVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.RelateOrdersVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getRelateOrdersReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getCreditCardList");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "userId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "addSource"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.CreditCardsVo", "CreditCardsVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.CreditCardsVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getCreditCardListReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("addCreditCard");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "cardRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.CreditCardRequest", "CreditCardRequest"), cn.itkt.btsf.hotel.vo.CreditCardRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "BaseVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.BaseVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "addCreditCardReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("deleteCreditCard");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "cardIds"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "BaseVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.BaseVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "deleteCreditCardReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("modifyCreditCard");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "cardRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.CreditCardRequest", "CreditCardRequest"), cn.itkt.btsf.hotel.vo.CreditCardRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "BaseVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.BaseVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "modifyCreditCardReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getInterestHotelVo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "hotelRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.InterestHotelRequest", "InterestHotelRequest"), cn.itkt.btsf.hotel.vo.InterestHotelRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.InterestHotelVo", "InterestHotelVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.InterestHotelVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getInterestHotelVoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("cancelHotelOrderById");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminald"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "orderId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "cancelReason"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "BaseVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.BaseVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "cancelHotelOrderByIdReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("findHotelBrandsVo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "brandRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelBrandRequest", "HotelBrandRequest"), cn.itkt.btsf.hotel.vo.HotelBrandRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailInfoVo", "HotelBrandDetailInfoVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelBrandDetailInfoVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "findHotelBrandsVoReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[22] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("getHotelComment");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminalId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "hotleID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCommentVo", "HotelCommentVo"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelCommentVo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "getHotelCommentReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[23] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("importOrderOrSynChroNized");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "terminald"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "orders"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "importOrSynchronized"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderStateResult", "HotelOrderStateResult"));
        oper.setReturnClass(cn.itkt.btsf.hotel.vo.HotelOrderStateResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "importOrderOrSynChroNizedReturn"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[24] = oper;

    }

    public ELONGWEBHOTELSERVICESoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public ELONGWEBHOTELSERVICESoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public ELONGWEBHOTELSERVICESoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_soapenc_string");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns11_HotelCommVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelCommVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCommVo", "HotelCommVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns14_HotelForMoreHotelVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelForMoreHotelVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelForMoreHotelVo", "HotelForMoreHotelVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns15_RoomForHotel");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RoomForHotel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RoomForHotel", "RoomForHotel");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns16_RatePlanForHotel");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RatePlanForHotel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RatePlanForHotel", "RatePlanForHotel");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns17_DayRateForHotel");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.DayRateForHotel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.DayRateForHotel", "DayRateForHotel");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns18_VouchInfo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.VouchInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.VouchInfo", "VouchInfo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns20_ImageForHotel");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.ImageForHotel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.ImageForHotel", "ImageForHotel");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns25_ContacterForSubmitHotelOrder");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.ContacterForSubmitHotelOrder[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://po.elong.air.litsoft.com", "ContacterForSubmitHotelOrder");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns2_HotelBrandVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandVo", "HotelBrandVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns30_PopularCityVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.PopularCityVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.PopularCityVo", "PopularCityVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns35_HotelOrderDetailVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelOrderDetailVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderDetailVo", "HotelOrderDetailVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns38_HoteloneEconomicVO");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HoteloneEconomicVO[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HoteloneEconomicVO", "HoteloneEconomicVO");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns41_RelateOrderVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RelateOrderVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RelateOrderVo", "RelateOrderVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns43_CreditCardVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.CreditCardVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.CreditCardVo", "CreditCardVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns46_HotelBrandDetailsVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandDetailsVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailsVo", "HotelBrandDetailsVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns47_HotelBrandDetailVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandDetailVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailVo", "HotelBrandDetailVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns4_HotelProvinceVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelProvinceVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelProvinceVo", "HotelProvinceVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns51_CommentItem");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.CommentItem[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.CommentItem", "CommentItem");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns5_HotelCityInfoVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelCityInfoVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCityInfoVo", "HotelCityInfoVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns7_HotelDistrictVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelDistrictVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelDistrictVo", "HotelDistrictVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "ArrayOf_tns9_HotelLandMarkVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelLandMarkVo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelLandMarkVo", "HotelLandMarkVo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "BaseVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.BaseVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.CommentItem", "CommentItem");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.CommentItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.CreditCardsVo", "CreditCardsVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.CreditCardsVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.CreditCardVo", "CreditCardVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.CreditCardVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.DayRateForHotel", "DayRateForHotel");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.DayRateForHotel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailInfoVo", "HotelBrandDetailInfoVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandDetailInfoVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailsVo", "HotelBrandDetailsVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandDetailsVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailVo", "HotelBrandDetailVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandDetailVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandsVo", "HotelBrandsVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandsVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandVo", "HotelBrandVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCityInfoVo", "HotelCityInfoVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelCityInfoVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCommentVo", "HotelCommentVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelCommentVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCommsVo", "HotelCommsVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelCommsVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCommVo", "HotelCommVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelCommVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelDistrictsVo", "HotelDistrictsVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelDistrictsVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelDistrictVo", "HotelDistrictVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelDistrictVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelEconomicsVO", "HotelEconomicsVO");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelEconomicsVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelForMoreHotelVo", "HotelForMoreHotelVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelForMoreHotelVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelForOneHotelVo", "HotelForOneHotelVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelForOneHotelVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelLandMarksVo", "HotelLandMarksVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelLandMarksVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelLandMarkVo", "HotelLandMarkVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelLandMarkVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HoteloneEconomicVO", "HoteloneEconomicVO");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HoteloneEconomicVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderDetailsVo", "HotelOrderDetailsVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelOrderDetailsVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderDetailVo", "HotelOrderDetailVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelOrderDetailVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderStateResult", "HotelOrderStateResult");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelOrderStateResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderVo", "HotelOrderVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelOrderVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelProductVouchVo", "HotelProductVouchVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelProductVouchVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelProvinceVo", "HotelProvinceVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelProvinceVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelQueryResultVO", "HotelQueryResultVO");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelQueryResultVO.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelRegionVo", "HotelRegionVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelRegionVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.ImageForHotel", "ImageForHotel");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.ImageForHotel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.InterestHotelVo", "InterestHotelVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.InterestHotelVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.PopularCitysVo", "PopularCitysVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.PopularCitysVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.PopularCityVo", "PopularCityVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.PopularCityVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RatePlanForHotel", "RatePlanForHotel");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RatePlanForHotel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RelateOrdersVo", "RelateOrdersVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RelateOrdersVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RelateOrderVo", "RelateOrderVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RelateOrderVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.CreditCardRequest", "CreditCardRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.CreditCardRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.EconomicsRequest", "EconomicsRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.EconomicsRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelBrandRequest", "HotelBrandRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelBrandRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelListQueryRequest", "HotelListQueryRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelListQueryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelOneQueryRequest", "HotelOneQueryRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelOneQueryRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelOrderRequest", "HotelOrderRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelProductVouchRequest", "HotelProductVouchRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.HotelProductVouchRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.InterestHotelRequest", "InterestHotelRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.InterestHotelRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.PopularCityRequest", "PopularCityRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.PopularCityRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.QueryOrderListRequest", "QueryOrderListRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.QueryOrderListRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.RelateOrderRequest", "RelateOrderRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RelateOrderRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.RoomReserveRequest", "RoomReserveRequest");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RoomReserveRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RoomForHotel", "RoomForHotel");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RoomForHotel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RoomReserveInfoVo", "RoomReserveInfoVo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.RoomReserveInfoVo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.VouchInfo", "VouchInfo");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.VouchInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://elong.com/NorthBoundAPI/", "FaxForSubmitHotelOrder");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.FaxForSubmitHotelOrder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://elong.com/NorthBoundAPI/", "PhoneForSubmitHotelOrder");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.PhoneForSubmitHotelOrder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://po.elong.air.litsoft.com", "ContacterForSubmitHotelOrder");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.ContacterForSubmitHotelOrder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://po.elong.air.litsoft.com", "CreditCardForSubmitHotelOrder");
            cachedSerQNames.add(qName);
            cls = cn.itkt.btsf.hotel.vo.CreditCardForSubmitHotelOrder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
                    _call.setEncodingStyle(org.apache.axis.Constants.URI_SOAP11_ENC);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public cn.itkt.btsf.hotel.vo.HotelBrandsVo findBtsfHotelBasicBrand(java.lang.String terminalId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findBtsfHotelBasicBrand"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminalId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelBrandsVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelBrandsVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelBrandsVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelRegionVo findCityInfo(java.lang.String terminalId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findCityInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminalId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelRegionVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelRegionVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelRegionVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelDistrictsVo findHotelDistrict(java.lang.String terminalId, java.lang.String citycode) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findHotelDistrict"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminalId, citycode});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelDistrictsVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelDistrictsVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelDistrictsVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelLandMarksVo findHotelLandMark(java.lang.String terminalId, java.lang.String citycode) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findHotelLandMark"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminalId, citycode});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelLandMarksVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelLandMarksVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelLandMarksVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelBrandsVo getHotelBrandsVoByCity(java.lang.String terminalId, java.lang.String citycode) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getHotelBrandsVoByCity"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminalId, citycode});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelBrandsVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelBrandsVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelBrandsVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelCommsVo findHotelCommsVo(java.lang.String terminalId, java.lang.String citycode) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findHotelCommsVo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminalId, citycode});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelCommsVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelCommsVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelCommsVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelQueryResultVO findHotelQueryResultVO(cn.itkt.btsf.hotel.vo.HotelListQueryRequest hotelListQueryRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findHotelQueryResultVO"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {hotelListQueryRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelQueryResultVO) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelQueryResultVO) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelQueryResultVO.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelQueryResultVO findOneHotelQueryResultVO(cn.itkt.btsf.hotel.vo.HotelOneQueryRequest hotelListQueryRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findOneHotelQueryResultVO"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {hotelListQueryRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelQueryResultVO) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelQueryResultVO) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelQueryResultVO.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelProductVouchVo getHotelProductVouchVo(cn.itkt.btsf.hotel.vo.HotelProductVouchRequest orderVouchRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getHotelProductVouchVo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {orderVouchRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelProductVouchVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelProductVouchVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelProductVouchVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelOrderVo getHotelOrderVo(cn.itkt.btsf.hotel.vo.HotelOrderRequest orderRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getHotelOrderVo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {orderRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelOrderVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelOrderVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelOrderVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.PopularCitysVo findPopularCity(cn.itkt.btsf.hotel.vo.PopularCityRequest cityRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findPopularCity"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cityRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.PopularCitysVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.PopularCitysVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.PopularCitysVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.RoomReserveInfoVo getRoomReserveInfoVo(cn.itkt.btsf.hotel.vo.RoomReserveRequest reserveRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getRoomReserveInfoVo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {reserveRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.RoomReserveInfoVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.RoomReserveInfoVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.RoomReserveInfoVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelOrderDetailsVo gethotelOrderDetailList(cn.itkt.btsf.hotel.vo.QueryOrderListRequest orderRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "gethotelOrderDetailList"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {orderRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelOrderDetailsVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelOrderDetailsVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelOrderDetailsVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelEconomicsVO getHotelEconomicsVO(cn.itkt.btsf.hotel.vo.EconomicsRequest economicsRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getHotelEconomicsVO"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {economicsRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelEconomicsVO) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelEconomicsVO) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelEconomicsVO.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelEconomicsVO getSimpleBrandBycityId(cn.itkt.btsf.hotel.vo.EconomicsRequest economicsRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getSimpleBrandBycityId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {economicsRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelEconomicsVO) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelEconomicsVO) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelEconomicsVO.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.RelateOrdersVo getRelateOrders(cn.itkt.btsf.hotel.vo.RelateOrderRequest relateOrderRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getRelateOrders"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {relateOrderRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.RelateOrdersVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.RelateOrdersVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.RelateOrdersVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.CreditCardsVo getCreditCardList(java.lang.String userId, java.lang.String addSource) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getCreditCardList"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userId, addSource});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.CreditCardsVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.CreditCardsVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.CreditCardsVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.BaseVo addCreditCard(cn.itkt.btsf.hotel.vo.CreditCardRequest cardRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "addCreditCard"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cardRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.BaseVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.BaseVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.BaseVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.BaseVo deleteCreditCard(java.lang.String cardIds) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "deleteCreditCard"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cardIds});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.BaseVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.BaseVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.BaseVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.BaseVo modifyCreditCard(cn.itkt.btsf.hotel.vo.CreditCardRequest cardRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "modifyCreditCard"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {cardRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.BaseVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.BaseVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.BaseVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.InterestHotelVo getInterestHotelVo(cn.itkt.btsf.hotel.vo.InterestHotelRequest hotelRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getInterestHotelVo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {hotelRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.InterestHotelVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.InterestHotelVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.InterestHotelVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.BaseVo cancelHotelOrderById(java.lang.String terminald, java.lang.String orderId, java.lang.String cancelReason) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "cancelHotelOrderById"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminald, orderId, cancelReason});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.BaseVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.BaseVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.BaseVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelBrandDetailInfoVo findHotelBrandsVo(cn.itkt.btsf.hotel.vo.HotelBrandRequest brandRequest) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "findHotelBrandsVo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {brandRequest});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelBrandDetailInfoVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelBrandDetailInfoVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelBrandDetailInfoVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelCommentVo getHotelComment(java.lang.String terminalId, java.lang.String hotleID) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[23]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "getHotelComment"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminalId, hotleID});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelCommentVo) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelCommentVo) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelCommentVo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public cn.itkt.btsf.hotel.vo.HotelOrderStateResult importOrderOrSynChroNized(java.lang.String terminald, java.lang.String orders, boolean importOrSynchronized) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[24]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.BaseVo", "importOrderOrSynChroNized"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {terminald, orders, new java.lang.Boolean(importOrSynchronized)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (cn.itkt.btsf.hotel.vo.HotelOrderStateResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (cn.itkt.btsf.hotel.vo.HotelOrderStateResult) org.apache.axis.utils.JavaUtils.convert(_resp, cn.itkt.btsf.hotel.vo.HotelOrderStateResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
