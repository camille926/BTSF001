/**
 * VouchInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class VouchInfo  implements java.io.Serializable {
    private java.lang.String description;

    private int isRoomAmountVouch;

    private int isTimeVouch;

    private int isVouch;

    private java.lang.String notVouchDescription;

    private java.lang.String notVouchTime;

    private int roomAmount;

    private java.lang.String vouchDescription;

    private int vouchMoneyType;

    private java.lang.String vouchTime;

    public VouchInfo() {
    }

    public VouchInfo(
           java.lang.String description,
           int isRoomAmountVouch,
           int isTimeVouch,
           int isVouch,
           java.lang.String notVouchDescription,
           java.lang.String notVouchTime,
           int roomAmount,
           java.lang.String vouchDescription,
           int vouchMoneyType,
           java.lang.String vouchTime) {
           this.description = description;
           this.isRoomAmountVouch = isRoomAmountVouch;
           this.isTimeVouch = isTimeVouch;
           this.isVouch = isVouch;
           this.notVouchDescription = notVouchDescription;
           this.notVouchTime = notVouchTime;
           this.roomAmount = roomAmount;
           this.vouchDescription = vouchDescription;
           this.vouchMoneyType = vouchMoneyType;
           this.vouchTime = vouchTime;
    }


    /**
     * Gets the description value for this VouchInfo.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this VouchInfo.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the isRoomAmountVouch value for this VouchInfo.
     * 
     * @return isRoomAmountVouch
     */
    public int getIsRoomAmountVouch() {
        return isRoomAmountVouch;
    }


    /**
     * Sets the isRoomAmountVouch value for this VouchInfo.
     * 
     * @param isRoomAmountVouch
     */
    public void setIsRoomAmountVouch(int isRoomAmountVouch) {
        this.isRoomAmountVouch = isRoomAmountVouch;
    }


    /**
     * Gets the isTimeVouch value for this VouchInfo.
     * 
     * @return isTimeVouch
     */
    public int getIsTimeVouch() {
        return isTimeVouch;
    }


    /**
     * Sets the isTimeVouch value for this VouchInfo.
     * 
     * @param isTimeVouch
     */
    public void setIsTimeVouch(int isTimeVouch) {
        this.isTimeVouch = isTimeVouch;
    }


    /**
     * Gets the isVouch value for this VouchInfo.
     * 
     * @return isVouch
     */
    public int getIsVouch() {
        return isVouch;
    }


    /**
     * Sets the isVouch value for this VouchInfo.
     * 
     * @param isVouch
     */
    public void setIsVouch(int isVouch) {
        this.isVouch = isVouch;
    }


    /**
     * Gets the notVouchDescription value for this VouchInfo.
     * 
     * @return notVouchDescription
     */
    public java.lang.String getNotVouchDescription() {
        return notVouchDescription;
    }


    /**
     * Sets the notVouchDescription value for this VouchInfo.
     * 
     * @param notVouchDescription
     */
    public void setNotVouchDescription(java.lang.String notVouchDescription) {
        this.notVouchDescription = notVouchDescription;
    }


    /**
     * Gets the notVouchTime value for this VouchInfo.
     * 
     * @return notVouchTime
     */
    public java.lang.String getNotVouchTime() {
        return notVouchTime;
    }


    /**
     * Sets the notVouchTime value for this VouchInfo.
     * 
     * @param notVouchTime
     */
    public void setNotVouchTime(java.lang.String notVouchTime) {
        this.notVouchTime = notVouchTime;
    }


    /**
     * Gets the roomAmount value for this VouchInfo.
     * 
     * @return roomAmount
     */
    public int getRoomAmount() {
        return roomAmount;
    }


    /**
     * Sets the roomAmount value for this VouchInfo.
     * 
     * @param roomAmount
     */
    public void setRoomAmount(int roomAmount) {
        this.roomAmount = roomAmount;
    }


    /**
     * Gets the vouchDescription value for this VouchInfo.
     * 
     * @return vouchDescription
     */
    public java.lang.String getVouchDescription() {
        return vouchDescription;
    }


    /**
     * Sets the vouchDescription value for this VouchInfo.
     * 
     * @param vouchDescription
     */
    public void setVouchDescription(java.lang.String vouchDescription) {
        this.vouchDescription = vouchDescription;
    }


    /**
     * Gets the vouchMoneyType value for this VouchInfo.
     * 
     * @return vouchMoneyType
     */
    public int getVouchMoneyType() {
        return vouchMoneyType;
    }


    /**
     * Sets the vouchMoneyType value for this VouchInfo.
     * 
     * @param vouchMoneyType
     */
    public void setVouchMoneyType(int vouchMoneyType) {
        this.vouchMoneyType = vouchMoneyType;
    }


    /**
     * Gets the vouchTime value for this VouchInfo.
     * 
     * @return vouchTime
     */
    public java.lang.String getVouchTime() {
        return vouchTime;
    }


    /**
     * Sets the vouchTime value for this VouchInfo.
     * 
     * @param vouchTime
     */
    public void setVouchTime(java.lang.String vouchTime) {
        this.vouchTime = vouchTime;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VouchInfo)) return false;
        VouchInfo other = (VouchInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            this.isRoomAmountVouch == other.getIsRoomAmountVouch() &&
            this.isTimeVouch == other.getIsTimeVouch() &&
            this.isVouch == other.getIsVouch() &&
            ((this.notVouchDescription==null && other.getNotVouchDescription()==null) || 
             (this.notVouchDescription!=null &&
              this.notVouchDescription.equals(other.getNotVouchDescription()))) &&
            ((this.notVouchTime==null && other.getNotVouchTime()==null) || 
             (this.notVouchTime!=null &&
              this.notVouchTime.equals(other.getNotVouchTime()))) &&
            this.roomAmount == other.getRoomAmount() &&
            ((this.vouchDescription==null && other.getVouchDescription()==null) || 
             (this.vouchDescription!=null &&
              this.vouchDescription.equals(other.getVouchDescription()))) &&
            this.vouchMoneyType == other.getVouchMoneyType() &&
            ((this.vouchTime==null && other.getVouchTime()==null) || 
             (this.vouchTime!=null &&
              this.vouchTime.equals(other.getVouchTime())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        _hashCode += getIsRoomAmountVouch();
        _hashCode += getIsTimeVouch();
        _hashCode += getIsVouch();
        if (getNotVouchDescription() != null) {
            _hashCode += getNotVouchDescription().hashCode();
        }
        if (getNotVouchTime() != null) {
            _hashCode += getNotVouchTime().hashCode();
        }
        _hashCode += getRoomAmount();
        if (getVouchDescription() != null) {
            _hashCode += getVouchDescription().hashCode();
        }
        _hashCode += getVouchMoneyType();
        if (getVouchTime() != null) {
            _hashCode += getVouchTime().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VouchInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.VouchInfo", "VouchInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isRoomAmountVouch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isRoomAmountVouch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isTimeVouch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isTimeVouch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isVouch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isVouch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notVouchDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("", "notVouchDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notVouchTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "notVouchTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vouchDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vouchDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vouchMoneyType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vouchMoneyType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vouchTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vouchTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
