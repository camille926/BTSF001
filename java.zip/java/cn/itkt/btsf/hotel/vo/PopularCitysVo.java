/**
 * PopularCitysVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class PopularCitysVo  extends cn.itkt.btsf.hotel.vo.BaseVo  implements java.io.Serializable {
    private cn.itkt.btsf.hotel.vo.PopularCityVo[] popularCityVos;

    public PopularCitysVo() {
    }

    public PopularCitysVo(
           java.lang.String message,
           java.lang.String status,
           cn.itkt.btsf.hotel.vo.PopularCityVo[] popularCityVos) {
        super(
            message,
            status);
        this.popularCityVos = popularCityVos;
    }


    /**
     * Gets the popularCityVos value for this PopularCitysVo.
     * 
     * @return popularCityVos
     */
    public cn.itkt.btsf.hotel.vo.PopularCityVo[] getPopularCityVos() {
        return popularCityVos;
    }


    /**
     * Sets the popularCityVos value for this PopularCitysVo.
     * 
     * @param popularCityVos
     */
    public void setPopularCityVos(cn.itkt.btsf.hotel.vo.PopularCityVo[] popularCityVos) {
        this.popularCityVos = popularCityVos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PopularCitysVo)) return false;
        PopularCitysVo other = (PopularCitysVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.popularCityVos==null && other.getPopularCityVos()==null) || 
             (this.popularCityVos!=null &&
              java.util.Arrays.equals(this.popularCityVos, other.getPopularCityVos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getPopularCityVos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPopularCityVos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPopularCityVos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PopularCitysVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.PopularCitysVo", "PopularCitysVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("popularCityVos");
        elemField.setXmlName(new javax.xml.namespace.QName("", "popularCityVos"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.PopularCityVo", "PopularCityVo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
