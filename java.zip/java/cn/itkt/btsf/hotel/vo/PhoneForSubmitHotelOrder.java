/**
 * PhoneForSubmitHotelOrder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class PhoneForSubmitHotelOrder  implements java.io.Serializable {
    private int interCode;

    private int areaCode;

    private int nmber;

    private int ext;

    public PhoneForSubmitHotelOrder() {
    }

    public PhoneForSubmitHotelOrder(
           int interCode,
           int areaCode,
           int nmber,
           int ext) {
           this.interCode = interCode;
           this.areaCode = areaCode;
           this.nmber = nmber;
           this.ext = ext;
    }


    /**
     * Gets the interCode value for this PhoneForSubmitHotelOrder.
     * 
     * @return interCode
     */
    public int getInterCode() {
        return interCode;
    }


    /**
     * Sets the interCode value for this PhoneForSubmitHotelOrder.
     * 
     * @param interCode
     */
    public void setInterCode(int interCode) {
        this.interCode = interCode;
    }


    /**
     * Gets the areaCode value for this PhoneForSubmitHotelOrder.
     * 
     * @return areaCode
     */
    public int getAreaCode() {
        return areaCode;
    }


    /**
     * Sets the areaCode value for this PhoneForSubmitHotelOrder.
     * 
     * @param areaCode
     */
    public void setAreaCode(int areaCode) {
        this.areaCode = areaCode;
    }


    /**
     * Gets the nmber value for this PhoneForSubmitHotelOrder.
     * 
     * @return nmber
     */
    public int getNmber() {
        return nmber;
    }


    /**
     * Sets the nmber value for this PhoneForSubmitHotelOrder.
     * 
     * @param nmber
     */
    public void setNmber(int nmber) {
        this.nmber = nmber;
    }


    /**
     * Gets the ext value for this PhoneForSubmitHotelOrder.
     * 
     * @return ext
     */
    public int getExt() {
        return ext;
    }


    /**
     * Sets the ext value for this PhoneForSubmitHotelOrder.
     * 
     * @param ext
     */
    public void setExt(int ext) {
        this.ext = ext;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PhoneForSubmitHotelOrder)) return false;
        PhoneForSubmitHotelOrder other = (PhoneForSubmitHotelOrder) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.interCode == other.getInterCode() &&
            this.areaCode == other.getAreaCode() &&
            this.nmber == other.getNmber() &&
            this.ext == other.getExt();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getInterCode();
        _hashCode += getAreaCode();
        _hashCode += getNmber();
        _hashCode += getExt();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PhoneForSubmitHotelOrder.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://elong.com/NorthBoundAPI/", "PhoneForSubmitHotelOrder"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "InterCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("areaCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "AreaCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nmber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Nmber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ext");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Ext"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
