/**
 * HotelBrandDetailsVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelBrandDetailsVo  implements java.io.Serializable {
    private java.lang.String cityId;

    private cn.itkt.btsf.hotel.vo.HotelBrandDetailVo[] hotelBrandDetal;

    private int hotelCount;

    public HotelBrandDetailsVo() {
    }

    public HotelBrandDetailsVo(
           java.lang.String cityId,
           cn.itkt.btsf.hotel.vo.HotelBrandDetailVo[] hotelBrandDetal,
           int hotelCount) {
           this.cityId = cityId;
           this.hotelBrandDetal = hotelBrandDetal;
           this.hotelCount = hotelCount;
    }


    /**
     * Gets the cityId value for this HotelBrandDetailsVo.
     * 
     * @return cityId
     */
    public java.lang.String getCityId() {
        return cityId;
    }


    /**
     * Sets the cityId value for this HotelBrandDetailsVo.
     * 
     * @param cityId
     */
    public void setCityId(java.lang.String cityId) {
        this.cityId = cityId;
    }


    /**
     * Gets the hotelBrandDetal value for this HotelBrandDetailsVo.
     * 
     * @return hotelBrandDetal
     */
    public cn.itkt.btsf.hotel.vo.HotelBrandDetailVo[] getHotelBrandDetal() {
        return hotelBrandDetal;
    }


    /**
     * Sets the hotelBrandDetal value for this HotelBrandDetailsVo.
     * 
     * @param hotelBrandDetal
     */
    public void setHotelBrandDetal(cn.itkt.btsf.hotel.vo.HotelBrandDetailVo[] hotelBrandDetal) {
        this.hotelBrandDetal = hotelBrandDetal;
    }


    /**
     * Gets the hotelCount value for this HotelBrandDetailsVo.
     * 
     * @return hotelCount
     */
    public int getHotelCount() {
        return hotelCount;
    }


    /**
     * Sets the hotelCount value for this HotelBrandDetailsVo.
     * 
     * @param hotelCount
     */
    public void setHotelCount(int hotelCount) {
        this.hotelCount = hotelCount;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelBrandDetailsVo)) return false;
        HotelBrandDetailsVo other = (HotelBrandDetailsVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cityId==null && other.getCityId()==null) || 
             (this.cityId!=null &&
              this.cityId.equals(other.getCityId()))) &&
            ((this.hotelBrandDetal==null && other.getHotelBrandDetal()==null) || 
             (this.hotelBrandDetal!=null &&
              java.util.Arrays.equals(this.hotelBrandDetal, other.getHotelBrandDetal()))) &&
            this.hotelCount == other.getHotelCount();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCityId() != null) {
            _hashCode += getCityId().hashCode();
        }
        if (getHotelBrandDetal() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHotelBrandDetal());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHotelBrandDetal(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getHotelCount();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelBrandDetailsVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailsVo", "HotelBrandDetailsVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelBrandDetal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelBrandDetal"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailVo", "HotelBrandDetailVo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
