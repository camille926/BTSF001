/**
 * RatePlanForHotel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class RatePlanForHotel  implements java.io.Serializable {
    private int activeLcdfee;

    private double activeRate;

    private java.math.BigDecimal averagePrice;

    private cn.itkt.btsf.hotel.vo.DayRateForHotel[] eachDayRateList;

    private java.lang.String guestTypeCode;

    private java.lang.String ratePlanCode;

    private int ratePlanID;

    private java.lang.String ratePlanName;

    private java.lang.String returnAvgLcdMoney;

    private java.lang.String returnLcdMoney;

    private java.math.BigDecimal totalPrice;

    private cn.itkt.btsf.hotel.vo.VouchInfo[] vouchInfos;

    public RatePlanForHotel() {
    }

    public RatePlanForHotel(
           int activeLcdfee,
           double activeRate,
           java.math.BigDecimal averagePrice,
           cn.itkt.btsf.hotel.vo.DayRateForHotel[] eachDayRateList,
           java.lang.String guestTypeCode,
           java.lang.String ratePlanCode,
           int ratePlanID,
           java.lang.String ratePlanName,
           java.lang.String returnAvgLcdMoney,
           java.lang.String returnLcdMoney,
           java.math.BigDecimal totalPrice,
           cn.itkt.btsf.hotel.vo.VouchInfo[] vouchInfos) {
           this.activeLcdfee = activeLcdfee;
           this.activeRate = activeRate;
           this.averagePrice = averagePrice;
           this.eachDayRateList = eachDayRateList;
           this.guestTypeCode = guestTypeCode;
           this.ratePlanCode = ratePlanCode;
           this.ratePlanID = ratePlanID;
           this.ratePlanName = ratePlanName;
           this.returnAvgLcdMoney = returnAvgLcdMoney;
           this.returnLcdMoney = returnLcdMoney;
           this.totalPrice = totalPrice;
           this.vouchInfos = vouchInfos;
    }


    /**
     * Gets the activeLcdfee value for this RatePlanForHotel.
     * 
     * @return activeLcdfee
     */
    public int getActiveLcdfee() {
        return activeLcdfee;
    }


    /**
     * Sets the activeLcdfee value for this RatePlanForHotel.
     * 
     * @param activeLcdfee
     */
    public void setActiveLcdfee(int activeLcdfee) {
        this.activeLcdfee = activeLcdfee;
    }


    /**
     * Gets the activeRate value for this RatePlanForHotel.
     * 
     * @return activeRate
     */
    public double getActiveRate() {
        return activeRate;
    }


    /**
     * Sets the activeRate value for this RatePlanForHotel.
     * 
     * @param activeRate
     */
    public void setActiveRate(double activeRate) {
        this.activeRate = activeRate;
    }


    /**
     * Gets the averagePrice value for this RatePlanForHotel.
     * 
     * @return averagePrice
     */
    public java.math.BigDecimal getAveragePrice() {
        return averagePrice;
    }


    /**
     * Sets the averagePrice value for this RatePlanForHotel.
     * 
     * @param averagePrice
     */
    public void setAveragePrice(java.math.BigDecimal averagePrice) {
        this.averagePrice = averagePrice;
    }


    /**
     * Gets the eachDayRateList value for this RatePlanForHotel.
     * 
     * @return eachDayRateList
     */
    public cn.itkt.btsf.hotel.vo.DayRateForHotel[] getEachDayRateList() {
        return eachDayRateList;
    }


    /**
     * Sets the eachDayRateList value for this RatePlanForHotel.
     * 
     * @param eachDayRateList
     */
    public void setEachDayRateList(cn.itkt.btsf.hotel.vo.DayRateForHotel[] eachDayRateList) {
        this.eachDayRateList = eachDayRateList;
    }


    /**
     * Gets the guestTypeCode value for this RatePlanForHotel.
     * 
     * @return guestTypeCode
     */
    public java.lang.String getGuestTypeCode() {
        return guestTypeCode;
    }


    /**
     * Sets the guestTypeCode value for this RatePlanForHotel.
     * 
     * @param guestTypeCode
     */
    public void setGuestTypeCode(java.lang.String guestTypeCode) {
        this.guestTypeCode = guestTypeCode;
    }


    /**
     * Gets the ratePlanCode value for this RatePlanForHotel.
     * 
     * @return ratePlanCode
     */
    public java.lang.String getRatePlanCode() {
        return ratePlanCode;
    }


    /**
     * Sets the ratePlanCode value for this RatePlanForHotel.
     * 
     * @param ratePlanCode
     */
    public void setRatePlanCode(java.lang.String ratePlanCode) {
        this.ratePlanCode = ratePlanCode;
    }


    /**
     * Gets the ratePlanID value for this RatePlanForHotel.
     * 
     * @return ratePlanID
     */
    public int getRatePlanID() {
        return ratePlanID;
    }


    /**
     * Sets the ratePlanID value for this RatePlanForHotel.
     * 
     * @param ratePlanID
     */
    public void setRatePlanID(int ratePlanID) {
        this.ratePlanID = ratePlanID;
    }


    /**
     * Gets the ratePlanName value for this RatePlanForHotel.
     * 
     * @return ratePlanName
     */
    public java.lang.String getRatePlanName() {
        return ratePlanName;
    }


    /**
     * Sets the ratePlanName value for this RatePlanForHotel.
     * 
     * @param ratePlanName
     */
    public void setRatePlanName(java.lang.String ratePlanName) {
        this.ratePlanName = ratePlanName;
    }


    /**
     * Gets the returnAvgLcdMoney value for this RatePlanForHotel.
     * 
     * @return returnAvgLcdMoney
     */
    public java.lang.String getReturnAvgLcdMoney() {
        return returnAvgLcdMoney;
    }


    /**
     * Sets the returnAvgLcdMoney value for this RatePlanForHotel.
     * 
     * @param returnAvgLcdMoney
     */
    public void setReturnAvgLcdMoney(java.lang.String returnAvgLcdMoney) {
        this.returnAvgLcdMoney = returnAvgLcdMoney;
    }


    /**
     * Gets the returnLcdMoney value for this RatePlanForHotel.
     * 
     * @return returnLcdMoney
     */
    public java.lang.String getReturnLcdMoney() {
        return returnLcdMoney;
    }


    /**
     * Sets the returnLcdMoney value for this RatePlanForHotel.
     * 
     * @param returnLcdMoney
     */
    public void setReturnLcdMoney(java.lang.String returnLcdMoney) {
        this.returnLcdMoney = returnLcdMoney;
    }


    /**
     * Gets the totalPrice value for this RatePlanForHotel.
     * 
     * @return totalPrice
     */
    public java.math.BigDecimal getTotalPrice() {
        return totalPrice;
    }


    /**
     * Sets the totalPrice value for this RatePlanForHotel.
     * 
     * @param totalPrice
     */
    public void setTotalPrice(java.math.BigDecimal totalPrice) {
        this.totalPrice = totalPrice;
    }


    /**
     * Gets the vouchInfos value for this RatePlanForHotel.
     * 
     * @return vouchInfos
     */
    public cn.itkt.btsf.hotel.vo.VouchInfo[] getVouchInfos() {
        return vouchInfos;
    }


    /**
     * Sets the vouchInfos value for this RatePlanForHotel.
     * 
     * @param vouchInfos
     */
    public void setVouchInfos(cn.itkt.btsf.hotel.vo.VouchInfo[] vouchInfos) {
        this.vouchInfos = vouchInfos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RatePlanForHotel)) return false;
        RatePlanForHotel other = (RatePlanForHotel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.activeLcdfee == other.getActiveLcdfee() &&
            this.activeRate == other.getActiveRate() &&
            ((this.averagePrice==null && other.getAveragePrice()==null) || 
             (this.averagePrice!=null &&
              this.averagePrice.equals(other.getAveragePrice()))) &&
            ((this.eachDayRateList==null && other.getEachDayRateList()==null) || 
             (this.eachDayRateList!=null &&
              java.util.Arrays.equals(this.eachDayRateList, other.getEachDayRateList()))) &&
            ((this.guestTypeCode==null && other.getGuestTypeCode()==null) || 
             (this.guestTypeCode!=null &&
              this.guestTypeCode.equals(other.getGuestTypeCode()))) &&
            ((this.ratePlanCode==null && other.getRatePlanCode()==null) || 
             (this.ratePlanCode!=null &&
              this.ratePlanCode.equals(other.getRatePlanCode()))) &&
            this.ratePlanID == other.getRatePlanID() &&
            ((this.ratePlanName==null && other.getRatePlanName()==null) || 
             (this.ratePlanName!=null &&
              this.ratePlanName.equals(other.getRatePlanName()))) &&
            ((this.returnAvgLcdMoney==null && other.getReturnAvgLcdMoney()==null) || 
             (this.returnAvgLcdMoney!=null &&
              this.returnAvgLcdMoney.equals(other.getReturnAvgLcdMoney()))) &&
            ((this.returnLcdMoney==null && other.getReturnLcdMoney()==null) || 
             (this.returnLcdMoney!=null &&
              this.returnLcdMoney.equals(other.getReturnLcdMoney()))) &&
            ((this.totalPrice==null && other.getTotalPrice()==null) || 
             (this.totalPrice!=null &&
              this.totalPrice.equals(other.getTotalPrice()))) &&
            ((this.vouchInfos==null && other.getVouchInfos()==null) || 
             (this.vouchInfos!=null &&
              java.util.Arrays.equals(this.vouchInfos, other.getVouchInfos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getActiveLcdfee();
        _hashCode += new Double(getActiveRate()).hashCode();
        if (getAveragePrice() != null) {
            _hashCode += getAveragePrice().hashCode();
        }
        if (getEachDayRateList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEachDayRateList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEachDayRateList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGuestTypeCode() != null) {
            _hashCode += getGuestTypeCode().hashCode();
        }
        if (getRatePlanCode() != null) {
            _hashCode += getRatePlanCode().hashCode();
        }
        _hashCode += getRatePlanID();
        if (getRatePlanName() != null) {
            _hashCode += getRatePlanName().hashCode();
        }
        if (getReturnAvgLcdMoney() != null) {
            _hashCode += getReturnAvgLcdMoney().hashCode();
        }
        if (getReturnLcdMoney() != null) {
            _hashCode += getReturnLcdMoney().hashCode();
        }
        if (getTotalPrice() != null) {
            _hashCode += getTotalPrice().hashCode();
        }
        if (getVouchInfos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getVouchInfos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getVouchInfos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RatePlanForHotel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RatePlanForHotel", "RatePlanForHotel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activeLcdfee");
        elemField.setXmlName(new javax.xml.namespace.QName("", "activeLcdfee"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activeRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "activeRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("averagePrice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "averagePrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("eachDayRateList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "eachDayRateList"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.DayRateForHotel", "DayRateForHotel"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guestTypeCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "guestTypeCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ratePlanCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ratePlanCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ratePlanID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ratePlanID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ratePlanName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ratePlanName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnAvgLcdMoney");
        elemField.setXmlName(new javax.xml.namespace.QName("", "returnAvgLcdMoney"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnLcdMoney");
        elemField.setXmlName(new javax.xml.namespace.QName("", "returnLcdMoney"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "totalPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vouchInfos");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vouchInfos"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.VouchInfo", "VouchInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
