/**
 * HotelForMoreHotelVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelForMoreHotelVo  implements java.io.Serializable {
    private java.lang.String[] addValuesDescription;

    private java.lang.String[] bookingRuless;

    private java.lang.String brandid;

    private java.lang.String citycode;

    private java.lang.Long commentAll;

    private java.lang.Long commentGood;

    private java.lang.String commercial;

    private java.lang.String[] dRRRules;

    private java.lang.String district;

    private java.lang.String[] garanteeRules;

    private java.lang.String hotelAddress;

    private java.lang.String hotelId;

    private java.lang.String hotelInvStatusCode;

    private java.lang.String hotelName;

    private java.lang.String hotelurl;

    private java.lang.String latitude;

    private java.lang.String longitude;

    private java.math.BigDecimal lowestPrice;

    private java.lang.String phone;

    private java.lang.String por;

    private cn.itkt.btsf.hotel.vo.RoomForHotel[] roomForGetHoteList;

    private java.lang.String starCode;

    public HotelForMoreHotelVo() {
    }

    public HotelForMoreHotelVo(
           java.lang.String[] addValuesDescription,
           java.lang.String[] bookingRuless,
           java.lang.String brandid,
           java.lang.String citycode,
           java.lang.Long commentAll,
           java.lang.Long commentGood,
           java.lang.String commercial,
           java.lang.String[] dRRRules,
           java.lang.String district,
           java.lang.String[] garanteeRules,
           java.lang.String hotelAddress,
           java.lang.String hotelId,
           java.lang.String hotelInvStatusCode,
           java.lang.String hotelName,
           java.lang.String hotelurl,
           java.lang.String latitude,
           java.lang.String longitude,
           java.math.BigDecimal lowestPrice,
           java.lang.String phone,
           java.lang.String por,
           cn.itkt.btsf.hotel.vo.RoomForHotel[] roomForGetHoteList,
           java.lang.String starCode) {
           this.addValuesDescription = addValuesDescription;
           this.bookingRuless = bookingRuless;
           this.brandid = brandid;
           this.citycode = citycode;
           this.commentAll = commentAll;
           this.commentGood = commentGood;
           this.commercial = commercial;
           this.dRRRules = dRRRules;
           this.district = district;
           this.garanteeRules = garanteeRules;
           this.hotelAddress = hotelAddress;
           this.hotelId = hotelId;
           this.hotelInvStatusCode = hotelInvStatusCode;
           this.hotelName = hotelName;
           this.hotelurl = hotelurl;
           this.latitude = latitude;
           this.longitude = longitude;
           this.lowestPrice = lowestPrice;
           this.phone = phone;
           this.por = por;
           this.roomForGetHoteList = roomForGetHoteList;
           this.starCode = starCode;
    }


    /**
     * Gets the addValuesDescription value for this HotelForMoreHotelVo.
     * 
     * @return addValuesDescription
     */
    public java.lang.String[] getAddValuesDescription() {
        return addValuesDescription;
    }


    /**
     * Sets the addValuesDescription value for this HotelForMoreHotelVo.
     * 
     * @param addValuesDescription
     */
    public void setAddValuesDescription(java.lang.String[] addValuesDescription) {
        this.addValuesDescription = addValuesDescription;
    }


    /**
     * Gets the bookingRuless value for this HotelForMoreHotelVo.
     * 
     * @return bookingRuless
     */
    public java.lang.String[] getBookingRuless() {
        return bookingRuless;
    }


    /**
     * Sets the bookingRuless value for this HotelForMoreHotelVo.
     * 
     * @param bookingRuless
     */
    public void setBookingRuless(java.lang.String[] bookingRuless) {
        this.bookingRuless = bookingRuless;
    }


    /**
     * Gets the brandid value for this HotelForMoreHotelVo.
     * 
     * @return brandid
     */
    public java.lang.String getBrandid() {
        return brandid;
    }


    /**
     * Sets the brandid value for this HotelForMoreHotelVo.
     * 
     * @param brandid
     */
    public void setBrandid(java.lang.String brandid) {
        this.brandid = brandid;
    }


    /**
     * Gets the citycode value for this HotelForMoreHotelVo.
     * 
     * @return citycode
     */
    public java.lang.String getCitycode() {
        return citycode;
    }


    /**
     * Sets the citycode value for this HotelForMoreHotelVo.
     * 
     * @param citycode
     */
    public void setCitycode(java.lang.String citycode) {
        this.citycode = citycode;
    }


    /**
     * Gets the commentAll value for this HotelForMoreHotelVo.
     * 
     * @return commentAll
     */
    public java.lang.Long getCommentAll() {
        return commentAll;
    }


    /**
     * Sets the commentAll value for this HotelForMoreHotelVo.
     * 
     * @param commentAll
     */
    public void setCommentAll(java.lang.Long commentAll) {
        this.commentAll = commentAll;
    }


    /**
     * Gets the commentGood value for this HotelForMoreHotelVo.
     * 
     * @return commentGood
     */
    public java.lang.Long getCommentGood() {
        return commentGood;
    }


    /**
     * Sets the commentGood value for this HotelForMoreHotelVo.
     * 
     * @param commentGood
     */
    public void setCommentGood(java.lang.Long commentGood) {
        this.commentGood = commentGood;
    }


    /**
     * Gets the commercial value for this HotelForMoreHotelVo.
     * 
     * @return commercial
     */
    public java.lang.String getCommercial() {
        return commercial;
    }


    /**
     * Sets the commercial value for this HotelForMoreHotelVo.
     * 
     * @param commercial
     */
    public void setCommercial(java.lang.String commercial) {
        this.commercial = commercial;
    }


    /**
     * Gets the dRRRules value for this HotelForMoreHotelVo.
     * 
     * @return dRRRules
     */
    public java.lang.String[] getDRRRules() {
        return dRRRules;
    }


    /**
     * Sets the dRRRules value for this HotelForMoreHotelVo.
     * 
     * @param dRRRules
     */
    public void setDRRRules(java.lang.String[] dRRRules) {
        this.dRRRules = dRRRules;
    }


    /**
     * Gets the district value for this HotelForMoreHotelVo.
     * 
     * @return district
     */
    public java.lang.String getDistrict() {
        return district;
    }


    /**
     * Sets the district value for this HotelForMoreHotelVo.
     * 
     * @param district
     */
    public void setDistrict(java.lang.String district) {
        this.district = district;
    }


    /**
     * Gets the garanteeRules value for this HotelForMoreHotelVo.
     * 
     * @return garanteeRules
     */
    public java.lang.String[] getGaranteeRules() {
        return garanteeRules;
    }


    /**
     * Sets the garanteeRules value for this HotelForMoreHotelVo.
     * 
     * @param garanteeRules
     */
    public void setGaranteeRules(java.lang.String[] garanteeRules) {
        this.garanteeRules = garanteeRules;
    }


    /**
     * Gets the hotelAddress value for this HotelForMoreHotelVo.
     * 
     * @return hotelAddress
     */
    public java.lang.String getHotelAddress() {
        return hotelAddress;
    }


    /**
     * Sets the hotelAddress value for this HotelForMoreHotelVo.
     * 
     * @param hotelAddress
     */
    public void setHotelAddress(java.lang.String hotelAddress) {
        this.hotelAddress = hotelAddress;
    }


    /**
     * Gets the hotelId value for this HotelForMoreHotelVo.
     * 
     * @return hotelId
     */
    public java.lang.String getHotelId() {
        return hotelId;
    }


    /**
     * Sets the hotelId value for this HotelForMoreHotelVo.
     * 
     * @param hotelId
     */
    public void setHotelId(java.lang.String hotelId) {
        this.hotelId = hotelId;
    }


    /**
     * Gets the hotelInvStatusCode value for this HotelForMoreHotelVo.
     * 
     * @return hotelInvStatusCode
     */
    public java.lang.String getHotelInvStatusCode() {
        return hotelInvStatusCode;
    }


    /**
     * Sets the hotelInvStatusCode value for this HotelForMoreHotelVo.
     * 
     * @param hotelInvStatusCode
     */
    public void setHotelInvStatusCode(java.lang.String hotelInvStatusCode) {
        this.hotelInvStatusCode = hotelInvStatusCode;
    }


    /**
     * Gets the hotelName value for this HotelForMoreHotelVo.
     * 
     * @return hotelName
     */
    public java.lang.String getHotelName() {
        return hotelName;
    }


    /**
     * Sets the hotelName value for this HotelForMoreHotelVo.
     * 
     * @param hotelName
     */
    public void setHotelName(java.lang.String hotelName) {
        this.hotelName = hotelName;
    }


    /**
     * Gets the hotelurl value for this HotelForMoreHotelVo.
     * 
     * @return hotelurl
     */
    public java.lang.String getHotelurl() {
        return hotelurl;
    }


    /**
     * Sets the hotelurl value for this HotelForMoreHotelVo.
     * 
     * @param hotelurl
     */
    public void setHotelurl(java.lang.String hotelurl) {
        this.hotelurl = hotelurl;
    }


    /**
     * Gets the latitude value for this HotelForMoreHotelVo.
     * 
     * @return latitude
     */
    public java.lang.String getLatitude() {
        return latitude;
    }


    /**
     * Sets the latitude value for this HotelForMoreHotelVo.
     * 
     * @param latitude
     */
    public void setLatitude(java.lang.String latitude) {
        this.latitude = latitude;
    }


    /**
     * Gets the longitude value for this HotelForMoreHotelVo.
     * 
     * @return longitude
     */
    public java.lang.String getLongitude() {
        return longitude;
    }


    /**
     * Sets the longitude value for this HotelForMoreHotelVo.
     * 
     * @param longitude
     */
    public void setLongitude(java.lang.String longitude) {
        this.longitude = longitude;
    }


    /**
     * Gets the lowestPrice value for this HotelForMoreHotelVo.
     * 
     * @return lowestPrice
     */
    public java.math.BigDecimal getLowestPrice() {
        return lowestPrice;
    }


    /**
     * Sets the lowestPrice value for this HotelForMoreHotelVo.
     * 
     * @param lowestPrice
     */
    public void setLowestPrice(java.math.BigDecimal lowestPrice) {
        this.lowestPrice = lowestPrice;
    }


    /**
     * Gets the phone value for this HotelForMoreHotelVo.
     * 
     * @return phone
     */
    public java.lang.String getPhone() {
        return phone;
    }


    /**
     * Sets the phone value for this HotelForMoreHotelVo.
     * 
     * @param phone
     */
    public void setPhone(java.lang.String phone) {
        this.phone = phone;
    }


    /**
     * Gets the por value for this HotelForMoreHotelVo.
     * 
     * @return por
     */
    public java.lang.String getPor() {
        return por;
    }


    /**
     * Sets the por value for this HotelForMoreHotelVo.
     * 
     * @param por
     */
    public void setPor(java.lang.String por) {
        this.por = por;
    }


    /**
     * Gets the roomForGetHoteList value for this HotelForMoreHotelVo.
     * 
     * @return roomForGetHoteList
     */
    public cn.itkt.btsf.hotel.vo.RoomForHotel[] getRoomForGetHoteList() {
        return roomForGetHoteList;
    }


    /**
     * Sets the roomForGetHoteList value for this HotelForMoreHotelVo.
     * 
     * @param roomForGetHoteList
     */
    public void setRoomForGetHoteList(cn.itkt.btsf.hotel.vo.RoomForHotel[] roomForGetHoteList) {
        this.roomForGetHoteList = roomForGetHoteList;
    }


    /**
     * Gets the starCode value for this HotelForMoreHotelVo.
     * 
     * @return starCode
     */
    public java.lang.String getStarCode() {
        return starCode;
    }


    /**
     * Sets the starCode value for this HotelForMoreHotelVo.
     * 
     * @param starCode
     */
    public void setStarCode(java.lang.String starCode) {
        this.starCode = starCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelForMoreHotelVo)) return false;
        HotelForMoreHotelVo other = (HotelForMoreHotelVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.addValuesDescription==null && other.getAddValuesDescription()==null) || 
             (this.addValuesDescription!=null &&
              java.util.Arrays.equals(this.addValuesDescription, other.getAddValuesDescription()))) &&
            ((this.bookingRuless==null && other.getBookingRuless()==null) || 
             (this.bookingRuless!=null &&
              java.util.Arrays.equals(this.bookingRuless, other.getBookingRuless()))) &&
            ((this.brandid==null && other.getBrandid()==null) || 
             (this.brandid!=null &&
              this.brandid.equals(other.getBrandid()))) &&
            ((this.citycode==null && other.getCitycode()==null) || 
             (this.citycode!=null &&
              this.citycode.equals(other.getCitycode()))) &&
            ((this.commentAll==null && other.getCommentAll()==null) || 
             (this.commentAll!=null &&
              this.commentAll.equals(other.getCommentAll()))) &&
            ((this.commentGood==null && other.getCommentGood()==null) || 
             (this.commentGood!=null &&
              this.commentGood.equals(other.getCommentGood()))) &&
            ((this.commercial==null && other.getCommercial()==null) || 
             (this.commercial!=null &&
              this.commercial.equals(other.getCommercial()))) &&
            ((this.dRRRules==null && other.getDRRRules()==null) || 
             (this.dRRRules!=null &&
              java.util.Arrays.equals(this.dRRRules, other.getDRRRules()))) &&
            ((this.district==null && other.getDistrict()==null) || 
             (this.district!=null &&
              this.district.equals(other.getDistrict()))) &&
            ((this.garanteeRules==null && other.getGaranteeRules()==null) || 
             (this.garanteeRules!=null &&
              java.util.Arrays.equals(this.garanteeRules, other.getGaranteeRules()))) &&
            ((this.hotelAddress==null && other.getHotelAddress()==null) || 
             (this.hotelAddress!=null &&
              this.hotelAddress.equals(other.getHotelAddress()))) &&
            ((this.hotelId==null && other.getHotelId()==null) || 
             (this.hotelId!=null &&
              this.hotelId.equals(other.getHotelId()))) &&
            ((this.hotelInvStatusCode==null && other.getHotelInvStatusCode()==null) || 
             (this.hotelInvStatusCode!=null &&
              this.hotelInvStatusCode.equals(other.getHotelInvStatusCode()))) &&
            ((this.hotelName==null && other.getHotelName()==null) || 
             (this.hotelName!=null &&
              this.hotelName.equals(other.getHotelName()))) &&
            ((this.hotelurl==null && other.getHotelurl()==null) || 
             (this.hotelurl!=null &&
              this.hotelurl.equals(other.getHotelurl()))) &&
            ((this.latitude==null && other.getLatitude()==null) || 
             (this.latitude!=null &&
              this.latitude.equals(other.getLatitude()))) &&
            ((this.longitude==null && other.getLongitude()==null) || 
             (this.longitude!=null &&
              this.longitude.equals(other.getLongitude()))) &&
            ((this.lowestPrice==null && other.getLowestPrice()==null) || 
             (this.lowestPrice!=null &&
              this.lowestPrice.equals(other.getLowestPrice()))) &&
            ((this.phone==null && other.getPhone()==null) || 
             (this.phone!=null &&
              this.phone.equals(other.getPhone()))) &&
            ((this.por==null && other.getPor()==null) || 
             (this.por!=null &&
              this.por.equals(other.getPor()))) &&
            ((this.roomForGetHoteList==null && other.getRoomForGetHoteList()==null) || 
             (this.roomForGetHoteList!=null &&
              java.util.Arrays.equals(this.roomForGetHoteList, other.getRoomForGetHoteList()))) &&
            ((this.starCode==null && other.getStarCode()==null) || 
             (this.starCode!=null &&
              this.starCode.equals(other.getStarCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAddValuesDescription() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAddValuesDescription());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAddValuesDescription(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBookingRuless() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBookingRuless());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBookingRuless(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBrandid() != null) {
            _hashCode += getBrandid().hashCode();
        }
        if (getCitycode() != null) {
            _hashCode += getCitycode().hashCode();
        }
        if (getCommentAll() != null) {
            _hashCode += getCommentAll().hashCode();
        }
        if (getCommentGood() != null) {
            _hashCode += getCommentGood().hashCode();
        }
        if (getCommercial() != null) {
            _hashCode += getCommercial().hashCode();
        }
        if (getDRRRules() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDRRRules());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDRRRules(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDistrict() != null) {
            _hashCode += getDistrict().hashCode();
        }
        if (getGaranteeRules() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGaranteeRules());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGaranteeRules(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHotelAddress() != null) {
            _hashCode += getHotelAddress().hashCode();
        }
        if (getHotelId() != null) {
            _hashCode += getHotelId().hashCode();
        }
        if (getHotelInvStatusCode() != null) {
            _hashCode += getHotelInvStatusCode().hashCode();
        }
        if (getHotelName() != null) {
            _hashCode += getHotelName().hashCode();
        }
        if (getHotelurl() != null) {
            _hashCode += getHotelurl().hashCode();
        }
        if (getLatitude() != null) {
            _hashCode += getLatitude().hashCode();
        }
        if (getLongitude() != null) {
            _hashCode += getLongitude().hashCode();
        }
        if (getLowestPrice() != null) {
            _hashCode += getLowestPrice().hashCode();
        }
        if (getPhone() != null) {
            _hashCode += getPhone().hashCode();
        }
        if (getPor() != null) {
            _hashCode += getPor().hashCode();
        }
        if (getRoomForGetHoteList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRoomForGetHoteList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRoomForGetHoteList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getStarCode() != null) {
            _hashCode += getStarCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelForMoreHotelVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelForMoreHotelVo", "HotelForMoreHotelVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addValuesDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("", "addValuesDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bookingRuless");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bookingRuless"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("citycode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "citycode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commentAll");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commentAll"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commentGood");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commentGood"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commercial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DRRRules");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dRRRules"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("district");
        elemField.setXmlName(new javax.xml.namespace.QName("", "district"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("garanteeRules");
        elemField.setXmlName(new javax.xml.namespace.QName("", "garanteeRules"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelInvStatusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelInvStatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelurl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelurl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("latitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "latitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("longitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "longitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowestPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lowestPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phone");
        elemField.setXmlName(new javax.xml.namespace.QName("", "phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("por");
        elemField.setXmlName(new javax.xml.namespace.QName("", "por"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomForGetHoteList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomForGetHoteList"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RoomForHotel", "RoomForHotel"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("starCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "starCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
