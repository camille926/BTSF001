/**
 * RoomForHotel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class RoomForHotel  implements java.io.Serializable {
    private java.lang.String area;

    private int availableAmount;

    private java.lang.String beddescription;

    private java.lang.String bedtype;

    private java.lang.String floor;

    private java.lang.String hadbroadbandfee;

    private java.lang.String hasbroadband;

    private java.lang.String isOverBooking;

    private java.lang.String note;

    private cn.itkt.btsf.hotel.vo.RatePlanForHotel[] ratePlanForGetHotelList;

    private java.lang.String[] roomImageCodes;

    private java.lang.String roomInvStatusCode;

    private java.lang.String roomName;

    private java.lang.String roomTypeId;

    private java.lang.String roomtypenum;

    private java.lang.String roomurl;

    public RoomForHotel() {
    }

    public RoomForHotel(
           java.lang.String area,
           int availableAmount,
           java.lang.String beddescription,
           java.lang.String bedtype,
           java.lang.String floor,
           java.lang.String hadbroadbandfee,
           java.lang.String hasbroadband,
           java.lang.String isOverBooking,
           java.lang.String note,
           cn.itkt.btsf.hotel.vo.RatePlanForHotel[] ratePlanForGetHotelList,
           java.lang.String[] roomImageCodes,
           java.lang.String roomInvStatusCode,
           java.lang.String roomName,
           java.lang.String roomTypeId,
           java.lang.String roomtypenum,
           java.lang.String roomurl) {
           this.area = area;
           this.availableAmount = availableAmount;
           this.beddescription = beddescription;
           this.bedtype = bedtype;
           this.floor = floor;
           this.hadbroadbandfee = hadbroadbandfee;
           this.hasbroadband = hasbroadband;
           this.isOverBooking = isOverBooking;
           this.note = note;
           this.ratePlanForGetHotelList = ratePlanForGetHotelList;
           this.roomImageCodes = roomImageCodes;
           this.roomInvStatusCode = roomInvStatusCode;
           this.roomName = roomName;
           this.roomTypeId = roomTypeId;
           this.roomtypenum = roomtypenum;
           this.roomurl = roomurl;
    }


    /**
     * Gets the area value for this RoomForHotel.
     * 
     * @return area
     */
    public java.lang.String getArea() {
        return area;
    }


    /**
     * Sets the area value for this RoomForHotel.
     * 
     * @param area
     */
    public void setArea(java.lang.String area) {
        this.area = area;
    }


    /**
     * Gets the availableAmount value for this RoomForHotel.
     * 
     * @return availableAmount
     */
    public int getAvailableAmount() {
        return availableAmount;
    }


    /**
     * Sets the availableAmount value for this RoomForHotel.
     * 
     * @param availableAmount
     */
    public void setAvailableAmount(int availableAmount) {
        this.availableAmount = availableAmount;
    }


    /**
     * Gets the beddescription value for this RoomForHotel.
     * 
     * @return beddescription
     */
    public java.lang.String getBeddescription() {
        return beddescription;
    }


    /**
     * Sets the beddescription value for this RoomForHotel.
     * 
     * @param beddescription
     */
    public void setBeddescription(java.lang.String beddescription) {
        this.beddescription = beddescription;
    }


    /**
     * Gets the bedtype value for this RoomForHotel.
     * 
     * @return bedtype
     */
    public java.lang.String getBedtype() {
        return bedtype;
    }


    /**
     * Sets the bedtype value for this RoomForHotel.
     * 
     * @param bedtype
     */
    public void setBedtype(java.lang.String bedtype) {
        this.bedtype = bedtype;
    }


    /**
     * Gets the floor value for this RoomForHotel.
     * 
     * @return floor
     */
    public java.lang.String getFloor() {
        return floor;
    }


    /**
     * Sets the floor value for this RoomForHotel.
     * 
     * @param floor
     */
    public void setFloor(java.lang.String floor) {
        this.floor = floor;
    }


    /**
     * Gets the hadbroadbandfee value for this RoomForHotel.
     * 
     * @return hadbroadbandfee
     */
    public java.lang.String getHadbroadbandfee() {
        return hadbroadbandfee;
    }


    /**
     * Sets the hadbroadbandfee value for this RoomForHotel.
     * 
     * @param hadbroadbandfee
     */
    public void setHadbroadbandfee(java.lang.String hadbroadbandfee) {
        this.hadbroadbandfee = hadbroadbandfee;
    }


    /**
     * Gets the hasbroadband value for this RoomForHotel.
     * 
     * @return hasbroadband
     */
    public java.lang.String getHasbroadband() {
        return hasbroadband;
    }


    /**
     * Sets the hasbroadband value for this RoomForHotel.
     * 
     * @param hasbroadband
     */
    public void setHasbroadband(java.lang.String hasbroadband) {
        this.hasbroadband = hasbroadband;
    }


    /**
     * Gets the isOverBooking value for this RoomForHotel.
     * 
     * @return isOverBooking
     */
    public java.lang.String getIsOverBooking() {
        return isOverBooking;
    }


    /**
     * Sets the isOverBooking value for this RoomForHotel.
     * 
     * @param isOverBooking
     */
    public void setIsOverBooking(java.lang.String isOverBooking) {
        this.isOverBooking = isOverBooking;
    }


    /**
     * Gets the note value for this RoomForHotel.
     * 
     * @return note
     */
    public java.lang.String getNote() {
        return note;
    }


    /**
     * Sets the note value for this RoomForHotel.
     * 
     * @param note
     */
    public void setNote(java.lang.String note) {
        this.note = note;
    }


    /**
     * Gets the ratePlanForGetHotelList value for this RoomForHotel.
     * 
     * @return ratePlanForGetHotelList
     */
    public cn.itkt.btsf.hotel.vo.RatePlanForHotel[] getRatePlanForGetHotelList() {
        return ratePlanForGetHotelList;
    }


    /**
     * Sets the ratePlanForGetHotelList value for this RoomForHotel.
     * 
     * @param ratePlanForGetHotelList
     */
    public void setRatePlanForGetHotelList(cn.itkt.btsf.hotel.vo.RatePlanForHotel[] ratePlanForGetHotelList) {
        this.ratePlanForGetHotelList = ratePlanForGetHotelList;
    }


    /**
     * Gets the roomImageCodes value for this RoomForHotel.
     * 
     * @return roomImageCodes
     */
    public java.lang.String[] getRoomImageCodes() {
        return roomImageCodes;
    }


    /**
     * Sets the roomImageCodes value for this RoomForHotel.
     * 
     * @param roomImageCodes
     */
    public void setRoomImageCodes(java.lang.String[] roomImageCodes) {
        this.roomImageCodes = roomImageCodes;
    }


    /**
     * Gets the roomInvStatusCode value for this RoomForHotel.
     * 
     * @return roomInvStatusCode
     */
    public java.lang.String getRoomInvStatusCode() {
        return roomInvStatusCode;
    }


    /**
     * Sets the roomInvStatusCode value for this RoomForHotel.
     * 
     * @param roomInvStatusCode
     */
    public void setRoomInvStatusCode(java.lang.String roomInvStatusCode) {
        this.roomInvStatusCode = roomInvStatusCode;
    }


    /**
     * Gets the roomName value for this RoomForHotel.
     * 
     * @return roomName
     */
    public java.lang.String getRoomName() {
        return roomName;
    }


    /**
     * Sets the roomName value for this RoomForHotel.
     * 
     * @param roomName
     */
    public void setRoomName(java.lang.String roomName) {
        this.roomName = roomName;
    }


    /**
     * Gets the roomTypeId value for this RoomForHotel.
     * 
     * @return roomTypeId
     */
    public java.lang.String getRoomTypeId() {
        return roomTypeId;
    }


    /**
     * Sets the roomTypeId value for this RoomForHotel.
     * 
     * @param roomTypeId
     */
    public void setRoomTypeId(java.lang.String roomTypeId) {
        this.roomTypeId = roomTypeId;
    }


    /**
     * Gets the roomtypenum value for this RoomForHotel.
     * 
     * @return roomtypenum
     */
    public java.lang.String getRoomtypenum() {
        return roomtypenum;
    }


    /**
     * Sets the roomtypenum value for this RoomForHotel.
     * 
     * @param roomtypenum
     */
    public void setRoomtypenum(java.lang.String roomtypenum) {
        this.roomtypenum = roomtypenum;
    }


    /**
     * Gets the roomurl value for this RoomForHotel.
     * 
     * @return roomurl
     */
    public java.lang.String getRoomurl() {
        return roomurl;
    }


    /**
     * Sets the roomurl value for this RoomForHotel.
     * 
     * @param roomurl
     */
    public void setRoomurl(java.lang.String roomurl) {
        this.roomurl = roomurl;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RoomForHotel)) return false;
        RoomForHotel other = (RoomForHotel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.area==null && other.getArea()==null) || 
             (this.area!=null &&
              this.area.equals(other.getArea()))) &&
            this.availableAmount == other.getAvailableAmount() &&
            ((this.beddescription==null && other.getBeddescription()==null) || 
             (this.beddescription!=null &&
              this.beddescription.equals(other.getBeddescription()))) &&
            ((this.bedtype==null && other.getBedtype()==null) || 
             (this.bedtype!=null &&
              this.bedtype.equals(other.getBedtype()))) &&
            ((this.floor==null && other.getFloor()==null) || 
             (this.floor!=null &&
              this.floor.equals(other.getFloor()))) &&
            ((this.hadbroadbandfee==null && other.getHadbroadbandfee()==null) || 
             (this.hadbroadbandfee!=null &&
              this.hadbroadbandfee.equals(other.getHadbroadbandfee()))) &&
            ((this.hasbroadband==null && other.getHasbroadband()==null) || 
             (this.hasbroadband!=null &&
              this.hasbroadband.equals(other.getHasbroadband()))) &&
            ((this.isOverBooking==null && other.getIsOverBooking()==null) || 
             (this.isOverBooking!=null &&
              this.isOverBooking.equals(other.getIsOverBooking()))) &&
            ((this.note==null && other.getNote()==null) || 
             (this.note!=null &&
              this.note.equals(other.getNote()))) &&
            ((this.ratePlanForGetHotelList==null && other.getRatePlanForGetHotelList()==null) || 
             (this.ratePlanForGetHotelList!=null &&
              java.util.Arrays.equals(this.ratePlanForGetHotelList, other.getRatePlanForGetHotelList()))) &&
            ((this.roomImageCodes==null && other.getRoomImageCodes()==null) || 
             (this.roomImageCodes!=null &&
              java.util.Arrays.equals(this.roomImageCodes, other.getRoomImageCodes()))) &&
            ((this.roomInvStatusCode==null && other.getRoomInvStatusCode()==null) || 
             (this.roomInvStatusCode!=null &&
              this.roomInvStatusCode.equals(other.getRoomInvStatusCode()))) &&
            ((this.roomName==null && other.getRoomName()==null) || 
             (this.roomName!=null &&
              this.roomName.equals(other.getRoomName()))) &&
            ((this.roomTypeId==null && other.getRoomTypeId()==null) || 
             (this.roomTypeId!=null &&
              this.roomTypeId.equals(other.getRoomTypeId()))) &&
            ((this.roomtypenum==null && other.getRoomtypenum()==null) || 
             (this.roomtypenum!=null &&
              this.roomtypenum.equals(other.getRoomtypenum()))) &&
            ((this.roomurl==null && other.getRoomurl()==null) || 
             (this.roomurl!=null &&
              this.roomurl.equals(other.getRoomurl())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getArea() != null) {
            _hashCode += getArea().hashCode();
        }
        _hashCode += getAvailableAmount();
        if (getBeddescription() != null) {
            _hashCode += getBeddescription().hashCode();
        }
        if (getBedtype() != null) {
            _hashCode += getBedtype().hashCode();
        }
        if (getFloor() != null) {
            _hashCode += getFloor().hashCode();
        }
        if (getHadbroadbandfee() != null) {
            _hashCode += getHadbroadbandfee().hashCode();
        }
        if (getHasbroadband() != null) {
            _hashCode += getHasbroadband().hashCode();
        }
        if (getIsOverBooking() != null) {
            _hashCode += getIsOverBooking().hashCode();
        }
        if (getNote() != null) {
            _hashCode += getNote().hashCode();
        }
        if (getRatePlanForGetHotelList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRatePlanForGetHotelList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRatePlanForGetHotelList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRoomImageCodes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRoomImageCodes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRoomImageCodes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRoomInvStatusCode() != null) {
            _hashCode += getRoomInvStatusCode().hashCode();
        }
        if (getRoomName() != null) {
            _hashCode += getRoomName().hashCode();
        }
        if (getRoomTypeId() != null) {
            _hashCode += getRoomTypeId().hashCode();
        }
        if (getRoomtypenum() != null) {
            _hashCode += getRoomtypenum().hashCode();
        }
        if (getRoomurl() != null) {
            _hashCode += getRoomurl().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RoomForHotel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RoomForHotel", "RoomForHotel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("area");
        elemField.setXmlName(new javax.xml.namespace.QName("", "area"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("availableAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "availableAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("beddescription");
        elemField.setXmlName(new javax.xml.namespace.QName("", "beddescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bedtype");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bedtype"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("floor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "floor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hadbroadbandfee");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hadbroadbandfee"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasbroadband");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hasbroadband"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isOverBooking");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isOverBooking"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("note");
        elemField.setXmlName(new javax.xml.namespace.QName("", "note"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ratePlanForGetHotelList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ratePlanForGetHotelList"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RatePlanForHotel", "RatePlanForHotel"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomImageCodes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomImageCodes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomInvStatusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomInvStatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomtypenum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomtypenum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomurl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomurl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
