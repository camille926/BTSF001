/**
 * HotelCommVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelCommVo  implements java.io.Serializable {
    private java.lang.String citycode;

    private java.lang.String commercialcode;

    private java.lang.String commercialname;

    public HotelCommVo() {
    }

    public HotelCommVo(
           java.lang.String citycode,
           java.lang.String commercialcode,
           java.lang.String commercialname) {
           this.citycode = citycode;
           this.commercialcode = commercialcode;
           this.commercialname = commercialname;
    }


    /**
     * Gets the citycode value for this HotelCommVo.
     * 
     * @return citycode
     */
    public java.lang.String getCitycode() {
        return citycode;
    }


    /**
     * Sets the citycode value for this HotelCommVo.
     * 
     * @param citycode
     */
    public void setCitycode(java.lang.String citycode) {
        this.citycode = citycode;
    }


    /**
     * Gets the commercialcode value for this HotelCommVo.
     * 
     * @return commercialcode
     */
    public java.lang.String getCommercialcode() {
        return commercialcode;
    }


    /**
     * Sets the commercialcode value for this HotelCommVo.
     * 
     * @param commercialcode
     */
    public void setCommercialcode(java.lang.String commercialcode) {
        this.commercialcode = commercialcode;
    }


    /**
     * Gets the commercialname value for this HotelCommVo.
     * 
     * @return commercialname
     */
    public java.lang.String getCommercialname() {
        return commercialname;
    }


    /**
     * Sets the commercialname value for this HotelCommVo.
     * 
     * @param commercialname
     */
    public void setCommercialname(java.lang.String commercialname) {
        this.commercialname = commercialname;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelCommVo)) return false;
        HotelCommVo other = (HotelCommVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.citycode==null && other.getCitycode()==null) || 
             (this.citycode!=null &&
              this.citycode.equals(other.getCitycode()))) &&
            ((this.commercialcode==null && other.getCommercialcode()==null) || 
             (this.commercialcode!=null &&
              this.commercialcode.equals(other.getCommercialcode()))) &&
            ((this.commercialname==null && other.getCommercialname()==null) || 
             (this.commercialname!=null &&
              this.commercialname.equals(other.getCommercialname())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCitycode() != null) {
            _hashCode += getCitycode().hashCode();
        }
        if (getCommercialcode() != null) {
            _hashCode += getCommercialcode().hashCode();
        }
        if (getCommercialname() != null) {
            _hashCode += getCommercialname().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelCommVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCommVo", "HotelCommVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("citycode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "citycode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commercialcode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commercialcode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commercialname");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commercialname"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
