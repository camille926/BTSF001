/**
 * ContacterForSubmitHotelOrder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class ContacterForSubmitHotelOrder  implements java.io.Serializable {
    private java.lang.String name;

    private java.lang.String genderCode;

    private java.lang.String email;

    private java.lang.String mobile;

    private java.lang.String idTypeCode;

    private java.lang.String idNumber;

    private cn.itkt.btsf.hotel.vo.PhoneForSubmitHotelOrder phone;

    private cn.itkt.btsf.hotel.vo.FaxForSubmitHotelOrder fax;

    public ContacterForSubmitHotelOrder() {
    }

    public ContacterForSubmitHotelOrder(
           java.lang.String name,
           java.lang.String genderCode,
           java.lang.String email,
           java.lang.String mobile,
           java.lang.String idTypeCode,
           java.lang.String idNumber,
           cn.itkt.btsf.hotel.vo.PhoneForSubmitHotelOrder phone,
           cn.itkt.btsf.hotel.vo.FaxForSubmitHotelOrder fax) {
           this.name = name;
           this.genderCode = genderCode;
           this.email = email;
           this.mobile = mobile;
           this.idTypeCode = idTypeCode;
           this.idNumber = idNumber;
           this.phone = phone;
           this.fax = fax;
    }


    /**
     * Gets the name value for this ContacterForSubmitHotelOrder.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ContacterForSubmitHotelOrder.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the genderCode value for this ContacterForSubmitHotelOrder.
     * 
     * @return genderCode
     */
    public java.lang.String getGenderCode() {
        return genderCode;
    }


    /**
     * Sets the genderCode value for this ContacterForSubmitHotelOrder.
     * 
     * @param genderCode
     */
    public void setGenderCode(java.lang.String genderCode) {
        this.genderCode = genderCode;
    }


    /**
     * Gets the email value for this ContacterForSubmitHotelOrder.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this ContacterForSubmitHotelOrder.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the mobile value for this ContacterForSubmitHotelOrder.
     * 
     * @return mobile
     */
    public java.lang.String getMobile() {
        return mobile;
    }


    /**
     * Sets the mobile value for this ContacterForSubmitHotelOrder.
     * 
     * @param mobile
     */
    public void setMobile(java.lang.String mobile) {
        this.mobile = mobile;
    }


    /**
     * Gets the idTypeCode value for this ContacterForSubmitHotelOrder.
     * 
     * @return idTypeCode
     */
    public java.lang.String getIdTypeCode() {
        return idTypeCode;
    }


    /**
     * Sets the idTypeCode value for this ContacterForSubmitHotelOrder.
     * 
     * @param idTypeCode
     */
    public void setIdTypeCode(java.lang.String idTypeCode) {
        this.idTypeCode = idTypeCode;
    }


    /**
     * Gets the idNumber value for this ContacterForSubmitHotelOrder.
     * 
     * @return idNumber
     */
    public java.lang.String getIdNumber() {
        return idNumber;
    }


    /**
     * Sets the idNumber value for this ContacterForSubmitHotelOrder.
     * 
     * @param idNumber
     */
    public void setIdNumber(java.lang.String idNumber) {
        this.idNumber = idNumber;
    }


    /**
     * Gets the phone value for this ContacterForSubmitHotelOrder.
     * 
     * @return phone
     */
    public cn.itkt.btsf.hotel.vo.PhoneForSubmitHotelOrder getPhone() {
        return phone;
    }


    /**
     * Sets the phone value for this ContacterForSubmitHotelOrder.
     * 
     * @param phone
     */
    public void setPhone(cn.itkt.btsf.hotel.vo.PhoneForSubmitHotelOrder phone) {
        this.phone = phone;
    }


    /**
     * Gets the fax value for this ContacterForSubmitHotelOrder.
     * 
     * @return fax
     */
    public cn.itkt.btsf.hotel.vo.FaxForSubmitHotelOrder getFax() {
        return fax;
    }


    /**
     * Sets the fax value for this ContacterForSubmitHotelOrder.
     * 
     * @param fax
     */
    public void setFax(cn.itkt.btsf.hotel.vo.FaxForSubmitHotelOrder fax) {
        this.fax = fax;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ContacterForSubmitHotelOrder)) return false;
        ContacterForSubmitHotelOrder other = (ContacterForSubmitHotelOrder) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.genderCode==null && other.getGenderCode()==null) || 
             (this.genderCode!=null &&
              this.genderCode.equals(other.getGenderCode()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.mobile==null && other.getMobile()==null) || 
             (this.mobile!=null &&
              this.mobile.equals(other.getMobile()))) &&
            ((this.idTypeCode==null && other.getIdTypeCode()==null) || 
             (this.idTypeCode!=null &&
              this.idTypeCode.equals(other.getIdTypeCode()))) &&
            ((this.idNumber==null && other.getIdNumber()==null) || 
             (this.idNumber!=null &&
              this.idNumber.equals(other.getIdNumber()))) &&
            ((this.phone==null && other.getPhone()==null) || 
             (this.phone!=null &&
              this.phone.equals(other.getPhone()))) &&
            ((this.fax==null && other.getFax()==null) || 
             (this.fax!=null &&
              this.fax.equals(other.getFax())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getGenderCode() != null) {
            _hashCode += getGenderCode().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getMobile() != null) {
            _hashCode += getMobile().hashCode();
        }
        if (getIdTypeCode() != null) {
            _hashCode += getIdTypeCode().hashCode();
        }
        if (getIdNumber() != null) {
            _hashCode += getIdNumber().hashCode();
        }
        if (getPhone() != null) {
            _hashCode += getPhone().hashCode();
        }
        if (getFax() != null) {
            _hashCode += getFax().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ContacterForSubmitHotelOrder.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://po.elong.air.litsoft.com", "ContacterForSubmitHotelOrder"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("genderCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "GenderCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mobile");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Mobile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idTypeCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IdTypeCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IdNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phone");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://elong.com/NorthBoundAPI/", "PhoneForSubmitHotelOrder"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fax");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Fax"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://elong.com/NorthBoundAPI/", "FaxForSubmitHotelOrder"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
