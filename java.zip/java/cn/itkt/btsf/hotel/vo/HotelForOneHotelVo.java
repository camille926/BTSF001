/**
 * HotelForOneHotelVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelForOneHotelVo  implements java.io.Serializable {
    private java.lang.String[] addValuesDescription;

    private java.lang.String availPolicy;

    private java.lang.String[] bookingRuless;

    private java.lang.String brandid;

    private java.lang.String ccaccepted;

    private java.lang.String citycode;

    private java.lang.Long commentAll;

    private java.lang.Long commentGood;

    private java.lang.String commercial;

    private java.lang.String commercialName;

    private java.lang.String conferenceamenities;

    private java.lang.String[] dRRRules;

    private java.lang.String diningaemnities;

    private java.lang.String district;

    private java.lang.String districtName;

    private java.lang.String fax;

    private java.lang.String featureinfo;

    private java.lang.String generaamenities;

    private java.lang.String hotelAddress;

    private java.lang.String hotelId;

    private java.lang.String[] hotelImageCodes;

    private java.lang.String hotelInvStatusCode;

    private java.lang.String hotelName;

    private java.lang.String hotelnameen;

    private java.lang.String hotelurl;

    private cn.itkt.btsf.hotel.vo.ImageForHotel[] imageForHotelList;

    private java.lang.String introeditor;

    private java.lang.String iseconomic;

    private java.lang.String latitude;

    private java.lang.String longdesc;

    private java.lang.String longitude;

    private java.math.BigDecimal lowestPrice;

    private java.lang.String openingdate;

    private java.lang.String phone;

    private java.lang.String por;

    private java.lang.String recreationamenities;

    private cn.itkt.btsf.hotel.vo.RoomForHotel[] roomForGetHoteList;

    private java.lang.String roomamenities;

    private java.lang.String roomnumber;

    private java.lang.String shortdesc;

    private java.lang.String starCode;

    private java.lang.String trafficandaroundinfo;

    private cn.itkt.btsf.hotel.vo.VouchInfo[] vouchInfos;

    public HotelForOneHotelVo() {
    }

    public HotelForOneHotelVo(
           java.lang.String[] addValuesDescription,
           java.lang.String availPolicy,
           java.lang.String[] bookingRuless,
           java.lang.String brandid,
           java.lang.String ccaccepted,
           java.lang.String citycode,
           java.lang.Long commentAll,
           java.lang.Long commentGood,
           java.lang.String commercial,
           java.lang.String commercialName,
           java.lang.String conferenceamenities,
           java.lang.String[] dRRRules,
           java.lang.String diningaemnities,
           java.lang.String district,
           java.lang.String districtName,
           java.lang.String fax,
           java.lang.String featureinfo,
           java.lang.String generaamenities,
           java.lang.String hotelAddress,
           java.lang.String hotelId,
           java.lang.String[] hotelImageCodes,
           java.lang.String hotelInvStatusCode,
           java.lang.String hotelName,
           java.lang.String hotelnameen,
           java.lang.String hotelurl,
           cn.itkt.btsf.hotel.vo.ImageForHotel[] imageForHotelList,
           java.lang.String introeditor,
           java.lang.String iseconomic,
           java.lang.String latitude,
           java.lang.String longdesc,
           java.lang.String longitude,
           java.math.BigDecimal lowestPrice,
           java.lang.String openingdate,
           java.lang.String phone,
           java.lang.String por,
           java.lang.String recreationamenities,
           cn.itkt.btsf.hotel.vo.RoomForHotel[] roomForGetHoteList,
           java.lang.String roomamenities,
           java.lang.String roomnumber,
           java.lang.String shortdesc,
           java.lang.String starCode,
           java.lang.String trafficandaroundinfo,
           cn.itkt.btsf.hotel.vo.VouchInfo[] vouchInfos) {
           this.addValuesDescription = addValuesDescription;
           this.availPolicy = availPolicy;
           this.bookingRuless = bookingRuless;
           this.brandid = brandid;
           this.ccaccepted = ccaccepted;
           this.citycode = citycode;
           this.commentAll = commentAll;
           this.commentGood = commentGood;
           this.commercial = commercial;
           this.commercialName = commercialName;
           this.conferenceamenities = conferenceamenities;
           this.dRRRules = dRRRules;
           this.diningaemnities = diningaemnities;
           this.district = district;
           this.districtName = districtName;
           this.fax = fax;
           this.featureinfo = featureinfo;
           this.generaamenities = generaamenities;
           this.hotelAddress = hotelAddress;
           this.hotelId = hotelId;
           this.hotelImageCodes = hotelImageCodes;
           this.hotelInvStatusCode = hotelInvStatusCode;
           this.hotelName = hotelName;
           this.hotelnameen = hotelnameen;
           this.hotelurl = hotelurl;
           this.imageForHotelList = imageForHotelList;
           this.introeditor = introeditor;
           this.iseconomic = iseconomic;
           this.latitude = latitude;
           this.longdesc = longdesc;
           this.longitude = longitude;
           this.lowestPrice = lowestPrice;
           this.openingdate = openingdate;
           this.phone = phone;
           this.por = por;
           this.recreationamenities = recreationamenities;
           this.roomForGetHoteList = roomForGetHoteList;
           this.roomamenities = roomamenities;
           this.roomnumber = roomnumber;
           this.shortdesc = shortdesc;
           this.starCode = starCode;
           this.trafficandaroundinfo = trafficandaroundinfo;
           this.vouchInfos = vouchInfos;
    }


    /**
     * Gets the addValuesDescription value for this HotelForOneHotelVo.
     * 
     * @return addValuesDescription
     */
    public java.lang.String[] getAddValuesDescription() {
        return addValuesDescription;
    }


    /**
     * Sets the addValuesDescription value for this HotelForOneHotelVo.
     * 
     * @param addValuesDescription
     */
    public void setAddValuesDescription(java.lang.String[] addValuesDescription) {
        this.addValuesDescription = addValuesDescription;
    }


    /**
     * Gets the availPolicy value for this HotelForOneHotelVo.
     * 
     * @return availPolicy
     */
    public java.lang.String getAvailPolicy() {
        return availPolicy;
    }


    /**
     * Sets the availPolicy value for this HotelForOneHotelVo.
     * 
     * @param availPolicy
     */
    public void setAvailPolicy(java.lang.String availPolicy) {
        this.availPolicy = availPolicy;
    }


    /**
     * Gets the bookingRuless value for this HotelForOneHotelVo.
     * 
     * @return bookingRuless
     */
    public java.lang.String[] getBookingRuless() {
        return bookingRuless;
    }


    /**
     * Sets the bookingRuless value for this HotelForOneHotelVo.
     * 
     * @param bookingRuless
     */
    public void setBookingRuless(java.lang.String[] bookingRuless) {
        this.bookingRuless = bookingRuless;
    }


    /**
     * Gets the brandid value for this HotelForOneHotelVo.
     * 
     * @return brandid
     */
    public java.lang.String getBrandid() {
        return brandid;
    }


    /**
     * Sets the brandid value for this HotelForOneHotelVo.
     * 
     * @param brandid
     */
    public void setBrandid(java.lang.String brandid) {
        this.brandid = brandid;
    }


    /**
     * Gets the ccaccepted value for this HotelForOneHotelVo.
     * 
     * @return ccaccepted
     */
    public java.lang.String getCcaccepted() {
        return ccaccepted;
    }


    /**
     * Sets the ccaccepted value for this HotelForOneHotelVo.
     * 
     * @param ccaccepted
     */
    public void setCcaccepted(java.lang.String ccaccepted) {
        this.ccaccepted = ccaccepted;
    }


    /**
     * Gets the citycode value for this HotelForOneHotelVo.
     * 
     * @return citycode
     */
    public java.lang.String getCitycode() {
        return citycode;
    }


    /**
     * Sets the citycode value for this HotelForOneHotelVo.
     * 
     * @param citycode
     */
    public void setCitycode(java.lang.String citycode) {
        this.citycode = citycode;
    }


    /**
     * Gets the commentAll value for this HotelForOneHotelVo.
     * 
     * @return commentAll
     */
    public java.lang.Long getCommentAll() {
        return commentAll;
    }


    /**
     * Sets the commentAll value for this HotelForOneHotelVo.
     * 
     * @param commentAll
     */
    public void setCommentAll(java.lang.Long commentAll) {
        this.commentAll = commentAll;
    }


    /**
     * Gets the commentGood value for this HotelForOneHotelVo.
     * 
     * @return commentGood
     */
    public java.lang.Long getCommentGood() {
        return commentGood;
    }


    /**
     * Sets the commentGood value for this HotelForOneHotelVo.
     * 
     * @param commentGood
     */
    public void setCommentGood(java.lang.Long commentGood) {
        this.commentGood = commentGood;
    }


    /**
     * Gets the commercial value for this HotelForOneHotelVo.
     * 
     * @return commercial
     */
    public java.lang.String getCommercial() {
        return commercial;
    }


    /**
     * Sets the commercial value for this HotelForOneHotelVo.
     * 
     * @param commercial
     */
    public void setCommercial(java.lang.String commercial) {
        this.commercial = commercial;
    }


    /**
     * Gets the commercialName value for this HotelForOneHotelVo.
     * 
     * @return commercialName
     */
    public java.lang.String getCommercialName() {
        return commercialName;
    }


    /**
     * Sets the commercialName value for this HotelForOneHotelVo.
     * 
     * @param commercialName
     */
    public void setCommercialName(java.lang.String commercialName) {
        this.commercialName = commercialName;
    }


    /**
     * Gets the conferenceamenities value for this HotelForOneHotelVo.
     * 
     * @return conferenceamenities
     */
    public java.lang.String getConferenceamenities() {
        return conferenceamenities;
    }


    /**
     * Sets the conferenceamenities value for this HotelForOneHotelVo.
     * 
     * @param conferenceamenities
     */
    public void setConferenceamenities(java.lang.String conferenceamenities) {
        this.conferenceamenities = conferenceamenities;
    }


    /**
     * Gets the dRRRules value for this HotelForOneHotelVo.
     * 
     * @return dRRRules
     */
    public java.lang.String[] getDRRRules() {
        return dRRRules;
    }


    /**
     * Sets the dRRRules value for this HotelForOneHotelVo.
     * 
     * @param dRRRules
     */
    public void setDRRRules(java.lang.String[] dRRRules) {
        this.dRRRules = dRRRules;
    }


    /**
     * Gets the diningaemnities value for this HotelForOneHotelVo.
     * 
     * @return diningaemnities
     */
    public java.lang.String getDiningaemnities() {
        return diningaemnities;
    }


    /**
     * Sets the diningaemnities value for this HotelForOneHotelVo.
     * 
     * @param diningaemnities
     */
    public void setDiningaemnities(java.lang.String diningaemnities) {
        this.diningaemnities = diningaemnities;
    }


    /**
     * Gets the district value for this HotelForOneHotelVo.
     * 
     * @return district
     */
    public java.lang.String getDistrict() {
        return district;
    }


    /**
     * Sets the district value for this HotelForOneHotelVo.
     * 
     * @param district
     */
    public void setDistrict(java.lang.String district) {
        this.district = district;
    }


    /**
     * Gets the districtName value for this HotelForOneHotelVo.
     * 
     * @return districtName
     */
    public java.lang.String getDistrictName() {
        return districtName;
    }


    /**
     * Sets the districtName value for this HotelForOneHotelVo.
     * 
     * @param districtName
     */
    public void setDistrictName(java.lang.String districtName) {
        this.districtName = districtName;
    }


    /**
     * Gets the fax value for this HotelForOneHotelVo.
     * 
     * @return fax
     */
    public java.lang.String getFax() {
        return fax;
    }


    /**
     * Sets the fax value for this HotelForOneHotelVo.
     * 
     * @param fax
     */
    public void setFax(java.lang.String fax) {
        this.fax = fax;
    }


    /**
     * Gets the featureinfo value for this HotelForOneHotelVo.
     * 
     * @return featureinfo
     */
    public java.lang.String getFeatureinfo() {
        return featureinfo;
    }


    /**
     * Sets the featureinfo value for this HotelForOneHotelVo.
     * 
     * @param featureinfo
     */
    public void setFeatureinfo(java.lang.String featureinfo) {
        this.featureinfo = featureinfo;
    }


    /**
     * Gets the generaamenities value for this HotelForOneHotelVo.
     * 
     * @return generaamenities
     */
    public java.lang.String getGeneraamenities() {
        return generaamenities;
    }


    /**
     * Sets the generaamenities value for this HotelForOneHotelVo.
     * 
     * @param generaamenities
     */
    public void setGeneraamenities(java.lang.String generaamenities) {
        this.generaamenities = generaamenities;
    }


    /**
     * Gets the hotelAddress value for this HotelForOneHotelVo.
     * 
     * @return hotelAddress
     */
    public java.lang.String getHotelAddress() {
        return hotelAddress;
    }


    /**
     * Sets the hotelAddress value for this HotelForOneHotelVo.
     * 
     * @param hotelAddress
     */
    public void setHotelAddress(java.lang.String hotelAddress) {
        this.hotelAddress = hotelAddress;
    }


    /**
     * Gets the hotelId value for this HotelForOneHotelVo.
     * 
     * @return hotelId
     */
    public java.lang.String getHotelId() {
        return hotelId;
    }


    /**
     * Sets the hotelId value for this HotelForOneHotelVo.
     * 
     * @param hotelId
     */
    public void setHotelId(java.lang.String hotelId) {
        this.hotelId = hotelId;
    }


    /**
     * Gets the hotelImageCodes value for this HotelForOneHotelVo.
     * 
     * @return hotelImageCodes
     */
    public java.lang.String[] getHotelImageCodes() {
        return hotelImageCodes;
    }


    /**
     * Sets the hotelImageCodes value for this HotelForOneHotelVo.
     * 
     * @param hotelImageCodes
     */
    public void setHotelImageCodes(java.lang.String[] hotelImageCodes) {
        this.hotelImageCodes = hotelImageCodes;
    }


    /**
     * Gets the hotelInvStatusCode value for this HotelForOneHotelVo.
     * 
     * @return hotelInvStatusCode
     */
    public java.lang.String getHotelInvStatusCode() {
        return hotelInvStatusCode;
    }


    /**
     * Sets the hotelInvStatusCode value for this HotelForOneHotelVo.
     * 
     * @param hotelInvStatusCode
     */
    public void setHotelInvStatusCode(java.lang.String hotelInvStatusCode) {
        this.hotelInvStatusCode = hotelInvStatusCode;
    }


    /**
     * Gets the hotelName value for this HotelForOneHotelVo.
     * 
     * @return hotelName
     */
    public java.lang.String getHotelName() {
        return hotelName;
    }


    /**
     * Sets the hotelName value for this HotelForOneHotelVo.
     * 
     * @param hotelName
     */
    public void setHotelName(java.lang.String hotelName) {
        this.hotelName = hotelName;
    }


    /**
     * Gets the hotelnameen value for this HotelForOneHotelVo.
     * 
     * @return hotelnameen
     */
    public java.lang.String getHotelnameen() {
        return hotelnameen;
    }


    /**
     * Sets the hotelnameen value for this HotelForOneHotelVo.
     * 
     * @param hotelnameen
     */
    public void setHotelnameen(java.lang.String hotelnameen) {
        this.hotelnameen = hotelnameen;
    }


    /**
     * Gets the hotelurl value for this HotelForOneHotelVo.
     * 
     * @return hotelurl
     */
    public java.lang.String getHotelurl() {
        return hotelurl;
    }


    /**
     * Sets the hotelurl value for this HotelForOneHotelVo.
     * 
     * @param hotelurl
     */
    public void setHotelurl(java.lang.String hotelurl) {
        this.hotelurl = hotelurl;
    }


    /**
     * Gets the imageForHotelList value for this HotelForOneHotelVo.
     * 
     * @return imageForHotelList
     */
    public cn.itkt.btsf.hotel.vo.ImageForHotel[] getImageForHotelList() {
        return imageForHotelList;
    }


    /**
     * Sets the imageForHotelList value for this HotelForOneHotelVo.
     * 
     * @param imageForHotelList
     */
    public void setImageForHotelList(cn.itkt.btsf.hotel.vo.ImageForHotel[] imageForHotelList) {
        this.imageForHotelList = imageForHotelList;
    }


    /**
     * Gets the introeditor value for this HotelForOneHotelVo.
     * 
     * @return introeditor
     */
    public java.lang.String getIntroeditor() {
        return introeditor;
    }


    /**
     * Sets the introeditor value for this HotelForOneHotelVo.
     * 
     * @param introeditor
     */
    public void setIntroeditor(java.lang.String introeditor) {
        this.introeditor = introeditor;
    }


    /**
     * Gets the iseconomic value for this HotelForOneHotelVo.
     * 
     * @return iseconomic
     */
    public java.lang.String getIseconomic() {
        return iseconomic;
    }


    /**
     * Sets the iseconomic value for this HotelForOneHotelVo.
     * 
     * @param iseconomic
     */
    public void setIseconomic(java.lang.String iseconomic) {
        this.iseconomic = iseconomic;
    }


    /**
     * Gets the latitude value for this HotelForOneHotelVo.
     * 
     * @return latitude
     */
    public java.lang.String getLatitude() {
        return latitude;
    }


    /**
     * Sets the latitude value for this HotelForOneHotelVo.
     * 
     * @param latitude
     */
    public void setLatitude(java.lang.String latitude) {
        this.latitude = latitude;
    }


    /**
     * Gets the longdesc value for this HotelForOneHotelVo.
     * 
     * @return longdesc
     */
    public java.lang.String getLongdesc() {
        return longdesc;
    }


    /**
     * Sets the longdesc value for this HotelForOneHotelVo.
     * 
     * @param longdesc
     */
    public void setLongdesc(java.lang.String longdesc) {
        this.longdesc = longdesc;
    }


    /**
     * Gets the longitude value for this HotelForOneHotelVo.
     * 
     * @return longitude
     */
    public java.lang.String getLongitude() {
        return longitude;
    }


    /**
     * Sets the longitude value for this HotelForOneHotelVo.
     * 
     * @param longitude
     */
    public void setLongitude(java.lang.String longitude) {
        this.longitude = longitude;
    }


    /**
     * Gets the lowestPrice value for this HotelForOneHotelVo.
     * 
     * @return lowestPrice
     */
    public java.math.BigDecimal getLowestPrice() {
        return lowestPrice;
    }


    /**
     * Sets the lowestPrice value for this HotelForOneHotelVo.
     * 
     * @param lowestPrice
     */
    public void setLowestPrice(java.math.BigDecimal lowestPrice) {
        this.lowestPrice = lowestPrice;
    }


    /**
     * Gets the openingdate value for this HotelForOneHotelVo.
     * 
     * @return openingdate
     */
    public java.lang.String getOpeningdate() {
        return openingdate;
    }


    /**
     * Sets the openingdate value for this HotelForOneHotelVo.
     * 
     * @param openingdate
     */
    public void setOpeningdate(java.lang.String openingdate) {
        this.openingdate = openingdate;
    }


    /**
     * Gets the phone value for this HotelForOneHotelVo.
     * 
     * @return phone
     */
    public java.lang.String getPhone() {
        return phone;
    }


    /**
     * Sets the phone value for this HotelForOneHotelVo.
     * 
     * @param phone
     */
    public void setPhone(java.lang.String phone) {
        this.phone = phone;
    }


    /**
     * Gets the por value for this HotelForOneHotelVo.
     * 
     * @return por
     */
    public java.lang.String getPor() {
        return por;
    }


    /**
     * Sets the por value for this HotelForOneHotelVo.
     * 
     * @param por
     */
    public void setPor(java.lang.String por) {
        this.por = por;
    }


    /**
     * Gets the recreationamenities value for this HotelForOneHotelVo.
     * 
     * @return recreationamenities
     */
    public java.lang.String getRecreationamenities() {
        return recreationamenities;
    }


    /**
     * Sets the recreationamenities value for this HotelForOneHotelVo.
     * 
     * @param recreationamenities
     */
    public void setRecreationamenities(java.lang.String recreationamenities) {
        this.recreationamenities = recreationamenities;
    }


    /**
     * Gets the roomForGetHoteList value for this HotelForOneHotelVo.
     * 
     * @return roomForGetHoteList
     */
    public cn.itkt.btsf.hotel.vo.RoomForHotel[] getRoomForGetHoteList() {
        return roomForGetHoteList;
    }


    /**
     * Sets the roomForGetHoteList value for this HotelForOneHotelVo.
     * 
     * @param roomForGetHoteList
     */
    public void setRoomForGetHoteList(cn.itkt.btsf.hotel.vo.RoomForHotel[] roomForGetHoteList) {
        this.roomForGetHoteList = roomForGetHoteList;
    }


    /**
     * Gets the roomamenities value for this HotelForOneHotelVo.
     * 
     * @return roomamenities
     */
    public java.lang.String getRoomamenities() {
        return roomamenities;
    }


    /**
     * Sets the roomamenities value for this HotelForOneHotelVo.
     * 
     * @param roomamenities
     */
    public void setRoomamenities(java.lang.String roomamenities) {
        this.roomamenities = roomamenities;
    }


    /**
     * Gets the roomnumber value for this HotelForOneHotelVo.
     * 
     * @return roomnumber
     */
    public java.lang.String getRoomnumber() {
        return roomnumber;
    }


    /**
     * Sets the roomnumber value for this HotelForOneHotelVo.
     * 
     * @param roomnumber
     */
    public void setRoomnumber(java.lang.String roomnumber) {
        this.roomnumber = roomnumber;
    }


    /**
     * Gets the shortdesc value for this HotelForOneHotelVo.
     * 
     * @return shortdesc
     */
    public java.lang.String getShortdesc() {
        return shortdesc;
    }


    /**
     * Sets the shortdesc value for this HotelForOneHotelVo.
     * 
     * @param shortdesc
     */
    public void setShortdesc(java.lang.String shortdesc) {
        this.shortdesc = shortdesc;
    }


    /**
     * Gets the starCode value for this HotelForOneHotelVo.
     * 
     * @return starCode
     */
    public java.lang.String getStarCode() {
        return starCode;
    }


    /**
     * Sets the starCode value for this HotelForOneHotelVo.
     * 
     * @param starCode
     */
    public void setStarCode(java.lang.String starCode) {
        this.starCode = starCode;
    }


    /**
     * Gets the trafficandaroundinfo value for this HotelForOneHotelVo.
     * 
     * @return trafficandaroundinfo
     */
    public java.lang.String getTrafficandaroundinfo() {
        return trafficandaroundinfo;
    }


    /**
     * Sets the trafficandaroundinfo value for this HotelForOneHotelVo.
     * 
     * @param trafficandaroundinfo
     */
    public void setTrafficandaroundinfo(java.lang.String trafficandaroundinfo) {
        this.trafficandaroundinfo = trafficandaroundinfo;
    }


    /**
     * Gets the vouchInfos value for this HotelForOneHotelVo.
     * 
     * @return vouchInfos
     */
    public cn.itkt.btsf.hotel.vo.VouchInfo[] getVouchInfos() {
        return vouchInfos;
    }


    /**
     * Sets the vouchInfos value for this HotelForOneHotelVo.
     * 
     * @param vouchInfos
     */
    public void setVouchInfos(cn.itkt.btsf.hotel.vo.VouchInfo[] vouchInfos) {
        this.vouchInfos = vouchInfos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelForOneHotelVo)) return false;
        HotelForOneHotelVo other = (HotelForOneHotelVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.addValuesDescription==null && other.getAddValuesDescription()==null) || 
             (this.addValuesDescription!=null &&
              java.util.Arrays.equals(this.addValuesDescription, other.getAddValuesDescription()))) &&
            ((this.availPolicy==null && other.getAvailPolicy()==null) || 
             (this.availPolicy!=null &&
              this.availPolicy.equals(other.getAvailPolicy()))) &&
            ((this.bookingRuless==null && other.getBookingRuless()==null) || 
             (this.bookingRuless!=null &&
              java.util.Arrays.equals(this.bookingRuless, other.getBookingRuless()))) &&
            ((this.brandid==null && other.getBrandid()==null) || 
             (this.brandid!=null &&
              this.brandid.equals(other.getBrandid()))) &&
            ((this.ccaccepted==null && other.getCcaccepted()==null) || 
             (this.ccaccepted!=null &&
              this.ccaccepted.equals(other.getCcaccepted()))) &&
            ((this.citycode==null && other.getCitycode()==null) || 
             (this.citycode!=null &&
              this.citycode.equals(other.getCitycode()))) &&
            ((this.commentAll==null && other.getCommentAll()==null) || 
             (this.commentAll!=null &&
              this.commentAll.equals(other.getCommentAll()))) &&
            ((this.commentGood==null && other.getCommentGood()==null) || 
             (this.commentGood!=null &&
              this.commentGood.equals(other.getCommentGood()))) &&
            ((this.commercial==null && other.getCommercial()==null) || 
             (this.commercial!=null &&
              this.commercial.equals(other.getCommercial()))) &&
            ((this.commercialName==null && other.getCommercialName()==null) || 
             (this.commercialName!=null &&
              this.commercialName.equals(other.getCommercialName()))) &&
            ((this.conferenceamenities==null && other.getConferenceamenities()==null) || 
             (this.conferenceamenities!=null &&
              this.conferenceamenities.equals(other.getConferenceamenities()))) &&
            ((this.dRRRules==null && other.getDRRRules()==null) || 
             (this.dRRRules!=null &&
              java.util.Arrays.equals(this.dRRRules, other.getDRRRules()))) &&
            ((this.diningaemnities==null && other.getDiningaemnities()==null) || 
             (this.diningaemnities!=null &&
              this.diningaemnities.equals(other.getDiningaemnities()))) &&
            ((this.district==null && other.getDistrict()==null) || 
             (this.district!=null &&
              this.district.equals(other.getDistrict()))) &&
            ((this.districtName==null && other.getDistrictName()==null) || 
             (this.districtName!=null &&
              this.districtName.equals(other.getDistrictName()))) &&
            ((this.fax==null && other.getFax()==null) || 
             (this.fax!=null &&
              this.fax.equals(other.getFax()))) &&
            ((this.featureinfo==null && other.getFeatureinfo()==null) || 
             (this.featureinfo!=null &&
              this.featureinfo.equals(other.getFeatureinfo()))) &&
            ((this.generaamenities==null && other.getGeneraamenities()==null) || 
             (this.generaamenities!=null &&
              this.generaamenities.equals(other.getGeneraamenities()))) &&
            ((this.hotelAddress==null && other.getHotelAddress()==null) || 
             (this.hotelAddress!=null &&
              this.hotelAddress.equals(other.getHotelAddress()))) &&
            ((this.hotelId==null && other.getHotelId()==null) || 
             (this.hotelId!=null &&
              this.hotelId.equals(other.getHotelId()))) &&
            ((this.hotelImageCodes==null && other.getHotelImageCodes()==null) || 
             (this.hotelImageCodes!=null &&
              java.util.Arrays.equals(this.hotelImageCodes, other.getHotelImageCodes()))) &&
            ((this.hotelInvStatusCode==null && other.getHotelInvStatusCode()==null) || 
             (this.hotelInvStatusCode!=null &&
              this.hotelInvStatusCode.equals(other.getHotelInvStatusCode()))) &&
            ((this.hotelName==null && other.getHotelName()==null) || 
             (this.hotelName!=null &&
              this.hotelName.equals(other.getHotelName()))) &&
            ((this.hotelnameen==null && other.getHotelnameen()==null) || 
             (this.hotelnameen!=null &&
              this.hotelnameen.equals(other.getHotelnameen()))) &&
            ((this.hotelurl==null && other.getHotelurl()==null) || 
             (this.hotelurl!=null &&
              this.hotelurl.equals(other.getHotelurl()))) &&
            ((this.imageForHotelList==null && other.getImageForHotelList()==null) || 
             (this.imageForHotelList!=null &&
              java.util.Arrays.equals(this.imageForHotelList, other.getImageForHotelList()))) &&
            ((this.introeditor==null && other.getIntroeditor()==null) || 
             (this.introeditor!=null &&
              this.introeditor.equals(other.getIntroeditor()))) &&
            ((this.iseconomic==null && other.getIseconomic()==null) || 
             (this.iseconomic!=null &&
              this.iseconomic.equals(other.getIseconomic()))) &&
            ((this.latitude==null && other.getLatitude()==null) || 
             (this.latitude!=null &&
              this.latitude.equals(other.getLatitude()))) &&
            ((this.longdesc==null && other.getLongdesc()==null) || 
             (this.longdesc!=null &&
              this.longdesc.equals(other.getLongdesc()))) &&
            ((this.longitude==null && other.getLongitude()==null) || 
             (this.longitude!=null &&
              this.longitude.equals(other.getLongitude()))) &&
            ((this.lowestPrice==null && other.getLowestPrice()==null) || 
             (this.lowestPrice!=null &&
              this.lowestPrice.equals(other.getLowestPrice()))) &&
            ((this.openingdate==null && other.getOpeningdate()==null) || 
             (this.openingdate!=null &&
              this.openingdate.equals(other.getOpeningdate()))) &&
            ((this.phone==null && other.getPhone()==null) || 
             (this.phone!=null &&
              this.phone.equals(other.getPhone()))) &&
            ((this.por==null && other.getPor()==null) || 
             (this.por!=null &&
              this.por.equals(other.getPor()))) &&
            ((this.recreationamenities==null && other.getRecreationamenities()==null) || 
             (this.recreationamenities!=null &&
              this.recreationamenities.equals(other.getRecreationamenities()))) &&
            ((this.roomForGetHoteList==null && other.getRoomForGetHoteList()==null) || 
             (this.roomForGetHoteList!=null &&
              java.util.Arrays.equals(this.roomForGetHoteList, other.getRoomForGetHoteList()))) &&
            ((this.roomamenities==null && other.getRoomamenities()==null) || 
             (this.roomamenities!=null &&
              this.roomamenities.equals(other.getRoomamenities()))) &&
            ((this.roomnumber==null && other.getRoomnumber()==null) || 
             (this.roomnumber!=null &&
              this.roomnumber.equals(other.getRoomnumber()))) &&
            ((this.shortdesc==null && other.getShortdesc()==null) || 
             (this.shortdesc!=null &&
              this.shortdesc.equals(other.getShortdesc()))) &&
            ((this.starCode==null && other.getStarCode()==null) || 
             (this.starCode!=null &&
              this.starCode.equals(other.getStarCode()))) &&
            ((this.trafficandaroundinfo==null && other.getTrafficandaroundinfo()==null) || 
             (this.trafficandaroundinfo!=null &&
              this.trafficandaroundinfo.equals(other.getTrafficandaroundinfo()))) &&
            ((this.vouchInfos==null && other.getVouchInfos()==null) || 
             (this.vouchInfos!=null &&
              java.util.Arrays.equals(this.vouchInfos, other.getVouchInfos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAddValuesDescription() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAddValuesDescription());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAddValuesDescription(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAvailPolicy() != null) {
            _hashCode += getAvailPolicy().hashCode();
        }
        if (getBookingRuless() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBookingRuless());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBookingRuless(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getBrandid() != null) {
            _hashCode += getBrandid().hashCode();
        }
        if (getCcaccepted() != null) {
            _hashCode += getCcaccepted().hashCode();
        }
        if (getCitycode() != null) {
            _hashCode += getCitycode().hashCode();
        }
        if (getCommentAll() != null) {
            _hashCode += getCommentAll().hashCode();
        }
        if (getCommentGood() != null) {
            _hashCode += getCommentGood().hashCode();
        }
        if (getCommercial() != null) {
            _hashCode += getCommercial().hashCode();
        }
        if (getCommercialName() != null) {
            _hashCode += getCommercialName().hashCode();
        }
        if (getConferenceamenities() != null) {
            _hashCode += getConferenceamenities().hashCode();
        }
        if (getDRRRules() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDRRRules());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDRRRules(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDiningaemnities() != null) {
            _hashCode += getDiningaemnities().hashCode();
        }
        if (getDistrict() != null) {
            _hashCode += getDistrict().hashCode();
        }
        if (getDistrictName() != null) {
            _hashCode += getDistrictName().hashCode();
        }
        if (getFax() != null) {
            _hashCode += getFax().hashCode();
        }
        if (getFeatureinfo() != null) {
            _hashCode += getFeatureinfo().hashCode();
        }
        if (getGeneraamenities() != null) {
            _hashCode += getGeneraamenities().hashCode();
        }
        if (getHotelAddress() != null) {
            _hashCode += getHotelAddress().hashCode();
        }
        if (getHotelId() != null) {
            _hashCode += getHotelId().hashCode();
        }
        if (getHotelImageCodes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getHotelImageCodes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getHotelImageCodes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHotelInvStatusCode() != null) {
            _hashCode += getHotelInvStatusCode().hashCode();
        }
        if (getHotelName() != null) {
            _hashCode += getHotelName().hashCode();
        }
        if (getHotelnameen() != null) {
            _hashCode += getHotelnameen().hashCode();
        }
        if (getHotelurl() != null) {
            _hashCode += getHotelurl().hashCode();
        }
        if (getImageForHotelList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getImageForHotelList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getImageForHotelList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIntroeditor() != null) {
            _hashCode += getIntroeditor().hashCode();
        }
        if (getIseconomic() != null) {
            _hashCode += getIseconomic().hashCode();
        }
        if (getLatitude() != null) {
            _hashCode += getLatitude().hashCode();
        }
        if (getLongdesc() != null) {
            _hashCode += getLongdesc().hashCode();
        }
        if (getLongitude() != null) {
            _hashCode += getLongitude().hashCode();
        }
        if (getLowestPrice() != null) {
            _hashCode += getLowestPrice().hashCode();
        }
        if (getOpeningdate() != null) {
            _hashCode += getOpeningdate().hashCode();
        }
        if (getPhone() != null) {
            _hashCode += getPhone().hashCode();
        }
        if (getPor() != null) {
            _hashCode += getPor().hashCode();
        }
        if (getRecreationamenities() != null) {
            _hashCode += getRecreationamenities().hashCode();
        }
        if (getRoomForGetHoteList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRoomForGetHoteList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRoomForGetHoteList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRoomamenities() != null) {
            _hashCode += getRoomamenities().hashCode();
        }
        if (getRoomnumber() != null) {
            _hashCode += getRoomnumber().hashCode();
        }
        if (getShortdesc() != null) {
            _hashCode += getShortdesc().hashCode();
        }
        if (getStarCode() != null) {
            _hashCode += getStarCode().hashCode();
        }
        if (getTrafficandaroundinfo() != null) {
            _hashCode += getTrafficandaroundinfo().hashCode();
        }
        if (getVouchInfos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getVouchInfos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getVouchInfos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelForOneHotelVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelForOneHotelVo", "HotelForOneHotelVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addValuesDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("", "addValuesDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("availPolicy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "availPolicy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bookingRuless");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bookingRuless"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ccaccepted");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ccaccepted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("citycode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "citycode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commentAll");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commentAll"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commentGood");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commentGood"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commercial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commercialName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commercialName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceamenities");
        elemField.setXmlName(new javax.xml.namespace.QName("", "conferenceamenities"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DRRRules");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dRRRules"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("diningaemnities");
        elemField.setXmlName(new javax.xml.namespace.QName("", "diningaemnities"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("district");
        elemField.setXmlName(new javax.xml.namespace.QName("", "district"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("districtName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "districtName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fax");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fax"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("featureinfo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "featureinfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("generaamenities");
        elemField.setXmlName(new javax.xml.namespace.QName("", "generaamenities"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelImageCodes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelImageCodes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelInvStatusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelInvStatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelnameen");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelnameen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelurl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelurl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("imageForHotelList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "imageForHotelList"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.ImageForHotel", "ImageForHotel"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("introeditor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "introeditor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iseconomic");
        elemField.setXmlName(new javax.xml.namespace.QName("", "iseconomic"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("latitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "latitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("longdesc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "longdesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("longitude");
        elemField.setXmlName(new javax.xml.namespace.QName("", "longitude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowestPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lowestPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openingdate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "openingdate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("phone");
        elemField.setXmlName(new javax.xml.namespace.QName("", "phone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("por");
        elemField.setXmlName(new javax.xml.namespace.QName("", "por"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recreationamenities");
        elemField.setXmlName(new javax.xml.namespace.QName("", "recreationamenities"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomForGetHoteList");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomForGetHoteList"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RoomForHotel", "RoomForHotel"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomamenities");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomamenities"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomnumber");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomnumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shortdesc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "shortdesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("starCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "starCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trafficandaroundinfo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "trafficandaroundinfo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vouchInfos");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vouchInfos"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.VouchInfo", "VouchInfo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
