package cn.itkt.btsf.hotel.vo;

import java.io.Serializable;
import java.util.Date;

/**
 * 类: SubmitOrderResultVo <br>
 * 描述: 提交订单结果Vo <br>
 * 作者: 王鹏 wangpeng@itkt.com <br>
 * 时间: 2013-2-26 下午3:59:30
 */
public class OrderSubmitVo extends BaseVo implements Serializable {

	private static final long serialVersionUID = -6862131812567392441L;

	/** 酒店订单id */
	private String orderId;
	/** 隆畅达订单ID */
	private String lcdOrderId;
	/** 最晚取消时间 */
	private Date cancelDate;

	/**
	 * 返回: the orderId <br>
	 * 时间: 2013-2-26 下午3:59:17
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * 参数: orderId to set the orderId <br>
	 * 时间: 2013-2-26 下午3:59:17
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * 返回: the lcdOrderId <br>
	 * 时间: 2013-2-26 下午3:59:17
	 */
	public String getLcdOrderId() {
		return lcdOrderId;
	}

	/**
	 * 参数: lcdOrderId to set the lcdOrderId <br>
	 * 时间: 2013-2-26 下午3:59:17
	 */
	public void setLcdOrderId(String lcdOrderId) {
		this.lcdOrderId = lcdOrderId;
	}

	/**
	 * 返回: the cancelDate <br>
	 * 时间: 2013-2-26 下午3:59:17
	 */
	public Date getCancelDate() {
		return cancelDate;
	}

	/**
	 * 参数: cancelDate to set the cancelDate <br>
	 * 时间: 2013-2-26 下午3:59:17
	 */
	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}
}
