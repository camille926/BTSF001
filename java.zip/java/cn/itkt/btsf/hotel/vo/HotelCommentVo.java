/**
 * HotelCommentVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelCommentVo  extends cn.itkt.btsf.hotel.vo.BaseVo  implements java.io.Serializable {
    private java.lang.Integer badComment;

    private cn.itkt.btsf.hotel.vo.CommentItem[] commentlist;

    private java.lang.Integer goodComment;

    private java.lang.Integer totalComment;

    public HotelCommentVo() {
    }

    public HotelCommentVo(
           java.lang.String message,
           java.lang.String status,
           java.lang.Integer badComment,
           cn.itkt.btsf.hotel.vo.CommentItem[] commentlist,
           java.lang.Integer goodComment,
           java.lang.Integer totalComment) {
        super(
            message,
            status);
        this.badComment = badComment;
        this.commentlist = commentlist;
        this.goodComment = goodComment;
        this.totalComment = totalComment;
    }


    /**
     * Gets the badComment value for this HotelCommentVo.
     * 
     * @return badComment
     */
    public java.lang.Integer getBadComment() {
        return badComment;
    }


    /**
     * Sets the badComment value for this HotelCommentVo.
     * 
     * @param badComment
     */
    public void setBadComment(java.lang.Integer badComment) {
        this.badComment = badComment;
    }


    /**
     * Gets the commentlist value for this HotelCommentVo.
     * 
     * @return commentlist
     */
    public cn.itkt.btsf.hotel.vo.CommentItem[] getCommentlist() {
        return commentlist;
    }


    /**
     * Sets the commentlist value for this HotelCommentVo.
     * 
     * @param commentlist
     */
    public void setCommentlist(cn.itkt.btsf.hotel.vo.CommentItem[] commentlist) {
        this.commentlist = commentlist;
    }


    /**
     * Gets the goodComment value for this HotelCommentVo.
     * 
     * @return goodComment
     */
    public java.lang.Integer getGoodComment() {
        return goodComment;
    }


    /**
     * Sets the goodComment value for this HotelCommentVo.
     * 
     * @param goodComment
     */
    public void setGoodComment(java.lang.Integer goodComment) {
        this.goodComment = goodComment;
    }


    /**
     * Gets the totalComment value for this HotelCommentVo.
     * 
     * @return totalComment
     */
    public java.lang.Integer getTotalComment() {
        return totalComment;
    }


    /**
     * Sets the totalComment value for this HotelCommentVo.
     * 
     * @param totalComment
     */
    public void setTotalComment(java.lang.Integer totalComment) {
        this.totalComment = totalComment;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelCommentVo)) return false;
        HotelCommentVo other = (HotelCommentVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.badComment==null && other.getBadComment()==null) || 
             (this.badComment!=null &&
              this.badComment.equals(other.getBadComment()))) &&
            ((this.commentlist==null && other.getCommentlist()==null) || 
             (this.commentlist!=null &&
              java.util.Arrays.equals(this.commentlist, other.getCommentlist()))) &&
            ((this.goodComment==null && other.getGoodComment()==null) || 
             (this.goodComment!=null &&
              this.goodComment.equals(other.getGoodComment()))) &&
            ((this.totalComment==null && other.getTotalComment()==null) || 
             (this.totalComment!=null &&
              this.totalComment.equals(other.getTotalComment())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBadComment() != null) {
            _hashCode += getBadComment().hashCode();
        }
        if (getCommentlist() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCommentlist());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCommentlist(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGoodComment() != null) {
            _hashCode += getGoodComment().hashCode();
        }
        if (getTotalComment() != null) {
            _hashCode += getTotalComment().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelCommentVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelCommentVo", "HotelCommentVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("badComment");
        elemField.setXmlName(new javax.xml.namespace.QName("", "badComment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commentlist");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commentlist"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.CommentItem", "CommentItem"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("goodComment");
        elemField.setXmlName(new javax.xml.namespace.QName("", "goodComment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("totalComment");
        elemField.setXmlName(new javax.xml.namespace.QName("", "totalComment"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
