/**
 * HotelOrderDetailVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelOrderDetailVo  implements java.io.Serializable {
    private java.lang.String arrivalEarlyTime;

    private java.lang.String arrivalLateTime;

    private java.lang.String bookTime;

    private java.lang.String checkInDate;

    private java.lang.String checkOutDate;

    private java.lang.String contacterMobile;

    private java.lang.String contacterName;

    private java.lang.String guestName;

    private boolean hasVouch;

    private java.lang.String hotelAddress;

    private java.lang.String hotelName;

    private long orderId;

    private java.lang.String orderSource;

    private java.lang.String orderStatus;

    private java.lang.String orderTime;

    private java.lang.String paymentType;

    private double price;

    private int returnLcdCurrency;

    private int roomAmount;

    private java.lang.String roomType;

    public HotelOrderDetailVo() {
    }

    public HotelOrderDetailVo(
           java.lang.String arrivalEarlyTime,
           java.lang.String arrivalLateTime,
           java.lang.String bookTime,
           java.lang.String checkInDate,
           java.lang.String checkOutDate,
           java.lang.String contacterMobile,
           java.lang.String contacterName,
           java.lang.String guestName,
           boolean hasVouch,
           java.lang.String hotelAddress,
           java.lang.String hotelName,
           long orderId,
           java.lang.String orderSource,
           java.lang.String orderStatus,
           java.lang.String orderTime,
           java.lang.String paymentType,
           double price,
           int returnLcdCurrency,
           int roomAmount,
           java.lang.String roomType) {
           this.arrivalEarlyTime = arrivalEarlyTime;
           this.arrivalLateTime = arrivalLateTime;
           this.bookTime = bookTime;
           this.checkInDate = checkInDate;
           this.checkOutDate = checkOutDate;
           this.contacterMobile = contacterMobile;
           this.contacterName = contacterName;
           this.guestName = guestName;
           this.hasVouch = hasVouch;
           this.hotelAddress = hotelAddress;
           this.hotelName = hotelName;
           this.orderId = orderId;
           this.orderSource = orderSource;
           this.orderStatus = orderStatus;
           this.orderTime = orderTime;
           this.paymentType = paymentType;
           this.price = price;
           this.returnLcdCurrency = returnLcdCurrency;
           this.roomAmount = roomAmount;
           this.roomType = roomType;
    }


    /**
     * Gets the arrivalEarlyTime value for this HotelOrderDetailVo.
     * 
     * @return arrivalEarlyTime
     */
    public java.lang.String getArrivalEarlyTime() {
        return arrivalEarlyTime;
    }


    /**
     * Sets the arrivalEarlyTime value for this HotelOrderDetailVo.
     * 
     * @param arrivalEarlyTime
     */
    public void setArrivalEarlyTime(java.lang.String arrivalEarlyTime) {
        this.arrivalEarlyTime = arrivalEarlyTime;
    }


    /**
     * Gets the arrivalLateTime value for this HotelOrderDetailVo.
     * 
     * @return arrivalLateTime
     */
    public java.lang.String getArrivalLateTime() {
        return arrivalLateTime;
    }


    /**
     * Sets the arrivalLateTime value for this HotelOrderDetailVo.
     * 
     * @param arrivalLateTime
     */
    public void setArrivalLateTime(java.lang.String arrivalLateTime) {
        this.arrivalLateTime = arrivalLateTime;
    }


    /**
     * Gets the bookTime value for this HotelOrderDetailVo.
     * 
     * @return bookTime
     */
    public java.lang.String getBookTime() {
        return bookTime;
    }


    /**
     * Sets the bookTime value for this HotelOrderDetailVo.
     * 
     * @param bookTime
     */
    public void setBookTime(java.lang.String bookTime) {
        this.bookTime = bookTime;
    }


    /**
     * Gets the checkInDate value for this HotelOrderDetailVo.
     * 
     * @return checkInDate
     */
    public java.lang.String getCheckInDate() {
        return checkInDate;
    }


    /**
     * Sets the checkInDate value for this HotelOrderDetailVo.
     * 
     * @param checkInDate
     */
    public void setCheckInDate(java.lang.String checkInDate) {
        this.checkInDate = checkInDate;
    }


    /**
     * Gets the checkOutDate value for this HotelOrderDetailVo.
     * 
     * @return checkOutDate
     */
    public java.lang.String getCheckOutDate() {
        return checkOutDate;
    }


    /**
     * Sets the checkOutDate value for this HotelOrderDetailVo.
     * 
     * @param checkOutDate
     */
    public void setCheckOutDate(java.lang.String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }


    /**
     * Gets the contacterMobile value for this HotelOrderDetailVo.
     * 
     * @return contacterMobile
     */
    public java.lang.String getContacterMobile() {
        return contacterMobile;
    }


    /**
     * Sets the contacterMobile value for this HotelOrderDetailVo.
     * 
     * @param contacterMobile
     */
    public void setContacterMobile(java.lang.String contacterMobile) {
        this.contacterMobile = contacterMobile;
    }


    /**
     * Gets the contacterName value for this HotelOrderDetailVo.
     * 
     * @return contacterName
     */
    public java.lang.String getContacterName() {
        return contacterName;
    }


    /**
     * Sets the contacterName value for this HotelOrderDetailVo.
     * 
     * @param contacterName
     */
    public void setContacterName(java.lang.String contacterName) {
        this.contacterName = contacterName;
    }


    /**
     * Gets the guestName value for this HotelOrderDetailVo.
     * 
     * @return guestName
     */
    public java.lang.String getGuestName() {
        return guestName;
    }


    /**
     * Sets the guestName value for this HotelOrderDetailVo.
     * 
     * @param guestName
     */
    public void setGuestName(java.lang.String guestName) {
        this.guestName = guestName;
    }


    /**
     * Gets the hasVouch value for this HotelOrderDetailVo.
     * 
     * @return hasVouch
     */
    public boolean isHasVouch() {
        return hasVouch;
    }


    /**
     * Sets the hasVouch value for this HotelOrderDetailVo.
     * 
     * @param hasVouch
     */
    public void setHasVouch(boolean hasVouch) {
        this.hasVouch = hasVouch;
    }


    /**
     * Gets the hotelAddress value for this HotelOrderDetailVo.
     * 
     * @return hotelAddress
     */
    public java.lang.String getHotelAddress() {
        return hotelAddress;
    }


    /**
     * Sets the hotelAddress value for this HotelOrderDetailVo.
     * 
     * @param hotelAddress
     */
    public void setHotelAddress(java.lang.String hotelAddress) {
        this.hotelAddress = hotelAddress;
    }


    /**
     * Gets the hotelName value for this HotelOrderDetailVo.
     * 
     * @return hotelName
     */
    public java.lang.String getHotelName() {
        return hotelName;
    }


    /**
     * Sets the hotelName value for this HotelOrderDetailVo.
     * 
     * @param hotelName
     */
    public void setHotelName(java.lang.String hotelName) {
        this.hotelName = hotelName;
    }


    /**
     * Gets the orderId value for this HotelOrderDetailVo.
     * 
     * @return orderId
     */
    public long getOrderId() {
        return orderId;
    }


    /**
     * Sets the orderId value for this HotelOrderDetailVo.
     * 
     * @param orderId
     */
    public void setOrderId(long orderId) {
        this.orderId = orderId;
    }


    /**
     * Gets the orderSource value for this HotelOrderDetailVo.
     * 
     * @return orderSource
     */
    public java.lang.String getOrderSource() {
        return orderSource;
    }


    /**
     * Sets the orderSource value for this HotelOrderDetailVo.
     * 
     * @param orderSource
     */
    public void setOrderSource(java.lang.String orderSource) {
        this.orderSource = orderSource;
    }


    /**
     * Gets the orderStatus value for this HotelOrderDetailVo.
     * 
     * @return orderStatus
     */
    public java.lang.String getOrderStatus() {
        return orderStatus;
    }


    /**
     * Sets the orderStatus value for this HotelOrderDetailVo.
     * 
     * @param orderStatus
     */
    public void setOrderStatus(java.lang.String orderStatus) {
        this.orderStatus = orderStatus;
    }


    /**
     * Gets the orderTime value for this HotelOrderDetailVo.
     * 
     * @return orderTime
     */
    public java.lang.String getOrderTime() {
        return orderTime;
    }


    /**
     * Sets the orderTime value for this HotelOrderDetailVo.
     * 
     * @param orderTime
     */
    public void setOrderTime(java.lang.String orderTime) {
        this.orderTime = orderTime;
    }


    /**
     * Gets the paymentType value for this HotelOrderDetailVo.
     * 
     * @return paymentType
     */
    public java.lang.String getPaymentType() {
        return paymentType;
    }


    /**
     * Sets the paymentType value for this HotelOrderDetailVo.
     * 
     * @param paymentType
     */
    public void setPaymentType(java.lang.String paymentType) {
        this.paymentType = paymentType;
    }


    /**
     * Gets the price value for this HotelOrderDetailVo.
     * 
     * @return price
     */
    public double getPrice() {
        return price;
    }


    /**
     * Sets the price value for this HotelOrderDetailVo.
     * 
     * @param price
     */
    public void setPrice(double price) {
        this.price = price;
    }


    /**
     * Gets the returnLcdCurrency value for this HotelOrderDetailVo.
     * 
     * @return returnLcdCurrency
     */
    public int getReturnLcdCurrency() {
        return returnLcdCurrency;
    }


    /**
     * Sets the returnLcdCurrency value for this HotelOrderDetailVo.
     * 
     * @param returnLcdCurrency
     */
    public void setReturnLcdCurrency(int returnLcdCurrency) {
        this.returnLcdCurrency = returnLcdCurrency;
    }


    /**
     * Gets the roomAmount value for this HotelOrderDetailVo.
     * 
     * @return roomAmount
     */
    public int getRoomAmount() {
        return roomAmount;
    }


    /**
     * Sets the roomAmount value for this HotelOrderDetailVo.
     * 
     * @param roomAmount
     */
    public void setRoomAmount(int roomAmount) {
        this.roomAmount = roomAmount;
    }


    /**
     * Gets the roomType value for this HotelOrderDetailVo.
     * 
     * @return roomType
     */
    public java.lang.String getRoomType() {
        return roomType;
    }


    /**
     * Sets the roomType value for this HotelOrderDetailVo.
     * 
     * @param roomType
     */
    public void setRoomType(java.lang.String roomType) {
        this.roomType = roomType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelOrderDetailVo)) return false;
        HotelOrderDetailVo other = (HotelOrderDetailVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.arrivalEarlyTime==null && other.getArrivalEarlyTime()==null) || 
             (this.arrivalEarlyTime!=null &&
              this.arrivalEarlyTime.equals(other.getArrivalEarlyTime()))) &&
            ((this.arrivalLateTime==null && other.getArrivalLateTime()==null) || 
             (this.arrivalLateTime!=null &&
              this.arrivalLateTime.equals(other.getArrivalLateTime()))) &&
            ((this.bookTime==null && other.getBookTime()==null) || 
             (this.bookTime!=null &&
              this.bookTime.equals(other.getBookTime()))) &&
            ((this.checkInDate==null && other.getCheckInDate()==null) || 
             (this.checkInDate!=null &&
              this.checkInDate.equals(other.getCheckInDate()))) &&
            ((this.checkOutDate==null && other.getCheckOutDate()==null) || 
             (this.checkOutDate!=null &&
              this.checkOutDate.equals(other.getCheckOutDate()))) &&
            ((this.contacterMobile==null && other.getContacterMobile()==null) || 
             (this.contacterMobile!=null &&
              this.contacterMobile.equals(other.getContacterMobile()))) &&
            ((this.contacterName==null && other.getContacterName()==null) || 
             (this.contacterName!=null &&
              this.contacterName.equals(other.getContacterName()))) &&
            ((this.guestName==null && other.getGuestName()==null) || 
             (this.guestName!=null &&
              this.guestName.equals(other.getGuestName()))) &&
            this.hasVouch == other.isHasVouch() &&
            ((this.hotelAddress==null && other.getHotelAddress()==null) || 
             (this.hotelAddress!=null &&
              this.hotelAddress.equals(other.getHotelAddress()))) &&
            ((this.hotelName==null && other.getHotelName()==null) || 
             (this.hotelName!=null &&
              this.hotelName.equals(other.getHotelName()))) &&
            this.orderId == other.getOrderId() &&
            ((this.orderSource==null && other.getOrderSource()==null) || 
             (this.orderSource!=null &&
              this.orderSource.equals(other.getOrderSource()))) &&
            ((this.orderStatus==null && other.getOrderStatus()==null) || 
             (this.orderStatus!=null &&
              this.orderStatus.equals(other.getOrderStatus()))) &&
            ((this.orderTime==null && other.getOrderTime()==null) || 
             (this.orderTime!=null &&
              this.orderTime.equals(other.getOrderTime()))) &&
            ((this.paymentType==null && other.getPaymentType()==null) || 
             (this.paymentType!=null &&
              this.paymentType.equals(other.getPaymentType()))) &&
            this.price == other.getPrice() &&
            this.returnLcdCurrency == other.getReturnLcdCurrency() &&
            this.roomAmount == other.getRoomAmount() &&
            ((this.roomType==null && other.getRoomType()==null) || 
             (this.roomType!=null &&
              this.roomType.equals(other.getRoomType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getArrivalEarlyTime() != null) {
            _hashCode += getArrivalEarlyTime().hashCode();
        }
        if (getArrivalLateTime() != null) {
            _hashCode += getArrivalLateTime().hashCode();
        }
        if (getBookTime() != null) {
            _hashCode += getBookTime().hashCode();
        }
        if (getCheckInDate() != null) {
            _hashCode += getCheckInDate().hashCode();
        }
        if (getCheckOutDate() != null) {
            _hashCode += getCheckOutDate().hashCode();
        }
        if (getContacterMobile() != null) {
            _hashCode += getContacterMobile().hashCode();
        }
        if (getContacterName() != null) {
            _hashCode += getContacterName().hashCode();
        }
        if (getGuestName() != null) {
            _hashCode += getGuestName().hashCode();
        }
        _hashCode += (isHasVouch() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getHotelAddress() != null) {
            _hashCode += getHotelAddress().hashCode();
        }
        if (getHotelName() != null) {
            _hashCode += getHotelName().hashCode();
        }
        _hashCode += new Long(getOrderId()).hashCode();
        if (getOrderSource() != null) {
            _hashCode += getOrderSource().hashCode();
        }
        if (getOrderStatus() != null) {
            _hashCode += getOrderStatus().hashCode();
        }
        if (getOrderTime() != null) {
            _hashCode += getOrderTime().hashCode();
        }
        if (getPaymentType() != null) {
            _hashCode += getPaymentType().hashCode();
        }
        _hashCode += new Double(getPrice()).hashCode();
        _hashCode += getReturnLcdCurrency();
        _hashCode += getRoomAmount();
        if (getRoomType() != null) {
            _hashCode += getRoomType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelOrderDetailVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderDetailVo", "HotelOrderDetailVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrivalEarlyTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "arrivalEarlyTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrivalLateTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "arrivalLateTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bookTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bookTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkInDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkInDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkOutDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkOutDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contacterMobile");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contacterMobile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contacterName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contacterName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guestName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "guestName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hasVouch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hasVouch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderSource");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderSource"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paymentType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("price");
        elemField.setXmlName(new javax.xml.namespace.QName("", "price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnLcdCurrency");
        elemField.setXmlName(new javax.xml.namespace.QName("", "returnLcdCurrency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
