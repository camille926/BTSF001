/**
 * HotelOrderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelOrderRequest  implements java.io.Serializable {
    private java.lang.String arrivalEarlyTime;

    private java.lang.String arrivalLateTime;

    private java.lang.String checkInDate;

    private java.lang.String checkOutDate;

    private cn.itkt.btsf.hotel.vo.ContacterForSubmitHotelOrder[] contacter;

    private cn.itkt.btsf.hotel.vo.CreditCardForSubmitHotelOrder creditCard;

    private java.lang.String firstDayPrice;

    private java.lang.String flag;

    private java.lang.String guaranteerules;

    private java.lang.String[] guestNames;

    private java.lang.String hotelId;

    private java.lang.String noteToHotel;

    private java.lang.String orderid;

    private cn.itkt.btsf.hotel.vo.RatePlanForHotel ratePlanForHotel;

    private java.lang.String roomTypeId;

    private java.lang.String star;

    private java.lang.String terminalNo;

    private java.lang.String userId;

    private java.lang.String userType;

    public HotelOrderRequest() {
    }

    public HotelOrderRequest(
           java.lang.String arrivalEarlyTime,
           java.lang.String arrivalLateTime,
           java.lang.String checkInDate,
           java.lang.String checkOutDate,
           cn.itkt.btsf.hotel.vo.ContacterForSubmitHotelOrder[] contacter,
           cn.itkt.btsf.hotel.vo.CreditCardForSubmitHotelOrder creditCard,
           java.lang.String firstDayPrice,
           java.lang.String flag,
           java.lang.String guaranteerules,
           java.lang.String[] guestNames,
           java.lang.String hotelId,
           java.lang.String noteToHotel,
           java.lang.String orderid,
           cn.itkt.btsf.hotel.vo.RatePlanForHotel ratePlanForHotel,
           java.lang.String roomTypeId,
           java.lang.String star,
           java.lang.String terminalNo,
           java.lang.String userId,
           java.lang.String userType) {
           this.arrivalEarlyTime = arrivalEarlyTime;
           this.arrivalLateTime = arrivalLateTime;
           this.checkInDate = checkInDate;
           this.checkOutDate = checkOutDate;
           this.contacter = contacter;
           this.creditCard = creditCard;
           this.firstDayPrice = firstDayPrice;
           this.flag = flag;
           this.guaranteerules = guaranteerules;
           this.guestNames = guestNames;
           this.hotelId = hotelId;
           this.noteToHotel = noteToHotel;
           this.orderid = orderid;
           this.ratePlanForHotel = ratePlanForHotel;
           this.roomTypeId = roomTypeId;
           this.star = star;
           this.terminalNo = terminalNo;
           this.userId = userId;
           this.userType = userType;
    }


    /**
     * Gets the arrivalEarlyTime value for this HotelOrderRequest.
     * 
     * @return arrivalEarlyTime
     */
    public java.lang.String getArrivalEarlyTime() {
        return arrivalEarlyTime;
    }


    /**
     * Sets the arrivalEarlyTime value for this HotelOrderRequest.
     * 
     * @param arrivalEarlyTime
     */
    public void setArrivalEarlyTime(java.lang.String arrivalEarlyTime) {
        this.arrivalEarlyTime = arrivalEarlyTime;
    }


    /**
     * Gets the arrivalLateTime value for this HotelOrderRequest.
     * 
     * @return arrivalLateTime
     */
    public java.lang.String getArrivalLateTime() {
        return arrivalLateTime;
    }


    /**
     * Sets the arrivalLateTime value for this HotelOrderRequest.
     * 
     * @param arrivalLateTime
     */
    public void setArrivalLateTime(java.lang.String arrivalLateTime) {
        this.arrivalLateTime = arrivalLateTime;
    }


    /**
     * Gets the checkInDate value for this HotelOrderRequest.
     * 
     * @return checkInDate
     */
    public java.lang.String getCheckInDate() {
        return checkInDate;
    }


    /**
     * Sets the checkInDate value for this HotelOrderRequest.
     * 
     * @param checkInDate
     */
    public void setCheckInDate(java.lang.String checkInDate) {
        this.checkInDate = checkInDate;
    }


    /**
     * Gets the checkOutDate value for this HotelOrderRequest.
     * 
     * @return checkOutDate
     */
    public java.lang.String getCheckOutDate() {
        return checkOutDate;
    }


    /**
     * Sets the checkOutDate value for this HotelOrderRequest.
     * 
     * @param checkOutDate
     */
    public void setCheckOutDate(java.lang.String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }


    /**
     * Gets the contacter value for this HotelOrderRequest.
     * 
     * @return contacter
     */
    public cn.itkt.btsf.hotel.vo.ContacterForSubmitHotelOrder[] getContacter() {
        return contacter;
    }


    /**
     * Sets the contacter value for this HotelOrderRequest.
     * 
     * @param contacter
     */
    public void setContacter(cn.itkt.btsf.hotel.vo.ContacterForSubmitHotelOrder[] contacter) {
        this.contacter = contacter;
    }


    /**
     * Gets the creditCard value for this HotelOrderRequest.
     * 
     * @return creditCard
     */
    public cn.itkt.btsf.hotel.vo.CreditCardForSubmitHotelOrder getCreditCard() {
        return creditCard;
    }


    /**
     * Sets the creditCard value for this HotelOrderRequest.
     * 
     * @param creditCard
     */
    public void setCreditCard(cn.itkt.btsf.hotel.vo.CreditCardForSubmitHotelOrder creditCard) {
        this.creditCard = creditCard;
    }


    /**
     * Gets the firstDayPrice value for this HotelOrderRequest.
     * 
     * @return firstDayPrice
     */
    public java.lang.String getFirstDayPrice() {
        return firstDayPrice;
    }


    /**
     * Sets the firstDayPrice value for this HotelOrderRequest.
     * 
     * @param firstDayPrice
     */
    public void setFirstDayPrice(java.lang.String firstDayPrice) {
        this.firstDayPrice = firstDayPrice;
    }


    /**
     * Gets the flag value for this HotelOrderRequest.
     * 
     * @return flag
     */
    public java.lang.String getFlag() {
        return flag;
    }


    /**
     * Sets the flag value for this HotelOrderRequest.
     * 
     * @param flag
     */
    public void setFlag(java.lang.String flag) {
        this.flag = flag;
    }


    /**
     * Gets the guaranteerules value for this HotelOrderRequest.
     * 
     * @return guaranteerules
     */
    public java.lang.String getGuaranteerules() {
        return guaranteerules;
    }


    /**
     * Sets the guaranteerules value for this HotelOrderRequest.
     * 
     * @param guaranteerules
     */
    public void setGuaranteerules(java.lang.String guaranteerules) {
        this.guaranteerules = guaranteerules;
    }


    /**
     * Gets the guestNames value for this HotelOrderRequest.
     * 
     * @return guestNames
     */
    public java.lang.String[] getGuestNames() {
        return guestNames;
    }


    /**
     * Sets the guestNames value for this HotelOrderRequest.
     * 
     * @param guestNames
     */
    public void setGuestNames(java.lang.String[] guestNames) {
        this.guestNames = guestNames;
    }


    /**
     * Gets the hotelId value for this HotelOrderRequest.
     * 
     * @return hotelId
     */
    public java.lang.String getHotelId() {
        return hotelId;
    }


    /**
     * Sets the hotelId value for this HotelOrderRequest.
     * 
     * @param hotelId
     */
    public void setHotelId(java.lang.String hotelId) {
        this.hotelId = hotelId;
    }


    /**
     * Gets the noteToHotel value for this HotelOrderRequest.
     * 
     * @return noteToHotel
     */
    public java.lang.String getNoteToHotel() {
        return noteToHotel;
    }


    /**
     * Sets the noteToHotel value for this HotelOrderRequest.
     * 
     * @param noteToHotel
     */
    public void setNoteToHotel(java.lang.String noteToHotel) {
        this.noteToHotel = noteToHotel;
    }


    /**
     * Gets the orderid value for this HotelOrderRequest.
     * 
     * @return orderid
     */
    public java.lang.String getOrderid() {
        return orderid;
    }


    /**
     * Sets the orderid value for this HotelOrderRequest.
     * 
     * @param orderid
     */
    public void setOrderid(java.lang.String orderid) {
        this.orderid = orderid;
    }


    /**
     * Gets the ratePlanForHotel value for this HotelOrderRequest.
     * 
     * @return ratePlanForHotel
     */
    public cn.itkt.btsf.hotel.vo.RatePlanForHotel getRatePlanForHotel() {
        return ratePlanForHotel;
    }


    /**
     * Sets the ratePlanForHotel value for this HotelOrderRequest.
     * 
     * @param ratePlanForHotel
     */
    public void setRatePlanForHotel(cn.itkt.btsf.hotel.vo.RatePlanForHotel ratePlanForHotel) {
        this.ratePlanForHotel = ratePlanForHotel;
    }


    /**
     * Gets the roomTypeId value for this HotelOrderRequest.
     * 
     * @return roomTypeId
     */
    public java.lang.String getRoomTypeId() {
        return roomTypeId;
    }


    /**
     * Sets the roomTypeId value for this HotelOrderRequest.
     * 
     * @param roomTypeId
     */
    public void setRoomTypeId(java.lang.String roomTypeId) {
        this.roomTypeId = roomTypeId;
    }


    /**
     * Gets the star value for this HotelOrderRequest.
     * 
     * @return star
     */
    public java.lang.String getStar() {
        return star;
    }


    /**
     * Sets the star value for this HotelOrderRequest.
     * 
     * @param star
     */
    public void setStar(java.lang.String star) {
        this.star = star;
    }


    /**
     * Gets the terminalNo value for this HotelOrderRequest.
     * 
     * @return terminalNo
     */
    public java.lang.String getTerminalNo() {
        return terminalNo;
    }


    /**
     * Sets the terminalNo value for this HotelOrderRequest.
     * 
     * @param terminalNo
     */
    public void setTerminalNo(java.lang.String terminalNo) {
        this.terminalNo = terminalNo;
    }


    /**
     * Gets the userId value for this HotelOrderRequest.
     * 
     * @return userId
     */
    public java.lang.String getUserId() {
        return userId;
    }


    /**
     * Sets the userId value for this HotelOrderRequest.
     * 
     * @param userId
     */
    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }


    /**
     * Gets the userType value for this HotelOrderRequest.
     * 
     * @return userType
     */
    public java.lang.String getUserType() {
        return userType;
    }


    /**
     * Sets the userType value for this HotelOrderRequest.
     * 
     * @param userType
     */
    public void setUserType(java.lang.String userType) {
        this.userType = userType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelOrderRequest)) return false;
        HotelOrderRequest other = (HotelOrderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.arrivalEarlyTime==null && other.getArrivalEarlyTime()==null) || 
             (this.arrivalEarlyTime!=null &&
              this.arrivalEarlyTime.equals(other.getArrivalEarlyTime()))) &&
            ((this.arrivalLateTime==null && other.getArrivalLateTime()==null) || 
             (this.arrivalLateTime!=null &&
              this.arrivalLateTime.equals(other.getArrivalLateTime()))) &&
            ((this.checkInDate==null && other.getCheckInDate()==null) || 
             (this.checkInDate!=null &&
              this.checkInDate.equals(other.getCheckInDate()))) &&
            ((this.checkOutDate==null && other.getCheckOutDate()==null) || 
             (this.checkOutDate!=null &&
              this.checkOutDate.equals(other.getCheckOutDate()))) &&
            ((this.contacter==null && other.getContacter()==null) || 
             (this.contacter!=null &&
              java.util.Arrays.equals(this.contacter, other.getContacter()))) &&
            ((this.creditCard==null && other.getCreditCard()==null) || 
             (this.creditCard!=null &&
              this.creditCard.equals(other.getCreditCard()))) &&
            ((this.firstDayPrice==null && other.getFirstDayPrice()==null) || 
             (this.firstDayPrice!=null &&
              this.firstDayPrice.equals(other.getFirstDayPrice()))) &&
            ((this.flag==null && other.getFlag()==null) || 
             (this.flag!=null &&
              this.flag.equals(other.getFlag()))) &&
            ((this.guaranteerules==null && other.getGuaranteerules()==null) || 
             (this.guaranteerules!=null &&
              this.guaranteerules.equals(other.getGuaranteerules()))) &&
            ((this.guestNames==null && other.getGuestNames()==null) || 
             (this.guestNames!=null &&
              java.util.Arrays.equals(this.guestNames, other.getGuestNames()))) &&
            ((this.hotelId==null && other.getHotelId()==null) || 
             (this.hotelId!=null &&
              this.hotelId.equals(other.getHotelId()))) &&
            ((this.noteToHotel==null && other.getNoteToHotel()==null) || 
             (this.noteToHotel!=null &&
              this.noteToHotel.equals(other.getNoteToHotel()))) &&
            ((this.orderid==null && other.getOrderid()==null) || 
             (this.orderid!=null &&
              this.orderid.equals(other.getOrderid()))) &&
            ((this.ratePlanForHotel==null && other.getRatePlanForHotel()==null) || 
             (this.ratePlanForHotel!=null &&
              this.ratePlanForHotel.equals(other.getRatePlanForHotel()))) &&
            ((this.roomTypeId==null && other.getRoomTypeId()==null) || 
             (this.roomTypeId!=null &&
              this.roomTypeId.equals(other.getRoomTypeId()))) &&
            ((this.star==null && other.getStar()==null) || 
             (this.star!=null &&
              this.star.equals(other.getStar()))) &&
            ((this.terminalNo==null && other.getTerminalNo()==null) || 
             (this.terminalNo!=null &&
              this.terminalNo.equals(other.getTerminalNo()))) &&
            ((this.userId==null && other.getUserId()==null) || 
             (this.userId!=null &&
              this.userId.equals(other.getUserId()))) &&
            ((this.userType==null && other.getUserType()==null) || 
             (this.userType!=null &&
              this.userType.equals(other.getUserType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getArrivalEarlyTime() != null) {
            _hashCode += getArrivalEarlyTime().hashCode();
        }
        if (getArrivalLateTime() != null) {
            _hashCode += getArrivalLateTime().hashCode();
        }
        if (getCheckInDate() != null) {
            _hashCode += getCheckInDate().hashCode();
        }
        if (getCheckOutDate() != null) {
            _hashCode += getCheckOutDate().hashCode();
        }
        if (getContacter() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getContacter());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getContacter(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCreditCard() != null) {
            _hashCode += getCreditCard().hashCode();
        }
        if (getFirstDayPrice() != null) {
            _hashCode += getFirstDayPrice().hashCode();
        }
        if (getFlag() != null) {
            _hashCode += getFlag().hashCode();
        }
        if (getGuaranteerules() != null) {
            _hashCode += getGuaranteerules().hashCode();
        }
        if (getGuestNames() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGuestNames());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGuestNames(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHotelId() != null) {
            _hashCode += getHotelId().hashCode();
        }
        if (getNoteToHotel() != null) {
            _hashCode += getNoteToHotel().hashCode();
        }
        if (getOrderid() != null) {
            _hashCode += getOrderid().hashCode();
        }
        if (getRatePlanForHotel() != null) {
            _hashCode += getRatePlanForHotel().hashCode();
        }
        if (getRoomTypeId() != null) {
            _hashCode += getRoomTypeId().hashCode();
        }
        if (getStar() != null) {
            _hashCode += getStar().hashCode();
        }
        if (getTerminalNo() != null) {
            _hashCode += getTerminalNo().hashCode();
        }
        if (getUserId() != null) {
            _hashCode += getUserId().hashCode();
        }
        if (getUserType() != null) {
            _hashCode += getUserType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelOrderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelOrderRequest", "HotelOrderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrivalEarlyTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "arrivalEarlyTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arrivalLateTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "arrivalLateTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkInDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkInDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkOutDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkOutDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contacter");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contacter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://po.elong.air.litsoft.com", "ContacterForSubmitHotelOrder"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditCard");
        elemField.setXmlName(new javax.xml.namespace.QName("", "creditCard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://po.elong.air.litsoft.com", "CreditCardForSubmitHotelOrder"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstDayPrice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "firstDayPrice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flag");
        elemField.setXmlName(new javax.xml.namespace.QName("", "flag"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guaranteerules");
        elemField.setXmlName(new javax.xml.namespace.QName("", "guaranteerules"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("guestNames");
        elemField.setXmlName(new javax.xml.namespace.QName("", "guestNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noteToHotel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "noteToHotel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ratePlanForHotel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ratePlanForHotel"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.RatePlanForHotel", "RatePlanForHotel"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("star");
        elemField.setXmlName(new javax.xml.namespace.QName("", "star"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminalNo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "terminalNo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
