/**
 * HotelProductVouchVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelProductVouchVo  extends cn.itkt.btsf.hotel.vo.BaseVo  implements java.io.Serializable {
    private java.lang.String description_CN;

    private java.lang.String description_EN;

    private int isVouch;

    private java.util.Calendar lastCancelTime;

    private java.lang.String vouchMoneyType;

    public HotelProductVouchVo() {
    }

    public HotelProductVouchVo(
           java.lang.String message,
           java.lang.String status,
           java.lang.String description_CN,
           java.lang.String description_EN,
           int isVouch,
           java.util.Calendar lastCancelTime,
           java.lang.String vouchMoneyType) {
        super(
            message,
            status);
        this.description_CN = description_CN;
        this.description_EN = description_EN;
        this.isVouch = isVouch;
        this.lastCancelTime = lastCancelTime;
        this.vouchMoneyType = vouchMoneyType;
    }


    /**
     * Gets the description_CN value for this HotelProductVouchVo.
     * 
     * @return description_CN
     */
    public java.lang.String getDescription_CN() {
        return description_CN;
    }


    /**
     * Sets the description_CN value for this HotelProductVouchVo.
     * 
     * @param description_CN
     */
    public void setDescription_CN(java.lang.String description_CN) {
        this.description_CN = description_CN;
    }


    /**
     * Gets the description_EN value for this HotelProductVouchVo.
     * 
     * @return description_EN
     */
    public java.lang.String getDescription_EN() {
        return description_EN;
    }


    /**
     * Sets the description_EN value for this HotelProductVouchVo.
     * 
     * @param description_EN
     */
    public void setDescription_EN(java.lang.String description_EN) {
        this.description_EN = description_EN;
    }


    /**
     * Gets the isVouch value for this HotelProductVouchVo.
     * 
     * @return isVouch
     */
    public int getIsVouch() {
        return isVouch;
    }


    /**
     * Sets the isVouch value for this HotelProductVouchVo.
     * 
     * @param isVouch
     */
    public void setIsVouch(int isVouch) {
        this.isVouch = isVouch;
    }


    /**
     * Gets the lastCancelTime value for this HotelProductVouchVo.
     * 
     * @return lastCancelTime
     */
    public java.util.Calendar getLastCancelTime() {
        return lastCancelTime;
    }


    /**
     * Sets the lastCancelTime value for this HotelProductVouchVo.
     * 
     * @param lastCancelTime
     */
    public void setLastCancelTime(java.util.Calendar lastCancelTime) {
        this.lastCancelTime = lastCancelTime;
    }


    /**
     * Gets the vouchMoneyType value for this HotelProductVouchVo.
     * 
     * @return vouchMoneyType
     */
    public java.lang.String getVouchMoneyType() {
        return vouchMoneyType;
    }


    /**
     * Sets the vouchMoneyType value for this HotelProductVouchVo.
     * 
     * @param vouchMoneyType
     */
    public void setVouchMoneyType(java.lang.String vouchMoneyType) {
        this.vouchMoneyType = vouchMoneyType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelProductVouchVo)) return false;
        HotelProductVouchVo other = (HotelProductVouchVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.description_CN==null && other.getDescription_CN()==null) || 
             (this.description_CN!=null &&
              this.description_CN.equals(other.getDescription_CN()))) &&
            ((this.description_EN==null && other.getDescription_EN()==null) || 
             (this.description_EN!=null &&
              this.description_EN.equals(other.getDescription_EN()))) &&
            this.isVouch == other.getIsVouch() &&
            ((this.lastCancelTime==null && other.getLastCancelTime()==null) || 
             (this.lastCancelTime!=null &&
              this.lastCancelTime.equals(other.getLastCancelTime()))) &&
            ((this.vouchMoneyType==null && other.getVouchMoneyType()==null) || 
             (this.vouchMoneyType!=null &&
              this.vouchMoneyType.equals(other.getVouchMoneyType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDescription_CN() != null) {
            _hashCode += getDescription_CN().hashCode();
        }
        if (getDescription_EN() != null) {
            _hashCode += getDescription_EN().hashCode();
        }
        _hashCode += getIsVouch();
        if (getLastCancelTime() != null) {
            _hashCode += getLastCancelTime().hashCode();
        }
        if (getVouchMoneyType() != null) {
            _hashCode += getVouchMoneyType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelProductVouchVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelProductVouchVo", "HotelProductVouchVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description_CN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description_CN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description_EN");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description_EN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isVouch");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isVouch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastCancelTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lastCancelTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vouchMoneyType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "vouchMoneyType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
