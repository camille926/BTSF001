/**
 * HotelListQueryRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelListQueryRequest  implements java.io.Serializable {
    private java.lang.String brandId;

    private java.lang.String checkInDate;

    private java.lang.String checkOutDate;

    private java.lang.String cityId;

    private java.lang.String commercialLocationId;

    private java.lang.String currencyCode;

    private java.lang.String districtId;

    private int highestRate;

    private java.lang.String hotelChineseName;

    private java.lang.String hotelId;

    private java.lang.String landmarkLocationID;

    private int lowestRate;

    private java.lang.String orderByCode;

    private java.lang.String orderTypeCode;

    private int reqPageNum;

    private java.lang.String starCode;

    private java.lang.String terminalId;

    public HotelListQueryRequest() {
    }

    public HotelListQueryRequest(
           java.lang.String brandId,
           java.lang.String checkInDate,
           java.lang.String checkOutDate,
           java.lang.String cityId,
           java.lang.String commercialLocationId,
           java.lang.String currencyCode,
           java.lang.String districtId,
           int highestRate,
           java.lang.String hotelChineseName,
           java.lang.String hotelId,
           java.lang.String landmarkLocationID,
           int lowestRate,
           java.lang.String orderByCode,
           java.lang.String orderTypeCode,
           int reqPageNum,
           java.lang.String starCode,
           java.lang.String terminalId) {
           this.brandId = brandId;
           this.checkInDate = checkInDate;
           this.checkOutDate = checkOutDate;
           this.cityId = cityId;
           this.commercialLocationId = commercialLocationId;
           this.currencyCode = currencyCode;
           this.districtId = districtId;
           this.highestRate = highestRate;
           this.hotelChineseName = hotelChineseName;
           this.hotelId = hotelId;
           this.landmarkLocationID = landmarkLocationID;
           this.lowestRate = lowestRate;
           this.orderByCode = orderByCode;
           this.orderTypeCode = orderTypeCode;
           this.reqPageNum = reqPageNum;
           this.starCode = starCode;
           this.terminalId = terminalId;
    }


    /**
     * Gets the brandId value for this HotelListQueryRequest.
     * 
     * @return brandId
     */
    public java.lang.String getBrandId() {
        return brandId;
    }


    /**
     * Sets the brandId value for this HotelListQueryRequest.
     * 
     * @param brandId
     */
    public void setBrandId(java.lang.String brandId) {
        this.brandId = brandId;
    }


    /**
     * Gets the checkInDate value for this HotelListQueryRequest.
     * 
     * @return checkInDate
     */
    public java.lang.String getCheckInDate() {
        return checkInDate;
    }


    /**
     * Sets the checkInDate value for this HotelListQueryRequest.
     * 
     * @param checkInDate
     */
    public void setCheckInDate(java.lang.String checkInDate) {
        this.checkInDate = checkInDate;
    }


    /**
     * Gets the checkOutDate value for this HotelListQueryRequest.
     * 
     * @return checkOutDate
     */
    public java.lang.String getCheckOutDate() {
        return checkOutDate;
    }


    /**
     * Sets the checkOutDate value for this HotelListQueryRequest.
     * 
     * @param checkOutDate
     */
    public void setCheckOutDate(java.lang.String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }


    /**
     * Gets the cityId value for this HotelListQueryRequest.
     * 
     * @return cityId
     */
    public java.lang.String getCityId() {
        return cityId;
    }


    /**
     * Sets the cityId value for this HotelListQueryRequest.
     * 
     * @param cityId
     */
    public void setCityId(java.lang.String cityId) {
        this.cityId = cityId;
    }


    /**
     * Gets the commercialLocationId value for this HotelListQueryRequest.
     * 
     * @return commercialLocationId
     */
    public java.lang.String getCommercialLocationId() {
        return commercialLocationId;
    }


    /**
     * Sets the commercialLocationId value for this HotelListQueryRequest.
     * 
     * @param commercialLocationId
     */
    public void setCommercialLocationId(java.lang.String commercialLocationId) {
        this.commercialLocationId = commercialLocationId;
    }


    /**
     * Gets the currencyCode value for this HotelListQueryRequest.
     * 
     * @return currencyCode
     */
    public java.lang.String getCurrencyCode() {
        return currencyCode;
    }


    /**
     * Sets the currencyCode value for this HotelListQueryRequest.
     * 
     * @param currencyCode
     */
    public void setCurrencyCode(java.lang.String currencyCode) {
        this.currencyCode = currencyCode;
    }


    /**
     * Gets the districtId value for this HotelListQueryRequest.
     * 
     * @return districtId
     */
    public java.lang.String getDistrictId() {
        return districtId;
    }


    /**
     * Sets the districtId value for this HotelListQueryRequest.
     * 
     * @param districtId
     */
    public void setDistrictId(java.lang.String districtId) {
        this.districtId = districtId;
    }


    /**
     * Gets the highestRate value for this HotelListQueryRequest.
     * 
     * @return highestRate
     */
    public int getHighestRate() {
        return highestRate;
    }


    /**
     * Sets the highestRate value for this HotelListQueryRequest.
     * 
     * @param highestRate
     */
    public void setHighestRate(int highestRate) {
        this.highestRate = highestRate;
    }


    /**
     * Gets the hotelChineseName value for this HotelListQueryRequest.
     * 
     * @return hotelChineseName
     */
    public java.lang.String getHotelChineseName() {
        return hotelChineseName;
    }


    /**
     * Sets the hotelChineseName value for this HotelListQueryRequest.
     * 
     * @param hotelChineseName
     */
    public void setHotelChineseName(java.lang.String hotelChineseName) {
        this.hotelChineseName = hotelChineseName;
    }


    /**
     * Gets the hotelId value for this HotelListQueryRequest.
     * 
     * @return hotelId
     */
    public java.lang.String getHotelId() {
        return hotelId;
    }


    /**
     * Sets the hotelId value for this HotelListQueryRequest.
     * 
     * @param hotelId
     */
    public void setHotelId(java.lang.String hotelId) {
        this.hotelId = hotelId;
    }


    /**
     * Gets the landmarkLocationID value for this HotelListQueryRequest.
     * 
     * @return landmarkLocationID
     */
    public java.lang.String getLandmarkLocationID() {
        return landmarkLocationID;
    }


    /**
     * Sets the landmarkLocationID value for this HotelListQueryRequest.
     * 
     * @param landmarkLocationID
     */
    public void setLandmarkLocationID(java.lang.String landmarkLocationID) {
        this.landmarkLocationID = landmarkLocationID;
    }


    /**
     * Gets the lowestRate value for this HotelListQueryRequest.
     * 
     * @return lowestRate
     */
    public int getLowestRate() {
        return lowestRate;
    }


    /**
     * Sets the lowestRate value for this HotelListQueryRequest.
     * 
     * @param lowestRate
     */
    public void setLowestRate(int lowestRate) {
        this.lowestRate = lowestRate;
    }


    /**
     * Gets the orderByCode value for this HotelListQueryRequest.
     * 
     * @return orderByCode
     */
    public java.lang.String getOrderByCode() {
        return orderByCode;
    }


    /**
     * Sets the orderByCode value for this HotelListQueryRequest.
     * 
     * @param orderByCode
     */
    public void setOrderByCode(java.lang.String orderByCode) {
        this.orderByCode = orderByCode;
    }


    /**
     * Gets the orderTypeCode value for this HotelListQueryRequest.
     * 
     * @return orderTypeCode
     */
    public java.lang.String getOrderTypeCode() {
        return orderTypeCode;
    }


    /**
     * Sets the orderTypeCode value for this HotelListQueryRequest.
     * 
     * @param orderTypeCode
     */
    public void setOrderTypeCode(java.lang.String orderTypeCode) {
        this.orderTypeCode = orderTypeCode;
    }


    /**
     * Gets the reqPageNum value for this HotelListQueryRequest.
     * 
     * @return reqPageNum
     */
    public int getReqPageNum() {
        return reqPageNum;
    }


    /**
     * Sets the reqPageNum value for this HotelListQueryRequest.
     * 
     * @param reqPageNum
     */
    public void setReqPageNum(int reqPageNum) {
        this.reqPageNum = reqPageNum;
    }


    /**
     * Gets the starCode value for this HotelListQueryRequest.
     * 
     * @return starCode
     */
    public java.lang.String getStarCode() {
        return starCode;
    }


    /**
     * Sets the starCode value for this HotelListQueryRequest.
     * 
     * @param starCode
     */
    public void setStarCode(java.lang.String starCode) {
        this.starCode = starCode;
    }


    /**
     * Gets the terminalId value for this HotelListQueryRequest.
     * 
     * @return terminalId
     */
    public java.lang.String getTerminalId() {
        return terminalId;
    }


    /**
     * Sets the terminalId value for this HotelListQueryRequest.
     * 
     * @param terminalId
     */
    public void setTerminalId(java.lang.String terminalId) {
        this.terminalId = terminalId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelListQueryRequest)) return false;
        HotelListQueryRequest other = (HotelListQueryRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.brandId==null && other.getBrandId()==null) || 
             (this.brandId!=null &&
              this.brandId.equals(other.getBrandId()))) &&
            ((this.checkInDate==null && other.getCheckInDate()==null) || 
             (this.checkInDate!=null &&
              this.checkInDate.equals(other.getCheckInDate()))) &&
            ((this.checkOutDate==null && other.getCheckOutDate()==null) || 
             (this.checkOutDate!=null &&
              this.checkOutDate.equals(other.getCheckOutDate()))) &&
            ((this.cityId==null && other.getCityId()==null) || 
             (this.cityId!=null &&
              this.cityId.equals(other.getCityId()))) &&
            ((this.commercialLocationId==null && other.getCommercialLocationId()==null) || 
             (this.commercialLocationId!=null &&
              this.commercialLocationId.equals(other.getCommercialLocationId()))) &&
            ((this.currencyCode==null && other.getCurrencyCode()==null) || 
             (this.currencyCode!=null &&
              this.currencyCode.equals(other.getCurrencyCode()))) &&
            ((this.districtId==null && other.getDistrictId()==null) || 
             (this.districtId!=null &&
              this.districtId.equals(other.getDistrictId()))) &&
            this.highestRate == other.getHighestRate() &&
            ((this.hotelChineseName==null && other.getHotelChineseName()==null) || 
             (this.hotelChineseName!=null &&
              this.hotelChineseName.equals(other.getHotelChineseName()))) &&
            ((this.hotelId==null && other.getHotelId()==null) || 
             (this.hotelId!=null &&
              this.hotelId.equals(other.getHotelId()))) &&
            ((this.landmarkLocationID==null && other.getLandmarkLocationID()==null) || 
             (this.landmarkLocationID!=null &&
              this.landmarkLocationID.equals(other.getLandmarkLocationID()))) &&
            this.lowestRate == other.getLowestRate() &&
            ((this.orderByCode==null && other.getOrderByCode()==null) || 
             (this.orderByCode!=null &&
              this.orderByCode.equals(other.getOrderByCode()))) &&
            ((this.orderTypeCode==null && other.getOrderTypeCode()==null) || 
             (this.orderTypeCode!=null &&
              this.orderTypeCode.equals(other.getOrderTypeCode()))) &&
            this.reqPageNum == other.getReqPageNum() &&
            ((this.starCode==null && other.getStarCode()==null) || 
             (this.starCode!=null &&
              this.starCode.equals(other.getStarCode()))) &&
            ((this.terminalId==null && other.getTerminalId()==null) || 
             (this.terminalId!=null &&
              this.terminalId.equals(other.getTerminalId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBrandId() != null) {
            _hashCode += getBrandId().hashCode();
        }
        if (getCheckInDate() != null) {
            _hashCode += getCheckInDate().hashCode();
        }
        if (getCheckOutDate() != null) {
            _hashCode += getCheckOutDate().hashCode();
        }
        if (getCityId() != null) {
            _hashCode += getCityId().hashCode();
        }
        if (getCommercialLocationId() != null) {
            _hashCode += getCommercialLocationId().hashCode();
        }
        if (getCurrencyCode() != null) {
            _hashCode += getCurrencyCode().hashCode();
        }
        if (getDistrictId() != null) {
            _hashCode += getDistrictId().hashCode();
        }
        _hashCode += getHighestRate();
        if (getHotelChineseName() != null) {
            _hashCode += getHotelChineseName().hashCode();
        }
        if (getHotelId() != null) {
            _hashCode += getHotelId().hashCode();
        }
        if (getLandmarkLocationID() != null) {
            _hashCode += getLandmarkLocationID().hashCode();
        }
        _hashCode += getLowestRate();
        if (getOrderByCode() != null) {
            _hashCode += getOrderByCode().hashCode();
        }
        if (getOrderTypeCode() != null) {
            _hashCode += getOrderTypeCode().hashCode();
        }
        _hashCode += getReqPageNum();
        if (getStarCode() != null) {
            _hashCode += getStarCode().hashCode();
        }
        if (getTerminalId() != null) {
            _hashCode += getTerminalId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelListQueryRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelListQueryRequest", "HotelListQueryRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkInDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkInDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkOutDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkOutDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cityId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cityId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commercialLocationId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "commercialLocationId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currencyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("districtId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "districtId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("highestRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "highestRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelChineseName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelChineseName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("landmarkLocationID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "landmarkLocationID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowestRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lowestRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderByCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderByCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderTypeCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderTypeCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reqPageNum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reqPageNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("starCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "starCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminalId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "terminalId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
