/**
 * HotelProductVouchRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelProductVouchRequest  implements java.io.Serializable {
    private java.lang.String arriveLaterTime;

    private java.lang.String checkInDate;

    private java.lang.String checkOutDate;

    private java.lang.String hotelId;

    private int ratePlanId;

    private int roomNum;

    private java.lang.String roomTypeId;

    public HotelProductVouchRequest() {
    }

    public HotelProductVouchRequest(
           java.lang.String arriveLaterTime,
           java.lang.String checkInDate,
           java.lang.String checkOutDate,
           java.lang.String hotelId,
           int ratePlanId,
           int roomNum,
           java.lang.String roomTypeId) {
           this.arriveLaterTime = arriveLaterTime;
           this.checkInDate = checkInDate;
           this.checkOutDate = checkOutDate;
           this.hotelId = hotelId;
           this.ratePlanId = ratePlanId;
           this.roomNum = roomNum;
           this.roomTypeId = roomTypeId;
    }


    /**
     * Gets the arriveLaterTime value for this HotelProductVouchRequest.
     * 
     * @return arriveLaterTime
     */
    public java.lang.String getArriveLaterTime() {
        return arriveLaterTime;
    }


    /**
     * Sets the arriveLaterTime value for this HotelProductVouchRequest.
     * 
     * @param arriveLaterTime
     */
    public void setArriveLaterTime(java.lang.String arriveLaterTime) {
        this.arriveLaterTime = arriveLaterTime;
    }


    /**
     * Gets the checkInDate value for this HotelProductVouchRequest.
     * 
     * @return checkInDate
     */
    public java.lang.String getCheckInDate() {
        return checkInDate;
    }


    /**
     * Sets the checkInDate value for this HotelProductVouchRequest.
     * 
     * @param checkInDate
     */
    public void setCheckInDate(java.lang.String checkInDate) {
        this.checkInDate = checkInDate;
    }


    /**
     * Gets the checkOutDate value for this HotelProductVouchRequest.
     * 
     * @return checkOutDate
     */
    public java.lang.String getCheckOutDate() {
        return checkOutDate;
    }


    /**
     * Sets the checkOutDate value for this HotelProductVouchRequest.
     * 
     * @param checkOutDate
     */
    public void setCheckOutDate(java.lang.String checkOutDate) {
        this.checkOutDate = checkOutDate;
    }


    /**
     * Gets the hotelId value for this HotelProductVouchRequest.
     * 
     * @return hotelId
     */
    public java.lang.String getHotelId() {
        return hotelId;
    }


    /**
     * Sets the hotelId value for this HotelProductVouchRequest.
     * 
     * @param hotelId
     */
    public void setHotelId(java.lang.String hotelId) {
        this.hotelId = hotelId;
    }


    /**
     * Gets the ratePlanId value for this HotelProductVouchRequest.
     * 
     * @return ratePlanId
     */
    public int getRatePlanId() {
        return ratePlanId;
    }


    /**
     * Sets the ratePlanId value for this HotelProductVouchRequest.
     * 
     * @param ratePlanId
     */
    public void setRatePlanId(int ratePlanId) {
        this.ratePlanId = ratePlanId;
    }


    /**
     * Gets the roomNum value for this HotelProductVouchRequest.
     * 
     * @return roomNum
     */
    public int getRoomNum() {
        return roomNum;
    }


    /**
     * Sets the roomNum value for this HotelProductVouchRequest.
     * 
     * @param roomNum
     */
    public void setRoomNum(int roomNum) {
        this.roomNum = roomNum;
    }


    /**
     * Gets the roomTypeId value for this HotelProductVouchRequest.
     * 
     * @return roomTypeId
     */
    public java.lang.String getRoomTypeId() {
        return roomTypeId;
    }


    /**
     * Sets the roomTypeId value for this HotelProductVouchRequest.
     * 
     * @param roomTypeId
     */
    public void setRoomTypeId(java.lang.String roomTypeId) {
        this.roomTypeId = roomTypeId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelProductVouchRequest)) return false;
        HotelProductVouchRequest other = (HotelProductVouchRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.arriveLaterTime==null && other.getArriveLaterTime()==null) || 
             (this.arriveLaterTime!=null &&
              this.arriveLaterTime.equals(other.getArriveLaterTime()))) &&
            ((this.checkInDate==null && other.getCheckInDate()==null) || 
             (this.checkInDate!=null &&
              this.checkInDate.equals(other.getCheckInDate()))) &&
            ((this.checkOutDate==null && other.getCheckOutDate()==null) || 
             (this.checkOutDate!=null &&
              this.checkOutDate.equals(other.getCheckOutDate()))) &&
            ((this.hotelId==null && other.getHotelId()==null) || 
             (this.hotelId!=null &&
              this.hotelId.equals(other.getHotelId()))) &&
            this.ratePlanId == other.getRatePlanId() &&
            this.roomNum == other.getRoomNum() &&
            ((this.roomTypeId==null && other.getRoomTypeId()==null) || 
             (this.roomTypeId!=null &&
              this.roomTypeId.equals(other.getRoomTypeId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getArriveLaterTime() != null) {
            _hashCode += getArriveLaterTime().hashCode();
        }
        if (getCheckInDate() != null) {
            _hashCode += getCheckInDate().hashCode();
        }
        if (getCheckOutDate() != null) {
            _hashCode += getCheckOutDate().hashCode();
        }
        if (getHotelId() != null) {
            _hashCode += getHotelId().hashCode();
        }
        _hashCode += getRatePlanId();
        _hashCode += getRoomNum();
        if (getRoomTypeId() != null) {
            _hashCode += getRoomTypeId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelProductVouchRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.HotelProductVouchRequest", "HotelProductVouchRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("arriveLaterTime");
        elemField.setXmlName(new javax.xml.namespace.QName("", "arriveLaterTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkInDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkInDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkOutDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkOutDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ratePlanId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ratePlanId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomNum");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomNum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
