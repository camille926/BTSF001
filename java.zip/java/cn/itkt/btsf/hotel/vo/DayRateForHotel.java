/**
 * DayRateForHotel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class DayRateForHotel  implements java.io.Serializable {
    private java.math.BigDecimal addBedRate;

    private java.lang.String currencyCode;

    private java.util.Calendar date;

    private java.lang.String invStatusCode;

    private java.math.BigDecimal memberRate;

    private java.math.BigDecimal retailRate;

    private java.lang.String strDate;

    public DayRateForHotel() {
    }

    public DayRateForHotel(
           java.math.BigDecimal addBedRate,
           java.lang.String currencyCode,
           java.util.Calendar date,
           java.lang.String invStatusCode,
           java.math.BigDecimal memberRate,
           java.math.BigDecimal retailRate,
           java.lang.String strDate) {
           this.addBedRate = addBedRate;
           this.currencyCode = currencyCode;
           this.date = date;
           this.invStatusCode = invStatusCode;
           this.memberRate = memberRate;
           this.retailRate = retailRate;
           this.strDate = strDate;
    }


    /**
     * Gets the addBedRate value for this DayRateForHotel.
     * 
     * @return addBedRate
     */
    public java.math.BigDecimal getAddBedRate() {
        return addBedRate;
    }


    /**
     * Sets the addBedRate value for this DayRateForHotel.
     * 
     * @param addBedRate
     */
    public void setAddBedRate(java.math.BigDecimal addBedRate) {
        this.addBedRate = addBedRate;
    }


    /**
     * Gets the currencyCode value for this DayRateForHotel.
     * 
     * @return currencyCode
     */
    public java.lang.String getCurrencyCode() {
        return currencyCode;
    }


    /**
     * Sets the currencyCode value for this DayRateForHotel.
     * 
     * @param currencyCode
     */
    public void setCurrencyCode(java.lang.String currencyCode) {
        this.currencyCode = currencyCode;
    }


    /**
     * Gets the date value for this DayRateForHotel.
     * 
     * @return date
     */
    public java.util.Calendar getDate() {
        return date;
    }


    /**
     * Sets the date value for this DayRateForHotel.
     * 
     * @param date
     */
    public void setDate(java.util.Calendar date) {
        this.date = date;
    }


    /**
     * Gets the invStatusCode value for this DayRateForHotel.
     * 
     * @return invStatusCode
     */
    public java.lang.String getInvStatusCode() {
        return invStatusCode;
    }


    /**
     * Sets the invStatusCode value for this DayRateForHotel.
     * 
     * @param invStatusCode
     */
    public void setInvStatusCode(java.lang.String invStatusCode) {
        this.invStatusCode = invStatusCode;
    }


    /**
     * Gets the memberRate value for this DayRateForHotel.
     * 
     * @return memberRate
     */
    public java.math.BigDecimal getMemberRate() {
        return memberRate;
    }


    /**
     * Sets the memberRate value for this DayRateForHotel.
     * 
     * @param memberRate
     */
    public void setMemberRate(java.math.BigDecimal memberRate) {
        this.memberRate = memberRate;
    }


    /**
     * Gets the retailRate value for this DayRateForHotel.
     * 
     * @return retailRate
     */
    public java.math.BigDecimal getRetailRate() {
        return retailRate;
    }


    /**
     * Sets the retailRate value for this DayRateForHotel.
     * 
     * @param retailRate
     */
    public void setRetailRate(java.math.BigDecimal retailRate) {
        this.retailRate = retailRate;
    }


    /**
     * Gets the strDate value for this DayRateForHotel.
     * 
     * @return strDate
     */
    public java.lang.String getStrDate() {
        return strDate;
    }


    /**
     * Sets the strDate value for this DayRateForHotel.
     * 
     * @param strDate
     */
    public void setStrDate(java.lang.String strDate) {
        this.strDate = strDate;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DayRateForHotel)) return false;
        DayRateForHotel other = (DayRateForHotel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.addBedRate==null && other.getAddBedRate()==null) || 
             (this.addBedRate!=null &&
              this.addBedRate.equals(other.getAddBedRate()))) &&
            ((this.currencyCode==null && other.getCurrencyCode()==null) || 
             (this.currencyCode!=null &&
              this.currencyCode.equals(other.getCurrencyCode()))) &&
            ((this.date==null && other.getDate()==null) || 
             (this.date!=null &&
              this.date.equals(other.getDate()))) &&
            ((this.invStatusCode==null && other.getInvStatusCode()==null) || 
             (this.invStatusCode!=null &&
              this.invStatusCode.equals(other.getInvStatusCode()))) &&
            ((this.memberRate==null && other.getMemberRate()==null) || 
             (this.memberRate!=null &&
              this.memberRate.equals(other.getMemberRate()))) &&
            ((this.retailRate==null && other.getRetailRate()==null) || 
             (this.retailRate!=null &&
              this.retailRate.equals(other.getRetailRate()))) &&
            ((this.strDate==null && other.getStrDate()==null) || 
             (this.strDate!=null &&
              this.strDate.equals(other.getStrDate())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAddBedRate() != null) {
            _hashCode += getAddBedRate().hashCode();
        }
        if (getCurrencyCode() != null) {
            _hashCode += getCurrencyCode().hashCode();
        }
        if (getDate() != null) {
            _hashCode += getDate().hashCode();
        }
        if (getInvStatusCode() != null) {
            _hashCode += getInvStatusCode().hashCode();
        }
        if (getMemberRate() != null) {
            _hashCode += getMemberRate().hashCode();
        }
        if (getRetailRate() != null) {
            _hashCode += getRetailRate().hashCode();
        }
        if (getStrDate() != null) {
            _hashCode += getStrDate().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DayRateForHotel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.DayRateForHotel", "DayRateForHotel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("addBedRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "addBedRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currencyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currencyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invStatusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "invStatusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("memberRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "memberRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("retailRate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "retailRate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("strDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "strDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
