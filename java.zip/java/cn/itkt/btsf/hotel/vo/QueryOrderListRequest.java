/**
 * QueryOrderListRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class QueryOrderListRequest  implements java.io.Serializable {
    private java.lang.String currentPage;

    private java.lang.String orderId;

    private java.lang.String orderResource;

    private java.lang.String orderState;

    private java.lang.Integer pageCount;

    private java.lang.String terminald;

    private java.lang.String userId;

    public QueryOrderListRequest() {
    }

    public QueryOrderListRequest(
           java.lang.String currentPage,
           java.lang.String orderId,
           java.lang.String orderResource,
           java.lang.String orderState,
           java.lang.Integer pageCount,
           java.lang.String terminald,
           java.lang.String userId) {
           this.currentPage = currentPage;
           this.orderId = orderId;
           this.orderResource = orderResource;
           this.orderState = orderState;
           this.pageCount = pageCount;
           this.terminald = terminald;
           this.userId = userId;
    }


    /**
     * Gets the currentPage value for this QueryOrderListRequest.
     * 
     * @return currentPage
     */
    public java.lang.String getCurrentPage() {
        return currentPage;
    }


    /**
     * Sets the currentPage value for this QueryOrderListRequest.
     * 
     * @param currentPage
     */
    public void setCurrentPage(java.lang.String currentPage) {
        this.currentPage = currentPage;
    }


    /**
     * Gets the orderId value for this QueryOrderListRequest.
     * 
     * @return orderId
     */
    public java.lang.String getOrderId() {
        return orderId;
    }


    /**
     * Sets the orderId value for this QueryOrderListRequest.
     * 
     * @param orderId
     */
    public void setOrderId(java.lang.String orderId) {
        this.orderId = orderId;
    }


    /**
     * Gets the orderResource value for this QueryOrderListRequest.
     * 
     * @return orderResource
     */
    public java.lang.String getOrderResource() {
        return orderResource;
    }


    /**
     * Sets the orderResource value for this QueryOrderListRequest.
     * 
     * @param orderResource
     */
    public void setOrderResource(java.lang.String orderResource) {
        this.orderResource = orderResource;
    }


    /**
     * Gets the orderState value for this QueryOrderListRequest.
     * 
     * @return orderState
     */
    public java.lang.String getOrderState() {
        return orderState;
    }


    /**
     * Sets the orderState value for this QueryOrderListRequest.
     * 
     * @param orderState
     */
    public void setOrderState(java.lang.String orderState) {
        this.orderState = orderState;
    }


    /**
     * Gets the pageCount value for this QueryOrderListRequest.
     * 
     * @return pageCount
     */
    public java.lang.Integer getPageCount() {
        return pageCount;
    }


    /**
     * Sets the pageCount value for this QueryOrderListRequest.
     * 
     * @param pageCount
     */
    public void setPageCount(java.lang.Integer pageCount) {
        this.pageCount = pageCount;
    }


    /**
     * Gets the terminald value for this QueryOrderListRequest.
     * 
     * @return terminald
     */
    public java.lang.String getTerminald() {
        return terminald;
    }


    /**
     * Sets the terminald value for this QueryOrderListRequest.
     * 
     * @param terminald
     */
    public void setTerminald(java.lang.String terminald) {
        this.terminald = terminald;
    }


    /**
     * Gets the userId value for this QueryOrderListRequest.
     * 
     * @return userId
     */
    public java.lang.String getUserId() {
        return userId;
    }


    /**
     * Sets the userId value for this QueryOrderListRequest.
     * 
     * @param userId
     */
    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof QueryOrderListRequest)) return false;
        QueryOrderListRequest other = (QueryOrderListRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.currentPage==null && other.getCurrentPage()==null) || 
             (this.currentPage!=null &&
              this.currentPage.equals(other.getCurrentPage()))) &&
            ((this.orderId==null && other.getOrderId()==null) || 
             (this.orderId!=null &&
              this.orderId.equals(other.getOrderId()))) &&
            ((this.orderResource==null && other.getOrderResource()==null) || 
             (this.orderResource!=null &&
              this.orderResource.equals(other.getOrderResource()))) &&
            ((this.orderState==null && other.getOrderState()==null) || 
             (this.orderState!=null &&
              this.orderState.equals(other.getOrderState()))) &&
            ((this.pageCount==null && other.getPageCount()==null) || 
             (this.pageCount!=null &&
              this.pageCount.equals(other.getPageCount()))) &&
            ((this.terminald==null && other.getTerminald()==null) || 
             (this.terminald!=null &&
              this.terminald.equals(other.getTerminald()))) &&
            ((this.userId==null && other.getUserId()==null) || 
             (this.userId!=null &&
              this.userId.equals(other.getUserId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCurrentPage() != null) {
            _hashCode += getCurrentPage().hashCode();
        }
        if (getOrderId() != null) {
            _hashCode += getOrderId().hashCode();
        }
        if (getOrderResource() != null) {
            _hashCode += getOrderResource().hashCode();
        }
        if (getOrderState() != null) {
            _hashCode += getOrderState().hashCode();
        }
        if (getPageCount() != null) {
            _hashCode += getPageCount().hashCode();
        }
        if (getTerminald() != null) {
            _hashCode += getTerminald().hashCode();
        }
        if (getUserId() != null) {
            _hashCode += getUserId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(QueryOrderListRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.QueryOrderListRequest", "QueryOrderListRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currentPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderResource");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderResource"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderState");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pageCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "pageCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("terminald");
        elemField.setXmlName(new javax.xml.namespace.QName("", "terminald"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
