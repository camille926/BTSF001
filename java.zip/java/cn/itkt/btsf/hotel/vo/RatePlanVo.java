package cn.itkt.btsf.hotel.vo;

import java.math.BigDecimal;
import java.util.List;

public class RatePlanVo implements java.io.Serializable {

	private static final long serialVersionUID = -9200263704582317947L;

	/** id */
	private int id;
	/** 编码 */
	private String code;
	/** 名称 */
	private String name;
	/** 客人类型 */
	private String guestType;
	/** 平均价格 */
	private BigDecimal avgPrice;
	/** 总价 */
	private BigDecimal totalPrice;
	/** 畅达币 */
	private int lcdMoney;
	/** 均价畅达币 */
	private int lcdAvgMoney;
	/** 畅达币比率 */
	private double lcdMoneyRate;
	/** 畅达币直降额 */
	private int lcdMoneyDown;
	/** 每天价格列表Vo */
	private List<RateVo> rateVos;
	/** 担保规则列表Vo */
	private List<VouchVo> vouchVos;
	/** 预订规则描述 */
	private List<String> bookingRulesDesc;
	/** 增值服务信息描述 */
	private List<String> addValuesDesc;
	/** 产品促销规则描述 */
	private List<String> drrRulesDesc;

	/**
	 * 返回: the id <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public int getId() {
		return id;
	}

	/**
	 * 参数: id to set the id <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * 返回: the code <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public String getCode() {
		return code;
	}

	/**
	 * 参数: code to set the code <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 返回: the name <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public String getName() {
		return name;
	}

	/**
	 * 参数: name to set the name <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * 返回: the guestType <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public String getGuestType() {
		return guestType;
	}

	/**
	 * 参数: guestType to set the guestType <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setGuestType(String guestType) {
		this.guestType = guestType;
	}

	/**
	 * 返回: the avgPrice <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public BigDecimal getAvgPrice() {
		return avgPrice;
	}

	/**
	 * 参数: avgPrice to set the avgPrice <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setAvgPrice(BigDecimal avgPrice) {
		this.avgPrice = avgPrice;
	}

	/**
	 * 返回: the totalPrice <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public BigDecimal getTotalPrice() {
		return totalPrice;
	}

	/**
	 * 参数: totalPrice to set the totalPrice <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setTotalPrice(BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	/**
	 * 返回: the lcdMoney <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public int getLcdMoney() {
		return lcdMoney;
	}

	/**
	 * 参数: lcdMoney to set the lcdMoney <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setLcdMoney(int lcdMoney) {
		this.lcdMoney = lcdMoney;
	}

	/**
	 * 返回: the lcdAvgMoney <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public int getLcdAvgMoney() {
		return lcdAvgMoney;
	}

	/**
	 * 参数: lcdAvgMoney to set the lcdAvgMoney <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setLcdAvgMoney(int lcdAvgMoney) {
		this.lcdAvgMoney = lcdAvgMoney;
	}

	/**
	 * 返回: the lcdMoneyRate <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public double getLcdMoneyRate() {
		return lcdMoneyRate;
	}

	/**
	 * 参数: lcdMoneyRate to set the lcdMoneyRate <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setLcdMoneyRate(double lcdMoneyRate) {
		this.lcdMoneyRate = lcdMoneyRate;
	}

	/**
	 * 返回: the lcdMoneyDown <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public int getLcdMoneyDown() {
		return lcdMoneyDown;
	}

	/**
	 * 参数: lcdMoneyDown to set the lcdMoneyDown <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setLcdMoneyDown(int lcdMoneyDown) {
		this.lcdMoneyDown = lcdMoneyDown;
	}

	/**
	 * 返回: the rateVos <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public List<RateVo> getRateVos() {
		return rateVos;
	}

	/**
	 * 参数: rateVos to set the rateVos <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setRateVos(List<RateVo> rateVos) {
		this.rateVos = rateVos;
	}

	/**
	 * 返回: the vouchInfos <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public List<VouchVo> getVouchVos() {
		return vouchVos;
	}

	/**
	 * 参数: vouchInfos to set the vouchInfos <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setVouchVos(List<VouchVo> vouchVos) {
		this.vouchVos = vouchVos;
	}

	/**
	 * 返回: the bookingRulesDesc <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public List<String> getBookingRulesDesc() {
		return bookingRulesDesc;
	}

	/**
	 * 参数: bookingRulesDesc to set the bookingRulesDesc <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setBookingRulesDesc(List<String> bookingRulesDesc) {
		this.bookingRulesDesc = bookingRulesDesc;
	}

	/**
	 * 返回: the addValuesDesc <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public List<String> getAddValuesDesc() {
		return addValuesDesc;
	}

	/**
	 * 参数: addValuesDesc to set the addValuesDesc <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setAddValuesDesc(List<String> addValuesDesc) {
		this.addValuesDesc = addValuesDesc;
	}

	/**
	 * 返回: the drrRulesDesc <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public List<String> getDrrRulesDesc() {
		return drrRulesDesc;
	}

	/**
	 * 参数: drrRulesDesc to set the drrRulesDesc <br>
	 * 时间: 2013-1-30 下午03:12:54
	 */
	public void setDrrRulesDesc(List<String> drrRulesDesc) {
		this.drrRulesDesc = drrRulesDesc;
	}
}
