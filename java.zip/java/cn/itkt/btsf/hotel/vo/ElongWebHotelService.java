/**
 * ElongWebHotelService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public interface ElongWebHotelService extends java.rmi.Remote {
    public cn.itkt.btsf.hotel.vo.HotelBrandsVo findBtsfHotelBasicBrand(java.lang.String terminalId) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelRegionVo findCityInfo(java.lang.String terminalId) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelDistrictsVo findHotelDistrict(java.lang.String terminalId, java.lang.String citycode) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelLandMarksVo findHotelLandMark(java.lang.String terminalId, java.lang.String citycode) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelBrandsVo getHotelBrandsVoByCity(java.lang.String terminalId, java.lang.String citycode) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelCommsVo findHotelCommsVo(java.lang.String terminalId, java.lang.String citycode) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelQueryResultVO findHotelQueryResultVO(cn.itkt.btsf.hotel.vo.HotelListQueryRequest hotelListQueryRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelQueryResultVO findOneHotelQueryResultVO(cn.itkt.btsf.hotel.vo.HotelOneQueryRequest hotelListQueryRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelProductVouchVo getHotelProductVouchVo(cn.itkt.btsf.hotel.vo.HotelProductVouchRequest orderVouchRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelOrderVo getHotelOrderVo(cn.itkt.btsf.hotel.vo.HotelOrderRequest orderRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.PopularCitysVo findPopularCity(cn.itkt.btsf.hotel.vo.PopularCityRequest cityRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.RoomReserveInfoVo getRoomReserveInfoVo(cn.itkt.btsf.hotel.vo.RoomReserveRequest reserveRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelOrderDetailsVo gethotelOrderDetailList(cn.itkt.btsf.hotel.vo.QueryOrderListRequest orderRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelEconomicsVO getHotelEconomicsVO(cn.itkt.btsf.hotel.vo.EconomicsRequest economicsRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelEconomicsVO getSimpleBrandBycityId(cn.itkt.btsf.hotel.vo.EconomicsRequest economicsRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.RelateOrdersVo getRelateOrders(cn.itkt.btsf.hotel.vo.RelateOrderRequest relateOrderRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.CreditCardsVo getCreditCardList(java.lang.String userId, java.lang.String addSource) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.BaseVo addCreditCard(cn.itkt.btsf.hotel.vo.CreditCardRequest cardRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.BaseVo deleteCreditCard(java.lang.String cardIds) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.BaseVo modifyCreditCard(cn.itkt.btsf.hotel.vo.CreditCardRequest cardRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.InterestHotelVo getInterestHotelVo(cn.itkt.btsf.hotel.vo.InterestHotelRequest hotelRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.BaseVo cancelHotelOrderById(java.lang.String terminald, java.lang.String orderId, java.lang.String cancelReason) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelBrandDetailInfoVo findHotelBrandsVo(cn.itkt.btsf.hotel.vo.HotelBrandRequest brandRequest) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelCommentVo getHotelComment(java.lang.String terminalId, java.lang.String hotleID) throws java.rmi.RemoteException;
    public cn.itkt.btsf.hotel.vo.HotelOrderStateResult importOrderOrSynChroNized(java.lang.String terminald, java.lang.String orders, boolean importOrSynchronized) throws java.rmi.RemoteException;
}
