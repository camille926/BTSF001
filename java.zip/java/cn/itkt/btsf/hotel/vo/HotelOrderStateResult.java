/**
 * HotelOrderStateResult.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelOrderStateResult  extends cn.itkt.btsf.hotel.vo.BaseVo  implements java.io.Serializable {
    private java.lang.String[] errorOrder;

    public HotelOrderStateResult() {
    }

    public HotelOrderStateResult(
           java.lang.String message,
           java.lang.String status,
           java.lang.String[] errorOrder) {
        super(
            message,
            status);
        this.errorOrder = errorOrder;
    }


    /**
     * Gets the errorOrder value for this HotelOrderStateResult.
     * 
     * @return errorOrder
     */
    public java.lang.String[] getErrorOrder() {
        return errorOrder;
    }


    /**
     * Sets the errorOrder value for this HotelOrderStateResult.
     * 
     * @param errorOrder
     */
    public void setErrorOrder(java.lang.String[] errorOrder) {
        this.errorOrder = errorOrder;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelOrderStateResult)) return false;
        HotelOrderStateResult other = (HotelOrderStateResult) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.errorOrder==null && other.getErrorOrder()==null) || 
             (this.errorOrder!=null &&
              java.util.Arrays.equals(this.errorOrder, other.getErrorOrder())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getErrorOrder() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getErrorOrder());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getErrorOrder(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelOrderStateResult.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderStateResult", "HotelOrderStateResult"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorOrder");
        elemField.setXmlName(new javax.xml.namespace.QName("", "errorOrder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
