/**
 * ImageForHotel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class ImageForHotel  implements java.io.Serializable {
    private java.lang.String imageCode;

    private java.lang.String imageSize;

    private java.lang.String imageTitle;

    private java.lang.String imageType;

    private java.lang.String imageUrl;

    private java.lang.String roomTypeId;

    public ImageForHotel() {
    }

    public ImageForHotel(
           java.lang.String imageCode,
           java.lang.String imageSize,
           java.lang.String imageTitle,
           java.lang.String imageType,
           java.lang.String imageUrl,
           java.lang.String roomTypeId) {
           this.imageCode = imageCode;
           this.imageSize = imageSize;
           this.imageTitle = imageTitle;
           this.imageType = imageType;
           this.imageUrl = imageUrl;
           this.roomTypeId = roomTypeId;
    }


    /**
     * Gets the imageCode value for this ImageForHotel.
     * 
     * @return imageCode
     */
    public java.lang.String getImageCode() {
        return imageCode;
    }


    /**
     * Sets the imageCode value for this ImageForHotel.
     * 
     * @param imageCode
     */
    public void setImageCode(java.lang.String imageCode) {
        this.imageCode = imageCode;
    }


    /**
     * Gets the imageSize value for this ImageForHotel.
     * 
     * @return imageSize
     */
    public java.lang.String getImageSize() {
        return imageSize;
    }


    /**
     * Sets the imageSize value for this ImageForHotel.
     * 
     * @param imageSize
     */
    public void setImageSize(java.lang.String imageSize) {
        this.imageSize = imageSize;
    }


    /**
     * Gets the imageTitle value for this ImageForHotel.
     * 
     * @return imageTitle
     */
    public java.lang.String getImageTitle() {
        return imageTitle;
    }


    /**
     * Sets the imageTitle value for this ImageForHotel.
     * 
     * @param imageTitle
     */
    public void setImageTitle(java.lang.String imageTitle) {
        this.imageTitle = imageTitle;
    }


    /**
     * Gets the imageType value for this ImageForHotel.
     * 
     * @return imageType
     */
    public java.lang.String getImageType() {
        return imageType;
    }


    /**
     * Sets the imageType value for this ImageForHotel.
     * 
     * @param imageType
     */
    public void setImageType(java.lang.String imageType) {
        this.imageType = imageType;
    }


    /**
     * Gets the imageUrl value for this ImageForHotel.
     * 
     * @return imageUrl
     */
    public java.lang.String getImageUrl() {
        return imageUrl;
    }


    /**
     * Sets the imageUrl value for this ImageForHotel.
     * 
     * @param imageUrl
     */
    public void setImageUrl(java.lang.String imageUrl) {
        this.imageUrl = imageUrl;
    }


    /**
     * Gets the roomTypeId value for this ImageForHotel.
     * 
     * @return roomTypeId
     */
    public java.lang.String getRoomTypeId() {
        return roomTypeId;
    }


    /**
     * Sets the roomTypeId value for this ImageForHotel.
     * 
     * @param roomTypeId
     */
    public void setRoomTypeId(java.lang.String roomTypeId) {
        this.roomTypeId = roomTypeId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ImageForHotel)) return false;
        ImageForHotel other = (ImageForHotel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.imageCode==null && other.getImageCode()==null) || 
             (this.imageCode!=null &&
              this.imageCode.equals(other.getImageCode()))) &&
            ((this.imageSize==null && other.getImageSize()==null) || 
             (this.imageSize!=null &&
              this.imageSize.equals(other.getImageSize()))) &&
            ((this.imageTitle==null && other.getImageTitle()==null) || 
             (this.imageTitle!=null &&
              this.imageTitle.equals(other.getImageTitle()))) &&
            ((this.imageType==null && other.getImageType()==null) || 
             (this.imageType!=null &&
              this.imageType.equals(other.getImageType()))) &&
            ((this.imageUrl==null && other.getImageUrl()==null) || 
             (this.imageUrl!=null &&
              this.imageUrl.equals(other.getImageUrl()))) &&
            ((this.roomTypeId==null && other.getRoomTypeId()==null) || 
             (this.roomTypeId!=null &&
              this.roomTypeId.equals(other.getRoomTypeId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getImageCode() != null) {
            _hashCode += getImageCode().hashCode();
        }
        if (getImageSize() != null) {
            _hashCode += getImageSize().hashCode();
        }
        if (getImageTitle() != null) {
            _hashCode += getImageTitle().hashCode();
        }
        if (getImageType() != null) {
            _hashCode += getImageType().hashCode();
        }
        if (getImageUrl() != null) {
            _hashCode += getImageUrl().hashCode();
        }
        if (getRoomTypeId() != null) {
            _hashCode += getRoomTypeId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ImageForHotel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.ImageForHotel", "ImageForHotel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("imageCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "imageCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("imageSize");
        elemField.setXmlName(new javax.xml.namespace.QName("", "imageSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("imageTitle");
        elemField.setXmlName(new javax.xml.namespace.QName("", "imageTitle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("imageType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "imageType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("imageUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "imageUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
