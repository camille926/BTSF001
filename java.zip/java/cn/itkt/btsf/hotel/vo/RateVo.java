package cn.itkt.btsf.hotel.vo;

import java.math.BigDecimal;
import java.util.Date;

public class RateVo implements java.io.Serializable {

	private static final long serialVersionUID = -4455181700043250837L;

	/** 日期 */
	private Date date;
	/** 货币代码 */
	private String currencyCode;
	/** 房态 */
	private String status;
	/** 门市价 */
	private BigDecimal retailRate;
	/** 会员价 */
	private BigDecimal memberRate;
	/** 加床价 */
	private BigDecimal addBedRate;

	/**
	 * 返回: the date <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public Date getDate() {
		return date;
	}

	/**
	 * 参数: date to set the date <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public void setDate(Date date) {
		this.date = date;
	}

	/**
	 * 返回: the currencyCode <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public String getCurrencyCode() {
		return currencyCode;
	}

	/**
	 * 参数: currencyCode to set the currencyCode <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	/**
	 * 返回: the status <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * 参数: status to set the status <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * 返回: the retailRate <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public BigDecimal getRetailRate() {
		return retailRate;
	}

	/**
	 * 参数: retailRate to set the retailRate <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public void setRetailRate(BigDecimal retailRate) {
		this.retailRate = retailRate;
	}

	/**
	 * 返回: the memberRate <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public BigDecimal getMemberRate() {
		return memberRate;
	}

	/**
	 * 参数: memberRate to set the memberRate <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public void setMemberRate(BigDecimal memberRate) {
		this.memberRate = memberRate;
	}

	/**
	 * 返回: the addBedRate <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public BigDecimal getAddBedRate() {
		return addBedRate;
	}

	/**
	 * 参数: addBedRate to set the addBedRate <br>
	 * 时间: 2013-1-30 下午02:34:12
	 */
	public void setAddBedRate(BigDecimal addBedRate) {
		this.addBedRate = addBedRate;
	}
}
