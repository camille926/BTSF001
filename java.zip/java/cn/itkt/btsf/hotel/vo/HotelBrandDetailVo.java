/**
 * HotelBrandDetailVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelBrandDetailVo  implements java.io.Serializable {
    private java.lang.String hotelAddress;

    private java.lang.String hotelCode;

    private java.lang.Long hotelId;

    private java.lang.String hotelImagePath;

    private java.lang.String hotelName;

    private java.lang.String returnLcdCurrency;

    public HotelBrandDetailVo() {
    }

    public HotelBrandDetailVo(
           java.lang.String hotelAddress,
           java.lang.String hotelCode,
           java.lang.Long hotelId,
           java.lang.String hotelImagePath,
           java.lang.String hotelName,
           java.lang.String returnLcdCurrency) {
           this.hotelAddress = hotelAddress;
           this.hotelCode = hotelCode;
           this.hotelId = hotelId;
           this.hotelImagePath = hotelImagePath;
           this.hotelName = hotelName;
           this.returnLcdCurrency = returnLcdCurrency;
    }


    /**
     * Gets the hotelAddress value for this HotelBrandDetailVo.
     * 
     * @return hotelAddress
     */
    public java.lang.String getHotelAddress() {
        return hotelAddress;
    }


    /**
     * Sets the hotelAddress value for this HotelBrandDetailVo.
     * 
     * @param hotelAddress
     */
    public void setHotelAddress(java.lang.String hotelAddress) {
        this.hotelAddress = hotelAddress;
    }


    /**
     * Gets the hotelCode value for this HotelBrandDetailVo.
     * 
     * @return hotelCode
     */
    public java.lang.String getHotelCode() {
        return hotelCode;
    }


    /**
     * Sets the hotelCode value for this HotelBrandDetailVo.
     * 
     * @param hotelCode
     */
    public void setHotelCode(java.lang.String hotelCode) {
        this.hotelCode = hotelCode;
    }


    /**
     * Gets the hotelId value for this HotelBrandDetailVo.
     * 
     * @return hotelId
     */
    public java.lang.Long getHotelId() {
        return hotelId;
    }


    /**
     * Sets the hotelId value for this HotelBrandDetailVo.
     * 
     * @param hotelId
     */
    public void setHotelId(java.lang.Long hotelId) {
        this.hotelId = hotelId;
    }


    /**
     * Gets the hotelImagePath value for this HotelBrandDetailVo.
     * 
     * @return hotelImagePath
     */
    public java.lang.String getHotelImagePath() {
        return hotelImagePath;
    }


    /**
     * Sets the hotelImagePath value for this HotelBrandDetailVo.
     * 
     * @param hotelImagePath
     */
    public void setHotelImagePath(java.lang.String hotelImagePath) {
        this.hotelImagePath = hotelImagePath;
    }


    /**
     * Gets the hotelName value for this HotelBrandDetailVo.
     * 
     * @return hotelName
     */
    public java.lang.String getHotelName() {
        return hotelName;
    }


    /**
     * Sets the hotelName value for this HotelBrandDetailVo.
     * 
     * @param hotelName
     */
    public void setHotelName(java.lang.String hotelName) {
        this.hotelName = hotelName;
    }


    /**
     * Gets the returnLcdCurrency value for this HotelBrandDetailVo.
     * 
     * @return returnLcdCurrency
     */
    public java.lang.String getReturnLcdCurrency() {
        return returnLcdCurrency;
    }


    /**
     * Sets the returnLcdCurrency value for this HotelBrandDetailVo.
     * 
     * @param returnLcdCurrency
     */
    public void setReturnLcdCurrency(java.lang.String returnLcdCurrency) {
        this.returnLcdCurrency = returnLcdCurrency;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelBrandDetailVo)) return false;
        HotelBrandDetailVo other = (HotelBrandDetailVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.hotelAddress==null && other.getHotelAddress()==null) || 
             (this.hotelAddress!=null &&
              this.hotelAddress.equals(other.getHotelAddress()))) &&
            ((this.hotelCode==null && other.getHotelCode()==null) || 
             (this.hotelCode!=null &&
              this.hotelCode.equals(other.getHotelCode()))) &&
            ((this.hotelId==null && other.getHotelId()==null) || 
             (this.hotelId!=null &&
              this.hotelId.equals(other.getHotelId()))) &&
            ((this.hotelImagePath==null && other.getHotelImagePath()==null) || 
             (this.hotelImagePath!=null &&
              this.hotelImagePath.equals(other.getHotelImagePath()))) &&
            ((this.hotelName==null && other.getHotelName()==null) || 
             (this.hotelName!=null &&
              this.hotelName.equals(other.getHotelName()))) &&
            ((this.returnLcdCurrency==null && other.getReturnLcdCurrency()==null) || 
             (this.returnLcdCurrency!=null &&
              this.returnLcdCurrency.equals(other.getReturnLcdCurrency())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHotelAddress() != null) {
            _hashCode += getHotelAddress().hashCode();
        }
        if (getHotelCode() != null) {
            _hashCode += getHotelCode().hashCode();
        }
        if (getHotelId() != null) {
            _hashCode += getHotelId().hashCode();
        }
        if (getHotelImagePath() != null) {
            _hashCode += getHotelImagePath().hashCode();
        }
        if (getHotelName() != null) {
            _hashCode += getHotelName().hashCode();
        }
        if (getReturnLcdCurrency() != null) {
            _hashCode += getReturnLcdCurrency().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelBrandDetailVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandDetailVo", "HotelBrandDetailVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelImagePath");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelImagePath"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("returnLcdCurrency");
        elemField.setXmlName(new javax.xml.namespace.QName("", "returnLcdCurrency"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
