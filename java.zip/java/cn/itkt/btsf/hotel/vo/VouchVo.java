package cn.itkt.btsf.hotel.vo;

import java.io.Serializable;

/**
 * 类: VouchInfo <br>
 * 描述: 担保信息 <br>
 * 作者: 王鹏 wangpeng@itkt.com <br>
 * 时间: 2013-1-29 下午02:10:56
 */
public class VouchVo implements Serializable {

	private static final long serialVersionUID = 6744771438150725997L;

	/** 是否担保 */
	private int isVouch;
	/** 是否根据时间担保 */
	private int isTimeVouch;
	/** 是否根据房间数量担保 */
	private int isRoomAmountVouch;
	/** 担保房间数量 */
	private int roomAmount;
	/** 担保金额方式 */
	private int vouchMoneyType;
	/** 不担保时间 */
	private String notVouchTime;
	/** 不担保描述 */
	private String notVouchDescription;
	/** 担保时间 */
	private String vouchTime;
	/** 担保描述 */
	private String vouchDescription;
	/** 描述 */
	private String description;

	/**
	 * 返回: the isVouch <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public int getIsVouch() {
		return isVouch;
	}

	/**
	 * 参数: isVouch to set the isVouch <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setIsVouch(int isVouch) {
		this.isVouch = isVouch;
	}

	/**
	 * 返回: the isTimeVouch <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public int getIsTimeVouch() {
		return isTimeVouch;
	}

	/**
	 * 参数: isTimeVouch to set the isTimeVouch <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setIsTimeVouch(int isTimeVouch) {
		this.isTimeVouch = isTimeVouch;
	}

	/**
	 * 返回: the isRoomAmountVouch <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public int getIsRoomAmountVouch() {
		return isRoomAmountVouch;
	}

	/**
	 * 参数: isRoomAmountVouch to set the isRoomAmountVouch <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setIsRoomAmountVouch(int isRoomAmountVouch) {
		this.isRoomAmountVouch = isRoomAmountVouch;
	}

	/**
	 * 返回: the roomAmount <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public int getRoomAmount() {
		return roomAmount;
	}

	/**
	 * 参数: roomAmount to set the roomAmount <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setRoomAmount(int roomAmount) {
		this.roomAmount = roomAmount;
	}

	/**
	 * 返回: the vouchMoneyType <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public int getVouchMoneyType() {
		return vouchMoneyType;
	}

	/**
	 * 参数: vouchMoneyType to set the vouchMoneyType <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setVouchMoneyType(int vouchMoneyType) {
		this.vouchMoneyType = vouchMoneyType;
	}

	/**
	 * 返回: the notVouchTime <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public String getNotVouchTime() {
		return notVouchTime;
	}

	/**
	 * 参数: notVouchTime to set the notVouchTime <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setNotVouchTime(String notVouchTime) {
		this.notVouchTime = notVouchTime;
	}

	/**
	 * 返回: the notVouchDescription <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public String getNotVouchDescription() {
		return notVouchDescription;
	}

	/**
	 * 参数: notVouchDescription to set the notVouchDescription <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setNotVouchDescription(String notVouchDescription) {
		this.notVouchDescription = notVouchDescription;
	}

	/**
	 * 返回: the vouchTime <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public String getVouchTime() {
		return vouchTime;
	}

	/**
	 * 参数: vouchTime to set the vouchTime <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setVouchTime(String vouchTime) {
		this.vouchTime = vouchTime;
	}

	/**
	 * 返回: the vouchDescription <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public String getVouchDescription() {
		return vouchDescription;
	}

	/**
	 * 参数: vouchDescription to set the vouchDescription <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setVouchDescription(String vouchDescription) {
		this.vouchDescription = vouchDescription;
	}

	/**
	 * 返回: the description <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * 参数: description to set the description <br>
	 * 时间: 2013-1-29 下午02:10:44
	 */
	public void setDescription(String description) {
		this.description = description;
	}
}
