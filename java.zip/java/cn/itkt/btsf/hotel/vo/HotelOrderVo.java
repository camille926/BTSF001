/**
 * HotelOrderVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelOrderVo  extends cn.itkt.btsf.hotel.vo.BaseVo  implements java.io.Serializable {
    private java.util.Calendar checkInDate;

    private java.util.Calendar checkOutDate;

    private java.lang.String hotelName;

    private int hotelOrderId;

    private java.lang.String lcdOrderId;

    private java.lang.String paymentType;

    private double price;

    private int roomAmount;

    private java.lang.String roomType;

    public HotelOrderVo() {
    }

    public HotelOrderVo(
           java.lang.String message,
           java.lang.String status,
           java.util.Calendar checkInDate,
           java.util.Calendar checkOutDate,
           java.lang.String hotelName,
           int hotelOrderId,
           java.lang.String lcdOrderId,
           java.lang.String paymentType,
           double price,
           int roomAmount,
           java.lang.String roomType) {
        super(
            message,
            status);
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.hotelName = hotelName;
        this.hotelOrderId = hotelOrderId;
        this.lcdOrderId = lcdOrderId;
        this.paymentType = paymentType;
        this.price = price;
        this.roomAmount = roomAmount;
        this.roomType = roomType;
    }


    /**
     * Gets the checkInDate value for this HotelOrderVo.
     * 
     * @return checkInDate
     */
    public java.util.Calendar getCheckInDate() {
        return checkInDate;
    }


    /**
     * Sets the checkInDate value for this HotelOrderVo.
     * 
     * @param checkInDate
     */
    public void setCheckInDate(java.util.Calendar checkInDate) {
        this.checkInDate = checkInDate;
    }


    /**
     * Gets the checkOutDate value for this HotelOrderVo.
     * 
     * @return checkOutDate
     */
    public java.util.Calendar getCheckOutDate() {
        return checkOutDate;
    }


    /**
     * Sets the checkOutDate value for this HotelOrderVo.
     * 
     * @param checkOutDate
     */
    public void setCheckOutDate(java.util.Calendar checkOutDate) {
        this.checkOutDate = checkOutDate;
    }


    /**
     * Gets the hotelName value for this HotelOrderVo.
     * 
     * @return hotelName
     */
    public java.lang.String getHotelName() {
        return hotelName;
    }


    /**
     * Sets the hotelName value for this HotelOrderVo.
     * 
     * @param hotelName
     */
    public void setHotelName(java.lang.String hotelName) {
        this.hotelName = hotelName;
    }


    /**
     * Gets the hotelOrderId value for this HotelOrderVo.
     * 
     * @return hotelOrderId
     */
    public int getHotelOrderId() {
        return hotelOrderId;
    }


    /**
     * Sets the hotelOrderId value for this HotelOrderVo.
     * 
     * @param hotelOrderId
     */
    public void setHotelOrderId(int hotelOrderId) {
        this.hotelOrderId = hotelOrderId;
    }


    /**
     * Gets the lcdOrderId value for this HotelOrderVo.
     * 
     * @return lcdOrderId
     */
    public java.lang.String getLcdOrderId() {
        return lcdOrderId;
    }


    /**
     * Sets the lcdOrderId value for this HotelOrderVo.
     * 
     * @param lcdOrderId
     */
    public void setLcdOrderId(java.lang.String lcdOrderId) {
        this.lcdOrderId = lcdOrderId;
    }


    /**
     * Gets the paymentType value for this HotelOrderVo.
     * 
     * @return paymentType
     */
    public java.lang.String getPaymentType() {
        return paymentType;
    }


    /**
     * Sets the paymentType value for this HotelOrderVo.
     * 
     * @param paymentType
     */
    public void setPaymentType(java.lang.String paymentType) {
        this.paymentType = paymentType;
    }


    /**
     * Gets the price value for this HotelOrderVo.
     * 
     * @return price
     */
    public double getPrice() {
        return price;
    }


    /**
     * Sets the price value for this HotelOrderVo.
     * 
     * @param price
     */
    public void setPrice(double price) {
        this.price = price;
    }


    /**
     * Gets the roomAmount value for this HotelOrderVo.
     * 
     * @return roomAmount
     */
    public int getRoomAmount() {
        return roomAmount;
    }


    /**
     * Sets the roomAmount value for this HotelOrderVo.
     * 
     * @param roomAmount
     */
    public void setRoomAmount(int roomAmount) {
        this.roomAmount = roomAmount;
    }


    /**
     * Gets the roomType value for this HotelOrderVo.
     * 
     * @return roomType
     */
    public java.lang.String getRoomType() {
        return roomType;
    }


    /**
     * Sets the roomType value for this HotelOrderVo.
     * 
     * @param roomType
     */
    public void setRoomType(java.lang.String roomType) {
        this.roomType = roomType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelOrderVo)) return false;
        HotelOrderVo other = (HotelOrderVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.checkInDate==null && other.getCheckInDate()==null) || 
             (this.checkInDate!=null &&
              this.checkInDate.equals(other.getCheckInDate()))) &&
            ((this.checkOutDate==null && other.getCheckOutDate()==null) || 
             (this.checkOutDate!=null &&
              this.checkOutDate.equals(other.getCheckOutDate()))) &&
            ((this.hotelName==null && other.getHotelName()==null) || 
             (this.hotelName!=null &&
              this.hotelName.equals(other.getHotelName()))) &&
            this.hotelOrderId == other.getHotelOrderId() &&
            ((this.lcdOrderId==null && other.getLcdOrderId()==null) || 
             (this.lcdOrderId!=null &&
              this.lcdOrderId.equals(other.getLcdOrderId()))) &&
            ((this.paymentType==null && other.getPaymentType()==null) || 
             (this.paymentType!=null &&
              this.paymentType.equals(other.getPaymentType()))) &&
            this.price == other.getPrice() &&
            this.roomAmount == other.getRoomAmount() &&
            ((this.roomType==null && other.getRoomType()==null) || 
             (this.roomType!=null &&
              this.roomType.equals(other.getRoomType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCheckInDate() != null) {
            _hashCode += getCheckInDate().hashCode();
        }
        if (getCheckOutDate() != null) {
            _hashCode += getCheckOutDate().hashCode();
        }
        if (getHotelName() != null) {
            _hashCode += getHotelName().hashCode();
        }
        _hashCode += getHotelOrderId();
        if (getLcdOrderId() != null) {
            _hashCode += getLcdOrderId().hashCode();
        }
        if (getPaymentType() != null) {
            _hashCode += getPaymentType().hashCode();
        }
        _hashCode += new Double(getPrice()).hashCode();
        _hashCode += getRoomAmount();
        if (getRoomType() != null) {
            _hashCode += getRoomType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelOrderVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelOrderVo", "HotelOrderVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkInDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkInDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkOutDate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "checkOutDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelOrderId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelOrderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lcdOrderId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lcdOrderId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("paymentType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "paymentType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("price");
        elemField.setXmlName(new javax.xml.namespace.QName("", "price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomAmount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomAmount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("roomType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "roomType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
