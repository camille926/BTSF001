/**
 * RelateOrderRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class RelateOrderRequest  implements java.io.Serializable {
    private java.lang.String[] orderIds;

    private java.lang.String relateType;

    public RelateOrderRequest() {
    }

    public RelateOrderRequest(
           java.lang.String[] orderIds,
           java.lang.String relateType) {
           this.orderIds = orderIds;
           this.relateType = relateType;
    }


    /**
     * Gets the orderIds value for this RelateOrderRequest.
     * 
     * @return orderIds
     */
    public java.lang.String[] getOrderIds() {
        return orderIds;
    }


    /**
     * Sets the orderIds value for this RelateOrderRequest.
     * 
     * @param orderIds
     */
    public void setOrderIds(java.lang.String[] orderIds) {
        this.orderIds = orderIds;
    }


    /**
     * Gets the relateType value for this RelateOrderRequest.
     * 
     * @return relateType
     */
    public java.lang.String getRelateType() {
        return relateType;
    }


    /**
     * Sets the relateType value for this RelateOrderRequest.
     * 
     * @param relateType
     */
    public void setRelateType(java.lang.String relateType) {
        this.relateType = relateType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RelateOrderRequest)) return false;
        RelateOrderRequest other = (RelateOrderRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.orderIds==null && other.getOrderIds()==null) || 
             (this.orderIds!=null &&
              java.util.Arrays.equals(this.orderIds, other.getOrderIds()))) &&
            ((this.relateType==null && other.getRelateType()==null) || 
             (this.relateType!=null &&
              this.relateType.equals(other.getRelateType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderIds() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOrderIds());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOrderIds(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRelateType() != null) {
            _hashCode += getRelateType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RelateOrderRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.request.RelateOrderRequest", "RelateOrderRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderIds");
        elemField.setXmlName(new javax.xml.namespace.QName("", "orderIds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relateType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "relateType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
