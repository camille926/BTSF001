/**
 * HoteloneEconomicVO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HoteloneEconomicVO  implements java.io.Serializable {
    private java.lang.String hotelBigUrl;

    private java.lang.String hotelId;

    private java.lang.String hotelName;

    private java.lang.String hotelUrl;

    private java.math.BigDecimal lowestMoney;

    public HoteloneEconomicVO() {
    }

    public HoteloneEconomicVO(
           java.lang.String hotelBigUrl,
           java.lang.String hotelId,
           java.lang.String hotelName,
           java.lang.String hotelUrl,
           java.math.BigDecimal lowestMoney) {
           this.hotelBigUrl = hotelBigUrl;
           this.hotelId = hotelId;
           this.hotelName = hotelName;
           this.hotelUrl = hotelUrl;
           this.lowestMoney = lowestMoney;
    }


    /**
     * Gets the hotelBigUrl value for this HoteloneEconomicVO.
     * 
     * @return hotelBigUrl
     */
    public java.lang.String getHotelBigUrl() {
        return hotelBigUrl;
    }


    /**
     * Sets the hotelBigUrl value for this HoteloneEconomicVO.
     * 
     * @param hotelBigUrl
     */
    public void setHotelBigUrl(java.lang.String hotelBigUrl) {
        this.hotelBigUrl = hotelBigUrl;
    }


    /**
     * Gets the hotelId value for this HoteloneEconomicVO.
     * 
     * @return hotelId
     */
    public java.lang.String getHotelId() {
        return hotelId;
    }


    /**
     * Sets the hotelId value for this HoteloneEconomicVO.
     * 
     * @param hotelId
     */
    public void setHotelId(java.lang.String hotelId) {
        this.hotelId = hotelId;
    }


    /**
     * Gets the hotelName value for this HoteloneEconomicVO.
     * 
     * @return hotelName
     */
    public java.lang.String getHotelName() {
        return hotelName;
    }


    /**
     * Sets the hotelName value for this HoteloneEconomicVO.
     * 
     * @param hotelName
     */
    public void setHotelName(java.lang.String hotelName) {
        this.hotelName = hotelName;
    }


    /**
     * Gets the hotelUrl value for this HoteloneEconomicVO.
     * 
     * @return hotelUrl
     */
    public java.lang.String getHotelUrl() {
        return hotelUrl;
    }


    /**
     * Sets the hotelUrl value for this HoteloneEconomicVO.
     * 
     * @param hotelUrl
     */
    public void setHotelUrl(java.lang.String hotelUrl) {
        this.hotelUrl = hotelUrl;
    }


    /**
     * Gets the lowestMoney value for this HoteloneEconomicVO.
     * 
     * @return lowestMoney
     */
    public java.math.BigDecimal getLowestMoney() {
        return lowestMoney;
    }


    /**
     * Sets the lowestMoney value for this HoteloneEconomicVO.
     * 
     * @param lowestMoney
     */
    public void setLowestMoney(java.math.BigDecimal lowestMoney) {
        this.lowestMoney = lowestMoney;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HoteloneEconomicVO)) return false;
        HoteloneEconomicVO other = (HoteloneEconomicVO) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.hotelBigUrl==null && other.getHotelBigUrl()==null) || 
             (this.hotelBigUrl!=null &&
              this.hotelBigUrl.equals(other.getHotelBigUrl()))) &&
            ((this.hotelId==null && other.getHotelId()==null) || 
             (this.hotelId!=null &&
              this.hotelId.equals(other.getHotelId()))) &&
            ((this.hotelName==null && other.getHotelName()==null) || 
             (this.hotelName!=null &&
              this.hotelName.equals(other.getHotelName()))) &&
            ((this.hotelUrl==null && other.getHotelUrl()==null) || 
             (this.hotelUrl!=null &&
              this.hotelUrl.equals(other.getHotelUrl()))) &&
            ((this.lowestMoney==null && other.getLowestMoney()==null) || 
             (this.lowestMoney!=null &&
              this.lowestMoney.equals(other.getLowestMoney())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getHotelBigUrl() != null) {
            _hashCode += getHotelBigUrl().hashCode();
        }
        if (getHotelId() != null) {
            _hashCode += getHotelId().hashCode();
        }
        if (getHotelName() != null) {
            _hashCode += getHotelName().hashCode();
        }
        if (getHotelUrl() != null) {
            _hashCode += getHotelUrl().hashCode();
        }
        if (getLowestMoney() != null) {
            _hashCode += getLowestMoney().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HoteloneEconomicVO.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HoteloneEconomicVO", "HoteloneEconomicVO"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelBigUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelBigUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lowestMoney");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lowestMoney"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
