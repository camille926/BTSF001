/**
 * HotelBrandVo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelBrandVo  implements java.io.Serializable {
    private java.lang.String brandFirstletter;

    private java.lang.String brandID;

    private java.lang.String brandName;

    private java.lang.String brandNameLong;

    private java.lang.String brandPinYin;

    private java.lang.String brandURL;

    private java.lang.String groupId;

    private java.lang.String hotelCount;

    private java.lang.String picURL;

    public HotelBrandVo() {
    }

    public HotelBrandVo(
           java.lang.String brandFirstletter,
           java.lang.String brandID,
           java.lang.String brandName,
           java.lang.String brandNameLong,
           java.lang.String brandPinYin,
           java.lang.String brandURL,
           java.lang.String groupId,
           java.lang.String hotelCount,
           java.lang.String picURL) {
           this.brandFirstletter = brandFirstletter;
           this.brandID = brandID;
           this.brandName = brandName;
           this.brandNameLong = brandNameLong;
           this.brandPinYin = brandPinYin;
           this.brandURL = brandURL;
           this.groupId = groupId;
           this.hotelCount = hotelCount;
           this.picURL = picURL;
    }


    /**
     * Gets the brandFirstletter value for this HotelBrandVo.
     * 
     * @return brandFirstletter
     */
    public java.lang.String getBrandFirstletter() {
        return brandFirstletter;
    }


    /**
     * Sets the brandFirstletter value for this HotelBrandVo.
     * 
     * @param brandFirstletter
     */
    public void setBrandFirstletter(java.lang.String brandFirstletter) {
        this.brandFirstletter = brandFirstletter;
    }


    /**
     * Gets the brandID value for this HotelBrandVo.
     * 
     * @return brandID
     */
    public java.lang.String getBrandID() {
        return brandID;
    }


    /**
     * Sets the brandID value for this HotelBrandVo.
     * 
     * @param brandID
     */
    public void setBrandID(java.lang.String brandID) {
        this.brandID = brandID;
    }


    /**
     * Gets the brandName value for this HotelBrandVo.
     * 
     * @return brandName
     */
    public java.lang.String getBrandName() {
        return brandName;
    }


    /**
     * Sets the brandName value for this HotelBrandVo.
     * 
     * @param brandName
     */
    public void setBrandName(java.lang.String brandName) {
        this.brandName = brandName;
    }


    /**
     * Gets the brandNameLong value for this HotelBrandVo.
     * 
     * @return brandNameLong
     */
    public java.lang.String getBrandNameLong() {
        return brandNameLong;
    }


    /**
     * Sets the brandNameLong value for this HotelBrandVo.
     * 
     * @param brandNameLong
     */
    public void setBrandNameLong(java.lang.String brandNameLong) {
        this.brandNameLong = brandNameLong;
    }


    /**
     * Gets the brandPinYin value for this HotelBrandVo.
     * 
     * @return brandPinYin
     */
    public java.lang.String getBrandPinYin() {
        return brandPinYin;
    }


    /**
     * Sets the brandPinYin value for this HotelBrandVo.
     * 
     * @param brandPinYin
     */
    public void setBrandPinYin(java.lang.String brandPinYin) {
        this.brandPinYin = brandPinYin;
    }


    /**
     * Gets the brandURL value for this HotelBrandVo.
     * 
     * @return brandURL
     */
    public java.lang.String getBrandURL() {
        return brandURL;
    }


    /**
     * Sets the brandURL value for this HotelBrandVo.
     * 
     * @param brandURL
     */
    public void setBrandURL(java.lang.String brandURL) {
        this.brandURL = brandURL;
    }


    /**
     * Gets the groupId value for this HotelBrandVo.
     * 
     * @return groupId
     */
    public java.lang.String getGroupId() {
        return groupId;
    }


    /**
     * Sets the groupId value for this HotelBrandVo.
     * 
     * @param groupId
     */
    public void setGroupId(java.lang.String groupId) {
        this.groupId = groupId;
    }


    /**
     * Gets the hotelCount value for this HotelBrandVo.
     * 
     * @return hotelCount
     */
    public java.lang.String getHotelCount() {
        return hotelCount;
    }


    /**
     * Sets the hotelCount value for this HotelBrandVo.
     * 
     * @param hotelCount
     */
    public void setHotelCount(java.lang.String hotelCount) {
        this.hotelCount = hotelCount;
    }


    /**
     * Gets the picURL value for this HotelBrandVo.
     * 
     * @return picURL
     */
    public java.lang.String getPicURL() {
        return picURL;
    }


    /**
     * Sets the picURL value for this HotelBrandVo.
     * 
     * @param picURL
     */
    public void setPicURL(java.lang.String picURL) {
        this.picURL = picURL;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelBrandVo)) return false;
        HotelBrandVo other = (HotelBrandVo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.brandFirstletter==null && other.getBrandFirstletter()==null) || 
             (this.brandFirstletter!=null &&
              this.brandFirstletter.equals(other.getBrandFirstletter()))) &&
            ((this.brandID==null && other.getBrandID()==null) || 
             (this.brandID!=null &&
              this.brandID.equals(other.getBrandID()))) &&
            ((this.brandName==null && other.getBrandName()==null) || 
             (this.brandName!=null &&
              this.brandName.equals(other.getBrandName()))) &&
            ((this.brandNameLong==null && other.getBrandNameLong()==null) || 
             (this.brandNameLong!=null &&
              this.brandNameLong.equals(other.getBrandNameLong()))) &&
            ((this.brandPinYin==null && other.getBrandPinYin()==null) || 
             (this.brandPinYin!=null &&
              this.brandPinYin.equals(other.getBrandPinYin()))) &&
            ((this.brandURL==null && other.getBrandURL()==null) || 
             (this.brandURL!=null &&
              this.brandURL.equals(other.getBrandURL()))) &&
            ((this.groupId==null && other.getGroupId()==null) || 
             (this.groupId!=null &&
              this.groupId.equals(other.getGroupId()))) &&
            ((this.hotelCount==null && other.getHotelCount()==null) || 
             (this.hotelCount!=null &&
              this.hotelCount.equals(other.getHotelCount()))) &&
            ((this.picURL==null && other.getPicURL()==null) || 
             (this.picURL!=null &&
              this.picURL.equals(other.getPicURL())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBrandFirstletter() != null) {
            _hashCode += getBrandFirstletter().hashCode();
        }
        if (getBrandID() != null) {
            _hashCode += getBrandID().hashCode();
        }
        if (getBrandName() != null) {
            _hashCode += getBrandName().hashCode();
        }
        if (getBrandNameLong() != null) {
            _hashCode += getBrandNameLong().hashCode();
        }
        if (getBrandPinYin() != null) {
            _hashCode += getBrandPinYin().hashCode();
        }
        if (getBrandURL() != null) {
            _hashCode += getBrandURL().hashCode();
        }
        if (getGroupId() != null) {
            _hashCode += getGroupId().hashCode();
        }
        if (getHotelCount() != null) {
            _hashCode += getHotelCount().hashCode();
        }
        if (getPicURL() != null) {
            _hashCode += getPicURL().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelBrandVo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelBrandVo", "HotelBrandVo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandFirstletter");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandFirstletter"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandNameLong");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandNameLong"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandPinYin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandPinYin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("brandURL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "brandURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "groupId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelCount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelCount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("picURL");
        elemField.setXmlName(new javax.xml.namespace.QName("", "picURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
