/**
 * HotelQueryResultVO.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package cn.itkt.btsf.hotel.vo;

public class HotelQueryResultVO  extends cn.itkt.btsf.hotel.vo.BaseVo  implements java.io.Serializable {
    private java.lang.Integer currentPage;

    private java.lang.Integer hotelAccount;

    private java.lang.Integer hotelAllPage;

    private cn.itkt.btsf.hotel.vo.HotelForMoreHotelVo[] moreHotel;

    private cn.itkt.btsf.hotel.vo.HotelForOneHotelVo oneHotel;

    public HotelQueryResultVO() {
    }

    public HotelQueryResultVO(
           java.lang.String message,
           java.lang.String status,
           java.lang.Integer currentPage,
           java.lang.Integer hotelAccount,
           java.lang.Integer hotelAllPage,
           cn.itkt.btsf.hotel.vo.HotelForMoreHotelVo[] moreHotel,
           cn.itkt.btsf.hotel.vo.HotelForOneHotelVo oneHotel) {
        super(
            message,
            status);
        this.currentPage = currentPage;
        this.hotelAccount = hotelAccount;
        this.hotelAllPage = hotelAllPage;
        this.moreHotel = moreHotel;
        this.oneHotel = oneHotel;
    }


    /**
     * Gets the currentPage value for this HotelQueryResultVO.
     * 
     * @return currentPage
     */
    public java.lang.Integer getCurrentPage() {
        return currentPage;
    }


    /**
     * Sets the currentPage value for this HotelQueryResultVO.
     * 
     * @param currentPage
     */
    public void setCurrentPage(java.lang.Integer currentPage) {
        this.currentPage = currentPage;
    }


    /**
     * Gets the hotelAccount value for this HotelQueryResultVO.
     * 
     * @return hotelAccount
     */
    public java.lang.Integer getHotelAccount() {
        return hotelAccount;
    }


    /**
     * Sets the hotelAccount value for this HotelQueryResultVO.
     * 
     * @param hotelAccount
     */
    public void setHotelAccount(java.lang.Integer hotelAccount) {
        this.hotelAccount = hotelAccount;
    }


    /**
     * Gets the hotelAllPage value for this HotelQueryResultVO.
     * 
     * @return hotelAllPage
     */
    public java.lang.Integer getHotelAllPage() {
        return hotelAllPage;
    }


    /**
     * Sets the hotelAllPage value for this HotelQueryResultVO.
     * 
     * @param hotelAllPage
     */
    public void setHotelAllPage(java.lang.Integer hotelAllPage) {
        this.hotelAllPage = hotelAllPage;
    }


    /**
     * Gets the moreHotel value for this HotelQueryResultVO.
     * 
     * @return moreHotel
     */
    public cn.itkt.btsf.hotel.vo.HotelForMoreHotelVo[] getMoreHotel() {
        return moreHotel;
    }


    /**
     * Sets the moreHotel value for this HotelQueryResultVO.
     * 
     * @param moreHotel
     */
    public void setMoreHotel(cn.itkt.btsf.hotel.vo.HotelForMoreHotelVo[] moreHotel) {
        this.moreHotel = moreHotel;
    }


    /**
     * Gets the oneHotel value for this HotelQueryResultVO.
     * 
     * @return oneHotel
     */
    public cn.itkt.btsf.hotel.vo.HotelForOneHotelVo getOneHotel() {
        return oneHotel;
    }


    /**
     * Sets the oneHotel value for this HotelQueryResultVO.
     * 
     * @param oneHotel
     */
    public void setOneHotel(cn.itkt.btsf.hotel.vo.HotelForOneHotelVo oneHotel) {
        this.oneHotel = oneHotel;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HotelQueryResultVO)) return false;
        HotelQueryResultVO other = (HotelQueryResultVO) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.currentPage==null && other.getCurrentPage()==null) || 
             (this.currentPage!=null &&
              this.currentPage.equals(other.getCurrentPage()))) &&
            ((this.hotelAccount==null && other.getHotelAccount()==null) || 
             (this.hotelAccount!=null &&
              this.hotelAccount.equals(other.getHotelAccount()))) &&
            ((this.hotelAllPage==null && other.getHotelAllPage()==null) || 
             (this.hotelAllPage!=null &&
              this.hotelAllPage.equals(other.getHotelAllPage()))) &&
            ((this.moreHotel==null && other.getMoreHotel()==null) || 
             (this.moreHotel!=null &&
              java.util.Arrays.equals(this.moreHotel, other.getMoreHotel()))) &&
            ((this.oneHotel==null && other.getOneHotel()==null) || 
             (this.oneHotel!=null &&
              this.oneHotel.equals(other.getOneHotel())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getCurrentPage() != null) {
            _hashCode += getCurrentPage().hashCode();
        }
        if (getHotelAccount() != null) {
            _hashCode += getHotelAccount().hashCode();
        }
        if (getHotelAllPage() != null) {
            _hashCode += getHotelAllPage().hashCode();
        }
        if (getMoreHotel() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMoreHotel());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMoreHotel(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOneHotel() != null) {
            _hashCode += getOneHotel().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HotelQueryResultVO.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelQueryResultVO", "HotelQueryResultVO"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currentPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hotelAllPage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "hotelAllPage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://schemas.xmlsoap.org/soap/encoding/", "int"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("moreHotel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "moreHotel"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelForMoreHotelVo", "HotelForMoreHotelVo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oneHotel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "oneHotel"));
        elemField.setXmlType(new javax.xml.namespace.QName("com.itkt.mtravel.hotel.vo.HotelForOneHotelVo", "HotelForOneHotelVo"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
