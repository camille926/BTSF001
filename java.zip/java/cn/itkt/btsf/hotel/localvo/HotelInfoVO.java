package cn.itkt.btsf.hotel.localvo;

public class HotelInfoVO {
	//主键
	private  Long hotelId;
	//酒店名称
	private  String hotelName;
	//酒店地址
	private String hotelAddress;
	//酒店邮编
	private String ZIP;
	//标志物
	private String landMarkids;
	//交通概述
	private String trafficAndAroundInformations;
	//介绍
	private String introeditor;
	//电话
	private String phone;
	//英文名称
	private String hotelEnName;
	//服务设施
	private String generalamenities;
	//休闲服务设施
	private String recreationamenities ;
	//餐厅服务设施
	private String diningamenities;
	//特殊提示
	private String availpolicy;
	//是否经济型酒店
	private String iseconomic;
	//酒店概述
	private String description;
	//缩减版酒店介绍
	private String ShortIntroeditor;
	//城市编号
	private String cityId;
	//星级
	private String star;
	public Long getHotelId() {
		return hotelId;
	}
	public void setHotelId(Long hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelAddress() {
		return hotelAddress;
	}
	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}
	public String getZIP() {
		return ZIP;
	}
	public void setZIP(String zIP) {
		ZIP = zIP;
	}
	public String getLandMarkids() {
		return landMarkids;
	}
	public void setLandMarkids(String landMarkids) {
		this.landMarkids = landMarkids;
	}
	public String getTrafficAndAroundInformations() {
		return trafficAndAroundInformations;
	}
	public void setTrafficAndAroundInformations(String tranficAndAroundInformations) {
		this.trafficAndAroundInformations = tranficAndAroundInformations;
	}
	public String getIntroeditor() {
		return introeditor;
	}
	public void setIntroeditor(String introeditor) {
		this.introeditor = introeditor;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getHotelEnName() {
		return hotelEnName;
	}
	public void setHotelEnName(String hotelEnName) {
		this.hotelEnName = hotelEnName;
	}
	public String getGeneralamenities() {
		return generalamenities;
	}
	public void setGeneralamenities(String generalamenities) {
		this.generalamenities = generalamenities;
	}
	public String getRecreationamenities() {
		return recreationamenities;
	}
	public void setRecreationamenities(String recreationamenities) {
		this.recreationamenities = recreationamenities;
	}
	public String getDiningamenities() {
		return diningamenities;
	}
	public void setDiningamenities(String diningamenities) {
		this.diningamenities = diningamenities;
	}
	public String getAvailpolicy() {
		return availpolicy;
	}
	public void setAvailpolicy(String availpolicy) {
		this.availpolicy = availpolicy;
	}
	public String getIseconomic() {
		return iseconomic;
	}
	public void setIseconomic(String iseconomic) {
		this.iseconomic = iseconomic;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getShortIntroeditor() {
		return ShortIntroeditor;
	}
	public void setShortIntroeditor(String shortIntroeditor) {
		ShortIntroeditor = shortIntroeditor;
	}
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getStar() {
		return star;
	}
	public void setStar(String star) {
		this.star = star;
	}
	
}
