package cn.itkt.btsf.hotel.localvo;

import java.util.Date;


/**
 * 旅客酒店订单信息查询表 
 * @author codegen 2011-06-23 20:01:39 
 */
public class HotelOrderQueryVO {

    /** 入住日期 **/ 
	private Date inDate;
	private Date inDateLast;
	
    /** 离开日期 **/ 
	private Date outDate;
	private Date outDateLast;

	
    /** 预定日期 **/ 
	private Date beforehandDate;
	private Date beforehandDateLast;
	
    /** 客人姓名 **/ 
	private String guestName;
	
	   /** 联系人姓名 **/ 
	private String contactName;
	
	   /** 联系人电话 **/ 
	private String phone;
	
    /** elong单号 **/ 
	private String orderId;
	private String orderId1;
	/**客户类型**/
	private String userType;
	/**会员手机**/
	private String customerMobile;
	public String getOrderId1() {
		return orderId1;
	}

	public void setOrderId1(String orderId1) {
		this.orderId1 = orderId1;
	}

	/**订单编号  **/
	private String lcdorderid;
	
	/**订单状态:  N-新单  V-已审     A-已确认  **/
	private String lcdorderState;
	
	/** 订单来源 0手机，1网站，2呼叫中心，3终端 **/ 
	private String sourceId;

	public Date getInDate() {
		return inDate;
	}

	public void setInDate(Date inDate) {
		this.inDate = inDate;
	}

	public Date getInDateLast() {
		return inDateLast;
	}

	public void setInDateLast(Date inDateLast) {
		this.inDateLast = inDateLast;
	}

	public Date getOutDate() {
		return outDate;
	}

	public void setOutDate(Date outDate) {
		this.outDate = outDate;
	}

	public Date getOutDateLast() {
		return outDateLast;
	}

	public void setOutDateLast(Date outDateLast) {
		this.outDateLast = outDateLast;
	}

	public Date getBeforehandDate() {
		return beforehandDate;
	}

	public void setBeforehandDate(Date beforehandDate) {
		this.beforehandDate = beforehandDate;
	}

	public Date getBeforehandDateLast() {
		return beforehandDateLast;
	}

	public void setBeforehandDateLast(Date beforehandDateLast) {
		this.beforehandDateLast = beforehandDateLast;
	}

	public String getGuestName() {
		return guestName;
	}

	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getLcdorderid() {
		return lcdorderid;
	}

	public void setLcdorderid(String lcdorderid) {
		this.lcdorderid = lcdorderid;
	}


	public String getLcdorderState() {
		return lcdorderState;
	}

	public void setLcdorderState(String lcdorderState) {
		this.lcdorderState = lcdorderState;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getCustomerMobile() {
		return customerMobile;
	}

	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}


}