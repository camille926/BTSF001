package cn.itkt.btsf.hotel.localvo;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class HotelOrderInfoVO {
	//艺龙订单状态
	private static final Map<String,String> ORDER_STATES=new HashMap<String,String>();
	static{
		ORDER_STATES.put("F", "已入住");
		ORDER_STATES.put("C", "已结帐");
		ORDER_STATES.put("H", "变更");
		ORDER_STATES.put("E", "取消");
		ORDER_STATES.put("O", "满房");
		ORDER_STATES.put("G", "变价");
		ORDER_STATES.put("W", "虚拟");
		ORDER_STATES.put("Z", "删除,另换酒店");
		ORDER_STATES.put("I", "大单");
		ORDER_STATES.put("P", "暂无价格");
		ORDER_STATES.put("R", "预付");
		ORDER_STATES.put("U", "特殊满房");
		ORDER_STATES.put("T", "计划中");
		ORDER_STATES.put("B1", "有预定未查到");
		ORDER_STATES.put("B2", "待查");
		ORDER_STATES.put("B3", "暂不确定");
		ORDER_STATES.put("J", "仅酒店已确认");
		ORDER_STATES.put("V", "已审");
		ORDER_STATES.put("S", "特殊");
		ORDER_STATES.put("M", "恶意");
		ORDER_STATES.put("N", "新单");
		ORDER_STATES.put("A", "已确认");
		ORDER_STATES.put("D", "删除");
		ORDER_STATES.put("B", "NO SHOW");
		
	}
	private long id;
	//隆畅达订单编号
	private String lcdOrderId;
	//艺龙订单编号
	private String orderId;
	//预订时间
	private Date createTime;
	//订单状态订单状态:F-已入住 
//	 C-已结帐
//	  H-变更
//	  E-取消 
//	  O-满房 
//	  G-变价 
//	  W-虚拟 
//	  Z-删除,另换酒店 
//	  I-大单 
//	  P-暂无价格 
//	  R-预付 
//	  U-特殊满房 
//	  T-计划中
//	  B1-有预定未查到 
//	  B2-待查 
//	  B3-暂不确定 
//	  J-仅酒店已确认 
//	  V-已审 
//	  S-特殊 
//	  M-恶意 
//	  N-新单 
//	  A-已确认 
//	 D-删除 
//	  B-NO SHOW
	private String orderState;
	//酒店名称
	private String hotelName;
	//酒店编码
	private String hotelCode;
	//酒店星级
	private String category;
	//酒店地址
	private String hotelAddress;
	//酒店电话
	private String phone;
	//入住日期
	private String checkInDate;
	//离店日期
	private String checkOutDate;
	//房间名称
	private String roomName;
	//房间数量
	private int quantity;
	//订单总价
	private double totalPrice;
	//保留时间起始
	private String arriveEarlyTime;
	//保留时间起始
	private String arriveLateTime;
	//客人姓名
	private String guestName;
	//联系人
	private String contactName;
	//联系电话
	private String contactPhone;
	//特殊要求
	private String noteToElong;
	//备注
	private String remark;
	//最后操作人
	private String lastOperator;
	//会员类型
	private String userType;
	//会员id
	private Long userId;
	//会员名称
	private String userName;
	//会员电话
	private String userPhone;
	////0处理中  1未入住  2已结账  3已取消  4已确认
	private String lcdOrderState;
	//订单来源
	private String orderSource;
	//艺龙订单状态
	private String orderStateName;
//	private String userType;
//	private Long userId;
//	private String userName;
	public String getLcdOrderId() {
		return lcdOrderId;
	}
	public void setLcdOrderId(String lcdOrderId) {
		this.lcdOrderId = lcdOrderId;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getOrderState() {
		return orderState;
	}
	public void setOrderState(String orderState) {
		this.orderState = orderState;
		this.orderStateName=ORDER_STATES.get(this.orderState);
	}
	public HotelOrderInfoVO(String lcdOrderId, String orderId, Date createTime,
			String orderState) {
		super();
		this.lcdOrderId = lcdOrderId;
		this.orderId = orderId;
		this.createTime = createTime;
		this.orderState = orderState;
	}
	public HotelOrderInfoVO(){}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getHotelCode() {
		return hotelCode;
	}
	public void setHotelCode(String hotelCode) {
		this.hotelCode = hotelCode;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getHotelAddress() {
		return hotelAddress;
	}
	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public String getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(String checkInDate) {
		this.checkInDate = checkInDate;
	}
	public String getCheckOutDate() {
		return checkOutDate;
	}
	public void setCheckOutDate(String checkOutDate) {
		this.checkOutDate = checkOutDate;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getArriveEarlyTime() {
		return arriveEarlyTime;
	}
	public void setArriveEarlyTime(String arriveEarlyTime) {
		this.arriveEarlyTime = arriveEarlyTime;
	}
	public String getArriveLateTime() {
		return arriveLateTime;
	}
	public void setArriveLateTime(String arriveLateTime) {
		this.arriveLateTime = arriveLateTime;
	}
	public String getGuestName() {
		return guestName;
	}
	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}
	public String getContactPhone() {
		return contactPhone;
	}
	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}
	public String getNoteToElong() {
		return noteToElong;
	}
	public void setNoteToElong(String noteToElong) {
		this.noteToElong = noteToElong;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getLastOperator() {
		return lastOperator;
	}
	public void setLastOperator(String lastOperator) {
		this.lastOperator = lastOperator;
	}
	public String getContactName() {
		return contactName;
	}
	public void setContactName(String contactName) {
		this.contactName = contactName;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getLcdOrderState() {
		return lcdOrderState;
	}
	public void setLcdOrderState(String lcdOrderState) {
		this.lcdOrderState = lcdOrderState;
	}
	public String getOrderSource() {
		return orderSource;
	}
	public void setOrderSource(String orderSource) {
		this.orderSource = orderSource;
	}
	public String getOrderStateName() {
		return orderStateName;
	}
	public void setOrderStateName(String orderStateName) {
		this.orderStateName = orderStateName;
	}
	
	
}
