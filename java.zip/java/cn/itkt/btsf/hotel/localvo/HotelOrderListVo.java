package cn.itkt.btsf.hotel.localvo;

import java.util.Date;

public class HotelOrderListVo {
	private long id;   //id 
	private String lcdorderId; //订单编号
	private long orderId; //elong单号
	private Date createTime; //预定日期
	private Date  checkInDate; //入住日期
	private Date checkOutDate; //离店日期
	private String guestName; //客人姓名
	private String hotelName;  //酒店名称
	private String roomName;  //房型 
	private int quantity; //房子数量
	private String totalPrice;//房价
	private String  lcdorderState; //订单状态
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getLcdorderId() {
		return lcdorderId;
	}
	public void setLcdorderId(String lcdorderId) {
		this.lcdorderId = lcdorderId;
	}
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getCheckInDate() {
		return checkInDate;
	}
	public void setCheckInDate(Date checkInDate) {
		this.checkInDate = checkInDate;
	}
	public Date getCheckOutDate() {
		return checkOutDate;
	}
	public void setCheckOutDate(Date checkOutDate) {
		this.checkOutDate = checkOutDate;
	}
	public String getGuestName() {
		return guestName;
	}
	public void setGuestName(String guestName) {
		this.guestName = guestName;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getRoomName() {
		return roomName;
	}
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getLcdorderState() {
		return lcdorderState;
	}
	public void setLcdorderState(String lcdorderState) {
		this.lcdorderState = lcdorderState;
	}
	
	
	
}
