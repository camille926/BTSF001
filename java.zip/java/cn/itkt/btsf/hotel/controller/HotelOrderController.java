package cn.itkt.btsf.hotel.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.itkt.btsf.hotel.localvo.HotelOrderListVo;
import cn.itkt.btsf.hotel.localvo.HotelOrderQueryVO;
import cn.itkt.btsf.phone.problem.vo.ProblemVO;
import cn.itkt.btsf.sys.cc.national.controller.OrderManageControllerSupport;
import cn.itkt.btsf.sys.cc.national.service.InsuranceInfoService;
import cn.itkt.btsf.sys.flightchange.controller.FlightChangeControllerSupport;
import cn.itkt.btsf.sys.flightchange.po.FlightChangeDealPO;
import cn.itkt.btsf.sys.flightchange.vo.FlightChangeVO;
import cn.itkt.btsf.sys.flightchange.vo.FlightOperatorVO;
import cn.itkt.btsf.sys.member.service.MemberEnterpriseService;
import cn.itkt.btsf.util.LoginUtil;


@Controller
@RequestMapping("/hotel")
public class HotelOrderController {
	@Resource
	private HotelOrderControllerSupport hotelOrderControllerSupport;
	
    /**
	 * 酒店订单查询菜单URL
	 * @param
	 * @return
	 */
	@RequestMapping("/ordersList")
	public String hotelOrderQuery(ModelMap modelMap,@ModelAttribute HotelOrderQueryVO hotelOrderQueryVO,
		@RequestParam(value = "startIndex", required = false, defaultValue = "0") int startIndex) {
		modelMap.addAttribute("hotelQuery", hotelOrderQueryVO);
		hotelOrderControllerSupport.getHotelOrderList(modelMap,hotelOrderQueryVO,startIndex);
		modelMap.addAttribute("orderId1", hotelOrderQueryVO.getOrderId1());
		
		return "hotel/order/ordersList";
	}
	
	/**
	 * 订单详细信息
	 * @param request
	 */
//	@RequestMapping("/order")
//	public String hotelOrderDetail(@RequestParam("id")long orderId, ModelMap modelMap) {
//		hotelOrderControllerSupport.getHotelOrderDetail(orderId,modelMap);
//		return "/hotel/order/orderDetail";
//	}
//	
	
	
	/**
	 * 注册指定日期格式的日期属性编辑器
	 * 
	 * @param binder
	 */
	@InitBinder
	protected void initBinder(WebDataBinder binder){
		SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd");
		formater.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(formater, true));
	}
	
	/**
	 * 将导出订单列表导出到excel
	 * @param model
	 * @param queryVO
	 * @param startIndex
	 * @return
	 */
	@RequestMapping("/listExportToExcel")
	public String listExportToExcel(ModelMap modelMap,@ModelAttribute HotelOrderQueryVO hotelOrderQueryVO,int startIndex){
		hotelOrderControllerSupport.getHotelAllOrderList(modelMap, hotelOrderQueryVO, startIndex);
		return "exportHotelOrderExcel";
	}	
	
}
