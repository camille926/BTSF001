package cn.itkt.btsf.hotel.controller;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;

import cn.itkt.btsf.hotel.localvo.HotelOrderInfoVO;
import cn.itkt.btsf.hotel.po.CommercialPO;
import cn.itkt.btsf.hotel.po.DistrictPO;
import cn.itkt.btsf.hotel.po.GuarantyInfoPO;
import cn.itkt.btsf.hotel.po.HotelInfoPO;
import cn.itkt.btsf.hotel.po.HotelOrderInfoPO;
import cn.itkt.btsf.hotel.po.LandmarkPO;
import cn.itkt.btsf.hotel.po.OrderInfoPO;
import cn.itkt.btsf.hotel.service.HotelService;
import cn.itkt.btsf.hotel.vo.ContacterForSubmitHotelOrder;
import cn.itkt.btsf.hotel.vo.CreditCardForSubmitHotelOrder;
import cn.itkt.btsf.hotel.vo.FaxForSubmitHotelOrder;
import cn.itkt.btsf.hotel.vo.HotelCityInfoVo;
import cn.itkt.btsf.hotel.vo.HotelForMoreHotelVo;
import cn.itkt.btsf.hotel.vo.HotelForOneHotelVo;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOneQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderVo;
import cn.itkt.btsf.hotel.vo.HotelProductVouchRequest;
import cn.itkt.btsf.hotel.vo.HotelProductVouchVo;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.hotel.vo.PhoneForSubmitHotelOrder;
import cn.itkt.btsf.hotel.vo.RatePlanForHotel;
import cn.itkt.btsf.hotel.vo.RoomReserveInfoVo;
import cn.itkt.btsf.hotel.vo.RoomReserveRequest;
import cn.itkt.btsf.sys.cc.national.dao.OrderCcextDao;
import cn.itkt.btsf.sys.cc.national.po.OrderCcextPO;
import cn.itkt.btsf.sys.cc.national.po.ServiceFormPO;
import cn.itkt.btsf.sys.cc.national.service.OrderManageService;
import cn.itkt.btsf.sys.popscreen.vo.IncomingCallerVO;
import cn.itkt.btsf.sys.popscreen.vo.PopScreenServiceFormVO;
import cn.itkt.pagination.Pages;
/**
 * @version 1.0
 * @author SunLing
 * @date 2012-10-29
 * @title 酒店业务模块主要处理类
 */
@Controller
@RequestMapping("/hotel")
public class HotelController {
	private Logger log = LoggerFactory.getLogger(HotelController.class);
	private SimpleDateFormat format  = new SimpleDateFormat("yyyy-MM-dd");
	@Resource
	private HotelControllerSupport hotelControllerSupport;
	@Resource
	private HotelService hotelService;
	@Resource
	private OrderManageService orderManageService;
	@Resource
	private OrderCcextDao orderCcextDao; 
	/****
	 * 进行酒店查询页面,点击左边酒店预订时 不进行查询
	 * @param hotelPO 传入的参数为空，将入住日期与离店日期与城市设为默认
	 * @return
	 */
	@RequestMapping(value = "/findHotel")
	public String findHotel(ModelMap modelMap,HttpServletRequest request){
		HotelListQueryRequest hotelListQueryRequest = new HotelListQueryRequest();
		hotelListQueryRequest.setCheckInDate(this.getDateToday(0));				// 入住日期 默认今天
		hotelListQueryRequest.setCheckOutDate(this.getDateToday(1));			// 离店日期默认明天
		hotelListQueryRequest.setCityId("0101");								// 城市默认为北京
		log.info("跳转到酒店查询/预订页面!");
		modelMap.addAttribute("hotelQuery", hotelListQueryRequest);
		modelMap.addAttribute("hotelListResult", "");							//默认为空，即，刚进行页面时，无值，
		modelMap.addAttribute("cityName", "北京");
		
		List<DistrictPO> dstList = null;
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("cityCode", "0101");
		dstList = hotelService.findHotelDst(queryMap);
		
		List<CommercialPO> commList = null;
		commList = hotelService.findHotelComm(queryMap);
		
		List<LandmarkPO> lmList = null;
		lmList = hotelService.findHotelLm(queryMap);
		modelMap.addAttribute("dstList", dstList);
		modelMap.addAttribute("commList", commList);
		modelMap.addAttribute("lmList", lmList);
		modelMap.addAttribute("orderByCode", "star");
		modelMap.addAttribute("orderTypeCode", "desc");
		
		//带入弹屏用户信息
		String incomingId=(String) request.getParameter("incomingKey");
		modelMap.put("incomingKey", incomingId);
		return "/hotel/findHotel";
	}
	/**
	 ** 进行酒店预订页面,点击左边酒店预订时
	 * @param hotelListQueryRequest 封装的查询参数
	 * @param cityName	城市名  用于查询后在页面回显
	 * @param dstName   行政区
	 * @param commName	商业区
	 * @param lmName 附近标志物
	 * @param modelMap
	 * @return 查询的结果
	 */
	@RequestMapping(value = "/findHotelByCondition")
	public String findHotelByCondition(@ModelAttribute HotelListQueryRequest hotelListQueryRequest, 
												@RequestParam(value = "startIndex", required = false, defaultValue = "1") int startIndex,
																		String cityName, ModelMap modelMap, String orderByCode, String orderTypeCode,HttpServletRequest request){
		log.info("开始调用eLong接口，查询获取酒店信息");
		Pages<HotelForMoreHotelVo> page = null;
		try {
			hotelListQueryRequest.setOrderByCode(orderByCode);
			hotelListQueryRequest.setOrderTypeCode(orderTypeCode);
			String startIndexStr = "1";
			if(startIndex>1){
				startIndexStr = String.valueOf(startIndex);
				startIndexStr = startIndexStr.substring(0, startIndexStr.length()-1);
			}
			hotelListQueryRequest.setReqPageNum(startIndex>1?(Integer.parseInt(startIndexStr)+1):startIndex);
			HotelQueryResultVO result = hotelControllerSupport.findHotelQueryResultVO(hotelListQueryRequest);	//调用接口进行查询
			/**在这里做分页处理,新加**/
			
			page = new Pages<HotelForMoreHotelVo>(startIndex);
			if(result != null){
				if(result.getMoreHotel() != null){
					List<HotelForMoreHotelVo> hotelForMoreHotelVoS = Arrays.asList(result.getMoreHotel());
					page.setItems(hotelForMoreHotelVoS);
					page.setPageSize(10);
					page.setTotalCount(result.getHotelAccount());
					modelMap.addAttribute("page", page);
				}
			}
			
			modelMap.addAttribute("hotelQuery", hotelListQueryRequest);											//查询条件
			modelMap.addAttribute("hotelListResult", result);				//查询结果
			/**以下用于回显**/
			modelMap.addAttribute("cityName", cityName);					
			
			modelMap.addAttribute("checkInWeek", this.getWeekToday(hotelListQueryRequest.getCheckInDate()));	//提示入住日期星期
			modelMap.addAttribute("checkOutWeek", this.getWeekToday(hotelListQueryRequest.getCheckOutDate()));	//提示离店日期星期
			
			List<DistrictPO> dstList = null;
			Map<String, Object> queryMap = new HashMap<String, Object>();
			
			queryMap.put("cityCode", hotelListQueryRequest.getCityId());
			dstList = hotelService.findHotelDst(queryMap);
			List<CommercialPO> commList = null;
			commList = hotelService.findHotelComm(queryMap);
			List<LandmarkPO> lmList = null;
			lmList = hotelService.findHotelLm(queryMap);
			
			modelMap.addAttribute("dstList", dstList);
			modelMap.addAttribute("commList", commList);
			modelMap.addAttribute("lmList", lmList);
			modelMap.addAttribute("orderByCode", orderByCode);
			modelMap.addAttribute("orderTypeCode", orderTypeCode);
			
			//带入弹屏用户信息
			String incomingId=(String) request.getParameter("incomingKey");
			modelMap.put("incomingKey", incomingId);
		} catch (NumberFormatException e) {
			log.error("查询酒店信息出错!"+e.getMessage());
			modelMap.addAttribute("page", page);
		}
		return "/hotel/findHotel";
	}
	/****
	 * 点击某酒店下某个房间时,进入房间预订页面
	 * @param hotelListQueryRequest 酒店信息
	 * @param roomReserveRequest 房间信息
	 * @param modelMap
	 * @return 房间剩余数量
	 */
	@RequestMapping(value = "/preOrder")
	public String preOrder(@ModelAttribute HotelOrderInfoPO hotelOrderInfoPO, ModelMap modelMap,HttpServletRequest request){
		RoomReserveRequest roomRequest = new RoomReserveRequest();
		roomRequest.setHotelId(hotelOrderInfoPO.getHotelId());
		roomRequest.setRoomTypeID(hotelOrderInfoPO.getRoomTypeID());
		roomRequest.setStartDate(hotelOrderInfoPO.getStartDateStr());//需要更改2012-11-21
		roomRequest.setEndDate(hotelOrderInfoPO.getEndDateStr());
		roomRequest.setTerminalId((hotelOrderInfoPO.getTerminalId()));
		/**获取房间信息(是否够预订)**/
		RoomReserveInfoVo reserveInfoVo = hotelControllerSupport.getRoomReserveInfoVo(roomRequest);
		if(reserveInfoVo != null){
			if(reserveInfoVo.getRoomAmount()>0){
				modelMap.put("hotelRoomPO", hotelOrderInfoPO);
				modelMap.put("roomAmount", reserveInfoVo.getRoomAmount());
				//modelMap.put("vouch", vouch.isIsVouch());
				String today = format.format(new Date());
				if(today.equalsIgnoreCase(roomRequest.getStartDate())){
					SimpleDateFormat format = new SimpleDateFormat("HH");
					Calendar calendar = Calendar.getInstance();
					
					calendar.roll(Calendar.HOUR_OF_DAY,1);
					Date date0 = calendar.getTime();
					modelMap.put("hours0",format.format(date0));
					
					calendar.roll(Calendar.HOUR_OF_DAY,2);
					Date date3 = calendar.getTime();
					modelMap.put("hours3",format.format(date3));
				}else{
					modelMap.put("hours3",-1);
				}
				log.info("跳转到酒店填写酒店预订信息页面, "+ " 剩余房间数: "+reserveInfoVo.getRoomAmount());
			}else{
				modelMap.put("hotelRoomPO", hotelOrderInfoPO);
				modelMap.put("roomAmount", reserveInfoVo.getRoomAmount());
			}
			//带入弹屏用户信息
			/**得到当前request,便于从request中得到session.**/
			HttpServletRequest req = ((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest();
			HttpSession session = request.getSession();
			/**得到呼入时存放在session中的呼入信息, 在这个地方得到session 中呼入电话及客户信息**/
			PopScreenServiceFormVO serviceForm = (PopScreenServiceFormVO) session.getAttribute("serviceForm");
			if(serviceForm != null){
				
				ServiceFormPO serviceFormPO = new ServiceFormPO();
				/**会员电话**/
				serviceFormPO.setCustomerMobile(serviceForm.getCustomerTell());
				/**呼入电话**/
				serviceFormPO.setCcphone(serviceForm.getCustomerMobile());
				/**客户类型**/
				serviceFormPO.setCustomerType(serviceForm.getCustomerType());
				/**serviceForm中存放呼入人的信息.在此取出相关信息并在录入界面中显示**/
				modelMap.addAttribute("serviceForm", serviceFormPO);
			}
			String incomingId=(String) request.getParameter("incomingKey");
			modelMap.put("incomingKey", incomingId);
			if(incomingId!=null&&!"".equals(incomingId)){
				Map<String,IncomingCallerVO> incomingMap=(Map<String, IncomingCallerVO>)request.getSession().getAttribute("incomingId");
				IncomingCallerVO vo=incomingMap.get(incomingId);
				modelMap.put("orderInfo", vo);
			}
		}
		return "/hotel/preOrder";
	}
	/**
	 * 点击提交按钮时, 验证是否需要担保
	 * @param ho
	 * @return
	 */
	@RequestMapping(value = "/validateVouch")
	public @ResponseBody Map<String,Object> validateVouch(@ModelAttribute HotelOrderInfoPO ho){
		Map<String,Object> rtnMap = new HashMap<String,Object>();
		/**判断是否需要担保第一次提交、更改房间数量、更改最晚到店时候时，设为true**/
		if(ho.getVouch()){//如果为true，
			try {
				/**提交时判断是否需要担保.**/
				HotelProductVouchRequest orderVouchRequest = vouchParams(ho);
				HotelProductVouchVo vouch = hotelControllerSupport.getHotelProductVouchVo(orderVouchRequest);
				if(vouch != null){
					if(vouch.getIsVouch()==1){		//需要担保
						/**封装担保相关信息, 计算担保金类型, 1:首晚担保, 2:全额担保**/
						createVouch(ho, rtnMap, vouch);
						return rtnMap;
					}
				}
			} catch (Exception e) {
				log.error("查询是否需要担保出错!\t"+e.getMessage());
				e.printStackTrace();
			}
		}
		rtnMap.put("result", false);
		return rtnMap;
	}
	/**
	 * 提交酒店订单
	 * @param ho	//酒店封装信息，包括价格、房间数量、客人等,
	 * @param orderCcextPO	//客户类型,企业会员、个人会员等等
	 * @param ifVouch	//是否填写担保信息
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/submitHotelOrder")
	@Transactional(rollbackFor={Exception.class})
	public @ResponseBody Map<String,Object> submitHotelOrder(@ModelAttribute HotelOrderInfoPO ho, 
									@ModelAttribute OrderCcextPO orderCcextPO,	Boolean ifVouch,			// 存储客户信息：企业客户、个人会员、合作商户、掌上航旅会员
										ModelMap map){
		String result = "failure";											//默认提交失败
		Map<String,Object> rtnMap = new HashMap<String,Object>();
		/**封装酒店基本信息**/
		HotelOrderRequest hor = createBaseHOR(ho,orderCcextPO);
		/**酒店_早餐信息**/
	    RatePlanForHotel ratePlanForHotel = createRatePlanForHotel(ho);
	    /**酒店_联系人信息**/
	    ContacterForSubmitHotelOrder contacterForSubmitHotelOrder = createContacter(ho);
	    /**酒店_电话**/
	    // PhoneForSubmitHotelOrder phone = createPhone(ho);
	    /**酒店_传真**/
	    //  FaxForSubmitHotelOrder fax = createFax(ho);
	   // contacterForSubmitHotelOrder.setPhone(phone);
	    //contacterForSubmitHotelOrder.setFax(fax);
	    /**赋给酒店信息**/
	    hor.setRatePlanForHotel(ratePlanForHotel);    
	    hor.setContacter(new ContacterForSubmitHotelOrder[]{contacterForSubmitHotelOrder});
	    /**酒店_信用卡信息**/
	    if(ifVouch){
	    	CreditCardForSubmitHotelOrder creditCard = createCreditCard(ho, hor);
	    	hor.setCreditCard(creditCard);
	    }
		try {
			/**调用接口提交订单信息**/
			HotelOrderVo hotelOrderVo = hotelControllerSupport.getHotelOrderVo(hor);
			if(hotelOrderVo != null){
				if(hotelOrderVo.getHotelOrderId()>0){						//如果hotelId大于0则提交预订成功
					result = "success";
					rtnMap.put("elongId", hotelOrderVo.getHotelOrderId());//
				}else{
					rtnMap.put("message", hotelOrderVo.getMessage());		//如果失败则返回失败信息
				}
				rtnMap.put("result", result);
				rtnMap.put("localId", hotelOrderVo.getLcdOrderId());//本地订单号HTL201211251456...开头
//				if(!"".equals(hotelOrderVo.getLcdOrderId()) && hotelOrderVo.getLcdOrderId() != null){
//					OrderInfoPO orderInfoPO = hotelService.findIdByLcdId(hotelOrderVo.getLcdOrderId().replace(",", ""));
//					if(orderInfoPO != null){
//						rtnMap.put("id", orderInfoPO.getId());
//					}else{
//						rtnMap.put("id", 0);
//					}
//				}else{
//					rtnMap.put("id", "0");
//				}
			}
		} catch (Exception e) {
			rtnMap.put("message", "调用接口出错!");		//如果失败则返回失败信息
			log.error(e.getMessage()+"调用接口出错了");
		}
		return rtnMap;
	}
	/****
	 * 查看订单详情
	 * @param orderId 订单Id
	 * @return
	 */
	@RequestMapping(value = "/orderDetailsQuery")
	public String orderDetailsQuery(@RequestParam("orderId") String orderId, ModelMap modelMap) {
		int roomAmount = -1;
		// 查询订单信息
		log.info("查询酒店订单详情，包括订单、酒店、担保信息!");
		if(!"".equals(orderId)){
			try {
				OrderInfoPO orderInfoPO = hotelControllerSupport.findIdByLcdId(orderId);
				HotelOrderInfoVO orderInfos = new HotelOrderInfoVO();
				orderInfos.setUserType(orderInfoPO.getUsertype());
				orderInfos.setUserId(orderInfoPO.getUserid());
				hotelControllerSupport.setCustomerInfos(orderInfos, modelMap); //设定客户类型
				// 查询酒店信息
				HotelInfoPO hp = hotelControllerSupport.findOrderHotelInfo(orderId);
				// 查询担保信息
				GuarantyInfoPO gp = hotelControllerSupport.findOrderGuarantyInfo(orderId);
				// 封装页面所需信息

				HotelOrderInfoPO hotelOrderInfoPO = setHotelOrderInfoPOValues(orderInfoPO, hp, gp);
				modelMap.put("hotelRoomPO", hotelOrderInfoPO);
				if(gp != null){
					modelMap.put("gp", gp);
				}
				roomAmount = 0;
			} catch (NumberFormatException e) {
				log.error("重新请求预订酒店信息出错了!"+ e.getMessage());
			}
		}
		modelMap.put("roomAmount", roomAmount);
		return "/hotel/orderDetails";
	}
	/****
	 * 查看订单详情
	 * @param orderId 订单Id
	 * @return
	 */
	@RequestMapping(value = "/orderDetails")
	public String orderDetails(@RequestParam("orderId") String orderId, ModelMap modelMap) {
		int roomAmount = -1;
		// 查询订单信息
		log.info("查询酒店订单详情，包括订单、酒店、担保信息!");
		if(!orderId.equals("")){
			OrderInfoPO orderInfoPO = hotelControllerSupport.findIdByLcdId(orderId);
			try {
				if (orderInfoPO.getCheckindate() != null) {
					/**入住日期不能小于当前日期**/
					Calendar cal = Calendar.getInstance();
					Date checkInDate = format.parse(orderInfoPO.getCheckindate());
					/**得到昨天**/
					Date date = new Date();
					cal.setTime(date);
					cal.add(cal.DATE, -2); // 判断到昨天，比如 2012-11-20 10:00订的没成功, 2012-11-20 14:00(订的日期已经小于当前日期)再次提交也允许.
					Date yesterday = cal.getTime();
					/**入住日期小于昨天则认为不合法**/
					if (checkInDate.getTime() <= yesterday.getTime()) {
						roomAmount =  -2;
						modelMap.put("roomAmount", roomAmount);
						return "/hotel/rePreOrder";
					}
				}
			} catch (ParseException e) {
				log.error("验证订单是否过期出错!");
				roomAmount =  -2;
				modelMap.put("roomAmount", roomAmount);
				return "/hotel/rePreOrder";
			}
			try {
				HotelOrderInfoVO orderInfos = new HotelOrderInfoVO();
				if(orderInfoPO.getUsertype() != null && !orderInfoPO.getUsertype().equals("null")){
					orderInfos.setUserType(orderInfoPO.getUsertype());
				}else{
					orderInfos.setUserType("05");
				}
				if(orderInfoPO.getUserid() != null && !orderInfoPO.getUserid().equals("null")){
					orderInfos.setUserId(orderInfoPO.getUserid());
				}else{
					orderInfos.setUserId(0l);
				}
				hotelControllerSupport.setCustomerInfos(orderInfos, modelMap); //设定客户类型
				// 查询酒店信息
				HotelInfoPO hp = hotelControllerSupport.findOrderHotelInfo(orderInfoPO.getLcdorderid());
				// 查询担保信息
				GuarantyInfoPO gp = hotelControllerSupport.findOrderGuarantyInfo(orderInfoPO.getLcdorderid());
				// 封装页面所需信息
				
				HotelOneQueryRequest hotelListQueryRequest = new HotelOneQueryRequest();
				hotelListQueryRequest.setCheckInDate(orderInfoPO.getCheckindate());
				hotelListQueryRequest.setCheckOutDate(orderInfoPO.getCheckoutdate());
				hotelListQueryRequest.setHotelId(hp.getHotelcode());
//			hotelListQueryRequest.setCityId("0101");
				hotelListQueryRequest.setRatePlanID(Integer.parseInt(hp.getRateplanid()));
				hotelListQueryRequest.setRoomTypeId(hp.getRoomtypeid());
				String terminalId="callcenter;callcenter:"+(cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
				hotelListQueryRequest.setTerminalId(terminalId);
				//查询单酒店
				HotelQueryResultVO oneHotel = hotelControllerSupport.findOneHotelQueryResultVO(hotelListQueryRequest);
				if(oneHotel != null){
					if(oneHotel.getOneHotel() != null){
						HotelOrderInfoPO hotelOrderInfoPO = setHotelOrderInfoPOValues(orderInfoPO,hp, oneHotel, gp);
						RoomReserveRequest roomRequest = new RoomReserveRequest();
						roomRequest.setHotelId(hotelOrderInfoPO.getHotelId());
						roomRequest.setRoomTypeID(hotelOrderInfoPO.getRoomTypeID());
						roomRequest.setStartDate(hotelOrderInfoPO.getStartDateStr());
						roomRequest.setEndDate(hotelOrderInfoPO.getEndDateStr());
						roomRequest.setTerminalId((hotelOrderInfoPO.getTerminalId()));
						/** 获取房间信息(是否够预订) **/
						RoomReserveInfoVo reserveInfoVo = hotelControllerSupport.getRoomReserveInfoVo(roomRequest);
						if (reserveInfoVo != null) {
							if (reserveInfoVo.getRoomAmount() > 0) {
								modelMap.put("hotelRoomPO", hotelOrderInfoPO);
								//modelMap.put("roomAmount", reserveInfoVo.getRoomAmount());
								roomAmount = reserveInfoVo.getRoomAmount();
								String today = format.format(new Date());
								if(today.equalsIgnoreCase(roomRequest.getStartDate())){
									SimpleDateFormat format = new SimpleDateFormat("HH");
									Calendar calendar = Calendar.getInstance();
									
									calendar.roll(Calendar.HOUR_OF_DAY,1);
									Date date0 = calendar.getTime();
									modelMap.put("hours0",format.format(date0));
									
									calendar.roll(Calendar.HOUR_OF_DAY,2);
									Date date3 = calendar.getTime();
									modelMap.put("hours3",format.format(date3));
								}else{
									modelMap.put("hours3",-1);
								}
								// modelMap.put("vouch", vouch.isIsVouch());
								log.info("跳转到酒店填写酒店预订信息页面, " + " 剩余房间数: " + reserveInfoVo.getRoomAmount());
							}
						}
					}
				}
			} catch (NumberFormatException e) {
				log.error("重新请求预订酒店信息出错了!"+ e.getMessage());
			}
		}
		modelMap.put("roomAmount", roomAmount);
		return "/hotel/rePreOrder";
	}
	/**
	 * 提交酒店订单
	 * @param ho	//酒店封装信息，包括价格、房间数量、客人等,
	 * @param orderCcextPO	//客户类型,企业会员、个人会员等等
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/saveHotelCustomer")
	@Transactional(rollbackFor={Exception.class})
	public @ResponseBody Map<String,Object> saveHotelCustomer(@ModelAttribute OrderCcextPO orderCcextPO,				// 存储客户信息：企业客户、个人会员、合作商户、掌上航旅会员
										ModelMap map){
		Map<String,Object> rtnMap = new HashMap<String,Object>();
		orderCcextPO.setCustomerType(orderCcextPO.getCustomerType().charAt(1) + "");
		orderCcextPO.setRegisterName("酒店预订");
		try {
			if(orderCcextPO.getOrderNo() != null && !orderCcextPO.getOrderNo().equals("")){
				OrderCcextPO orderCE = orderManageService.findCcextByOrderNo(orderCcextPO.getOrderNo());
				if(orderCE != null ){
					int res = orderManageService.updateCCext(orderCcextPO);
					int res2 = orderManageService.updateCCext_bookInfo(orderCcextPO);
				}else{
					orderCcextDao.create(orderCcextPO);
				}
			}
			rtnMap.put("orderCC", orderCcextPO);
		} catch (Exception e) {
			rtnMap.put("error", " 保存失败!");
			log.error("保存会员信息出错,"+ e.getMessage());
		}
		return rtnMap;
	}
	/**
	 * 根据城市名，查询出此城市下的行政区，商业区以及标志建筑
	 * @param cityCode 城市代码
	 * @param map
	 * @return
	 */
	@RequestMapping(value = "/setDstCommLm")
	@Transactional(rollbackFor={Exception.class})
	public @ResponseBody Map<String,Object> setDstCommLm(@RequestParam("cityCode") String cityCode, ModelMap modelMap){
		Map<String,Object> rtnMap = new HashMap<String,Object>();
		List<DistrictPO> dstList = null;
		Map<String, Object> queryMap = new HashMap<String, Object>();
		
		queryMap.put("cityCode", cityCode);
		dstList = hotelService.findHotelDst(queryMap);
		List<CommercialPO> commList = null;
		commList = hotelService.findHotelComm(queryMap);
		List<LandmarkPO> lmList = null;
		lmList = hotelService.findHotelLm(queryMap);
		
		rtnMap.put("dstList", dstList);
		rtnMap.put("commList", commList);
		rtnMap.put("lmList", lmList);
		return rtnMap;
	}
	/**
	 * 封装提交订单所需参数，此方法方便于再次提交，所得的值是从数据库里取出来的，
	 * 封装完毕后，跳到再次提交页面，与preOrder.jsp一样的，会员那稍做了点修改
	 * @param order	订单
	 * @param hp	酒店
	 * @param gp   担保
	 * @return
	 */
	private HotelOrderInfoPO setHotelOrderInfoPOValues(OrderInfoPO order, HotelInfoPO hp, GuarantyInfoPO gp) {
		HotelOrderInfoPO hotelOrderInfoPO = new HotelOrderInfoPO();
		if (order != null) {
			try {
				// 预订规则没有需要自己去查询
				hotelOrderInfoPO.setOrderMessage(order.getOrdermessage());
				hotelOrderInfoPO.setTerminalId(order.getTerminalid());
				hotelOrderInfoPO.setStartDateStr(order.getCheckindate().split(" ")[0]);
				hotelOrderInfoPO.setEndDateStr(order.getCheckoutdate().split(" ")[0]);
				hotelOrderInfoPO.setCurrencyCode("RMB"); // 写死
				hotelOrderInfoPO.setStarCode("待完成");
				// hotelOrderInfoPO.setAveragePrice(0.0);
				hotelOrderInfoPO.setGuestTypeCode(order.getGuesttype());
				// hotelOrderInfoPO.setRatePlanCode(order.getr)
				// hotelOrderInfoPO.setReturnLcdMoney("")
				hotelOrderInfoPO.setTotalPrice(BigDecimal.valueOf(order.getTotalprice()));
				hotelOrderInfoPO.setTotalPriceVouch(0f);
				hotelOrderInfoPO.setFirstDayPriceVouch(0f);
				hotelOrderInfoPO.setStayAndLeave(order.getCheckindate() + "("
						+ this.getWeekToday(order.getCheckindate()) + ")" + "\t" + order.getCheckoutdate() + "("
						+ this.getWeekToday(order.getCheckoutdate()) + ")");
				String aa = order.getArriveearlytime().split(" ")[1];
				String al = order.getArrivelatetime().split(" ")[1];
				hotelOrderInfoPO.setArrivalEarlyTime(aa);
				hotelOrderInfoPO.setArrivalLateTime(al);
				// hotelOrderInfoPO.setSinglePrice(order.get)
				hotelOrderInfoPO.setGenderCode("未知");
				hotelOrderInfoPO.setMobile(order.getContactphone());
				hotelOrderInfoPO.setCreateTime(order.getCreatetime());
				hotelOrderInfoPO.setLcdOrderId(order.getLcdorderid());
				hotelOrderInfoPO.setGuestNames(order.getGuestname().equals("")? "":order.getGuestname().replace("&", "/"));
				if(!order.getContactname().equals("") && order.getContactname()!= null){
					hotelOrderInfoPO.setName(order.getContactname().replace(",", ""));
				}else{
					hotelOrderInfoPO.setName("");
				}
			} catch (Exception e) {
				log.error("封装订单信息出错!" + e.getMessage());
			}
		}

		if (hp != null) {
			try {
				hotelOrderInfoPO.setHotelId(hp.getHotelcode() + "");
				hotelOrderInfoPO.setRoomTypeID(hp.getRoomtypeid());
				hotelOrderInfoPO.setHotelName(hp.getHotelname());
				hotelOrderInfoPO.setRoomName(hp.getRoomname());
				hotelOrderInfoPO.setHotelAddress(hp.getHoteladdress());
				hotelOrderInfoPO.setBedType(hp.getBedtype());
				hotelOrderInfoPO.setRatePlanName(hp.getRateplanname());
				hotelOrderInfoPO.setRatePlanID(Integer.parseInt(hp.getRateplanid()));
				hotelOrderInfoPO.setCityName(hp.getCityname());
				hotelOrderInfoPO.setQuantity(hp.getQuantity());
				hotelOrderInfoPO.setNoteElong(hp.getNotetoelong());
				hotelOrderInfoPO.setBookingRuless(hp.getGuarantee());
				hotelOrderInfoPO.setStarCode(hp.getStar());
				hotelOrderInfoPO.setFirstDayPriceVouch(hp.getFirstdayprice()== null? 0f:hp.getFirstdayprice());
			} catch (Exception e) {
				log.error("封装酒店信息出错!" + e.getMessage());
			}
		}
		if (gp != null) {
			try {
				hotelOrderInfoPO.setIdTypeCode(gp.getBankname());
				hotelOrderInfoPO.setNumber(gp.getCardnum());
				// hotelOrderInfoPO.setValidYear(gp.getValiddate())//需要处理
				// hotelOrderInfoPO.setValidMonth("")需要处理
				hotelOrderInfoPO.setCardHolderName(gp.getOwnername());
				hotelOrderInfoPO.setIdTypeCode_card(gp.getIdtypecode());
				hotelOrderInfoPO.setIdNumber_card(gp.getIdnumber());
				hotelOrderInfoPO.setBankName(gp.getBankname());
				hotelOrderInfoPO.setVeryfyCode(gp.getCvv2());
				String valiDate = gp.getValiddate();
				if(valiDate != null && !"".equals(valiDate)){
					if(order.getTerminalid().contains("phone")){
						hotelOrderInfoPO.setValidMonth(Integer.parseInt(valiDate.substring(0, 2)));
						hotelOrderInfoPO.setValidYear(Integer.parseInt(valiDate.substring(2 )));
					}else{
						hotelOrderInfoPO.setValidYear(Integer.parseInt(valiDate.substring(0, 2)));
						hotelOrderInfoPO.setValidMonth(Integer.parseInt(valiDate.substring(2 )));
					}
				}else{
					hotelOrderInfoPO.setValidYear(22);
					hotelOrderInfoPO.setValidMonth(12);
				}
			} catch (Exception e) {
				log.error("封装担保信息出错 !" + e.getMessage());
			}
		}else{
			hotelOrderInfoPO.setValidYear(22);
			hotelOrderInfoPO.setValidMonth(12);
		}
		return hotelOrderInfoPO;

	}
	/**
	 * 封装提交订单所需参数，此方法方便于再次提交，所得的值是从数据库里取出来的，
	 * 封装完毕后，跳到再次提交页面，与preOrder.jsp一样的，会员那稍做了点修改
	 * @param order	订单
	 * @param hp	酒店
	 * @param gp   担保
	 * @return
	 */
	private HotelOrderInfoPO setHotelOrderInfoPOValues(OrderInfoPO order, HotelInfoPO hp,HotelQueryResultVO oneHotelObj, GuarantyInfoPO gp) {
		HotelForOneHotelVo oneHotel = oneHotelObj.getOneHotel();
		HotelOrderInfoPO hotelOrderInfoPO = new HotelOrderInfoPO();
		if (order != null) {
			try {
				// 预订规则没有需要自己去查询
				hotelOrderInfoPO.setOrderMessage(order.getOrdermessage());
				hotelOrderInfoPO.setStartDateStr(order.getCheckindate().split(" ")[0]);
				hotelOrderInfoPO.setEndDateStr(order.getCheckoutdate().split(" ")[0]);
				
				hotelOrderInfoPO.setCurrencyCode(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getEachDayRateList()[0].getCurrencyCode()); // 写死
				hotelOrderInfoPO.setStarCode(oneHotel.getStarCode());
				hotelOrderInfoPO.setGuestTypeCode(order.getGuesttype());
				hotelOrderInfoPO.setRatePlanCode(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getRatePlanCode());
				hotelOrderInfoPO.setReturnLcdMoney(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getReturnLcdMoney());
				hotelOrderInfoPO.setActiveRate(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getActiveRate());
				hotelOrderInfoPO.setActiveLcdfee(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getActiveLcdfee());
				hotelOrderInfoPO.setTotalPrice(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getTotalPrice());
				hotelOrderInfoPO.setTotalPriceVouch(0f);
				
				hotelOrderInfoPO.setStayAndLeave(order.getCheckindate() + "("
						+ this.getWeekToday(order.getCheckindate()) + ")" + "\t" + order.getCheckoutdate() + "("
						+ this.getWeekToday(order.getCheckoutdate()) + ")");
				
				hotelOrderInfoPO.setArrivalEarlyTime(order.getArriveearlytime());
				hotelOrderInfoPO.setArrivalLateTime(order.getArrivelatetime());
				hotelOrderInfoPO.setMobile(order.getContactphone());
				hotelOrderInfoPO.setCreateTime(order.getCreatetime());
				hotelOrderInfoPO.setLcdOrderId(order.getLcdorderid());
				hotelOrderInfoPO.setGuestNames(order.getGuestname().equals("")? "":order.getGuestname().replace("&", "/"));
				if(!order.getContactname().equals("") && order.getContactname()!= null){
					hotelOrderInfoPO.setName(order.getContactname().replace(",", ""));
				}else{
					hotelOrderInfoPO.setName("");
				}
			} catch (Exception e) {
				log.error("封装订单信息出错!" + e.getMessage());
			}
		}
		if (hp != null) {
			try {
				hotelOrderInfoPO.setHotelId(oneHotel.getHotelId());
				hotelOrderInfoPO.setRoomTypeID(oneHotel.getRoomForGetHoteList()[0].getRoomTypeId());
				hotelOrderInfoPO.setHotelName(oneHotel.getHotelName());
				hotelOrderInfoPO.setRoomName(oneHotel.getRoomForGetHoteList()[0].getRoomName());
				hotelOrderInfoPO.setHotelAddress(oneHotel.getHotelAddress());
				hotelOrderInfoPO.setBedType(oneHotel.getRoomForGetHoteList()[0].getBedtype());
				hotelOrderInfoPO.setRatePlanName(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getRatePlanName());
				hotelOrderInfoPO.setRatePlanID(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getRatePlanID());
				hotelOrderInfoPO.setCityName(hp.getCityname());
				hotelOrderInfoPO.setQuantity(hp.getQuantity());
				hotelOrderInfoPO.setNoteElong(hp.getNotetoelong());
				if(oneHotel.getBookingRuless() != null && !"".equals(oneHotel.getBookingRuless())){
					String bookingRules = "";
					for(int i=0; i<oneHotel.getBookingRuless().length; i++){
						bookingRules+=oneHotel.getBookingRuless()[i];
					}
					hotelOrderInfoPO.setBookingRuless(bookingRules);
				}
				hotelOrderInfoPO.setFirstDayPriceVouch(Float.parseFloat(oneHotel.getRoomForGetHoteList()[0].getRatePlanForGetHotelList()[0].getEachDayRateList()[0].getMemberRate().toString()));
			} catch (Exception e) {
				log.error("封装酒店信息出错!" + e.getMessage());
			}
		}
		if (gp != null) {
			try {
				hotelOrderInfoPO.setIdTypeCode(gp.getBankname());
				hotelOrderInfoPO.setNumber(gp.getCardnum());
				hotelOrderInfoPO.setCardHolderName(gp.getOwnername());
				hotelOrderInfoPO.setIdTypeCode_card(gp.getIdtypecode());
				hotelOrderInfoPO.setIdNumber_card(gp.getIdnumber());
				hotelOrderInfoPO.setBankName(gp.getBankname());
				hotelOrderInfoPO.setVeryfyCode(gp.getCvv2());
				String valiDate = gp.getValiddate();
				if(valiDate != null && !"".equals(valiDate)){
					if(order.getTerminalid().contains("phone")){
						hotelOrderInfoPO.setValidMonth(Integer.parseInt(valiDate.substring(0, 2)));
						hotelOrderInfoPO.setValidYear(Integer.parseInt(valiDate.substring(2 )));
					}else{
						hotelOrderInfoPO.setValidYear(Integer.parseInt(valiDate.substring(0, 2)));
						hotelOrderInfoPO.setValidMonth(Integer.parseInt(valiDate.substring(2 )));
					}
				}else{
					hotelOrderInfoPO.setValidYear(22);
					hotelOrderInfoPO.setValidMonth(12);
				}
			} catch (Exception e) {
				log.error("封装担保信息出错 !" + e.getMessage());
			}
		}else{
			hotelOrderInfoPO.setValidYear(22);
			hotelOrderInfoPO.setValidMonth(12);
		}
		return hotelOrderInfoPO;

	}
	/****
	 * 进行酒店预订页面,点击左边酒店预订时
	 * @param hotelPO 封装的查询参数
	 * @return
	 */
	@RequestMapping(value = "/result")
	public String result(@RequestParam("elongId") String elongId, @RequestParam("localId") String localId, 
							@RequestParam("id") String id, 
							@RequestParam("result") String result,
								ModelMap modelMap){
		modelMap.addAttribute("result", result);
		modelMap.addAttribute("elongId", elongId);
		modelMap.addAttribute("id", id);
		modelMap.addAttribute("localId", localId);
		log.info("跳转到预订结果页面!");
		return "/hotel/result";
	}
	/**
	 * 根据输入值模糊查询城市名称,自动提示
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/qryCity")
	public Object qryCity(@RequestParam(value="cityName",required=false, defaultValue="") String cityName, ModelMap model){
		List<HotelCityInfoVo> resultList = null;
		Map<String, Object> queryMap = new HashMap<String, Object>();
			try {
				cityName = URLDecoder.decode(cityName, "UTF-8");
				log.debug("**********查询城市名称，按名称前缀匹配，当前输入值【{}】 ", cityName);
				queryMap.put("cityName", cityName);
				resultList = hotelService.findHotelCities(queryMap);
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			return resultList;
	}
	/**
	 * 根据输入值模糊查询行政区名称,自动提示
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/qryDst")
	public Object qryDst(@RequestParam(value="dstName",required=false, defaultValue="") String dstName, 
								@RequestParam(value="cityCode",required=false, defaultValue="") String cityCode, ModelMap model){
		List<DistrictPO> resultList = null;
		Map<String, Object> queryMap = new HashMap<String, Object>();
		try {
			dstName = URLDecoder.decode(dstName, "UTF-8");
			log.debug("**********查询城市名称，按名称前缀匹配，当前输入值【{}】 ", dstName);
			//queryMap.put("dstName", dstName);
			queryMap.put("cityCode", cityCode);
			resultList = hotelService.findHotelDst(queryMap);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	/**
	 * 根据输入值模糊查询商业区名称,自动提示
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/qryComm")
	public Object qryComm(@RequestParam(value="commName",required=false, defaultValue="") String commName,
									@RequestParam(value="cityCode",required=false, defaultValue="") String cityCode,ModelMap model){
		List<CommercialPO> resultList = null;
		Map<String, Object> queryMap = new HashMap<String, Object>();
		try {
			commName = URLDecoder.decode(commName, "UTF-8");
			log.debug("**********查询城市名称，按名称前缀匹配，当前输入值【{}】 ", commName);
			queryMap.put("cityCode", cityCode);
			resultList = hotelService.findHotelComm(queryMap);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	/**
	 * 根据输入值模糊查询标志物名称,自动提示
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/qryLm")
	public Object qryLm(@RequestParam(value="lmName",required=false, defaultValue="") String lmName, 
								@RequestParam(value="cityCode",required=false, defaultValue="") String cityCode, ModelMap model){
		List<LandmarkPO> resultList = null;
		Map<String, Object> queryMap = new HashMap<String, Object>();
		try {
			lmName = URLDecoder.decode(lmName, "UTF-8");
			log.debug("**********查询城市名称，按名称前缀匹配，当前输入值【{}】 ", lmName);
			queryMap.put("cityCode", cityCode);
			resultList = hotelService.findHotelLm(queryMap);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return resultList;
	}
	
	@RequestMapping(value="/showHotelInfo")
	public String showHotelInfo(ModelMap modelMap,@RequestParam(value="hotelId",required=true) String hotelId){
		hotelControllerSupport.findHotelInfo(modelMap,hotelId);
		return "/hotel/hotelInfoShow";
	}
	/**
	 * 跳转到订单导入页面
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/toOrderImport")
	public String toOrderImport(ModelMap modelMap){
		return "/hotel/orderImport";
	}
	/**
	 * 导入艺龙订单
	 * @param modelMap
	 * @param elongId
	 * @return
	 */
	@RequestMapping(value="/importOrderInfo")
	public ModelAndView importOrder(ModelMap modelMap,@RequestParam(value="orderId",required=true) String elongId){
		hotelControllerSupport.importOrder(modelMap,elongId);
		return new ModelAndView("jsonView"); 
	}
	/**
	 * 更新订单会员信息
	 * @param modelMap
	 * @param request
	 * @param primaryOrderId
	 * @param orderUserType
	 * @param orderUserId
	 * @return
	 */
	@RequestMapping(value="/updateOrderUser")
	public ModelAndView updateOrderUser(ModelMap modelMap,HttpServletRequest request,@RequestParam(value="primaryOrderId",required=true) long primaryOrderId,
			@RequestParam(value="orderUserType",required=false,defaultValue="05") String orderUserType,
			@RequestParam(value="orderUserId",required=false) Long orderUserId){
		HotelOrderInfoVO orderInfo=new HotelOrderInfoVO();
		orderInfo.setId(primaryOrderId);
		orderInfo.setUserId(orderUserId);
		orderInfo.setUserType(orderUserType);
		if("01".equals(orderUserType)||"02".equals(orderUserType)){
			orderInfo.setContactName(request.getParameter("encontactName"));
			orderInfo.setContactPhone(request.getParameter("encontactPhone"));
		}else if("00".equals(orderUserType)){
			orderInfo.setContactName(request.getParameter("incontactName"));
			orderInfo.setContactPhone(request.getParameter("incontactPhone"));
		}else if("03".equals(orderUserType)){
			orderInfo.setContactName(request.getParameter("cocontactName"));
			orderInfo.setContactPhone(request.getParameter("cocontactPhone"));
		}else if("04".equals(orderUserType)){
			orderInfo.setContactName(request.getParameter("phcontactName"));
			orderInfo.setContactPhone(request.getParameter("phcontactPhone"));
		}else {
			orderInfo.setContactName(request.getParameter("nocontactName"));
			orderInfo.setContactPhone(request.getParameter("nocontactPhone"));
			//orderInfo.setUserType("05");
			orderInfo.setUserId(null);
		}
		hotelControllerSupport.updateOrderUser(modelMap,orderInfo);
		return new ModelAndView("jsonView");
	}
	/**
	 * 取消订单
	 * @param modelMap
	 * @param elongId
	 * @return
	 */
	@RequestMapping(value="/cancelOrder")
	public ModelAndView cancelHotelOrder(ModelMap modelMap,@RequestParam(value="orderId",required=true) String elongId){
		boolean result=hotelControllerSupport.cancelHotelOrder(modelMap,elongId);
		return new ModelAndView("jsonView");
	}
	/**
	 * 同步订单
	 * @param modelMap
	 * @param elongId
	 * @return
	 */
	@RequestMapping(value="/synchronizeOrder")
	public ModelAndView synchronizeOrder(ModelMap modelMap,@RequestParam(value="orderId",required=false,defaultValue="") String elongId){
		hotelControllerSupport.synchronizeOrder(modelMap,elongId);
		return new ModelAndView("jsonView");
	}
	/**
	 * 查询订单详情
	 * @param modelMap
	 * @param elongId
	 * @return
	 */
	@RequestMapping(value="/toOrderInfo")
	public String getOrderInfoByElongId(ModelMap modelMap,@RequestParam(value="orderId",required=true) String elongId,@RequestParam(value="importFlag",required=false,defaultValue="") String importFlag){
		boolean flag=hotelControllerSupport.getOrderInfoByElongId(modelMap, elongId);
		modelMap.put("importFlag", importFlag);
		if(flag) return "/hotel/orderInfo";
		else return "/common/popwinCloseErr";
	}
	/**
	 * 如果需要担保时，封装担保信息
	 * @param ho
	 * @param rtnMap
	 * @param vouch
	 */
	private void createVouch(HotelOrderInfoPO ho, Map<String, Object> rtnMap, HotelProductVouchVo vouch) {
		Float vouchMoney = 0f;
		String vouchType = "";
		if(vouch.getVouchMoneyType().equals("1")){
			vouchType = "首晚担保";
			vouchMoney = ho.getQuantity() * ho.getFirstDayPriceVouch();
		}else if(vouch.getVouchMoneyType().equals("2")){
			vouchType = "全额担保";
			vouchMoney = ho.getQuantity() * Float.parseFloat(ho.getTotalPrice().toString());
		}
		rtnMap.put("result", true);	
		rtnMap.put("vouchType", vouchType);
		rtnMap.put("vouchMoney", vouchMoney);
		rtnMap.put("vouchDesc", vouch.getDescription_CN());
	}
	private CreditCardForSubmitHotelOrder createCreditCard(HotelOrderInfoPO ho, HotelOrderRequest hor) {
		CreditCardForSubmitHotelOrder creditCard = new CreditCardForSubmitHotelOrder();
		creditCard.setCardHolderName(ho.getCardHolderName());
		creditCard.setIdNumber(ho.getIdNumber_card());
		creditCard.setIdTypeCode(ho.getIdTypeCode_card());
		if(ho.getNumber() != null && !"".equals(ho.getNumber())){
			creditCard.setNumber(ho.getNumber().replace(" ", ""));
		}
		creditCard.setBankId(ho.getIdTypeCode());
		creditCard.setValidMonth(ho.getValidMonth());
		creditCard.setValidYear(ho.getValidYear());
		creditCard.setValidDate("20"+ho.getValidYear()+"-"+ho.getValidMonth()+"-1 00:00:00");
		creditCard.setVeryfyCode(ho.getVeryfyCode());
		return creditCard;
	}
	private FaxForSubmitHotelOrder createFax(HotelOrderInfoPO ho) {
		FaxForSubmitHotelOrder fax = new FaxForSubmitHotelOrder();
	    fax.setAreaCode(ho.getAreaCode_fax());
	    fax.setExt(ho.getExt_fax());
	    fax.setInterCode(ho.getInterCode_fax());
	    fax.setNmber(ho.getNmber_fax());
		return fax;
	}
	private PhoneForSubmitHotelOrder createPhone(HotelOrderInfoPO ho) {
		PhoneForSubmitHotelOrder phone = new PhoneForSubmitHotelOrder();
	    phone.setAreaCode(ho.getAreaCode_phone());
	    phone.setExt(ho.getExt_phone());
	    phone.setInterCode(ho.getInterCode_phone());
	    phone.setNmber(ho.getNmber_phone());
		return phone;
	}
	private ContacterForSubmitHotelOrder createContacter(HotelOrderInfoPO ho) {
		ContacterForSubmitHotelOrder contacterForSubmitHotelOrder = new ContacterForSubmitHotelOrder();
	    contacterForSubmitHotelOrder.setEmail(ho.getEmail());
	    contacterForSubmitHotelOrder.setGenderCode(ho.getGenderCode());
	    contacterForSubmitHotelOrder.setIdNumber(ho.getIdNumber());
	    contacterForSubmitHotelOrder.setIdTypeCode(ho.getIdTypeCode());
	    contacterForSubmitHotelOrder.setMobile(ho.getMobile());
	    contacterForSubmitHotelOrder.setName(ho.getName());
		return contacterForSubmitHotelOrder;
	}
	private RatePlanForHotel createRatePlanForHotel(HotelOrderInfoPO ho) {
		RatePlanForHotel ratePlanForHotel = new RatePlanForHotel();
	    ratePlanForHotel.setAveragePrice(ho.getAveragePrice());
	    ratePlanForHotel.setGuestTypeCode(ho.getGuestTypeCode());
	    ratePlanForHotel.setRatePlanCode(ho.getRatePlanCode());
	    ratePlanForHotel.setRatePlanID(ho.getRatePlanID());
	    ratePlanForHotel.setRatePlanName(ho.getRatePlanName());
	    
	    ratePlanForHotel.setReturnLcdMoney(ho.getReturnLcdMoney());
	    ratePlanForHotel.setActiveLcdfee(ho.getActiveLcdfee());
	    ratePlanForHotel.setActiveRate(ho.getActiveRate());
		
	    ratePlanForHotel.setTotalPrice(ho.getTotalPrice());
	    ratePlanForHotel.setEachDayRateList(null);
		return ratePlanForHotel;
	}
	private HotelOrderRequest createBaseHOR(HotelOrderInfoPO ho,OrderCcextPO orderCcextPO) {
		HotelOrderRequest hor = new HotelOrderRequest();
		/**基本信息**/
		String guestName = ho.getGuestNames();
		String [] guestNames = guestName.split("/");
		hor.setFlag(1+"");
		hor.setArrivalEarlyTime(ho.getArrivalEarlyTime());
		hor.setArrivalLateTime(ho.getArrivalLateTime());
		hor.setCheckInDate(ho.getStartDateStr() + " 00:00:00");
		hor.setCheckOutDate(ho.getEndDateStr() + " 00:00:00");
		hor.setHotelId(ho.getHotelId());
		hor.setRoomTypeId(ho.getRoomTypeID());
		String terminalId="callcenter;callcenter:"+(cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
		hor.setTerminalNo(terminalId);
		hor.setGuestNames(guestNames);
		
//		hor.setReturnLcdMoney(ho.getReturnLcdMoney());
//		hor.setActiveLcdfee(ho.getActiveLcdfee());
//		hor.setActiveRate(ho.getActiveRate());
		
		hor.setUserId(orderCcextPO.getCustomerId()+"");
		hor.setUserType(orderCcextPO.getCustomerType());
		hor.setNoteToHotel(ho.getNoteElong());
		hor.setOrderid(ho.getLcdOrderId());
		hor.setStar(ho.getStarCode());
		hor.setFirstDayPrice(ho.getFirstDayPriceVouch().toString());
		hor.setGuaranteerules(ho.getBookingRuless());
		return hor;
	}
	/**
	 * 转换时间从字符串格式到日期格式
	 * @param date
	 * @return
	 */
	private Calendar transDate(String date){
		Calendar cal = Calendar.getInstance();
		Date newDate = null;
		if(date != null && !"".equals(date)){
			try {
				newDate = format.parse(date);
				cal.setTime(newDate);
			} catch (ParseException e) {
				log.error("预订房间时，解析时间出错!");
				e.printStackTrace();
			}
		}
		return cal;
	}
	/**
	 * 得到今天/明天日期，字符串格式
	 * @return 今天或明天
	 */
	private String getDateToday(Integer whichDay){
		
		Calendar cal = Calendar.getInstance();
		Date dayDate = new Date();
		cal.setTime(dayDate);
		switch(whichDay){
			case 0 : {
				break;
			}
			case 1 : {
				// 根据今天得到明天
				cal.add(cal.DATE, 1);
				break;
			}
		}
		return format.format(cal.getTime());
	}
	/**
	 * 得到今天/明天是星期几，字符串格式
	 * @return 今天或明天
	 */
	private String getWeekToday(String dateStr){
		SimpleDateFormat fmtWeek  = new SimpleDateFormat("EEEE");
		Date date = null;;
		try {
			date = format.parse(dateStr);
		} catch (ParseException e) {
			log.error("日期格式转换为星期格式出错!..."+ e.getMessage());
			e.printStackTrace();
		}
		return fmtWeek.format(date);
	}
	/****
	 * 判断是否需要担保
	 * @param hotelForMoreHotelVo
	 * @return
	 */
	private HotelProductVouchRequest vouchParams(HotelOrderInfoPO hotelForMoreHotelVo) {
		HotelProductVouchRequest orderVouchRequest = new HotelProductVouchRequest();
		orderVouchRequest.setCheckInDate(hotelForMoreHotelVo.getStartDateStr() + " 00:00:00");
		orderVouchRequest.setCheckOutDate(hotelForMoreHotelVo.getEndDateStr() + " 00:00:00");
		orderVouchRequest.setHotelId(hotelForMoreHotelVo.getHotelId());
		orderVouchRequest.setRoomTypeId(hotelForMoreHotelVo.getRoomTypeID());
		orderVouchRequest.setRatePlanId(hotelForMoreHotelVo.getRatePlanID());
		orderVouchRequest.setRoomNum(hotelForMoreHotelVo.getQuantity());
		orderVouchRequest.setArriveLaterTime(hotelForMoreHotelVo.getArrivalLateTime());
		return orderVouchRequest;
	}
	/**
	 * 更新订单备注
	 * @param modelMap
	 * @param primaryId
	 * @param remark
	 * @return
	 */
	@RequestMapping(value="/updateOrderRemark")
	public ModelAndView updateOrderRemark(ModelMap modelMap,@RequestParam(value="lcdOrderId",required=true)String lcdOrderId,
			@RequestParam(value="remark",required=false,defaultValue="") String remark){
		hotelControllerSupport.updateOrderRemark(modelMap,lcdOrderId,remark);
		return new ModelAndView("jsonView");
	}

}
//OrderInfoPO order = createOrderInfoPO(ho);
//Integer res_order = hotelControllerSupport.createOrder(order);
///**创建订单酒店信息**/
//HotelInfoPO hotelInfoPO = createHotelInfoPO(ho, order);
//Integer res_hotel = hotelControllerSupport.createHotel(hotelInfoPO);
//System.out.println(hotelInfoPO.getId());
//System.out.println(order.getId());