package cn.itkt.btsf.hotel.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.hotel.localvo.HotelOrderQueryVO;
import cn.itkt.btsf.hotel.service.HotelOrderService;
import cn.itkt.btsf.hotel.service.HotelService;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.sys.coop.po.CooperationPO;
import cn.itkt.btsf.sys.coop.service.CoopService;
import cn.itkt.btsf.sys.member.po.MemberEnterprisePO;
import cn.itkt.btsf.sys.member.po.MemberIndividualPO;
import cn.itkt.btsf.sys.member.service.MemberEnterpriseService;
import cn.itkt.btsf.sys.member.service.MemberIndividualService;
import cn.itkt.pagination.Pages;

@Service
public class HotelOrderControllerSupport {
	private static final Logger log = LoggerFactory.getLogger(HotelOrderControllerSupport.class);

	private int pageSize = 10;

	@Resource
	private HotelOrderService hotelOrderService;
	@Resource
	private HotelService hotelService;
	@Resource
	private MemberEnterpriseService memberEnterpriseService;
	@Resource
	private MemberIndividualService memberIndividualService;
	@Resource
	private CoopService coopService;
	@Resource
	private PhoneUsersService phoneUsersService;

	public void getHotelOrderList(ModelMap modelMap, HotelOrderQueryVO hotelOrderQueryVO, int startIndex) {
		try {
			Pages<HashMap<String, Object>> pages = new Pages<HashMap<String, Object>>(startIndex, pageSize);
			HashMap<String, Object> sqlParamMap = new HashMap<String, Object>();
			sqlParamMap.put("inDate", hotelOrderQueryVO.getInDate());
			sqlParamMap.put("inDateLast", hotelOrderQueryVO.getInDateLast());
			sqlParamMap.put("guestName", hotelOrderQueryVO.getGuestName());
			sqlParamMap.put("contactName", hotelOrderQueryVO.getContactName());
			sqlParamMap.put("outDate", hotelOrderQueryVO.getOutDate());
			sqlParamMap.put("outDateLast", hotelOrderQueryVO.getOutDateLast());
			sqlParamMap.put("lcdorderState", hotelOrderQueryVO.getLcdorderState());
			sqlParamMap.put("phone", hotelOrderQueryVO.getPhone());
			sqlParamMap.put("orderId1", hotelOrderQueryVO.getOrderId1());
			
//			if (hotelOrderQueryVO.getOrderId1() != null && !"".equals(hotelOrderQueryVO.getOrderId1())) {
//				if (hotelOrderQueryVO.getOrderId1().equals("0")) {
//					sqlParamMap.put("orderId1", hotelOrderQueryVO.getOrderId1());
//					sqlParamMap.put("orderId2", "");
//				} else if (hotelOrderQueryVO.getOrderId1().equals("2")) {
//					sqlParamMap.put("orderId1", "");
//					sqlParamMap.put("orderId2", "2");
//				}
//			}

			sqlParamMap.put("orderId", hotelOrderQueryVO.getOrderId());
			sqlParamMap.put("lcdorderid", hotelOrderQueryVO.getLcdorderid());
			sqlParamMap.put("beforehandDate", hotelOrderQueryVO.getBeforehandDate());
			sqlParamMap.put("beforehandDateLast", hotelOrderQueryVO.getBeforehandDateLast());
			sqlParamMap.put("sourceId", hotelOrderQueryVO.getSourceId());
			sqlParamMap.put("startIndex", startIndex);
			sqlParamMap.put("pageSize", pageSize);

			sqlParamMap.put("userType", hotelOrderQueryVO.getUserType());
			if(hotelOrderQueryVO.getCustomerMobile() != null &&
					!"".equals(hotelOrderQueryVO.getCustomerMobile())){
				try {
					List<Long> userIds = this.getUserIdByCustomerMobile(hotelOrderQueryVO.getCustomerMobile());
					if(userIds != null && userIds.size()>0)
						sqlParamMap.put("userIds", userIds);
					else
						sqlParamMap.put("userIds", new ArrayList<Long>());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
				
				
			/** 调用接口 **/
			// List<HashMap<String, Object>>
			// orderList=hotelOrderService.getHotelOrderList(sqlParamMap);
			List<HashMap<String, Object>> orderList = hotelService.getHotelOrderList(sqlParamMap);
			if (orderList != null && orderList.size() > 0) {
				pages.setItems(orderList);
				Object totalCount = orderList.get(0).get("totalCount") + "";
				pages.setTotalCount(Integer.valueOf(totalCount + ""));
				/** 改为接口调用 **/
				// pages.setTotalCount(hotelOrderService.getHotelOrderCount(sqlParamMap));
				modelMap.addAttribute("orderList", orderList);
				modelMap.addAttribute("page", pages);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}

	}

	private List<Long> getUserIdByCustomerMobile(String customerMobile) {
		List<Long> userIds = new ArrayList<Long>();
		Map<String , Object> queryMap = new HashMap<String,Object>();
		queryMap.put("contact", customerMobile);
		List<MemberEnterprisePO> meList = memberEnterpriseService.findAllWithoutPage(queryMap);
		if(meList != null && meList.size()>0){
			for(MemberEnterprisePO me: meList){
				userIds.add(me.getId());
			}
		}
		List<MemberIndividualPO> miList = memberIndividualService.findIndividualMbr(customerMobile);
		if(miList != null && miList.size()>0){
			for(MemberIndividualPO mv : miList){
				userIds.add(mv.getId());
			}
		}
		List<CooperationPO> coops = coopService.findByCoopPhone(customerMobile);
		if(coops != null && coops.size()>0){
			for(CooperationPO co: coops){
				userIds.add(co.getId());
			}
		}
		PhoneUsersPO phoneUser = phoneUsersService.findByPhone(customerMobile);
		if(phoneUser != null){
			userIds.add(phoneUser.getUserid());
		}
 		return userIds;
	}

	/**
	 * 将导出订单列表导出到excel
	 * 
	 * @param model
	 * @param queryVO
	 * @param startIndex
	 * @return
	 */
	public void getHotelAllOrderList(ModelMap modelMap, HotelOrderQueryVO hotelOrderQueryVO, int startIndex) {
		try {

			try {
				Pages<HashMap<String, Object>> pages = new Pages<HashMap<String, Object>>(startIndex, 30000);
				HashMap<String, Object> sqlParamMap = new HashMap<String, Object>();
				sqlParamMap.put("inDate", hotelOrderQueryVO.getInDate());
				sqlParamMap.put("inDateLast", hotelOrderQueryVO.getInDateLast());
				sqlParamMap.put("guestName", hotelOrderQueryVO.getGuestName());
				sqlParamMap.put("contactName", hotelOrderQueryVO.getContactName());
				sqlParamMap.put("outDate", hotelOrderQueryVO.getOutDate());
				sqlParamMap.put("outDateLast", hotelOrderQueryVO.getOutDateLast());
				sqlParamMap.put("lcdorderState", hotelOrderQueryVO.getLcdorderState());
				sqlParamMap.put("phone", hotelOrderQueryVO.getPhone());
				sqlParamMap.put("orderId1", hotelOrderQueryVO.getOrderId1());
				
//				if (hotelOrderQueryVO.getOrderId1() != null && !"".equals(hotelOrderQueryVO.getOrderId1())) {
//					if (hotelOrderQueryVO.getOrderId1().equals("0")) {
//						sqlParamMap.put("orderId1", hotelOrderQueryVO.getOrderId1());
//						sqlParamMap.put("orderId2", "");
//					} else if (hotelOrderQueryVO.getOrderId1().equals("2")) {
//						sqlParamMap.put("orderId1", "");
//						sqlParamMap.put("orderId2", "2");
//					}
//				}

				sqlParamMap.put("orderId", hotelOrderQueryVO.getOrderId());
				sqlParamMap.put("lcdorderid", hotelOrderQueryVO.getLcdorderid());
				sqlParamMap.put("beforehandDate", hotelOrderQueryVO.getBeforehandDate());
				sqlParamMap.put("beforehandDateLast", hotelOrderQueryVO.getBeforehandDateLast());
				sqlParamMap.put("sourceId", hotelOrderQueryVO.getSourceId());
				sqlParamMap.put("startIndex", startIndex);
				sqlParamMap.put("pageSize", 30000);

				sqlParamMap.put("userType", hotelOrderQueryVO.getUserType());
				sqlParamMap.put("customerMobile", hotelOrderQueryVO.getCustomerMobile());
				/** 调用接口 **/
				// List<HashMap<String, Object>>
				// orderList=hotelOrderService.getHotelOrderList(sqlParamMap);
				List<HashMap<String, Object>> orderList = hotelService.getHotelOrderList(sqlParamMap);
				if (orderList != null && orderList.size() > 0) {
					pages.setItems(orderList);
					Object totalCount = orderList.get(0).get("totalCount") + "";
					pages.setTotalCount(Integer.valueOf(totalCount + ""));
					/** 改为接口调用 **/
					// pages.setTotalCount(hotelOrderService.getHotelOrderCount(sqlParamMap));
					modelMap.addAttribute("orderList", orderList);
					modelMap.addAttribute("page", pages);
				}
			} catch (Exception e) {
				e.printStackTrace();
				log.error(e.getMessage());
			}

		
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
		}

	}

}
