package cn.itkt.btsf.hotel.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cn.itkt.btsf.hotel.po.HotelAccountInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountResult;
import cn.itkt.btsf.hotel.service.HotelService;

/**
 * @version 1.0
 * @author SunLing
 * @date 2012-10-29
 * @title 酒店业务模块主要处理类
 */
@Controller
@RequestMapping("/hotel")
public class HotelAccountController {
	@Resource
	private HotelService hotelService;
	private SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	/****
	 * 进行酒店查询页面,点击左边酒店预订时 不进行查询
	 * @param hotelPO 传入的参数为空，将入住日期与离店日期与城市设为默认
	 * @return
	 */
	@RequestMapping(value = "/account")
	public String findAccount(ModelMap modelMap,HttpServletRequest request){
		Calendar cal = Calendar.getInstance();//当前日期  
	    cal.set(Calendar.DATE,1);//设为当前月的1号  
	    cal.add(Calendar.DATE,-1);//减一天，变为上月最后一天  
	    String checkoutDate = format.format(cal.getTime());//输出2012-12-31 
	    cal.clear();
	    Calendar cal2 = Calendar.getInstance();//当前日期  
	    cal2.set(Calendar.DATE,1);//设为当前月的1号  
	    cal2.add(Calendar.MONTH,-1);//减一月，变为上月第一天  
	    String checkinDate = format.format(cal2.getTime());//输出2012-12-01
	    cal.clear();
		modelMap.put("checkinDate", checkinDate);
		modelMap.put("checkoutDate", checkoutDate);
		return "/hotel/account/findAccount";
	}
	/****
	 * 进行酒店查询页面,点击左边酒店预订时 不进行查询
	 * @param hotelPO 传入的参数为空，将入住日期与离店日期与城市设为默认
	 * @return
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/accountList")
	public String accountList(@RequestParam("checkinDate") String checkinDate,
									@RequestParam("checkoutDate") String checkoutDate,
											@RequestParam("ifexport") String ifexport,
											ModelMap modelMap,HttpServletRequest request) throws ParseException{
		Date cidate = null;
		Date codate = null;
		Map<String, Object> queryMap = new HashMap<String, Object>();
		if(checkinDate != null && !"".equals(checkinDate)){
			cidate = format.parse(checkinDate);
		}
		if(checkoutDate != null && !"".equals(checkoutDate)){
			codate = format.parse(checkoutDate);
		}
		queryMap.put("checkinDate", cidate);
		queryMap.put("checkoutDate", codate);
		
		 Map<String, Object>  maps = hotelService.findHotelJsonAccounts(queryMap); 
		List<HotelAccountInfoPO> hotelAccounts =  (List<HotelAccountInfoPO>) maps.get("hotelAccounts");
		HotelAccountResult totalAccount = (HotelAccountResult) maps.get("totalAccount");
		modelMap.put("accountList", hotelAccounts);
		modelMap.put("totalResult", totalAccount);
		modelMap.put("checkinDate", checkinDate);
		modelMap.put("checkoutDate", checkoutDate);
		if(ifexport != null && "true".equals(ifexport)){
			return "hotelAccountExcel";
		}else{
			return "/hotel/account/findAccount";
		}
	}
	/****
	 * 进行酒店查询页面,点击左边酒店预订时 不进行查询
	 * @param hotelPO 传入的参数为空，将入住日期与离店日期与城市设为默认
	 * @return
	 * @throws ParseException 
	 */
	@RequestMapping(value = "/accountList_bak")
	public String accountList_bak(@RequestParam("checkinDate") String checkinDate,
			@RequestParam("checkoutDate") String checkoutDate,
			@RequestParam("ifexport") String ifexport,
			ModelMap modelMap,HttpServletRequest request) throws ParseException{
		Date cidate = null;
		Date codate = null;
		Map<String, Object> queryMap = new HashMap<String, Object>();
		if(checkinDate != null && !"".equals(checkinDate)){
			cidate = format.parse(checkinDate);
		}
		if(checkoutDate != null && !"".equals(checkoutDate)){
			codate = format.parse(checkoutDate);
		}
		queryMap.put("checkinDate", cidate);
		queryMap.put("checkoutDate", codate);
		List<HotelAccountInfoPO> hotelAccounts = hotelService.findHotelAccounts(queryMap);
		
		HotelAccountResult totalAccount = new HotelAccountResult();
		if(hotelAccounts != null && hotelAccounts.size()>0){
			Double commission = 0d;
			Integer quantitydays = 0;
			Double bonuspunish = 0d;
			Integer totalQuantityDays = hotelService.findQuantityDaysTotal(queryMap);
			for(int i=0; i<hotelAccounts.size(); i++){
				commission += hotelAccounts.get(i).getCommission();
				quantitydays += hotelAccounts.get(i).getQuantitydays();
				bonuspunish += hotelAccounts.get(i).getBonuspunish();
			}
			totalAccount.setRewardPunishAmount(bonuspunish);
			totalAccount.setTotalCommission(commission);    					//总佣金
			totalAccount.setTotalOrderQuantityDay(totalQuantityDays);			//总预订间夜
			totalAccount.setTotalRealCommission(commission + bonuspunish);			
			totalAccount.setValidQuantityDay(quantitydays);						//入住间夜
			totalAccount.setValidQuantityDayRate((float)quantitydays/(float)totalQuantityDays); //有效间夜率	= 入住间夜 / 总预订间夜
		}
		modelMap.put("accountList", hotelAccounts);
		modelMap.put("totalResult", totalAccount);
		modelMap.put("checkinDate", checkinDate);
		modelMap.put("checkoutDate", checkoutDate);
		if(ifexport != null && "true".equals(ifexport)){
			return "hotelAccountExcel";
		}else{
			return "/hotel/account/findAccount";
		}
	}

}
