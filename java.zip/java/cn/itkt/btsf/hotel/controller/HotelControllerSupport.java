package cn.itkt.btsf.hotel.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import cn.itkt.btsf.hotel.localvo.HotelInfoVO;
import cn.itkt.btsf.hotel.localvo.HotelOrderInfoVO;
import cn.itkt.btsf.hotel.po.GuarantyInfoPO;
import cn.itkt.btsf.hotel.po.HotelInfoPO;
import cn.itkt.btsf.hotel.po.OrderInfoPO;
import cn.itkt.btsf.hotel.service.HotelService;
import cn.itkt.btsf.hotel.vo.BaseVo;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOneQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderStateResult;
import cn.itkt.btsf.hotel.vo.HotelOrderVo;
import cn.itkt.btsf.hotel.vo.HotelProductVouchRequest;
import cn.itkt.btsf.hotel.vo.HotelProductVouchVo;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.hotel.vo.RoomReserveInfoVo;
import cn.itkt.btsf.hotel.vo.RoomReserveRequest;
import cn.itkt.btsf.hotel.webservice.HotelWebService;
import cn.itkt.btsf.phone.users.po.PhoneUsersPO;
import cn.itkt.btsf.phone.users.service.PhoneUsersService;
import cn.itkt.btsf.sys.coop.po.CooperationPO;
import cn.itkt.btsf.sys.coop.service.CoopService;
import cn.itkt.btsf.sys.member.po.MemberEnterprisePO;
import cn.itkt.btsf.sys.member.po.MemberIndividualPO;
import cn.itkt.btsf.sys.member.service.MemberEnterpriseService;
import cn.itkt.btsf.sys.member.service.MemberIndividualService;
import cn.itkt.btsf.util.LoginUtil;

/**
 * @version 1.0
 * @author SunLing
 * @date 2012-10-29
 * @title 酒店业务模块主要辅助类
 */
@Service("hotelControllerSupport")
public class HotelControllerSupport {
	private Logger log = LoggerFactory.getLogger(HotelControllerSupport.class);
	@Resource
	private HotelWebService hotelWebService;
	@Resource
	private HotelService hotelService;
	@Resource
	private MemberEnterpriseService memberEnterpriseService;
	@Resource
	private MemberIndividualService memberIndividualService;
	@Resource
	private CoopService coopService;
	@Resource
	private PhoneUsersService phoneUsersService;
	
	
	
	/****
	 * 根据查询条件，查询获取酒店信息
	 * @param hotelListQueryRequest 查询条件
	 * @return
	 */
	public HotelQueryResultVO findHotelQueryResultVO(HotelListQueryRequest hotelListQueryRequest) {
		HotelQueryResultVO result = hotelWebService.findHotelQueryResultVO(hotelListQueryRequest);
		return result;
	}
	/****
	 * 进入填写预订酒店房间信息页面
	 * @param reserveRequest 封装的房间预订参数
	 * @return 房间对象，主要包含剩余房间数
	 */
	public RoomReserveInfoVo getRoomReserveInfoVo(RoomReserveRequest reserveRequest) {
		RoomReserveInfoVo result = hotelWebService.getRoomReserveInfoVo(reserveRequest);
		return result;
	}
	/****
	 * 判断是否需要担保
	 * @param orderVouchRequest
	 * @return
	 */
	public HotelProductVouchVo getHotelProductVouchVo(HotelProductVouchRequest orderVouchRequest){
		return hotelWebService.getHotelProductVouchVo(orderVouchRequest);
	}
	/****
	 * 提交酒店订单
	 * @param hotelOrderRequest
	 * @return
	 */
	public HotelOrderVo getHotelOrderVo(HotelOrderRequest hotelOrderRequest){
		return hotelWebService.getHotelOrderVo(hotelOrderRequest);
	}
	/****
	 * 查询订单详情
	 * @param orderId 订单Id
	 * @return
	 */
	public OrderInfoPO findOrderInfo(Long orderId) {
		
		return hotelService.findOrderInfo(orderId);
	}
	/****
	 * 查询订单详情根据lcdOrderId
	 * @param orderId 订单Id
	 * @return
	 */
	public OrderInfoPO findIdByLcdId(String lcdOrderId){
		return hotelService.findIdByLcdId(lcdOrderId);
	}
	/****
	 * 查询订单详情
	 * @param orderId 订单Id
	 * @return
	 */
	public HotelInfoPO findOrderHotelInfo(String orderId) {
		return hotelService.findOrderHotelInfo(orderId);
	}
	/****
	 * 查询订单详情
	 * @param orderId 订单Id
	 * @return
	 */
	public GuarantyInfoPO findOrderGuarantyInfo(String orderId) {
		return hotelService.findOrderGuarantyInfo(orderId);
	}
	/**
	 * 查询酒店信息
	 * @param modelMap
	 * @param hotelId
	 */
	public void findHotelInfo(ModelMap modelMap, String hotelId) {
		HotelInfoVO hotelInfoVO=hotelService.findHotelInfo(hotelId);
/*		hotelInfoVO.setShortIntroeditor(hotelInfoVO.getIntroeditor().substring(0, 50)+"...");
		String markId=hotelInfoVO.getLandMarkids();
		if(markId!=null&&markId.endsWith(",")){
			markId=markId.substring(0, markId.length()-1);
		}
		Map<String,Object> query=new HashMap<String,Object>();
		query.put("cityId", hotelInfoVO.getCityId());
		query.put("landMarkids", markId);
		query.put("hotelId", hotelInfoVO.getHotelId());
		//查询酒店标志物
		List<String> landMark=hotelService.findLandMarkByHotelMark(query);
		StringBuffer sb=new StringBuffer();
		
		for(String s:landMark){
			if(sb.length()!=0){
				sb.append(",");
			}
			sb.append(s);
		}
		hotelInfoVO.setLandMarkids(sb.toString());*/
		modelMap.put("hotelInfo", hotelInfoVO);
		
	}
	public boolean importOrder(ModelMap modelMap, String elongId) {
		HotelOrderStateResult result;
		try {
			int elongIdCount=hotelService.countOrderByElongId(elongId);
			if(elongIdCount>0){
				modelMap.put("msg", "此艺龙订单已存在");
				modelMap.put("result", "0");
				return false;
			}
			result = hotelWebService.importOrderOrSynChroNized(elongId,true);
			if(result==null){
				modelMap.put("msg", "导入出错");
				modelMap.put("result", "1");
				return false;
			}
			if("0".equals(result.getStatus())){
				HotelOrderInfoVO orderInfo=hotelService.findHotelInfoByElongId(elongId);
				if(orderInfo==null){
					modelMap.put("msg", "导入失败");
					modelMap.put("result", "1");
					return false;
				}
				
				setOrderUserInfo(orderInfo);
				modelMap.put("orderInfo", orderInfo);
				modelMap.put("msg", "导入成功");
				modelMap.put("result", "0");
			}else{
				modelMap.put("msg", result.getMessage());
				modelMap.put("result", "1");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("msg", "导入出错，请联系管理员");
			modelMap.put("result", "1");
			return false;
		}
		
		return true;
	}
	/**
	 * 更新订单会员信息
	 * @param modelMap
	 * @param orderInfo
	 */
	public void updateOrderUser(ModelMap modelMap, HotelOrderInfoVO orderInfo) {
		try {
			hotelService.updateOrderUser(orderInfo);
			modelMap.put("msg", "更新成功");
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("msg", "更新失败");
		}
		
	}
	/**
	 * 取消订单
	 * @param modelMap
	 * @param elongId
	 * @return
	 */
	public boolean cancelHotelOrder(ModelMap modelMap, String elongId) {
		try {
			BaseVo cancelHotelOrderByIdResponse=hotelWebService.cancelHotelOrderById(elongId);
			if(cancelHotelOrderByIdResponse==null||cancelHotelOrderByIdResponse.getStatus()==null){
				modelMap.put("msg", "取消出错，请联系管理员");
				modelMap.put("result", "1");
				return false;
			}
			if("0".equals(cancelHotelOrderByIdResponse.getStatus())){
				//hotelService.cancelOrderStateByElongId(elongId); 去掉了，不合理
				modelMap.put("msg", "取消成功");
				modelMap.put("result", "0");
			}else{
				modelMap.put("msg",cancelHotelOrderByIdResponse.getMessage());
				modelMap.put("result", "1");
			}
//			HotelOrderInfoVO orderInfo=hotelService.findHotelInfoByElongId(elongId);
//			if(orderInfo==null){
//				modelMap.put("msg", "取消出错，请联系管理员");
//				return false;
//			}
//			setOrderUserInfo(orderInfo);
//			modelMap.put("orderInfo", orderInfo);
//			}
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("msg", "取消出错，请联系管理员");
			modelMap.put("result", "1");
			return false;
		}
		
		return true;
	}
	/**
	 * 查询订单信息
	 * @param modelMap
	 * @param elongId
	 */
	public boolean getOrderInfoByElongId(ModelMap modelMap,String elongId){
		try {
			HotelOrderInfoVO orderInfo=hotelService.findHotelInfoByElongId(elongId);
			setOrderUserInfo(orderInfo);
			modelMap.put("orderInfo", orderInfo);
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("msg", "艺龙订单id重复或不存在");
			return false;
		}
		return true;
	}
	/**
	 * 根据订单会员类型、会员id查询对应会员信息
	 * @param orderInfo
	 */
	private void setOrderUserInfo(HotelOrderInfoVO orderInfo){

		if("01".equals(orderInfo.getUserType())||"02".equals(orderInfo.getUserType())){
			MemberEnterprisePO memberPo=memberEnterpriseService.find(orderInfo.getUserId());
			if(memberPo!=null){
				orderInfo.setUserName(memberPo.getMemberName());
				orderInfo.setUserPhone(memberPo.getKeeperContact());
			}
		}else 	if("00".equals(orderInfo.getUserType())){
			MemberIndividualPO inPo=memberIndividualService.find(orderInfo.getUserId());
			if(inPo!=null){
				orderInfo.setUserName(inPo.getMemberName());
				orderInfo.setUserPhone(inPo.getMobile());
			}
		}else 	if("03".equals(orderInfo.getUserType())){
			CooperationPO coop=coopService.find(orderInfo.getUserId());
			if(coop!=null){
				orderInfo.setUserName(coop.getCoopName());
				orderInfo.setUserPhone(coop.getCoopPhone());
			}
		}else 	if("04".equals(orderInfo.getUserType())){
			PhoneUsersPO phPo=phoneUsersService.find(orderInfo.getUserId());
			if(phPo!=null){
				orderInfo.setUserName(phPo.getName());
				orderInfo.setUserPhone(phPo.getTelephone());
			}
		}
	}
	/**
	 * 同步单个订单
	 * @param modelMap
	 * @param elongId
	 * @return
	 */
	public boolean synchronizeOrder(ModelMap modelMap, String elongId) {
		HotelOrderStateResult result;
		try {
			result = hotelWebService.importOrderOrSynChroNized(elongId,false);
			if(result==null){
				modelMap.put("msg", "同步出错，请联系管理员");
				modelMap.put("result", "1");
			}
			if("0".equals(result.getStatus())){
				modelMap.put("msg", "同步成功");
				//hotelService.cancelOrderStateByElongId(elongId);
				modelMap.put("result", "0");
			}else{
				modelMap.put("msg",result.getMessage());
				modelMap.put("result", "1");
			}
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("msg", "同步出错，请联系管理员");
			modelMap.put("result", "1");
			return false;
		}
		return false;
	}
	/**
	 * 更新订单备注
	 * @param modelMap
	 * @param primaryId
	 * @param remark
	 */
	public void updateOrderRemark(ModelMap modelMap, String lcdOrderId,
			String remark) {
		try {
			HotelOrderInfoVO orderInfo=new HotelOrderInfoVO();
			orderInfo.setLcdOrderId(lcdOrderId);
			orderInfo.setRemark(remark);
			orderInfo.setLastOperator(LoginUtil.getLoginUser().getName());
			hotelService.updateOrderRemark(orderInfo);
			modelMap.put("result", "0");
			modelMap.put("msg", "更新成功");
		} catch (Exception e) {
			modelMap.put("result", "1");
			modelMap.put("msg", "更新失败");
			e.printStackTrace();
		}
	}
	public void setCustomerInfos(HotelOrderInfoVO orderInfo, ModelMap modelMap){
		this.setOrderUserInfo(orderInfo);
		modelMap.put("orderInfo", orderInfo);
	}
	public HotelQueryResultVO findOneHotelQueryResultVO(HotelOneQueryRequest hotelListQueryRequest) {
		return hotelWebService.findOneHotelQueryResultVO(hotelListQueryRequest);
	}
}
