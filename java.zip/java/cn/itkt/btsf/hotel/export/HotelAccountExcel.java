package cn.itkt.btsf.hotel.export;

import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import cn.itkt.btsf.hotel.po.HotelAccountInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountResult;
import cn.itkt.btsf.phone.orderquery.export.PhoneOrderQueryExcel;
import cn.itkt.btsf.sys.cc.national.po.ServiceFormPO;
import cn.itkt.util.DateUtil;

public class HotelAccountExcel extends AbstractExcelView {

	@SuppressWarnings("unchecked")
	@Override
	protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook workbook, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		/** 要导出的数据，带查询条件 **/
		List<HotelAccountInfoPO> hotelAccounts  = (List<HotelAccountInfoPO>) model.get("accountList");
		HotelAccountResult totalAccount  = (HotelAccountResult) model.get("totalResult");
		/**设置文件内容格式，包括字体，背景色，列宽等**/
		HSSFSheet sheet = setCellStype(workbook, "酒店结算报表");
		HSSFSheet sheet2 = setCellStype(workbook, "酒店结算归总");
		/**将数据写到文件中**/
		setCellValues(hotelAccounts, sheet);					//处理情况 操作 serviceFormlist
		setCellValues2(totalAccount, sheet2);					//处理情况 操作 serviceFormlist
		/**命名文件，解决乱码问题, 并关闭输入流(这一步很重要，如果不关，会导致浏览器一直处于繁忙状态)**/
		writeFile(workbook, request, response, hotelAccounts);
	}

	private void writeFile(HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response,
			List<HotelAccountInfoPO> hotelAccounts) throws IOException {
		String fileName = "酒店结算报表"+".xls";
		fileName = PhoneOrderQueryExcel.encodeFilename(fileName, request);
		response.setContentType("application/vnd.ms-excel");
		response.setHeader("Content-disposition", "attachment;filename=" + fileName);
		OutputStream ouputStream = response.getOutputStream();
		workbook.write(ouputStream);
		ouputStream.flush();
		ouputStream.close();
	}

	private void setCellValues(List<HotelAccountInfoPO> hotelAccounts,HSSFSheet sheet) {
		if (hotelAccounts != null && hotelAccounts.size()>0) {
			setText(getCell(sheet, 0, 0), "序号");
			setText(getCell(sheet, 0, 1), "订单号");
			setText(getCell(sheet, 0, 2), "elong订单号");
			setText(getCell(sheet, 0, 3), "入住日期");
			setText(getCell(sheet, 0, 4), "离店日期");
			
			setText(getCell(sheet, 0, 5), "酒店名称");
			setText(getCell(sheet, 0, 6), "客人姓名");
			setText(getCell(sheet, 0, 7), "房量");
			setText(getCell(sheet, 0, 8), "间夜");
			
			setText(getCell(sheet, 0, 9), "总价");
			setText(getCell(sheet, 0, 10), "佣金");
			setText(getCell(sheet, 0, 11), "奖惩");
			if (hotelAccounts != null) {
				HotelAccountInfoPO po = null;
				for (int i = 0; i < hotelAccounts.size(); i++) {
					po = hotelAccounts.get(i);
					setText(getCell(sheet, (i + 1), 0), String.valueOf(i + 1));
					setText(getCell(sheet, (i + 1), 1), po.getLcdorderid());
					setText(getCell(sheet, (i + 1), 2), po.getOrderid()+"");
					
					setText(getCell(sheet, (i + 1), 3), po.getCheckindate());
					setText(getCell(sheet, (i + 1), 4), po.getCheckoutdate());
					setText(getCell(sheet, (i + 1), 5), po.getHotelname());
					
					setText(getCell(sheet, (i + 1), 6), po.getGuestname());
					setText(getCell(sheet, (i + 1), 7), po.getQuantity()+"");
					setText(getCell(sheet, (i + 1), 8), po.getQuantitydays()+"");
					
					setText(getCell(sheet, (i + 1), 9), po.getTotalprice()+"");
					setText(getCell(sheet, (i + 1), 10), po.getCommission()+"");
					setText(getCell(sheet, (i + 1), 11), po.getBonuspunish()+"");
				}
			}
		}
		
	}
	private void setCellValues2(HotelAccountResult totalAccount,HSSFSheet sheet2) {
		 DecimalFormat   fmt   =   new   DecimalFormat("#.00"); 
		if (totalAccount != null) {
			setText(getCell(sheet2, 0, 0), "总佣金");
			setText(getCell(sheet2, 0, 1), fmt.format(totalAccount.getTotalCommission()));
			
			setText(getCell(sheet2, 1, 0), "总预订间夜");
			setText(getCell(sheet2, 1, 1), totalAccount.getTotalOrderQuantityDay()+"");
			
			setText(getCell(sheet2, 2, 0), "入住间夜");
			setText(getCell(sheet2, 2, 1), totalAccount.getValidQuantityDay()+"");
			
			setText(getCell(sheet2, 4, 0), "奖惩金额");
			setText(getCell(sheet2, 4, 1), fmt.format(totalAccount.getRewardPunishAmount()));
			
			setText(getCell(sheet2, 5, 0), "实际佣金");
			setText(getCell(sheet2, 5, 1),fmt.format(totalAccount.getTotalRealCommission()));
			 fmt.applyPattern("0.00%");
			setText(getCell(sheet2, 3, 0), "有效间夜率");
			setText(getCell(sheet2, 3, 1), fmt.format(totalAccount.getValidQuantityDayRate()));
		}
	}

	private HSSFSheet setCellStype(HSSFWorkbook workbook, String sheetName) {
		HSSFSheet sheet = null;
		sheet = workbook.createSheet(sheetName);
		//添加单元格格式
		HSSFCellStyle cellStyle=workbook.createCellStyle();
		HSSFFont font=workbook.createFont();
		font.setFontHeightInPoints((short)10);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		cellStyle.setFont(font);
		cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		cellStyle.setFillForegroundColor(HSSFColor.LIGHT_ORANGE.index);
		cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		//默认列宽
		sheet.setDefaultColumnWidth(20);
		for(int i=0; i<9; i++){
			//居中排列
			getCell(sheet,0,i).getCellStyle().setAlignment(HSSFCellStyle.ALIGN_CENTER);
			//设置单元格格式
			getCell(sheet,0,i).setCellStyle(cellStyle);
		}
		sheet.setColumnWidth(0, 2500);
		return sheet;
	}
}
