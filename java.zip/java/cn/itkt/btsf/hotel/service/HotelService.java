package cn.itkt.btsf.hotel.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.itkt.btsf.hotel.localvo.HotelInfoVO;
import cn.itkt.btsf.hotel.localvo.HotelOrderInfoVO;
import cn.itkt.btsf.hotel.po.CommercialPO;
import cn.itkt.btsf.hotel.po.DistrictPO;
import cn.itkt.btsf.hotel.po.GuarantyInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountResult;
import cn.itkt.btsf.hotel.po.HotelInfoPO;
import cn.itkt.btsf.hotel.po.LandmarkPO;
import cn.itkt.btsf.hotel.po.OrderInfoPO;
import cn.itkt.btsf.hotel.vo.HotelCityInfoVo;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;


/**
 * @version 1.0
 * @author SunLing
 * @date 2012-10-29
 * @title 酒店业务模块业务逻辑处理接口
 */ 
public interface HotelService {
	/****
	 * 根据查询条件调用接口查询酒店信息
	 * @param hotelListQueryRequest
	 * @return
	 */
	public HotelQueryResultVO findHotelQueryResultVO(HotelListQueryRequest hotelListQueryRequest);
	/****
	 * 根据输入自动提示城市名称
	 * @param namePrefix
	 * @return
	 */
	public List<HotelCityInfoVo> findHotelCities(Map<String, Object> cityName);
	/****
	 * 查询订单详情
	 * @param orderId 订单Id
	 * @return
	 */
	public OrderInfoPO findOrderInfo(Long orderId);
	/****
	 * 查询订单酒店详情
	 * @param orderId 订单Id
	 * @return
	 */
	public HotelInfoPO findOrderHotelInfo(String  orderId);
	/****
	 * 查询订单担保详情
	 * @param orderId 订单Id
	 * @return
	 */
	public GuarantyInfoPO findOrderGuarantyInfo(String orderId);
	/**
	 * 查询酒店西信息
	 * @param hotelId
	 * @return
	 */
	public HotelInfoVO findHotelInfo(String hotelId);
	/**
	 * 模糊查询行政区
	 * @param queryMap
	 * @return
	 */
	public List<DistrictPO> findHotelDst(Map<String, Object> queryMap);
	/**
	 * 模糊查询商业区
	 * @param queryMap
	 * @return
	 */
	public List<CommercialPO> findHotelComm(Map<String, Object> queryMap);
	/**
	 * 查询标志物
	 * @param queryMap
	 * @return
	 */
	public List<LandmarkPO> findHotelLm(Map<String, Object> queryMap);
	/**
	 * 查询订单主键
	 * @param elongId
	 * @return
	 */
	public long findPrimaryIdByElongId(String elongId);
	/**
	 * 查询订单信息
	 * @param elongId
	 * @return
	 */
	public HotelOrderInfoVO findHotelInfoByElongId(String elongId);
	/**
	 * 更新订单会员信息
	 * @param orderInfo
	 */
	public void updateOrderUser(HotelOrderInfoVO orderInfo);
	/**
	 * 将订单状态改为已取消
	 * @param elongId
	 */
	public void cancelOrderStateByElongId(String elongId);
	/**
	 * 更新订单备注
	 * @param orderInfo
	 * @throws Exception 
	 */
	public void updateOrderRemark(HotelOrderInfoVO orderInfo) throws Exception;
	/**
	 * 查询标志物
	 * @param query
	 * @return
	 */
	public List<String> findLandMarkByHotelMark(Map<String, Object> query);
	/**
	 * 查询艺龙单号在数据库中的数量
	 * @param elongId
	 * @return
	 */
	public int countOrderByElongId(String elongId);
	/**
	 * 根据lcdOrderId 得到Id
	 * @param lcdOrderId
	 * @return
	 */
	public OrderInfoPO findIdByLcdId(String lcdOrderId);
	/**
	 * 查询结算
	 * @return
	 */
	public  Map<String, Object> findHotelJsonAccounts(Map<String, Object> queryMap);
	/**
	 * 查询结算
	 * @return
	 */
	public  List<HotelAccountInfoPO> findHotelAccounts(Map<String, Object> queryMap);
	
	/**
	 * 总间夜数，不属于结账状态，但elong有订单号
	 * @return
	 */
	public Integer findQuantityDaysTotal(Map<String, Object> queryMap);
	
	/**根据条件查询所有所有的订单
	 * @param sqlParamMap
	 * @return
	 */
	public List<HashMap<String, Object>> getHotelOrderList(HashMap<String, Object> sqlParamMap);
}
