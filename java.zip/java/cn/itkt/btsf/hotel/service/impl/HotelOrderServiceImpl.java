package cn.itkt.btsf.hotel.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.itkt.btsf.hotel.dao.HotelOrderDao;
import cn.itkt.btsf.hotel.service.HotelOrderService;

@Service
public class HotelOrderServiceImpl implements HotelOrderService{
	
	@Resource
	private HotelOrderDao hotelOrderDao;
	
	
	/* 
	 * 根据查询条件查询所有订单
	 */
	public List<HashMap<String, Object>> getHotelOrderList(HashMap<String, Object> sqlParamMap){
		
		return hotelOrderDao.getHotelOrderList(sqlParamMap);
	}


	@Override
	public int getHotelOrderCount(HashMap<String, Object> sqlParamMap) {
		
		return hotelOrderDao.getHotelOrderCount(sqlParamMap);
	}

}
