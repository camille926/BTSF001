package cn.itkt.btsf.hotel.service.impl;
/**
 * @version 1.0
 * @author SunLing
 * @date 2012-10-29
 * @title 酒店业务模块业务逻辑处理类
 */ 
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import cn.itkt.btsf.hotel.vo.HotelCityInfoVo;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.dao.HotelDao;
import cn.itkt.btsf.hotel.localvo.HotelInfoVO;
import cn.itkt.btsf.hotel.localvo.HotelOrderInfoVO;
import cn.itkt.btsf.hotel.po.CommercialPO;
import cn.itkt.btsf.hotel.po.DistrictPO;
import cn.itkt.btsf.hotel.po.GuarantyInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountResult;
import cn.itkt.btsf.hotel.po.HotelInfoPO;
import cn.itkt.btsf.hotel.po.LandmarkPO;
import cn.itkt.btsf.hotel.po.OrderInfoPO;
import cn.itkt.btsf.hotel.service.HotelService;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.hotel.webservice.HotelWebService;
import cn.itkt.btsf.util.LoginUtil;

@Service("hotelService_bak")
public class HotelServiceImpl implements HotelService {
	@Resource
	private HotelWebService hotelWebService;
	@Resource
	private HotelDao hotelDao;
	
	@Override
	public HotelQueryResultVO findHotelQueryResultVO(HotelListQueryRequest hotelListQueryRequest) {
		HotelQueryResultVO result = hotelWebService.findHotelQueryResultVO(hotelListQueryRequest);
		return result;
	}
	@Override
	public List<HotelCityInfoVo> findHotelCities(Map<String, Object> cityName) {
		return hotelDao.findHotelCities(cityName);
	}
	/**
	 * 查询酒店西信息
	 * @param hotelId
	 * @return
	 */
	public HotelInfoVO findHotelInfo(String hotelId){
		return hotelDao.findHotelInfo(hotelId);
	}
	@Override
	public OrderInfoPO findOrderInfo(Long orderId) {
		return hotelDao.findOrderInfo(orderId);
	}
//	@Override
//	public GuarantyInfoPO findOrderGuarantyInfo(Long orderId) {
//		return hotelDao.findOrderGuarantyInfo(orderId);
//	}
//	@Override
//	public HotelInfoPO findOrderHotelInfo(Long orderId) {
//		return hotelDao.findOrderHotelInfo(orderId);
//	}
	@Override
	public List<CommercialPO> findHotelComm(Map<String, Object> queryMap) {
		return hotelDao.findHotelComm(queryMap);
	}
	@Override
	public List<DistrictPO> findHotelDst(Map<String, Object> queryMap) {
		return hotelDao.findHotelDst(queryMap);
	}
	@Override
	public List<LandmarkPO> findHotelLm(Map<String, Object> queryMap) {
		return hotelDao.findHotelLm(queryMap);
	}
	/**
	 * 查询订单主键
	 * @param elongId
	 * @return
	 */
	public long findPrimaryIdByElongId(String elongId){
		return hotelDao.findPrimaryIdByElongId(elongId);
	}
	/**
	 * 查询订单信息
	 * @param elongId
	 * @return
	 */
	public HotelOrderInfoVO findHotelInfoByElongId(String elongId){
		return hotelDao.findHotelInfoByElongId(elongId);
	}
	/**
	 * 更新订单会员信息
	 * @param orderInfo
	 */
	public void updateOrderUser(HotelOrderInfoVO orderInfo){
		orderInfo.setLastOperator(LoginUtil.getLoginUser().getUsername());
		hotelDao.updateOrderUser(orderInfo);
	}
	/**
	 * 将订单状态改为已取消
	 * @param elongId
	 */
	public void cancelOrderStateByElongId(String elongId){
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("elongId", elongId);
		map.put("operator", LoginUtil.getLoginUser().getName());
		hotelDao.cancelOrderStateByElongId(map);
	}
	/**
	 * 更新订单备注
	 * @param orderInfo
	 */
	public void updateOrderRemark(HotelOrderInfoVO orderInfo){
		hotelDao.updateOrderRemark(orderInfo);
	}
	/**
	 * 查询标志物
	 * @param landMarkids
	 * @return
	 */
	public List<String> findLandMarkByHotelMark(Map<String, Object> query){
		return hotelDao.findLandMarkByHotelMark(query);
	}
	/**
	 * 查询艺龙单号在数据库中的数量
	 * @param elongId
	 * @return
	 */
	public int countOrderByElongId(String elongId){
		return hotelDao.countOrderByElongId(elongId);
	}
	@Override
	public OrderInfoPO findIdByLcdId(String lcdOrderId) {
		return hotelDao.findIdByLcdId(lcdOrderId);
	}
	@Override
	public List<HotelAccountInfoPO> findHotelAccounts(Map<String, Object> queryMap) {
		return hotelDao.newFindHotelAccounts(queryMap);
	}
//	@Override
//	public HotelAccountResult findHotelAccountsTotal(Map<String, Object> queryMap) {
//		return hotelDao.findHotelAccountsTotal(queryMap);
//	}
	@Override
	public Integer findQuantityDaysTotal(Map<String, Object> queryMap) {
		return hotelDao.findQuantityDaysTotal(queryMap);
	}
	@Override
	public Map<String, Object> findHotelJsonAccounts(Map<String, Object> queryMap) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<HashMap<String, Object>> getHotelOrderList(HashMap<String, Object> sqlParamMap) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public GuarantyInfoPO findOrderGuarantyInfo(String orderId) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public HotelInfoPO findOrderHotelInfo(String orderId) {
		// TODO Auto-generated method stub
		return null;
	}
}
