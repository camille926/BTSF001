package cn.itkt.btsf.hotel.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public interface HotelOrderService {

	/**根据条件查询所有所有的订单
	 * @param sqlParamMap
	 * @return
	 */
	public List<HashMap<String, Object>> getHotelOrderList(HashMap<String, Object> sqlParamMap);

	/**根据条件查询所有所有的订单count
	 * @param sqlParamMap
	 * @return
	 */
	public int getHotelOrderCount(HashMap<String, Object> sqlParamMap);

}
