package cn.itkt.btsf.hotel.webservice.impl;
/**
 * @version 1.0
 * @author SunLing
 * @date 2013-03-27
 * @title 查询酒店的数据库操作全改为接口
 */ 
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.annotation.Resource;

import org.mvel2.optimizers.impl.refl.nodes.ArrayLength;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.hotel.localvo.HotelInfoVO;
import cn.itkt.btsf.hotel.localvo.HotelOrderInfoVO;
import cn.itkt.btsf.hotel.po.CommercialPO;
import cn.itkt.btsf.hotel.po.DistrictPO;
import cn.itkt.btsf.hotel.po.GuarantyInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountInfoPO;
import cn.itkt.btsf.hotel.po.HotelInfoPO;
import cn.itkt.btsf.hotel.po.LandmarkPO;
import cn.itkt.btsf.hotel.po.OrderInfoPO;
import cn.itkt.btsf.hotel.service.HotelService;
import cn.itkt.btsf.hotel.vo.HotelCityInfoVo;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.hotel.webservice.HotelWebService;
import cn.itkt.btsf.hotel.webservice.util.TransferJsonToClass;
import cn.itkt.btsf.hotel.webservice.util.UnitopTerNotice;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.btsf.util.PropertyUtil;

@Service("hotelService")
public class HotelJsonWebServiceImpl implements HotelService{
	private  Logger log = LoggerFactory.getLogger(HotelJsonWebServiceImpl.class);
	@Resource
	private HotelWebService hotelWebService;
	private static String baseUrl= ""; //http://192.168.101.110:6060/RemoteService_Hotel/mvc";
	ResourceBundle bundleWebService = null;
	private static String terminalId="callcenter;callcenter:"+(cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
	public HotelJsonWebServiceImpl() {
		try {
			/**得到接口的地址**/
			bundleWebService = PropertyUtil.getWebServceiProperty();
			baseUrl = bundleWebService.getString("HOTELENDPOINT");
			if(!"".equals(baseUrl) && baseUrl != null){
				String[] urls = baseUrl.split("=");
				baseUrl = urls[1];
			}
//			System.out.println(baseUrl);
		} catch (Exception e) {
			log.error("------初始化酒店接口错误!----------" + e.getMessage());
		}
	}
	@Override
	public List<HotelCityInfoVo> findHotelCities(Map<String, Object> cityName) {
		String url = baseUrl+"/manager/position/getAllCitysInfo";
    	String param="terminalId="+terminalId;
		String result=UnitopTerNotice.requestHttp(url, param);
		return TransferJsonToClass.parseCity(result, cityName);
	}
	@Override
	public List<DistrictPO> findHotelDst(Map<String, Object> queryMap) {
		String url = baseUrl+"/manager/position/getDistrictsInfo";
    	String param="terminalId="+terminalId+"&"+"cityCode="+queryMap.get("cityCode");
		String result=UnitopTerNotice.requestHttp(url, param);
		return TransferJsonToClass.parseDst(result);
	}
	@Override
	public List<CommercialPO> findHotelComm(Map<String, Object> queryMap) {
		String url = baseUrl+"/manager/position/getCommercialsVo";
    	String param="terminalId="+terminalId+"&"+"cityCode="+queryMap.get("cityCode");
		String result=UnitopTerNotice.requestHttp(url, param);
		return TransferJsonToClass.parseComm(result);
	}
	@Override
	public Map<String, Object> findHotelJsonAccounts(Map<String, Object> queryMap) {
		String url = baseUrl+"/manager/order/orderAccount";
		String param="terminalId="+terminalId+"&"+"checkInTime="+queryMap.get("checkinDate")+"&checkOutTime="+queryMap.get("checkoutDate")+"&pageNumber=1&pageSize=30000";
		String result=UnitopTerNotice.requestHttp(url, param);
		return TransferJsonToClass.parseHotelAccount(result);
	}
	@Override
	public int countOrderByElongId(String elongId) {
		String url = baseUrl+"/manager/order/getOrderDetail";
		String param="terminalId="+terminalId+"&"+"orderId="+elongId;
		String result=UnitopTerNotice.requestHttp(url, param);
		return TransferJsonToClass.countOrder(result);
	}
	@Override
	public HotelInfoVO findHotelInfo(String hotelId) {
		String url = baseUrl+"/web/hotel/getHotel";
		String param="terminalId="+terminalId+"&"+"hotelId="+hotelId+"&checkInDate="+new java.sql.Date(System.currentTimeMillis())+"&checkOutDate="+new java.sql.Date(System.currentTimeMillis()+1*60*60*24*1000);
		String result=UnitopTerNotice.requestHttp(url, param);
		return TransferJsonToClass.parseHotelInfoVO(result);
	}
	@Override
	public void updateOrderRemark(HotelOrderInfoVO orderInfo) throws Exception{
		String url = baseUrl+"/web/order/updateOrder";
		String param="terminalId="+terminalId+"&id="+orderInfo.getLcdOrderId()+"&operator="+orderInfo.getLastOperator()+"&remark="+orderInfo.getRemark();
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
	}
	@Override
	public void updateOrderUser(HotelOrderInfoVO orderInfo) {
		String url = baseUrl+"/web/order/updateOrder";
		String param="terminalId="+terminalId+"&id="+orderInfo.getLcdOrderId()+"&userId="+orderInfo.getUserId()+"&userType="+orderInfo.getUserType()+"&operator="+LoginUtil.getLoginUser().getUsername();
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
	}
	@Override
	public HotelOrderInfoVO findHotelInfoByElongId(String elongId) {
		String url = baseUrl+"/manager/order/getOrderDetail";
		String param="terminalId="+terminalId+"&"+"orderId="+elongId;
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		HotelOrderInfoVO hotelOrder = TransferJsonToClass.parseHotelOrderInfoVO(result);
		HotelInfoVO hotelInfo = this.findHotelInfo(hotelOrder.getHotelCode());
		hotelOrder.setCategory(hotelInfo.getStar());
		hotelOrder.setPhone(hotelInfo.getPhone());
		hotelOrder.setHotelName(hotelInfo.getHotelName());
		hotelOrder.setHotelAddress(hotelInfo.getHotelAddress());
		return hotelOrder;
	}
	@Override
	public HotelQueryResultVO findHotelQueryResultVO(HotelListQueryRequest hotelListQueryRequest) {
		HotelQueryResultVO result = hotelWebService.findHotelQueryResultVO(hotelListQueryRequest);
		return result;
	}
	@Override
	public OrderInfoPO findIdByLcdId(String lcdOrderId) {
		String url = baseUrl+"/manager/order/getOrderDetail";
		String param="terminalId="+terminalId+"&"+"lcdOrderId="+lcdOrderId;
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonToClass.parseOrderInfoPO(result);
	}
	@Override
	public List<String> findLandMarkByHotelMark(Map<String, Object> query) {
		HotelInfoVO hotelInfo = this.findHotelInfo(query.get("hotelId")+"");
		String landMarks = hotelInfo.getLandMarkids();
		if(landMarks != null && !"".equals(landMarks)){
			landMarks = landMarks.substring(1, landMarks.length()-1);
			System.out.println(landMarks);
		}
		return null;
	}
	@Override
	public GuarantyInfoPO findOrderGuarantyInfo(String  orderId) {
		String url = baseUrl+"/manager/order/getOrderDetail";
		String param="terminalId="+terminalId+"&"+"orderId="+orderId;
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonToClass.parseGuarantyInfo(result);
	}
	@Override
	public HotelInfoPO findOrderHotelInfo(String orderId) {
		String url = baseUrl+"/manager/order/getOrderDetail";
		String param="terminalId="+terminalId+"&"+"lcdOrderId=" + orderId;
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonToClass.parseHotelInfoPO(result);
	}
	@Override
	public OrderInfoPO findOrderInfo(Long orderId) {
		String url = baseUrl+"/manager/order/getOrderDetail";
		String param="terminalId="+terminalId+"&"+"orderId="+orderId;
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonToClass.parseOrderInfoPO(result);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<HashMap<String, Object>> getHotelOrderList(HashMap<String, Object> queryMap) {
		String url = baseUrl+"/web/order/findAllOrder";
		
		List<Long> userIds = (List<Long>) queryMap.get("userIds");
		if(userIds != null && userIds.size()>0){
			List<HashMap<String, Object>> total = new ArrayList<HashMap<String,Object>>();
			for(Long userId : userIds){
				queryMap.put("userId", userId);
				String param=this.parseQueryMap(queryMap);
				String result=UnitopTerNotice.requestHttp(url, param);
				System.out.println(result);
				total.addAll((TransferJsonToClass.parseHotelOrderList(result)));
			}
			return total;
		}else{
			String param=this.parseQueryMap(queryMap);
			String result=UnitopTerNotice.requestHttp(url, param);
			System.out.println(result);
			return TransferJsonToClass.parseHotelOrderList(result);
		}
	}
	private String parseQueryMap(HashMap<String, Object> queryMap) {
		StringBuilder buff = new StringBuilder();
		buff.append("terminalId="+terminalId).append("&pageSize="+queryMap.get("pageSize"));;//
		if(queryMap != null && queryMap.size()>0){
			 System.out.println(queryMap.get("orderId"));
			if(!"".equalsIgnoreCase(queryMap.get("orderId")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("orderId")+"".trim())){
				buff.append("&orderId="+queryMap.get("orderId"));//
			}
			if(!"".equalsIgnoreCase(queryMap.get("lcdorderid")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("lcdorderid")+"".trim())){
				buff.append("&lcdOrderId="+queryMap.get("lcdorderid"));
			}
			if(!"".equalsIgnoreCase(queryMap.get("userType")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("userType")+"".trim())){
				buff.append("&userType=" + queryMap.get("userType"));
			}
			if(!"".equalsIgnoreCase((queryMap.get("userId")+"").trim()) && !"null".equalsIgnoreCase((queryMap.get("userId")+"").trim())){
				buff.append("&userId=" + queryMap.get("userId"));
			}
			if(!"".equalsIgnoreCase(queryMap.get("inDate")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("inDate")+"".trim())){
				Date date = (Date) queryMap.get("inDate");
				buff.append("&checkInBeginDate="+new java.sql.Date(date.getTime()));
			}
			if(!"".equalsIgnoreCase(queryMap.get("inDateLast")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("inDateLast")+"".trim())){
				Date date = (Date) queryMap.get("inDateLast");
				buff.append("&checkInEndDate="+new java.sql.Date(date.getTime()));
			}
			if(!"".equalsIgnoreCase(queryMap.get("outDate")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("outDate")+"".trim())){
				Date date = (Date) queryMap.get("outDate");
				buff.append("&checkOutBeginDate="+new java.sql.Date(date.getTime()));
			}
			if(!"".equalsIgnoreCase(queryMap.get("outDateLast")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("outDateLast")+"".trim())){
				Date date = (Date) queryMap.get("outDateLast");
				buff.append("&checkOutEndDate="+new java.sql.Date(date.getTime()));
			}
			if(!"".equalsIgnoreCase(queryMap.get("beforehandDate")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("beforehandDate")+"".trim())){
				Date date = (Date) queryMap.get("beforehandDate");
				buff.append("&createBeginDate="+new java.sql.Date(date.getTime()));
			}
			if(!"".equalsIgnoreCase(queryMap.get("beforehandDateLast")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("beforehandDateLast")+"".trim())){
				Date date = (Date) queryMap.get("beforehandDateLast");
				buff.append("&createEndDate="+new java.sql.Date(date.getTime()));
			}
			if(!"".equalsIgnoreCase(queryMap.get("contactName")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("contactName")+"".trim())){
				buff.append("&contactName="+queryMap.get("contactName"));
			}
			if(!"".equalsIgnoreCase(queryMap.get("phone")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("phone")+"".trim())){
				buff.append("&contactTell="+queryMap.get("phone"));
			}
			if(!"".equalsIgnoreCase(queryMap.get("guestName")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("guestName")+"".trim())){
				buff.append("&guestName="+queryMap.get("guestName"));
			}
			if(!"".equalsIgnoreCase(queryMap.get("sourceId")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("sourceId")+"".trim())){
				buff.append("&sourceFlag="+queryMap.get("sourceId"));
			}
			if(!"".equalsIgnoreCase(queryMap.get("lcdorderState")+"".trim()) && !"null".equalsIgnoreCase(queryMap.get("lcdorderState")+"".trim())){
				buff.append("&stateFlag="+queryMap.get("lcdorderState"));
			}
			if(!"".equalsIgnoreCase(queryMap.get("orderId1")+"".trim()) && !"Null".equalsIgnoreCase(queryMap.get("orderId1")+"".trim())){
				buff.append("&failFlag="+queryMap.get("orderId1"));
			}
			if(queryMap.get("startIndex") != null && Integer.valueOf(queryMap.get("startIndex")+"") >= 0){
				String startIndexStr = "1";
				int startIndex = new Integer(queryMap.get("startIndex")+"");
				if(startIndex>1){
					startIndexStr = String.valueOf(startIndex);
					startIndexStr = startIndexStr.substring(0, startIndexStr.length()-1);
				}else{
					startIndex = 1;
				}
				buff.append("&pageNumber=" + (startIndex>1?(Integer.parseInt(startIndexStr)+1):startIndex));
			}
		}
		return buff.toString();
	}
	@Override
	public long findPrimaryIdByElongId(String elongId) {
		// TODO Auto-generated method stub
		return 0;
	}
	public static void main(String[] args) {
		HotelService hws = new HotelJsonWebServiceImpl();
		hws.findHotelInfoByElongId("55451941");
		HashMap<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("contactName", "孙亮");
		hws.findHotelInfo("00101025");
//		OrderInfoPO orderInfo = hws.findIdByLcdId("HTL201304101007223281314");
//		System.out.println(orderInfo);
		//hws.findHotelInfoByElongId("54775798");
		//hws.getHotelOrderList(queryMap);
		//hws.findOrderHotelInfo(48387373l);
	}
	@Override
	public List<HotelAccountInfoPO> findHotelAccounts(Map<String, Object> queryMap) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	@Deprecated
	public void cancelOrderStateByElongId(String elongId) {
		
	}
	@Override
	@Deprecated
	public List<LandmarkPO> findHotelLm(Map<String, Object> queryMap) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	@Deprecated
	public Integer findQuantityDaysTotal(Map<String, Object> queryMap) {
		// TODO Auto-generated method stub
		return null;
	}
}
