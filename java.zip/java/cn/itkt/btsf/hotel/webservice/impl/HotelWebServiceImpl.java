package cn.itkt.btsf.hotel.webservice.impl;
/**
 * @version 1.0
 * @author SunLing
 * @date 2013-04-11
 * @title 酒店业务模块业务逻辑WebService调用接口处理类
 */ 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.hotel.vo.BaseVo;
import cn.itkt.btsf.hotel.vo.ContactVo;
import cn.itkt.btsf.hotel.vo.ContacterForSubmitHotelOrder;
import cn.itkt.btsf.hotel.vo.CreditCardForSubmitHotelOrder;
import cn.itkt.btsf.hotel.po.CreditCardVo;
import cn.itkt.btsf.hotel.vo.DayRateForHotel;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOneQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderStateResult;
import cn.itkt.btsf.hotel.vo.HotelOrderVo;
import cn.itkt.btsf.hotel.vo.HotelProductVouchRequest;
import cn.itkt.btsf.hotel.vo.HotelProductVouchVo;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.hotel.vo.OrderSubmitVo;
import cn.itkt.btsf.hotel.vo.RatePlanForHotel;
import cn.itkt.btsf.hotel.vo.RatePlanVo;
import cn.itkt.btsf.hotel.vo.RateVo;
import cn.itkt.btsf.hotel.vo.RoomReserveInfoVo;
import cn.itkt.btsf.hotel.vo.RoomReserveRequest;
import cn.itkt.btsf.hotel.vo.SubmitOrderRequest;
import cn.itkt.btsf.hotel.vo.VouchInfo;
import cn.itkt.btsf.hotel.vo.VouchVo;
import cn.itkt.btsf.hotel.webservice.HotelWebService;
import cn.itkt.btsf.hotel.webservice.util.HttpClientUtil;
import cn.itkt.btsf.hotel.webservice.util.TransferJsonBookToClass;
import cn.itkt.btsf.hotel.webservice.util.UnitopTerNotice;
import cn.itkt.btsf.util.LoginUtil;
import cn.itkt.btsf.util.PropertyUtil;

@Service("hotelWebService")
public class HotelWebServiceImpl implements HotelWebService{
	private  Logger log = LoggerFactory.getLogger(HotelWebServiceImpl.class);
	private static String baseUrl= "";//"http://192.168.101.110:6060/RemoteService_Hotel/mvc";
	private static String terminalId="callcenter;callcenter:"+(cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase();
	ResourceBundle bundleWebService = null;
	public HotelWebServiceImpl() {
		try {
			/**得到接口的地址**/
			bundleWebService = PropertyUtil.getWebServceiProperty();
			baseUrl = bundleWebService.getString("HOTELENDPOINT");
			if(!"".equals(baseUrl) && baseUrl != null){
				String[] urls = baseUrl.split("=");
				baseUrl = urls[1];
			}
//			System.out.println(baseUrl);
		} catch (Exception e) {
			log.error("------初始化酒店接口错误!----------" + e.getMessage());
		}
	}
	@Override
	public BaseVo cancelHotelOrderById(String orderId) {
		String url = baseUrl+"/web/order/cancelOrder";
		String param = "terminalId="+terminalId+"&orderId="+orderId;	
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonBookToClass.parseCancelHotelOrder(result);
	}

	@Override
	public HotelQueryResultVO findHotelQueryResultVO(HotelListQueryRequest re) {
		String url = baseUrl+"/web/hotel/findAllHotel";
    	String param="terminalId="+terminalId;
    	param += "&cityId=" + re.getCityId();
    	param += "&checkInDate=" + re.getCheckInDate();
    	param += "&checkOutDate="+ re.getCheckOutDate();
    	param += "&hotelName="+ re.getHotelChineseName();
			
    	param += "&districtId="+ re.getDistrictId();
    	param += "&commercialId="+ re.getCommercialLocationId();
    	param += "&minPrice="+ re.getLowestRate();
    	param += "&maxPrice="+ re.getHighestRate();
			
    	param += "&sort="+ re.getOrderByCode();
    	param += "&sortType="+ re.getOrderTypeCode();
    	param += "&star="+ re.getStarCode();
//		json.put("isEconomic"+ re.get);
    	param += "&pageNumber="+ re.getReqPageNum();
    	param += "&pageSize="+ 10;
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonBookToClass.parseHotelQueryResultVO(result);
	}

	@Override
	public HotelQueryResultVO findOneHotelQueryResultVO(HotelOneQueryRequest hotelListQueryRequest) {
		String url = baseUrl+"/web/hotel/getHotel";
		String param = "terminalId="+terminalId;
		param += "&hotelId=" + hotelListQueryRequest.getHotelId();
		param += "&checkInDate="+new java.sql.Date(System.currentTimeMillis())+"";
		param += "&checkOutDate="+ new java.sql.Date(System.currentTimeMillis()+1*60*60*24*1000);
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonBookToClass.parseOneHotelQueryResultVO(result); //标明查询间个酒店
	}

	@Override
	public HotelOrderVo getHotelOrderVo(HotelOrderRequest hotelOrderRequest) {
		String url = baseUrl+"/web/order/submitOrder";
		SubmitOrderRequest re = new SubmitOrderRequest();
		
		/**设置联系人**/
		List<ContactVo> contactors = new ArrayList<ContactVo>();
		ContacterForSubmitHotelOrder[] contacters = hotelOrderRequest.getContacter();
		for(int x=0; x<contacters.length; x++){
			ContactVo contact = new ContactVo();
			
			ContacterForSubmitHotelOrder contacter = contacters[x];
			contact.setCardNumber(contacter.getIdNumber());
			contact.setCardType(contacter.getIdTypeCode());
			contact.setEmail(contacter.getEmail());
			contact.setName(contacter.getName());
			contact.setSex(contacter.getGenderCode());
//			PhoneForSubmitHotelOrder tell = contacter.getPhone();
			contact.setTell(contacter.getMobile());
			contactors.add(contact);
		}
		re.setContactVos(contactors);
		
		/**设置信用卡**/
		CreditCardForSubmitHotelOrder creditCard = hotelOrderRequest.getCreditCard();
		if(creditCard != null){
			CreditCardVo creditCardVo = new CreditCardVo();
			creditCardVo.setBankCardNumber(creditCard.getNumber());
			creditCardVo.setBankId(creditCard.getBankId());
			creditCardVo.setBankName("");
			creditCardVo.setCardNumber(creditCard.getIdNumber());
			creditCardVo.setCardType(creditCard.getIdTypeCode());
			creditCardVo.setCcv2(creditCard.getVeryfyCode());
			creditCardVo.setValidityDate(creditCard.getValidDate());
			creditCardVo.setUserName(creditCard.getCardHolderName());
			re.setCreditCardVo(creditCardVo);
		}
		
		/**设置客户姓名**/
		String[] guestNames = hotelOrderRequest.getGuestNames();
		List<String> guestList = new ArrayList<String>();
		for(int i=0; i<guestNames.length; i++){
			guestList.add(guestNames[i]);
		}
		re.setGuestNames(guestList);
		/**设置房间**/
		RatePlanForHotel rph = hotelOrderRequest.getRatePlanForHotel();
		RatePlanVo ratePlanVo = new RatePlanVo();
		
		ratePlanVo.setAddValuesDesc(new ArrayList<String>());
		ratePlanVo.setAvgPrice(rph.getAveragePrice());
		ratePlanVo.setBookingRulesDesc(new ArrayList<String>());
		ratePlanVo.setCode(rph.getRatePlanCode());
		ratePlanVo.setDrrRulesDesc(new ArrayList<String>());
		ratePlanVo.setGuestType(rph.getGuestTypeCode());
		ratePlanVo.setId(rph.getRatePlanID());
		ratePlanVo.setLcdAvgMoney(0);
		ratePlanVo.setLcdMoney(0);
		ratePlanVo.setLcdMoneyDown(0);
		ratePlanVo.setLcdMoneyRate(0);
		ratePlanVo.setName(rph.getRatePlanName());
		ratePlanVo.setTotalPrice(rph.getTotalPrice());
		/**设置每天价格**/
		DayRateForHotel[] dayRates = rph.getEachDayRateList();
		if(dayRates != null && dayRates.length>0){
			List<RateVo> rateVos = new ArrayList<RateVo>();
			for(DayRateForHotel dateRate : dayRates){
				RateVo rateVo = new RateVo();
				rateVo.setAddBedRate(dateRate.getAddBedRate());
				rateVo.setCurrencyCode(dateRate.getCurrencyCode());
				rateVo.setDate(dateRate.getDate().getTime());
				rateVo.setMemberRate(dateRate.getMemberRate());
				rateVo.setRetailRate(dateRate.getMemberRate());
				rateVo.setStatus(dateRate.getInvStatusCode());
				rateVos.add(rateVo);
			}
			ratePlanVo.setRateVos(rateVos);
		}
		
		VouchInfo[] vouchInfos = rph.getVouchInfos();
		if(vouchInfos != null && vouchInfos.length>0){
			List<VouchVo> vouchVos = new ArrayList<VouchVo>();
			for(VouchInfo vouchInfo : vouchInfos){
				VouchVo vouchVo = new VouchVo();
				vouchVo.setDescription(vouchInfo.getDescription());
				vouchVo.setIsRoomAmountVouch(vouchInfo.getIsRoomAmountVouch());
				vouchVo.setIsTimeVouch(vouchInfo.getIsTimeVouch());
				vouchVo.setIsVouch(vouchInfo.getIsVouch());
				vouchVo.setNotVouchDescription(vouchInfo.getNotVouchDescription());
				vouchVo.setNotVouchTime(vouchInfo.getNotVouchTime());
				vouchVo.setRoomAmount(vouchInfo.getRoomAmount());
				vouchVo.setVouchDescription(vouchInfo.getVouchDescription());
				vouchVo.setVouchMoneyType(vouchInfo.getVouchMoneyType());
				vouchVo.setVouchTime(vouchInfo.getVouchTime());
				vouchVos.add(vouchVo);
			}
			ratePlanVo.setVouchVos(vouchVos);
		}
		
		re.setRatePlanVo(ratePlanVo);
		
		re.setArrivalEarlyTime(hotelOrderRequest.getArrivalEarlyTime());
		re.setArrivalLateTime(hotelOrderRequest.getArrivalLateTime());
		re.setCheckInDate(hotelOrderRequest.getCheckInDate());
		re.setCheckOutDate(hotelOrderRequest.getCheckOutDate());
		re.setHotelId(hotelOrderRequest.getHotelId());
		re.setNoteToHotel(hotelOrderRequest.getNoteToHotel());
		re.setOperator( LoginUtil.getLoginUser().getName());
		re.setRoomId(hotelOrderRequest.getRoomTypeId());
		re.setUserId(hotelOrderRequest.getUserId());
		re.setUserType(hotelOrderRequest.getUserType());
		re.setTerminalId(terminalId);
		re.setFlag(hotelOrderRequest.getFlag());
		OrderSubmitVo submitResult = HttpClientUtil.doFormPost(url, re, OrderSubmitVo.class);
		HotelOrderVo hotelOrderVo = null;
		if(submitResult != null){
			hotelOrderVo = new HotelOrderVo();
			hotelOrderVo.setHotelOrderId(Integer.valueOf(submitResult.getOrderId()));
			hotelOrderVo.setLcdOrderId(submitResult.getLcdOrderId());
			hotelOrderVo.setMessage(submitResult.getMessage());
			hotelOrderVo.setStatus(submitResult.getStatus());
		}
		return hotelOrderVo;
	}

	@Override
	public HotelProductVouchVo getHotelProductVouchVo(HotelProductVouchRequest orderVouchRequest) {
		String url = baseUrl+"/web/order/getVouchSimple";
		String param =	"terminalId" + terminalId;
		param += "&hotelId=" + orderVouchRequest.getHotelId();
		param += "&roomTypeId="+ orderVouchRequest.getRoomTypeId();
		param += "&ratePlanId="+ orderVouchRequest.getRatePlanId();
		param += "&arriveLaterTime="+ orderVouchRequest.getArriveLaterTime();
		param += "&checkInDate="+ orderVouchRequest.getCheckInDate();
		param += "&checkOutDate="+ orderVouchRequest.getCheckOutDate();
		param += "&roomNum="+ orderVouchRequest.getRoomNum();
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonBookToClass.parseHotelProductVouchVo(result); //标明查询间个酒店
	}

	@Override
	public RoomReserveInfoVo getRoomReserveInfoVo(RoomReserveRequest re) {
		String url = baseUrl+"/web/hotel/getRoomReserve";
		String param="terminalId="+terminalId;
		param +="&hotelId="+ re.getHotelId();
		param +="&roomId="+re.getRoomTypeID();
		param +="&checkInDate="+re.getStartDate();
		param +="&checkOutDate="+ re.getEndDate();
		String result=UnitopTerNotice.requestHttp(url,param);
		System.out.println(result);
		return TransferJsonBookToClass.parseRoomReserveNumber(result);
	}

	@Override
	public HotelOrderStateResult importOrderOrSynChroNized(String orderId, boolean isImport) {
		String url = "";
		String param = "terminalId="+terminalId;
		if(isImport){
			url = baseUrl+"/web/order/importOrder";
			param+="&orderIds="+ orderId;
			
		}else if(!"".equals(orderId) && Integer.valueOf(orderId)>0){
			url = baseUrl+"/web/order/synchronizeOrder";
			param+="&orderIds="+ orderId;
		}else{
			url = baseUrl+"/manager/order/synchronizeAllOrder";
		}
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);
		return TransferJsonBookToClass.parseImportOrSyn(result, isImport);
	}
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("55267135");
		System.out.println(Arrays.asList(list));
		HotelWebService hws = new HotelWebServiceImpl();
		hws.importOrderOrSynChroNized("54998888", false);
//		RoomReserveRequest reserveRequest = new RoomReserveRequest();
//		reserveRequest.setEndDate("2013-04-13");
//		reserveRequest.setStartDate("2013-04-13");
//		reserveRequest.setHotelId("00101025");
//		reserveRequest.setRoomTypeID("1017");
//		hws.getRoomReserveInfoVo(new RoomReserveRequest());
		/**房间剩余量**/
		//hws.getRoomReserveInfoVo(reserveRequest);
		/**测试取消订单**/
//		hws.cancelHotelOrderById("54998888");
		/**单酒店查询**/
		HotelOneQueryRequest hh = new HotelOneQueryRequest();
		hh.setCheckInDate("2013-04-11");
		hh.setCheckOutDate("2013-04-13");
		hh.setHotelId("50101002");
		HotelQueryResultVO one = hws.findOneHotelQueryResultVO(hh);
		//System.out.println(one);
		/**多酒店查询**/
//		HotelQueryResultVO result = hws.findHotelQueryResultVO(null);
//		System.out.println(result);
	}
}
