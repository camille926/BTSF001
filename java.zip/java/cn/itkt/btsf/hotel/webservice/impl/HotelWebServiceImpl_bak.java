package cn.itkt.btsf.hotel.webservice.impl;
/**
 * @version 1.0
 * @author SunLing
 * @date 2012-10-30
 * @title 酒店业务模块业务逻辑WebService调用接口处理类
 */ 
import java.net.URL;
import java.util.ResourceBundle;

import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;

import org.apache.axis.AxisFault;
import org.apache.axis.client.Call;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import cn.itkt.btsf.hotel.vo.BaseVo;
import cn.itkt.btsf.hotel.vo.ELONGWEBHOTELSERVICESoapBindingStub;
import cn.itkt.btsf.hotel.vo.ElongWebHotelService;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOneQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderStateResult;
import cn.itkt.btsf.hotel.vo.HotelOrderVo;
import cn.itkt.btsf.hotel.vo.HotelProductVouchRequest;
import cn.itkt.btsf.hotel.vo.HotelProductVouchVo;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.hotel.vo.RoomReserveInfoVo;
import cn.itkt.btsf.hotel.vo.RoomReserveRequest;
import cn.itkt.btsf.hotel.webservice.HotelWebService;
import cn.itkt.btsf.sys.common.constant.WebServiceConstant;
import cn.itkt.btsf.util.PropertyUtil;

@Service("hotelWebService_bak")
public class HotelWebServiceImpl_bak implements HotelWebService{

	private  Logger log = LoggerFactory.getLogger(HotelWebServiceImpl_bak.class);
	private  org.apache.axis.client.Service service = null;
	ResourceBundle bundleWebService = null;
	private  Call call = null;			//CALL
	private  String HOTELENDPOINT = ""; //终端接口地址
	private  QName QNAME = null;		//命名空间
	URL url = null;						//封装后的终端接口地址
	ElongWebHotelService soap = null;
	public HotelWebServiceImpl_bak() {
//		try {
//			/**得到接口的地址**/
//			bundleWebService = PropertyUtil.getWebServceiProperty();
//			HOTELENDPOINT = bundleWebService.getString("HOTELENDPOINT");
//			url = new URL(HOTELENDPOINT);
//		} catch (Exception e) {
//			log.error("------初始化酒店接口错误!----------" + e.getMessage());
//		}
	}
	@Override
	public HotelQueryResultVO findHotelQueryResultVO(HotelListQueryRequest hotelListQueryRequest) {
		String endpoint=WebServiceConstant.getHotelEndPoint();
		URL url;
		HotelQueryResultVO result = null; 
		ElongWebHotelService soap=null;
	    try {
			url = new URL(endpoint);
			javax.xml.rpc.Service service = new org.apache.axis.client.Service();
			soap = new ELONGWEBHOTELSERVICESoapBindingStub(url, service);
			result= soap.findHotelQueryResultVO(hotelListQueryRequest);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
//		HotelQueryResultVO result = null;
//		String operation = "findHotelQueryResultVO";
//		QNAME = new QName("HotelQueryResultVO","com.itkt.mtravel.hotel.vo.HotelQueryResultVO");
//		/**创建service**/
//		service = new org.apache.axis.client.Service();
//		/**创建连接**/
//		try {
//			call = (Call) service.createCall(); 
//			/**设置连接的URL**/
//			call.setTargetEndpointAddress(new URL(HOTELENDPOINT));   
//		    call.setOperationName(new QName("http://controller.hotel.mtravel.itkt.com/",operation));   
//		    call.setReturnType(QNAME, HotelQueryResultVO.class);
//            call.addParameter("arg0", QNAME, ParameterMode.IN);
//            result = (HotelQueryResultVO) call.invoke(new Object[] { hotelListQueryRequest});    
//		} catch (Exception e) {
//			log.error("查询酒店错误!" + e.getMessage());
//			e.printStackTrace();
//		}
//		return result;
	
	}
	@Override
	public HotelQueryResultVO findOneHotelQueryResultVO(HotelOneQueryRequest hotelListQueryRequest) {
		HotelQueryResultVO result = null;
		String endpoint=WebServiceConstant.getHotelEndPoint();
		URL url;
		ElongWebHotelService soap=null;
	    try {
			url = new URL(endpoint);
			javax.xml.rpc.Service service = new org.apache.axis.client.Service();
			soap = new ELONGWEBHOTELSERVICESoapBindingStub(url, service);
			result= soap.findOneHotelQueryResultVO(hotelListQueryRequest);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
//		String operation = "findOneHotelQueryResultVO";
//		QNAME = new QName("HotelQueryResultVO","com.itkt.mtravel.hotel.vo.HotelQueryResultVO");
//		/**创建service**/
//		service = new org.apache.axis.client.Service();
//		/**创建连接**/
//		try {
//			call = (Call) service.createCall(); 
//			/**设置连接的URL**/
//			call.setTargetEndpointAddress(new URL(HOTELENDPOINT));   
//		    call.setOperationName(new QName("HotelQueryResultVO",operation));   
//		    call.setReturnType(QNAME, HotelQueryResultVO.class);
//            call.addParameter("arg0", QNAME, ParameterMode.IN);
//            result = (HotelQueryResultVO) call.invoke(new Object[] { hotelListQueryRequest});    
//		} catch (Exception e) {
//			log.error("查询酒店错误!" + e.getMessage());
//			e.printStackTrace();
//		}
//		return result;
	}

	@Override
	public RoomReserveInfoVo getRoomReserveInfoVo(RoomReserveRequest reserveRequest) {
		RoomReserveInfoVo result = null;
		String endpoint=WebServiceConstant.getHotelEndPoint();
		URL url;
		ElongWebHotelService soap=null;
	    try {
			url = new URL(endpoint);
			javax.xml.rpc.Service service = new org.apache.axis.client.Service();
			soap = new ELONGWEBHOTELSERVICESoapBindingStub(url, service);
			result= soap.getRoomReserveInfoVo(reserveRequest);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
//		String operation = "getRoomReserveInfoVo";
//		QNAME = new QName("RoomReserveRequest","com.itkt.mtravel.hotel.vo.request.RoomReserveRequest");
//		try {
//			/**创建service**/
//			service = new org.apache.axis.client.Service();
//			/**创建连接**/
//			call = (Call) service.createCall(); 
//			/**设置连接的URL**/
//	        call.setTargetEndpointAddress(new URL(HOTELENDPOINT));   
//		    call.setOperationName(new QName("RoomReserveRequest",operation));   
//		    call.setReturnType(QNAME, RoomReserveInfoVo.class);
//            call.addParameter("arg0", QNAME, ParameterMode.IN);
//            result = (RoomReserveInfoVo) call.invoke(new Object[] { reserveRequest});    
//		} catch (Exception e) {
//			log.error("查询酒店房间错误!" + e.getMessage());
//			e.printStackTrace();
//		}
//		return result;
	}
	@Override
	public HotelOrderVo getHotelOrderVo(HotelOrderRequest hotelOrderRequest) {
		
		HotelOrderVo result = null;
		String endpoint=WebServiceConstant.getHotelEndPoint();
		URL url;
		ElongWebHotelService soap=null;
	    try {
			url = new URL(endpoint);
			javax.xml.rpc.Service service = new org.apache.axis.client.Service();
			soap = new ELONGWEBHOTELSERVICESoapBindingStub(url, service);
			result= soap.getHotelOrderVo(hotelOrderRequest);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
//		String operation = "getHotelOrderVo";
//		QNAME = new QName("HotelOrderVo","com.itkt.mtravel.hotel.vo.HotelOrderVo");
//		try {
//			/**创建service**/
//			service = new org.apache.axis.client.Service();
//			/**创建连接**/
//			call = (Call) service.createCall(); 
//			/**设置连接的URL**/
//			call.setTargetEndpointAddress(new URL(HOTELENDPOINT));   
//			call.setOperationName(new QName("HotelOrderVo",operation));   
//			call.setReturnType(QNAME, HotelOrderVo.class);
//			call.addParameter("arg0", QNAME, ParameterMode.IN);
//			result = (HotelOrderVo) call.invoke(new Object[] { hotelOrderRequest});    
//		} catch (Exception e) {
//			log.error("提交酒店订单信息错误!" + e.getMessage());
//			e.printStackTrace();
//		}
//		return result;
		
	}
	@Override
	public HotelProductVouchVo getHotelProductVouchVo(HotelProductVouchRequest orderVouchRequest) {

		HotelProductVouchVo result = null;
		String endpoint=WebServiceConstant.getHotelEndPoint();
		URL url;
		ElongWebHotelService soap=null;
	    try {
			url = new URL(endpoint);
			javax.xml.rpc.Service service = new org.apache.axis.client.Service();
			soap = new ELONGWEBHOTELSERVICESoapBindingStub(url, service);
			result= soap.getHotelProductVouchVo(orderVouchRequest);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return result;
//		String operation = "getHotelProductVouchVo";
//		QNAME = new QName("HotelProductVouchVo","com.itkt.mtravel.hotel.vo.HotelProductVouchVo");
//		try {
//			/**创建service**/
//			service = new org.apache.axis.client.Service();
//			/**创建连接**/
//			call = (Call) service.createCall(); 
//			/**设置连接的URL**/
//	        call.setTargetEndpointAddress(new URL(HOTELENDPOINT));   
//		    call.setOperationName(new QName("HotelProductVouchVo",operation));   
//		    call.setReturnType(QNAME, HotelProductVouchVo.class);
//            call.addParameter("arg0", QNAME, ParameterMode.IN);
//            result = (HotelProductVouchVo) call.invoke(new Object[] { orderVouchRequest});    
//		} catch (Exception e) {
//			log.error("获取信用卡担保信息错误!" + e.getMessage());
//			e.printStackTrace();
//		}
//		return result;
	}
	@Override
	public HotelOrderStateResult importOrderOrSynChroNized(String orderId,boolean isImport) {
		String endpoint=WebServiceConstant.getHotelEndPoint();
		URL url;
		HotelOrderStateResult hotel=null;	
		ElongWebHotelService soap=null;
			    try {
					url = new URL(endpoint);

					javax.xml.rpc.Service service = new org.apache.axis.client.Service();

					 soap = new ELONGWEBHOTELSERVICESoapBindingStub(
							url, service);
					  
					 
					 hotel= soap.importOrderOrSynChroNized("callcenter", orderId, isImport);
					 
					
					 
					 
				} catch (AxisFault e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				return hotel;
				 
				
				
				
	}
	@Override
	public BaseVo cancelHotelOrderById(String orderId) {
		String endpoint=WebServiceConstant.getHotelEndPoint();
		URL url;
		BaseVo  hotel=null;	
		ElongWebHotelService soap=null;
			    try {
					url = new URL(endpoint);

					javax.xml.rpc.Service service = new org.apache.axis.client.Service();

					 soap = new ELONGWEBHOTELSERVICESoapBindingStub(
							url, service);
					  
					 
					 hotel= soap.cancelHotelOrderById("callcenter", orderId, "");
					 
					
					 
					 
				} catch (AxisFault e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return hotel;
	}
}
