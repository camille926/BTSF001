package cn.itkt.btsf.hotel.webservice;
import cn.itkt.btsf.hotel.vo.BaseVo;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOneQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderRequest;
import cn.itkt.btsf.hotel.vo.HotelOrderStateResult;
import cn.itkt.btsf.hotel.vo.HotelOrderVo;
import cn.itkt.btsf.hotel.vo.HotelProductVouchRequest;
import cn.itkt.btsf.hotel.vo.HotelProductVouchVo;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.hotel.vo.RoomReserveInfoVo;
import cn.itkt.btsf.hotel.vo.RoomReserveRequest;

public interface HotelWebService {
	/****
	 * 根据查询条件，调用elong接口进行酒店信息查询
	 * @param hotelListQueryRequest 查询条件
	 * @return 查询结果
	 */
	public  HotelQueryResultVO findHotelQueryResultVO(HotelListQueryRequest hotelListQueryRequest);
	/****
	 * 进入填写预订酒店房间信息页面
	 * @param reserveRequest 封装的参数
	 * @return 房间
	 */
	public RoomReserveInfoVo getRoomReserveInfoVo(RoomReserveRequest reserveRequest);
	/****
	 * 获取提交酒店订单信息
	 * @param hotelOrderRequest酒店订单信息
	 * @return
	 */
	public HotelOrderVo getHotelOrderVo(HotelOrderRequest hotelOrderRequest);
	/****
	 * 判断是否需要担保
	 * @param orderVouchRequest
	 * @return
	 */
	public HotelProductVouchVo getHotelProductVouchVo(HotelProductVouchRequest orderVouchRequest);
	/****
	 * 判断是否需要担保
	 * @param orderVouchRequest
	 * @return
	 */
	public HotelOrderStateResult importOrderOrSynChroNized(String orderId,boolean isImport);
	/****
	 * 取消订单
	 * @param orderId
	 * @return
	 */
	public BaseVo cancelHotelOrderById(String orderId);
	/****
	 * 查询一个酒店，内含一个房间
	 * @param hotelListQueryRequest
	 * @return
	 */
	public HotelQueryResultVO findOneHotelQueryResultVO(HotelOneQueryRequest hotelListQueryRequest);

}
