package cn.itkt.btsf.hotel.webservice.util;

import org.junit.Test;

/**
 * 类: PhoneControllerTest <br>
 * 描述: TODO <br>
 * 作者: 李永刚 liyg@itkt.com <br>
 * 时间: 2013-1-24 下午01:32:06
 */
public class PositionControllerTest {
   
	private static String baseUrl="http://t-hotel.itkt.com.cn:6060/RemoteService_Hotel";
	/**
	 * 方法: testgetcityinfo <br>
	 * 描述: 获取城市信息 <br>
	 * 作者: 李永刚 liyg@itkt.com <br>
	 * 时间: 2013-3-8 下午05:56:01
	 * @throws Exception
	 */
	@Test
    public void testgetcityinfo() throws Exception
	{
    	String url = baseUrl+"/mvc/mobile/ehotel/updateHotelCityList";
    	String termi="phone001;1:36E96BA1C914A0120424127E9C48D075";
    	String param="terminalId="+termi;
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);      //打印xml字符串。
	    
	}
	/**
	 * 方法: testfilterHotel <br>
	 * 描述: 获取筛选条件 <br>
	 * 作者: 李永刚 liyg@itkt.com <br>
	 * 时间: 2013-3-8 下午05:56:24
	 * @throws Exception
	 */
	@Test
    public void testfilterHotel() throws Exception
	{
    	String url = baseUrl+"/mvc/mobile/ehotel/filterHotel";
    	String termi="phone001;1:36E96BA1C914A0120424127E9C48D075";
    	String param="terminalId="+termi+"&cityCode=0101";
		String result=UnitopTerNotice.requestHttp(url, param);
		System.out.println(result);      //打印xml字符串。

	}
	public static void main(String[] args) {
		PositionControllerTest pt = new PositionControllerTest();
		try {
			pt.testgetcityinfo();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
