package cn.itkt.btsf.hotel.webservice.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import cn.itkt.btsf.hotel.localvo.HotelInfoVO;
import cn.itkt.btsf.hotel.localvo.HotelOrderInfoVO;
import cn.itkt.btsf.hotel.po.CommercialPO;
import cn.itkt.btsf.hotel.po.DistrictPO;
import cn.itkt.btsf.hotel.po.GuarantyInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountResult;
import cn.itkt.btsf.hotel.po.HotelInfoPO;
import cn.itkt.btsf.hotel.po.OrderInfoPO;
import cn.itkt.btsf.hotel.vo.HotelCityInfoVo;

public class TransferJsonToClass {
	/**
	 * 将json格式的转成DistrictPO
	 * @param json
	 * @return
	 */
	public static List<DistrictPO> parseDst(String json){
		DistrictPO dstPO = null;
		List<DistrictPO> dsts = new ArrayList<DistrictPO>();
		try {
			JSONObject jsons = new JSONObject(json);
			JSONArray jArray = jsons.getJSONArray("districtVos");
			//id districtId name cityId
			for(int i =0; i<jArray.length(); i++){
				JSONObject obj = jArray.getJSONObject(i);
				dstPO = new DistrictPO();
				dstPO.setId(Long.valueOf(obj.get("id").toString()));
				dstPO.setCityCode(obj.get("cityId")+"");
				dstPO.setDistrictCode(obj.get("districtId")+"");
				dstPO.setDistrictName(obj.get("name")+"");
				dsts.add(dstPO);
			}
			//System.out.println(jArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return dsts;
	}
	/**
	 * 将json格式的转成CommercialPO
	 * @param json
	 * @return
	 */
	public static List<CommercialPO> parseComm(String json) {

		CommercialPO commPO = null;
		List<CommercialPO> dsts = new ArrayList<CommercialPO>();
		try {
			JSONObject jsons = new JSONObject(json);
			JSONArray jArray = jsons.getJSONArray("commercialVos");
			for(int i =0; i<jArray.length(); i++){
				JSONObject obj = jArray.getJSONObject(i);
				commPO = new CommercialPO();
				commPO.setId(Long.valueOf(obj.get("id").toString()));
				commPO.setCityCode(obj.get("cityId")+"");
				commPO.setCommercialCode(obj.get("commercialId")+"");
				commPO.setDistrictNameCommercialName(obj.get("name")+"");
				dsts.add(commPO);
			}
			//System.out.println(jArray);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return dsts;
	}
	/**
	 * 将json格式的转成HotelCityInfoVo
	 * @param result
	 * @return
	 */
	public static List<HotelCityInfoVo> parseCity(String json, Map<String, Object> cityName) {
		String cname = (cityName.get("cityName")+"").toLowerCase();
		HotelCityInfoVo hotel = null;
		List<HotelCityInfoVo> hotels = new ArrayList<HotelCityInfoVo>();
		try {
			JSONObject jsons = new JSONObject(json);
			if(jsons != null){
				JSONArray jArray = jsons.getJSONArray("cityVos");
				for(int i =0; i<jArray.length(); i++){
					JSONObject obj = jArray.getJSONObject(i);
					String firstLetter = obj.get("firstLetter")+"";
					String letter = obj.get("letter")+"";
					String name = obj.get("name")+"";
					if(firstLetter.contains(cname) || letter.contains(cname) || name.contains(cname)){
						hotel = new HotelCityInfoVo();
						hotel.setCityCode(obj.get("id")+"");
						hotel.setCityName(name);
						hotel.setCityPinyin(letter);
						hotel.setCityPyfw(firstLetter);
						hotels.add(hotel);
					}
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return hotels;
	}
	public static Map<String, Object> parseHotelAccount(String json) {
		Map<String, Object>  map = new HashMap<String, Object>();
		try {
			/**查询结果数据**/
			JSONObject jsons = new JSONObject(json);
			if(jsons != null){
				HotelAccountResult totalAccount = getTotalAccount(jsons);
				map.put("totalAccount", totalAccount);
				List<HotelAccountInfoPO> hotelAccounts = getHotelAccounts(jsons);
				map.put("hotelAccounts", hotelAccounts);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return map;
	}
	public static HotelInfoVO parseHotelInfoVO(String json) {
		HotelInfoVO hotelInfoVO = new HotelInfoVO();
		try {
			JSONObject jsons = new JSONObject(json);
			System.out.println(json);
			hotelInfoVO = getHotelInfoVO(hotelInfoVO, jsons);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hotelInfoVO;
	}
	public static HotelOrderInfoVO parseHotelOrderInfoVO(String json) {
		HotelOrderInfoVO hotelOrderInfoVO = new HotelOrderInfoVO();
		/**查询结果数据**/
		try {
			JSONObject jsons = new JSONObject(json);
			
			hotelOrderInfoVO.setOrderId(jsons.get("orderId")+"");
			hotelOrderInfoVO.setLcdOrderId(jsons.get("lcdOrderId")+"");
			hotelOrderInfoVO.setCreateTime(new java.sql.Date(jsons.getLong("createTime")));
			hotelOrderInfoVO.setNoteToElong(jsons.getString("noteToElong")); 
			hotelOrderInfoVO.setOrderState(jsons.getString("status"));
			
			
			hotelOrderInfoVO.setQuantity(jsons.getInt("roomTotalCount"));
			hotelOrderInfoVO.setRemark(jsons.getString("remark"));
			hotelOrderInfoVO.setLastOperator(jsons.getString("operator"));
			
			hotelOrderInfoVO.setUserId(jsons.getString("userId").equalsIgnoreCase("null")?0l:jsons.getLong("userId"));
			
			hotelOrderInfoVO.setUserType(jsons.getString("userType"));
			hotelOrderInfoVO.setLcdOrderState(jsons.getString("lcdStatus"));
			hotelOrderInfoVO.setOrderSource(jsons.getString("source"));
			/**解析订单详情信息**/
			JSONObject obj = jsons.getJSONObject("orderDetailVo");
			hotelOrderInfoVO.setRoomName(obj.getString("roomName"));
			hotelOrderInfoVO.setTotalPrice(obj.getDouble("totalPrice"));
			
			hotelOrderInfoVO.setCheckInDate(new java.sql.Date(obj.getLong("checkInTime"))+"");
			hotelOrderInfoVO.setCheckOutDate(new java.sql.Date(obj.getLong("checkOutTime"))+"");
			hotelOrderInfoVO.setArriveEarlyTime(new java.sql.Date(obj.getLong("arriveEarlyTime"))+"");
			hotelOrderInfoVO.setArriveLateTime(new java.sql.Date(obj.getLong("arriveLateTime"))+"");
			
			hotelOrderInfoVO.setGuestName(obj.getString("guestName"));
			hotelOrderInfoVO.setContactName(obj.getString("contactName"));
			hotelOrderInfoVO.setContactPhone(obj.getString("contactTell"));
			hotelOrderInfoVO.setHotelCode(obj.getString("hotelId"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hotelOrderInfoVO;
	}
	public static int countOrder(String json) {
		JSONObject jsons = null;
		try {
			jsons = new JSONObject(json);
			String orderId = jsons.getString("orderId");
			if(orderId != null && !"null".equals(orderId)){
				return 1;
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public static OrderInfoPO parseOrderInfoPO(String json) {
		JSONObject jsons = null;
		OrderInfoPO orderInfoPO = null;
		try {
			jsons = new JSONObject(json);
			orderInfoPO = new OrderInfoPO();
			orderInfoPO.setOrderid(jsons.getString("orderId"));
			orderInfoPO.setCreatetime(new Date(jsons.getLong("createTime")));
			orderInfoPO.setLcdorderid(jsons.getString("lcdOrderId"));
			
			orderInfoPO.setOrdermessage(jsons.getString("failReason"));
			orderInfoPO.setOrdersource(jsons.getString("source"));
			orderInfoPO.setOrderstate(jsons.getString("status"));
			
			orderInfoPO.setPayment(jsons.getString("payment"));
			if(!jsons.getString("userId").equals("null")){
				orderInfoPO.setUserid(jsons.getLong("userId"));
			}
			if(!jsons.getString("userType").equals("null")){
				orderInfoPO.setUsertype(jsons.getString("userType"));
			}
			orderInfoPO.setOperatetime(new Date(jsons.getLong("modifyTime")));
			
			JSONObject obj = jsons.getJSONObject("orderDetailVo");
			
			orderInfoPO.setArriveearlytime(new java.sql.Date(obj.getLong("arriveEarlyTime"))+"");
			orderInfoPO.setArrivelatetime(new java.sql.Date(obj.getLong("arriveLateTime"))+"");
			orderInfoPO.setCheckindate(new java.sql.Date(obj.getLong("checkInTime"))+"");
			orderInfoPO.setCheckoutdate(new java.sql.Date(obj.getLong("checkOutTime"))+"");
			
			orderInfoPO.setContactname(obj.getString("contactName"));
			orderInfoPO.setContactphone(obj.getString("contactTell"));
			orderInfoPO.setEmail(obj.getString("contactEmail"));
			orderInfoPO.setGuestname(obj.getString("guestName"));
			orderInfoPO.setGuesttype(obj.getString("guestType"));
			//orderInfoPO.setIsoperate(isoperate)
			orderInfoPO.setLcdreturnfee(obj.getInt("lcdMoney"));
			orderInfoPO.setTerminalid("callcenter;callcenter:"+(cn.itkt.util.MD5Util.getMD5Message("callcenter;callcentercallcenter")).toUpperCase());
			orderInfoPO.setTotalprice(Float.valueOf(obj.getString("totalPrice")));
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return orderInfoPO;
	}
	public static GuarantyInfoPO parseGuarantyInfo(String json) {
		GuarantyInfoPO po = new GuarantyInfoPO();
		try {
			JSONObject jsons = new JSONObject(json);
//			JSONObject obj = jsons.getJSONObject("orderDetailVo");
//			po.setBankname(bankname);
//			po.setCvv2(cvv2)
			if(!jsons.getString("validityDate").equals("null")){
				po.setValiddate(jsons.getString(new Date(jsons.getLong("validityDate"))+""));
			}
			po.setCardnum(jsons.getString("bankCardNumber"));
//			po.setGuaranteetype(obj.getString("vouchType"));
			po.setIdnumber(jsons.getString("cardNumber"));
			po.setIdtypecode(jsons.getString("cardType"));
			po.setOwnername(jsons.getString("cardHolderName"));
//			po.setVauchmoney(obj.getDouble("vouchPrice"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return po;
	}
	public static HotelInfoPO parseHotelInfoPO(String json) {
		HotelInfoPO po = null;
		try {
			po = new HotelInfoPO();
			JSONObject jsons = new JSONObject(json);
			JSONObject obj = jsons.getJSONObject("orderDetailVo");
//			JSONArray array = obj.getJSONArray("rateVos");
//			JSONObject rateVo = array.getJSONObject(0);
			
			//po.setBedtype(bedtype)
			po.setBrandname(obj.getString("brandName"));
			po.setCityname(jsons.getString("cityName"));
			//po.setFirstdayprice(Float.valueOf(rateVo.getString("memberRate")));
			po.setGuarantee(obj.getString("bookingRulesDesc"));
			po.setHotelcode(obj.getString("hotelId"));
			po.setNotetoelong(jsons.getString("noteToElong"));
			po.setQuantity(obj.getInt("roomCount"));
			po.setRateplanid(obj.getString("ratePlanId"));

			po.setRateplanname(obj.getString("ratePlanName"));
			po.setRoomname(obj.getString("roomName"));
			po.setRoomtypeid(obj.getString("roomId"));
			po.setHotelname(obj.getString("hotelName"));
			po.setHoteladdress(obj.getString("hotelAddress"));
//			Map<String, String> map = findHotelInfo(obj.getString("hotelId"));
//			po.setStar(map.get("star"));
//			po.setHotelname(map.get("name"));
//			po.setHoteladdress(map.get("address"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return po;
	}
	public static List<HashMap<String, Object>> parseHotelOrderList(String json) {
		List<HashMap<String, Object>> orderList = null;
		HashMap<String, Object> map = null;
		try {
			orderList = new ArrayList<HashMap<String,Object>>();
			JSONObject jsons = new JSONObject(json);
			int totalCount = jsons.getInt("orderCount");
			JSONArray jsonArray = jsons.getJSONArray("orderVos");
			for(int i=0; i<jsonArray.length(); i++){
				map = new HashMap<String, Object>();
				JSONObject order = jsonArray.getJSONObject(i);
				JSONObject orderDetailVo = order.getJSONObject("orderDetailVo");
				map.put("LCDORDERID", order.getString("lcdOrderId"));
				map.put("ORDERID", order.getString("orderId"));
				map.put("CREATETIME", new java.sql.Date(order.getLong("createTime")));
				map.put("CHECKINDATE", new java.sql.Date(orderDetailVo.getLong("checkInTime")));
				
				map.put("CHECKOUTDATE", new java.sql.Date(orderDetailVo.getLong("checkOutTime")));
				map.put("GUESTNAME", orderDetailVo.getString("guestName"));
				map.put("HOTELNAME", orderDetailVo.getString("hotelName"));
				map.put("ROOMNAME", orderDetailVo.getString("roomName"));
				
				map.put("QUANTITY", orderDetailVo.getInt("roomCount"));
				map.put("TOTALPRICE", orderDetailVo.getDouble("totalPrice"));
				map.put("ORDERSTATE", order.getString("status"));
				map.put("USERTYPE", order.getString("userType"));
				
				map.put("ORDERSOURCE", order.getString("source"));
				map.put("totalCount", totalCount);
				orderList.add(map);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return orderList;
	}
	private static HotelInfoVO getHotelInfoVO(HotelInfoVO hotelInfoVO, JSONObject jsons) {
		try {
			hotelInfoVO.setAvailpolicy(jsons.getString("availpolicy"));
			hotelInfoVO.setCityId(jsons.getString("cityId"));
			hotelInfoVO.setDescription(jsons.getString("description"));
			
			hotelInfoVO.setDiningamenities(jsons.getString("diningOverview"));
			hotelInfoVO.setGeneralamenities(jsons.getString("generalOverview"));
			hotelInfoVO.setHotelAddress(jsons.getString("address"));
			
			hotelInfoVO.setHotelEnName(jsons.getString("nameEn"));
			hotelInfoVO.setHotelId(jsons.getLong("id"));
			hotelInfoVO.setHotelName(jsons.getString("name"));
			
			hotelInfoVO.setIntroeditor(jsons.getString("introduce"));
			hotelInfoVO.setIseconomic(jsons.getString("economicFalg"));
			try {
				JSONArray landmarkNames = jsons.getJSONArray("landmarkNames");
				hotelInfoVO.setLandMarkids(landmarkNames.toString());
			} catch (Exception e) {
				e.printStackTrace();
			}
			hotelInfoVO.setPhone(jsons.getString("phone"));
			hotelInfoVO.setRecreationamenities(jsons.getString("recreationOverview"));
			hotelInfoVO.setShortIntroeditor(jsons.getString("featureOverview"));
			
			hotelInfoVO.setTrafficAndAroundInformations(jsons.getString("trafficOverview"));
			hotelInfoVO.setZIP(jsons.getString("zip"));
			hotelInfoVO.setStar(jsons.getString("star"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hotelInfoVO;
	}
	private static List<HotelAccountInfoPO> getHotelAccounts(JSONObject jsonObj) throws Exception{
		HotelAccountInfoPO hotelAccount = null;
		List<HotelAccountInfoPO> hotelAccounts = new ArrayList<HotelAccountInfoPO>();
		JSONObject commissionVos = jsonObj.getJSONObject("commissionVo");
		JSONArray jArray = commissionVos.getJSONArray("accountVos");
		for(int i =0; i<jArray.length(); i++){
			hotelAccount = new HotelAccountInfoPO();
			JSONObject obj = jArray.getJSONObject(i);
			hotelAccount.setCheckindate(new java.sql.Date(Long.parseLong(obj.get("checkInDate")+""))+"");
			hotelAccount.setCheckoutdate(new java.sql.Date(Long.parseLong(obj.get("checkOutDate")+""))+"");
			hotelAccount.setCommission(Double.parseDouble(obj.get("commission")+""));
			hotelAccount.setGuestname(obj.get("guestName")+"");
			hotelAccount.setHotelname(obj.get("hotelName")+"");
			hotelAccount.setLcdorderid(obj.get("lcdOrderId")+"");
			hotelAccount.setOrderid(Long.parseLong(obj.get("orderid")+""));
			hotelAccount.setBonuspunish(Double.parseDouble(obj.get("rewardPunishMoney")+""));
			hotelAccount.setQuantity(Integer.parseInt(obj.get("roomAccount")+""));
			hotelAccount.setQuantitydays(Integer.parseInt(obj.get("roomNight")+""));
			hotelAccount.setTotalprice(Double.parseDouble(obj.get("totalPrice")+""));
			hotelAccounts.add(hotelAccount);
		}
		return hotelAccounts;
	
	}
	private static HotelAccountResult getTotalAccount(JSONObject jsonObj) throws Exception{
		HotelAccountResult totalAccount = new HotelAccountResult();
		JSONObject commissionVos = jsonObj.getJSONObject("commissionVo");
		String effectiveTimeRate = commissionVos.get("effectiveTimeRate")+"";
		String realCommission = commissionVos.get("realCommission")+"";
		Integer totalBookingTime = Integer.valueOf(commissionVos.get("totalBookingTime")+"");
		Integer totalChickInTime = Integer.valueOf(commissionVos.get("totalChickInTime")+"");
		String totalCommission = commissionVos.get("totalCommission")+"";
		String totalPunishMoney = commissionVos.get("totalPunishMoney")+"";
		
		totalAccount.setRewardPunishAmount(Double.valueOf(totalPunishMoney));
		totalAccount.setTotalCommission(Double.valueOf(totalCommission));    					//总佣金
		totalAccount.setTotalOrderQuantityDay(totalBookingTime);			//总预订间夜
		totalAccount.setTotalRealCommission(Double.valueOf(realCommission));			
		totalAccount.setValidQuantityDay(totalChickInTime);						//入住间夜
		totalAccount.setValidQuantityDayRate(Double.valueOf(effectiveTimeRate)); //有效间夜率	= 入住间夜 / 总预订间夜
		return totalAccount;
		
	}
	public static void main(String[] args) {
		System.out.println(new java.sql.Date(System.currentTimeMillis()));
		System.out.println(new java.sql.Date(System.currentTimeMillis()+1*60*60*24*1000));
		
	}

}