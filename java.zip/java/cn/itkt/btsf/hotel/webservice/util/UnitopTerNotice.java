package cn.itkt.btsf.hotel.webservice.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class UnitopTerNotice {

	public static String requestHttp(String URL, String param) {
		String result = "";
		try {
			String url = URL;
			URL requestUrl = new URL(url);

			HttpURLConnection httpConn = (HttpURLConnection) requestUrl.openConnection();
			httpConn.setDoOutput(true);
			httpConn.setDoInput(true);
			httpConn.setUseCaches(false);
			httpConn.setRequestMethod("POST");

//			PrintWriter out = new PrintWriter(httpConn.getOutputStream());
//			out.print(param);
			OutputStreamWriter out = new OutputStreamWriter(httpConn.getOutputStream(), "utf-8");
			out.write(param);
			out.flush();
			out.close();

			InputStream inputStream = httpConn.getInputStream();
			InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "utf-8");
			BufferedReader in = new BufferedReader(inputStreamReader);
			String lineStr;
			while ((lineStr = in.readLine()) != null) {
				result += lineStr;
				result += "\r\n";
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}
}
