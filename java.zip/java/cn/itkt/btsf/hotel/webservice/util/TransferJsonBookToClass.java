package cn.itkt.btsf.hotel.webservice.util;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.itkt.btsf.hotel.vo.BaseVo;
import cn.itkt.btsf.hotel.vo.DayRateForHotel;
import cn.itkt.btsf.hotel.vo.HotelForMoreHotelVo;
import cn.itkt.btsf.hotel.vo.HotelForOneHotelVo;
import cn.itkt.btsf.hotel.vo.HotelOrderStateResult;
import cn.itkt.btsf.hotel.vo.HotelProductVouchVo;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.hotel.vo.RatePlanForHotel;
import cn.itkt.btsf.hotel.vo.RoomForHotel;
import cn.itkt.btsf.hotel.vo.RoomReserveInfoVo;
import cn.itkt.btsf.hotel.vo.VouchInfo;

public class TransferJsonBookToClass {	
	/**以下为酒店预订的相关转换方法**/
	public static HotelQueryResultVO parseHotelQueryResultVO(String json) {
		HotelQueryResultVO resultVO = null;
		JSONObject jsons = null;
		try {
			jsons = new JSONObject(json);
			resultVO = new HotelQueryResultVO();
			resultVO.setCurrentPage(jsons.getInt("pageNumber"));
			resultVO.setHotelAccount(jsons.getInt("hotelCount"));
			resultVO.setHotelAllPage(jsons.getInt("totalPages"));
			resultVO.setMessage(jsons.getString("message"));
			resultVO.setStatus(jsons.getString("statusCode"));
			
			/**设置酒店**/
			HotelForMoreHotelVo[] moreHotelVo = new HotelForMoreHotelVo[10];
			JSONArray hotelVos = jsons.getJSONArray("hotelVos");
			System.out.println(hotelVos);
			for(int i=0; i<hotelVos.length(); i++){
				HotelForMoreHotelVo moreHotel = new HotelForMoreHotelVo();
				JSONObject hotelVo = hotelVos.getJSONObject(i);
//				moreHotel.setAddValuesDescription()
//				moreHotel.setBookingRuless(bookingRuless)
				moreHotel.setBrandid(hotelVo.getString("brandId"));
				moreHotel.setCitycode(hotelVo.getString("cityId"));
				moreHotel.setCommentAll(hotelVo.getLong("commentTotal"));
				//moreHotel.setCommentGood(hotelVo.getLong("commentGoodRate"));
				
				moreHotel.setCommercial(hotelVo.getString("commercialName"));
				moreHotel.setDistrict(hotelVo.getString("districtName"));
//				moreHotel.setDRRRules(dRRRules)
//				moreHotel.setGaranteeRules(garanteeRules)
				moreHotel.setHotelAddress(hotelVo.getString("address"));
				moreHotel.setHotelId(hotelVo.getString("id"));
//				moreHotel.setHotelInvStatusCode(hotelInvStatusCode)
				moreHotel.setHotelName(hotelVo.getString("name"));
//				moreHotel.setHotelurl("")
				moreHotel.setLatitude(hotelVo.getString("lat"));
				moreHotel.setLongitude(hotelVo.getString("lon"));
				moreHotel.setLowestPrice(BigDecimal.valueOf(hotelVo.getLong("lowestPrice")));
				moreHotel.setPhone(hotelVo.getString("phone"));
//				moreHotel.setPor(por)
				moreHotel.setStarCode(hotelVo.getString("star"));
				/**设置房间**/
				JSONArray roomVos = hotelVo.getJSONArray("roomVos");
				RoomForHotel[] rooms = new RoomForHotel[roomVos.length()];
				String bookingRules = setRooms(roomVos, rooms);
				String[] br = new String[1];
				br[0] = bookingRules;
				moreHotel.setBookingRuless(br);
				moreHotel.setRoomForGetHoteList(rooms);
				moreHotelVo[i] = moreHotel;
			}
			resultVO.setMoreHotel(moreHotelVo);
		} catch (JSONException e) {
			System.out.println("--------------解析查询酒店列表JSON串出错!!!-------------------------");
			e.printStackTrace();
		}
		return resultVO;
	}
	public static HotelQueryResultVO parseOneHotelQueryResultVO(String json) {
		HotelQueryResultVO resultVO = null;
		JSONObject hotelVo = null;
		try {
			hotelVo = new JSONObject(json);
			resultVO = new HotelQueryResultVO();
			HotelForOneHotelVo oneHotel = new HotelForOneHotelVo();
//				moreHotel.setAddValuesDescription()
//				moreHotel.setBookingRuless(bookingRuless)
			oneHotel.setBrandid(hotelVo.getString("brandId"));
			oneHotel.setCitycode(hotelVo.getString("cityId"));
			oneHotel.setCommentAll(hotelVo.getLong("commentTotal"));
			//oneHotel.setCommentGood(hotelVo.getLong("commentGoodRate"));
			
			oneHotel.setCommercial(hotelVo.getString("commercialName"));
			oneHotel.setDistrict(hotelVo.getString("districtName"));
//				oneHotel.setDRRRules(dRRRules)
//				oneHotel.setGaranteeRules(garanteeRules)
			oneHotel.setHotelAddress(hotelVo.getString("address"));
			oneHotel.setHotelId(hotelVo.getString("id"));
//				oneHotel.setHotelInvStatusCode(hotelInvStatusCode)
			oneHotel.setHotelName(hotelVo.getString("name"));
//				oneHotel.setHotelurl("")
			oneHotel.setLatitude(hotelVo.getString("lat"));
			oneHotel.setLongitude(hotelVo.getString("lon"));
			oneHotel.setLowestPrice(BigDecimal.valueOf(hotelVo.getLong("lowestPrice")));
			oneHotel.setPhone(hotelVo.getString("phone"));
//				oneHotel.setPor(por)
			oneHotel.setStarCode(hotelVo.getString("star"));
			/**设置房间**/
			JSONArray roomVos = hotelVo.getJSONArray("roomVos");
			RoomForHotel[] rooms = new RoomForHotel[roomVos.length()];
			String bookingRules = setRooms(roomVos, rooms);
			String[] br = new String[1];
			br[0] = bookingRules;
			oneHotel.setBookingRuless(br);
			oneHotel.setRoomForGetHoteList(rooms);
			resultVO.setOneHotel(oneHotel);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return resultVO;
	}
	public static BaseVo parseCancelHotelOrder(String json) {
		JSONObject hotelVo = null;
		BaseVo baseVo = new BaseVo();
		try {
			//{"message":"el-00001","statusCode":"fail"}
			hotelVo = new JSONObject(json);
			baseVo.setMessage(hotelVo.getString("message"));
			baseVo.setStatus(hotelVo.getString("statusCode"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		return baseVo;
	}
	public static RoomReserveInfoVo parseRoomReserveNumber(String result) {
		RoomReserveInfoVo roomReserve = new RoomReserveInfoVo();
		try {
			JSONObject json = new JSONObject(result);
			roomReserve.setMessage(json.getString("message"));
			roomReserve.setStatus(json.getString("statusCode"));
			JSONArray array = json.getJSONArray("roomReserveVos");
			for(int i=0; i<array.length(); i++){
				JSONObject obj = array.getJSONObject(i);
				roomReserve.setRoomAmount(obj.getInt("roomAmount"));
//				if(rid.equals("roomTypeId")){
//					return roomReserve;
//				}
			}
			System.out.println(json);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return roomReserve;
	}
	public static HotelProductVouchVo parseHotelProductVouchVo(String result) {
		HotelProductVouchVo productVouch = new HotelProductVouchVo();
		try {
			//{"description_CN":null,"description_EN":null,"isVouch":0,"lastCancelTime":null,"message":null,"statusCode":"fail","vouchMoneyType":null}
			JSONObject json = new JSONObject(result);
			productVouch.setDescription_CN(json.getString("description_CN"));
			productVouch.setDescription_EN(json.getString("description_EN"));
			productVouch.setIsVouch(json.getInt("isVouch"));
			//productVouch.setLastCancelTime(json.getString("lastCancelTime"));
			productVouch.setVouchMoneyType(json.getString("vouchMoneyType"));
			productVouch.setMessage(json.getString("message"));
			productVouch.setStatus(json.getString("statusCode"));
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return productVouch;
	}
	public static HotelOrderStateResult parseImportOrSyn(String result, boolean isImport) {
		HotelOrderStateResult stateResult = null;
		try {
			stateResult = new HotelOrderStateResult();
			JSONObject obj = new JSONObject(result);
			String statusCode = obj.getString("statusCode");
			String message = obj.getString("message");
//			JSONArray failOrderIds = obj.getJSONArray("failOrderIds");
			stateResult.setStatus(statusCode);
			stateResult.setMessage(message);
//			stateResult.setErrorOrder(failOrderIds.);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return stateResult;
	}
	private static String setRatePlans(JSONArray ratePlanVos, RatePlanForHotel[] ratePlans) throws JSONException {
		String bookingRules = null;
			for(int k=0; k<ratePlanVos.length(); k++){
				RatePlanForHotel ratePlan = new RatePlanForHotel();
				JSONObject ratePlanVo = ratePlanVos.getJSONObject(k);
	//						ratePlan.setActiveLcdfee(ratePlanVo.getInt(""))
				ratePlan.setAveragePrice(BigDecimal.valueOf(ratePlanVo.getLong("avgPrice")));
				ratePlan.setGuestTypeCode(ratePlanVo.getString("guestType"));
				ratePlan.setRatePlanCode(ratePlanVo.getString("code"));
				ratePlan.setRatePlanID(ratePlanVo.getInt("id"));
				ratePlan.setRatePlanName(ratePlanVo.getString("name"));
				ratePlan.setReturnAvgLcdMoney(ratePlanVo.getString("lcdAvgMoney"));
				ratePlan.setReturnLcdMoney(ratePlanVo.getString("lcdMoney"));
				ratePlan.setTotalPrice(BigDecimal.valueOf(ratePlanVo.getLong("totalPrice")));
				bookingRules = ratePlanVo.getJSONArray("bookingRulesDesc")+"";
				/**设置每天价格**/
				JSONArray rateVos =	ratePlanVo.getJSONArray("rateVos");
				DayRateForHotel[] dateRates = new DayRateForHotel[rateVos.length()]; 
				setDateRates(rateVos, dateRates);
				ratePlan.setEachDayRateList(dateRates);
				/**设置担保规则**/
				VouchInfo[] vouchInfos = setVouchVos(ratePlanVo);
				ratePlan.setVouchInfos(vouchInfos);
				ratePlans[k] = ratePlan;
			}
			return bookingRules;
		}
	private static void setDateRates(JSONArray rateVos, DayRateForHotel[] dateRates) throws JSONException {
		for(int x=0; x<rateVos.length(); x++){
			DayRateForHotel dateRate = new DayRateForHotel(); 
			JSONObject rateVo = rateVos.getJSONObject(x);
			dateRate.setAddBedRate(BigDecimal.valueOf(rateVo.getLong("addBedRate")));
			dateRate.setCurrencyCode(rateVo.getString("currencyCode"));
			Calendar c = Calendar.getInstance();
			c.setTime(new Date(rateVo.getLong("date")));
			dateRate.setDate(c);
//						dateRate.setInvStatusCode(invStatusCode)
			dateRate.setMemberRate(BigDecimal.valueOf(rateVo.getLong("memberRate")));
			dateRate.setRetailRate(BigDecimal.valueOf(rateVo.getLong("retailRate")));
			dateRate.setStrDate(new java.sql.Date(rateVo.getLong("date"))+"");
			dateRates[x] = dateRate;
		}
	}
	private static VouchInfo[] setVouchVos(JSONObject ratePlanVo) throws JSONException {
		JSONArray vouchVos = ratePlanVo.getJSONArray("vouchVos");
		VouchInfo[] vouchInfos = new VouchInfo[vouchVos.length()];
		for(int y=0; y<vouchVos.length(); y++){
			VouchInfo vouchInfo = new VouchInfo();
			JSONObject vouchVo = vouchVos.getJSONObject(y);
			vouchInfo.setDescription(vouchVo.getString("description"));
			vouchInfo.setIsRoomAmountVouch(vouchVo.getInt("isRoomAmountVouch"));
			vouchInfo.setIsTimeVouch(vouchVo.getInt("isTimeVouch"));
			vouchInfo.setIsVouch(vouchVo.getInt("isVouch"));
			vouchInfo.setNotVouchDescription(vouchVo.getString("notVouchDescription"));
			vouchInfo.setNotVouchTime(vouchVo.getString("notVouchTime"));
			vouchInfo.setRoomAmount(vouchVo.getInt("roomAmount"));
			vouchInfo.setVouchDescription(vouchVo.getString("vouchDescription"));
			vouchInfo.setVouchMoneyType(vouchVo.getInt("vouchMoneyType"));
			vouchInfo.setVouchTime(vouchVo.getString("vouchTime"));
			vouchInfos[y] = vouchInfo;
		}
		return vouchInfos;
	}
	private static String setRooms(JSONArray roomVos, RoomForHotel[] rooms) throws JSONException {
		String bookingRules = "";
			for(int j=0; j<roomVos.length(); j++){
				RoomForHotel room = new RoomForHotel();
				JSONObject roomVo = roomVos.getJSONObject(j);
				room.setArea(roomVo.getString("area"));
	//					room.setAvailableAmount(roomVo.getInt(""))
				room.setBeddescription(roomVo.getString("bedDesc"));
				room.setBedtype(roomVo.getString("bedType"));
				room.setFloor(roomVo.getString("floorNumber"));
				room.setHadbroadbandfee(roomVo.getString("broadbandFeeFlag"));
				room.setHasbroadband(roomVo.getString("broadbandFlag"));
	//					room.setIsOverBooking("")
				room.setNote(roomVo.getString("remark"));
	//					room.setRoomImageCodes(roomImageCodes)
				room.setRoomInvStatusCode(roomVo.getInt("satus")+"");
				room.setRoomName(roomVo.getString("name"));
				room.setRoomTypeId(roomVo.getString("id"));
	//					room.setRoomtypenum(roomtypenum)
	//					room.setRoomurl(roomurl)
				/**设置床型**/
				JSONArray ratePlanVos = roomVo.getJSONArray("ratePlanVos");
				RatePlanForHotel[] ratePlans = new RatePlanForHotel[ratePlanVos.length()];
				bookingRules = setRatePlans(ratePlanVos, ratePlans);
				room.setRatePlanForGetHotelList(ratePlans);
				rooms[j] = room;
			}
			return bookingRules;
		}}