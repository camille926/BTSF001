package cn.itkt.btsf.hotel.dao;

import java.util.List;
import java.util.Map;

import cn.itkt.btsf.hotel.localvo.HotelInfoVO;
import cn.itkt.btsf.hotel.localvo.HotelOrderInfoVO;
import cn.itkt.btsf.hotel.po.CommercialPO;
import cn.itkt.btsf.hotel.po.DistrictPO;
import cn.itkt.btsf.hotel.po.GuarantyInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountInfoPO;
import cn.itkt.btsf.hotel.po.HotelAccountResult;
import cn.itkt.btsf.hotel.po.HotelInfoPO;
import cn.itkt.btsf.hotel.po.LandmarkPO;
import cn.itkt.btsf.hotel.po.OrderInfoPO;
import cn.itkt.btsf.hotel.vo.HotelCityInfoVo;

/**
 * @version 1.0
 * @author SunLing
 * @date 2012-10-29
 * @title 酒店业务模块持久化接口
 */
public interface HotelDao {
	/****
	 * 根据输入自动提示城市名称
	 * @param namePrefix
	 * @return
	 */
	public List<HotelCityInfoVo> findHotelCities(Map<String, Object> map);
	/****
	 * 根据输入自动提示行政区名称
	 * @param namePrefix
	 * @return
	 */
	public List<DistrictPO> findHotelDst(Map<String, Object> map);
	/****
	 * 根据输入自动提示商业名称
	 * @param namePrefix
	 * @return
	 */
	public List<CommercialPO> findHotelComm(Map<String, Object> map);
	/****
	 * 根据输入自动提示标志物名称
	 * @param namePrefix
	 * @return
	 */
	public List<LandmarkPO> findHotelLm(Map<String, Object> map);
	/****
	 * 保存本地订单
	 * @param orderInfoPO
	 * @return
	 */
	public Integer create(OrderInfoPO orderInfoPO);
	/****
	 * 保存本地订单
	 * @param orderInfoPO
	 * @return
	 */
	public Integer createHotel(HotelInfoPO hotelInfoPO);
	/****
	 * 查询订单详情
	 * @param orderId 订单Id
	 * @return
	 */
	public OrderInfoPO findOrderInfo(Long orderId);
	/****
	 * 查询订单详情
	 * @param orderId 订单Id
	 * @return
	 */
	public OrderInfoPO findIdByLcdId(String lcdOrderId);
	/****
	 * 查询订单酒店详情
	 * @param orderId 订单Id
	 * @return
	 */
	public HotelInfoPO findOrderHotelInfo(Long orderId);
	/****
	 * 查询订单担保详情
	 * @param orderId 订单Id
	 * @return
	 */
	public GuarantyInfoPO findOrderGuarantyInfo(Long orderId);
	
	public HotelInfoVO findHotelInfo(String hotelId);
	/**
	 * 查询订单主键
	 * @param elongId
	 * @return
	 */
	public long findPrimaryIdByElongId(String elongId);
	/**
	 * 查询订单信息
	 * @param elongId
	 * @return
	 */
	public HotelOrderInfoVO findHotelInfoByElongId(String elongId);
	/**
	 * 更新订单会员信息
	 * @param orderInfo
	 */
	public void updateOrderUser(HotelOrderInfoVO orderInfo);
	/**
	 * 更新订单状态为已取消
	 * @param elongId
	 */
	public void cancelOrderStateByElongId(Map<String,Object> map);
	/**
	 * 更新订单备注
	 * @param orderInfo
	 */
	public void updateOrderRemark(HotelOrderInfoVO orderInfo);
	/**
	 * 查询标志物
	 * @param query
	 */
	public List<String> findLandMarkByHotelMark(Map<String, Object> query);
	/**
	 * 查询艺龙单号在数据库中的数量
	 * @param elongId
	 * @return
	 */
	public int countOrderByElongId(String elongId);
	/**
	 * 查询结算
	 * @return
	 */
	public List<HotelAccountInfoPO> findHotelAccounts(Map<String, Object> queryMap);
	public List<HotelAccountInfoPO> newFindHotelAccounts(Map<String, Object> queryMap);
	/**
	 * 总结算
	 * @return
	 */
	public HotelAccountResult findHotelAccountsTotal(Map<String, Object> queryMap);
	/**
	 * 总间夜数，不属于结账状态，但elong有订单号
	 * @return
	 */
	public Integer findQuantityDaysTotal(Map<String, Object> queryMap);
}
