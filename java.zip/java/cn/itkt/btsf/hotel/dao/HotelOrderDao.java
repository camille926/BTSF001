package cn.itkt.btsf.hotel.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**酒店订单列表查询
 * @author liu
 *
 */

public interface HotelOrderDao {
	
	
	/**根据查询条件查询所有订单
	 * @param sqlParamMap
	 * @return
	 */
	public List<HashMap<String, Object>> getHotelOrderList(HashMap<String, Object> sqlParamMap);

	public int getHotelOrderCount(Map<String, Object> sqlParamMap);


}
