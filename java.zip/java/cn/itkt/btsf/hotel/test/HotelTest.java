package cn.itkt.btsf.hotel.test;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;
import java.util.ResourceBundle;

import org.apache.axis.AxisFault;

import cn.itkt.btsf.hotel.vo.ELONGWEBHOTELSERVICESoapBindingStub;
import cn.itkt.btsf.hotel.vo.ElongWebHotelService;
import cn.itkt.btsf.hotel.vo.HotelListQueryRequest;
import cn.itkt.btsf.hotel.vo.HotelQueryResultVO;
import cn.itkt.btsf.util.PropertyUtil;

public class HotelTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ResourceBundle bundleWebService = PropertyUtil.getWebServceiProperty();
		String HOTELENDPOINT = bundleWebService.getString("HOTELENDPOINT");
		try {
			URL url = new URL(HOTELENDPOINT);
			javax.xml.rpc.Service service = new org.apache.axis.client.Service();
			ElongWebHotelService soap = new ELONGWEBHOTELSERVICESoapBindingStub(url, service);
			HotelListQueryRequest hotelListQueryRequest = new HotelListQueryRequest();
			hotelListQueryRequest.setCheckInDate("2012-11-10");
			hotelListQueryRequest.setCheckOutDate("2012-11-12");
			hotelListQueryRequest.setCityId("0101");

			HotelQueryResultVO  aa = soap.findHotelQueryResultVO(hotelListQueryRequest);
			System.out.println(aa.getMessage());
			System.out.println(aa.getStatus());
			System.out.println(aa.getMoreHotel().length);
		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
