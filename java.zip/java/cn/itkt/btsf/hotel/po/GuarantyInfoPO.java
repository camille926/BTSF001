package cn.itkt.btsf.hotel.po;
/**
 * @version 1.0
 * @author SunLing
 * @date 2012-11-07
 * @title 订单中的担保金信息
 */
public class GuarantyInfoPO {
	private Long id;
	private Long resorderid;//订单提交数据表ID
	private String guaranteetype;//首晚担保0，或者全额担保1
	private String bankname;//信用卡所属银行
	private String cvv2;//
	private String ownername;//姓名
	private String cardnum;//所属银行卡号，卡号后四位没有
	private String validdate;//有效期年12-12
	private String idtypecode;//证件类别代码   0  身份证    4护照
	private String idnumber;//证件号码
	private Double vauchmoney;//担保金额
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getResorderid() {
		return resorderid;
	}
	public void setResorderid(Long resorderid) {
		this.resorderid = resorderid;
	}
	public String getGuaranteetype() {
		return guaranteetype;
	}
	public void setGuaranteetype(String guaranteetype) {
		this.guaranteetype = guaranteetype;
	}
	public String getBankname() {
		return bankname;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public String getCvv2() {
		return cvv2;
	}
	public void setCvv2(String cvv2) {
		this.cvv2 = cvv2;
	}
	public String getOwnername() {
		return ownername;
	}
	public void setOwnername(String ownername) {
		this.ownername = ownername;
	}
	public String getCardnum() {
		return cardnum;
	}
	public void setCardnum(String cardnum) {
		this.cardnum = cardnum;
	}
	public String getValiddate() {
		return validdate;
	}
	public void setValiddate(String validdate) {
		this.validdate = validdate;
	}
	public String getIdtypecode() {
		return idtypecode;
	}
	public void setIdtypecode(String idtypecode) {
		this.idtypecode = idtypecode;
	}
	public String getIdnumber() {
		return idnumber;
	}
	public void setIdnumber(String idnumber) {
		this.idnumber = idnumber;
	}
	public Double getVauchmoney() {
		return vauchmoney;
	}
	public void setVauchmoney(Double vauchmoney) {
		this.vauchmoney = vauchmoney;
	}
	
}
