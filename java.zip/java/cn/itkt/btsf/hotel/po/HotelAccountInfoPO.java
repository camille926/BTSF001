package cn.itkt.btsf.hotel.po;

import java.util.Date;

/**
 * @version 1.0
 * @author SunLing
 * @date 2013-01-10
 * @title 接收或封装酒店结算信息
 */

public class HotelAccountInfoPO {
	
	private Long id;                  
	private String lcdorderid;
	private Long orderid;
	private String checkindate;
	private String checkoutdate;
	private String hotelname;
	private String guestname;
	private Integer quantity;
	private Integer quantitydays;
	private Double totalprice;
	private Double commission;
	private Double bonuspunish;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLcdorderid() {
		return lcdorderid;
	}
	public void setLcdorderid(String lcdorderid) {
		this.lcdorderid = lcdorderid;
	}
	public Long getOrderid() {
		return orderid;
	}
	public void setOrderid(Long orderid) {
		this.orderid = orderid;
	}
	public String getCheckindate() {
		return checkindate;
	}
	public void setCheckindate(String checkindate) {
		this.checkindate = checkindate;
	}
	public String getCheckoutdate() {
		return checkoutdate;
	}
	public void setCheckoutdate(String checkoutdate) {
		this.checkoutdate = checkoutdate;
	}
	public String getHotelname() {
		return hotelname;
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	public String getGuestname() {
		return guestname;
	}
	public void setGuestname(String guestname) {
		this.guestname = guestname;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Integer getQuantitydays() {
		return quantitydays;
	}
	public void setQuantitydays(Integer quantitydays) {
		this.quantitydays = quantitydays;
	}
	public Double getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}
	public Double getCommission() {
		return commission;
	}
	public void setCommission(Double commission) {
		this.commission = commission;
	}
	public Double getBonuspunish() {
		return bonuspunish;
	}
	public void setBonuspunish(Double bonuspunish) {
		this.bonuspunish = bonuspunish;
	}

}
