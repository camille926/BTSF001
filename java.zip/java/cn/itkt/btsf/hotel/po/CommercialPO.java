package cn.itkt.btsf.hotel.po;
/****
 * 商业区对象
 * @author sl
 *	2012-11-12 
 */
public class CommercialPO {
	private Long id;
	/**城市编码**/
	private String cityCode;
	/**商业区编码**/
	private String commercialCode;
	/**商业区行政区名称**/
	private String districtNameCommercialName;
	/**预防districtName重名，列出属于的省名**/
	private String province;
	/**预防districtName重名，列出属于的城市名**/
	private String cityName;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCommercialCode() {
		return commercialCode;
	}
	public void setCommercialCode(String commercialCode) {
		this.commercialCode = commercialCode;
	}
	public String getDistrictNameCommercialName() {
		return districtNameCommercialName;
	}
	public void setDistrictNameCommercialName(String districtNameCommercialName) {
		this.districtNameCommercialName = districtNameCommercialName;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

}
