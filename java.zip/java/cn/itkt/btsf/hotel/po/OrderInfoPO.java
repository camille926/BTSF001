package cn.itkt.btsf.hotel.po;

import java.util.Date;

/**
 * @version 1.0
 * @author SunLing
 * @date 2012-11-07
 * @title 订单信息
 */
public class OrderInfoPO {
	private Long id;	
	private String terminalid;			//自助终端编号
	private String checkindate;			//入住起始时间
	private String checkoutdate;		//入住截止时间
	private String payment;				//支付方式
	private String arriveearlytime;		//到店最早时间
	private String arrivelatetime;		//到店最晚时间
	private Float totalprice;			//总房价
	private String orderid;				//订单id
	private String guestname;			//入住人姓名
	private String contactphone;		//联系电话
	private Integer lcdreturnfee;		//应返还的畅达币
	private String email;				//邮箱
	private String guesttype;			//客户类型
	private String isoperate;			//0处理前,1处理后反，2处理后不反
	private Date createtime;			//创建时间
	private String lcdorderid;			//自己创建的lcdorderID
	private Date operatetime;			//操作时间
	private Long userid;				//会员id
	private String usertype;
	private String orderstate;
	private String ordersource;
	private String contactname;			//联系人姓名
	private String ordermessage;		//订单返回信息

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTerminalid() {
		return terminalid;
	}
	public void setTerminalid(String terminalid) {
		this.terminalid = terminalid;
	}
	public String getCheckindate() {
		return checkindate;
	}
	public void setCheckindate(String checkindate) {
		this.checkindate = checkindate;
	}
	public String getCheckoutdate() {
		return checkoutdate;
	}
	public void setCheckoutdate(String checkoutdate) {
		this.checkoutdate = checkoutdate;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public String getArriveearlytime() {
		return arriveearlytime;
	}
	public void setArriveearlytime(String arriveearlytime) {
		this.arriveearlytime = arriveearlytime;
	}
	public String getArrivelatetime() {
		return arrivelatetime;
	}
	public void setArrivelatetime(String arrivelatetime) {
		this.arrivelatetime = arrivelatetime;
	}
	public Float getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(Float totalprice) {
		this.totalprice = totalprice;
	}
	public String getOrderid() {
		return orderid;
	}
	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}
	public String getGuestname() {
		return guestname;
	}
	public void setGuestname(String guestname) {
		this.guestname = guestname;
	}
	public String getContactphone() {
		return contactphone;
	}
	public void setContactphone(String contactphone) {
		this.contactphone = contactphone;
	}
	public Integer getLcdreturnfee() {
		return lcdreturnfee;
	}
	public void setLcdreturnfee(Integer lcdreturnfee) {
		this.lcdreturnfee = lcdreturnfee;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGuesttype() {
		return guesttype;
	}
	public void setGuesttype(String guesttype) {
		this.guesttype = guesttype;
	}
	public String getIsoperate() {
		return isoperate;
	}
	public void setIsoperate(String isoperate) {
		this.isoperate = isoperate;
	}
	public Date getCreatetime() {
		return createtime;
	}
	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}
	public String getLcdorderid() {
		return lcdorderid;
	}
	public void setLcdorderid(String lcdorderid) {
		this.lcdorderid = lcdorderid;
	}
	public Date getOperatetime() {
		return operatetime;
	}
	public void setOperatetime(Date operatetime) {
		this.operatetime = operatetime;
	}

	public Long getUserid() {
		return userid;
	}
	public void setUserid(Long userid) {
		this.userid = userid;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getOrderstate() {
		return orderstate;
	}
	public void setOrderstate(String orderstate) {
		this.orderstate = orderstate;
	}
	public String getOrdersource() {
		return ordersource;
	}
	public void setOrdersource(String ordersource) {
		this.ordersource = ordersource;
	}
	public String getContactname() {
		return contactname;
	}
	public void setContactname(String contactname) {
		this.contactname = contactname;
	}
	public String getOrdermessage() {
		return ordermessage;
	}
	public void setOrdermessage(String ordermessage) {
		this.ordermessage = ordermessage;
	}
	
}
