package cn.itkt.btsf.hotel.po;
/****
 * 行政区对象
 * @author sunliang
 *	2012-11-12 
 */
public class DistrictPO {
	private Long id;
	/**城市代码**/
	private String cityCode;
	/**预防districtName重名，列出属于的省名**/
	private String province;
	/**预防districtName重名，列出属于的城市名**/
	private String cityName;
	/**行政区编码**/
	private String districtCode;
	/**行政区名称**/
	private String districtName;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getDistrictCode() {
		return districtCode;
	}
	public void setDistrictCode(String districtCode) {
		this.districtCode = districtCode;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	
}
