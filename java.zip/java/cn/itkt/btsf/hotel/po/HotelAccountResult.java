package cn.itkt.btsf.hotel.po;

public class HotelAccountResult {
	private double totalCommission; //总佣金	查询结果列表中佣金的总和
	private int totalOrderQuantityDay;//总预订间夜	查询日期范围内，全部订单的间夜总和
	private int validQuantityDay;//入住间夜	查询结果列表中，间夜的总和
	private double validQuantityDayRate;//有效间夜率	入住间夜 / 总预订间夜
	private double rewardPunishAmount;//奖惩金额	查询结果列表中奖惩的总和
	private double totalRealCommission;//实际佣金	总佣金 + 奖惩金额
	public double getTotalCommission() {
		return totalCommission;
	}
	public void setTotalCommission(double totalCommission) {
		this.totalCommission = totalCommission;
	}
	public int getTotalOrderQuantityDay() {
		return totalOrderQuantityDay;
	}
	public void setTotalOrderQuantityDay(int totalOrderQuantityDay) {
		this.totalOrderQuantityDay = totalOrderQuantityDay;
	}
	public int getValidQuantityDay() {
		return validQuantityDay;
	}
	public void setValidQuantityDay(int validQuantityDay) {
		this.validQuantityDay = validQuantityDay;
	}

	public double getValidQuantityDayRate() {
		return validQuantityDayRate;
	}
	public void setValidQuantityDayRate(double validQuantityDayRate) {
		this.validQuantityDayRate = validQuantityDayRate;
	}
	public double getRewardPunishAmount() {
		return rewardPunishAmount;
	}
	public void setRewardPunishAmount(double rewardPunishAmount) {
		this.rewardPunishAmount = rewardPunishAmount;
	}
	public double getTotalRealCommission() {
		return totalRealCommission;
	}
	public void setTotalRealCommission(double totalRealCommission) {
		this.totalRealCommission = totalRealCommission;
	}
	
}
