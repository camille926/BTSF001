package cn.itkt.btsf.hotel.po;
/****
 *  地标对象
 * @author Administrator
 *	2012-11-12 
 */
public class LandmarkPO {
	
	private Long id;
	/**城市代码**/
	private String cityCode;
	/**地标编码**/
	private String landmarkCode;
	/**地标名称**/
	private String landmarkName;
	/**预防districtName重名，列出属于的省名**/
	private String province;
	/**预防districtName重名，列出属于的城市名**/
	private String cityName;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getLandmarkCode() {
		return landmarkCode;
	}
	public void setLandmarkCode(String landmarkCode) {
		this.landmarkCode = landmarkCode;
	}
	public String getLandmarkName() {
		return landmarkName;
	}
	public void setLandmarkName(String landmarkName) {
		this.landmarkName = landmarkName;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
}
