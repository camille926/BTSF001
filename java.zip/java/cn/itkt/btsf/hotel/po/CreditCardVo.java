package cn.itkt.btsf.hotel.po;

import java.io.Serializable;

/**
 * 类: CreditCardVo <br>
 * 描述: 信用卡Vo <br>
 * 作者: 王鹏 wangpeng@itkt.com <br>
 * 时间: 2013-1-29 下午02:03:07
 */
public class CreditCardVo implements Serializable {

	private static final long serialVersionUID = -1580323333302765263L;

	/** id */
	private String id;
	/** 用户名 */
	private String userName;
	/** 证件类型 */
	private String cardType;
	/** 证件号码 */
	private String cardNumber;
	/** 银行 */
	private String bankName;
	/** 银行ID */
	private String bankId;
	/** 银行卡号 */
	private String bankCardNumber;
	/** 校验码 */
	private String ccv2;
	/** 有效期 */
	private String validityDate;

	/**
	 * 返回: the id <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getId() {
		return id;
	}

	/**
	 * 参数: id to set the id <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * 返回: the userName <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * 参数: userName to set the userName <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * 返回: the cardType <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getCardType() {
		return cardType;
	}

	/**
	 * 参数: cardType to set the cardType <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	/**
	 * 返回: the cardNumber <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getCardNumber() {
		return cardNumber;
	}

	/**
	 * 参数: cardNumber to set the cardNumber <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	/**
	 * 返回: the bankName <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getBankName() {
		return bankName;
	}

	/**
	 * 参数: bankName to set the bankName <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * 返回: the bankId <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getBankId() {
		return bankId;
	}

	/**
	 * 参数: bankId to set the bankId <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	/**
	 * 返回: the bankCardNumber <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getBankCardNumber() {
		return bankCardNumber;
	}

	/**
	 * 参数: bankCardNumber to set the bankCardNumber <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setBankCardNumber(String bankCardNumber) {
		this.bankCardNumber = bankCardNumber;
	}

	/**
	 * 返回: the ccv2 <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getCcv2() {
		return ccv2;
	}

	/**
	 * 参数: ccv2 to set the ccv2 <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setCcv2(String ccv2) {
		this.ccv2 = ccv2;
	}

	/**
	 * 返回: the validityDate <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public String getValidityDate() {
		return validityDate;
	}

	/**
	 * 参数: validityDate to set the validityDate <br>
	 * 时间: 2013-2-25 下午2:29:55
	 */
	public void setValidityDate(String validityDate) {
		this.validityDate = validityDate;
	}
}
