package cn.itkt.btsf.hotel.po;
/**
 * @version 1.0
 * @author SunLing
 * @date 2012-11-2
 * @title 接收或封装订单信息
 */
import java.util.Date;

import cn.itkt.btsf.hotel.vo.FaxForSubmitHotelOrder;
public class HotelOrderInfoPO {
    private int activeLcdfee;
    private double activeRate;
    private String returnAvgLcdMoney;
	private Float totalPriceVouch;			//用于计算全额担保金额
	private Float firstDayPriceVouch;		//用于计算首晚担保金额 提交订单时用到
	private String userId;					//客户id  00：个人会员，01：企业会员，02：VIP，03：合作商户，04：移动商旅会员,05散客
	private String userType;				//客户类型
	/** 预订房间时，查询所需条件 **/
	private String terminalId; 				// 终端 默认callcenter
	private String hotelId; 				// 酒店ID
	private String roomTypeID;				// 房间类型ID
	private String startDateStr; 			// 开始日期(入店)
	private String endDateStr; 				// 结束日期(离店)
	private String vouchType;				//首晚担保0，或者全额担保1
	private String bookingRuless;			//酒店预订规则
	private String lcdOrderId;				//htl2012111614523655 不管成功与否，都会生成的本地订单号
	private Date createTime;				//订单创建时间
	private String orderMessage;			//预订失败原因
	/** 用于在填写订单时页面展现数据 **/
	private String stayAndLeave; 			// 开始日期与离店日期包含星期，上个页面已经存在，就不在运算星期了
	private String currencyCode; 			// 货币类型
	private String hotelName; 				// 酒店名称
	private String roomName;				//房间名称
	private String starCode; 				// 星级
	private String hotelAddress; 			// 酒店地址
	private String bedType; 				// 床型
	private String hotelPhone; 				// 酒店电话
	private Integer quantity;				// 酒店数量
	private Float singlePrice; 				// 预订房间的价格
	/** RatePlanForHotel **/
	private java.math.BigDecimal averagePrice;	//平均价格
	private java.lang.String guestTypeCode;		// 客店类型
	private java.lang.String ratePlanCode;		
	private int ratePlanID; 			// 是否含早餐Id
	private String ratePlanName; 		// 是否含早餐
	private java.lang.String returnLcdMoney;	
	private java.math.BigDecimal totalPrice;	

	/**以下为提交订单时补充**/
	private String arrivalLateTime;			//最晚到店时间
	private String arrivalEarlyTime;		//最早到店时间
	private String guestNames;				//入住人
	/**ContacterForSubmitHotelOrder**/
    private java.lang.String name;	//联系人
    private String noteElong;		//特殊要求
    private java.lang.String genderCode;//性别

    private java.lang.String email;			

    private java.lang.String mobile;		

    private java.lang.String idTypeCode;	//

    private java.lang.String idNumber;

    private FaxForSubmitHotelOrder fax;
    
    //private PhoneForSubmitHotelOrder phone;
    private int interCode_phone;

    private int areaCode_phone;

    private int nmber_phone;

    private int ext_phone;
    //private PhoneForSubmitHotelOrder phone;
    private int interCode_fax;
    
    private int areaCode_fax;
    
    private int nmber_fax;
    
    private int ext_fax;
    
    /**信用卡**/
    private java.lang.String number;

    private java.lang.String veryfyCode;

    private int validYear;

    private int validMonth;

    private java.lang.String cardHolderName;

    private java.lang.String idTypeCode_card;

    private java.lang.String idNumber_card;
    
    private String cityName;
    
    private String bankName;			//银行 信用卡所在
    
    private Float vouchMoney;					//担保金额
    
    private Boolean vouch;

	public Float getTotalPriceVouch() {
		return totalPriceVouch;
	}

	public void setTotalPriceVouch(Float totalPriceVouch) {
		this.totalPriceVouch = totalPriceVouch;
	}

	public Float getFirstDayPriceVouch() {
		return firstDayPriceVouch;
	}

	public void setFirstDayPriceVouch(Float firstDayPriceVouch) {
		this.firstDayPriceVouch = firstDayPriceVouch;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getTerminalId() {
		return terminalId;
	}

	public void setTerminalId(String terminalId) {
		this.terminalId = terminalId;
	}

	public String getHotelId() {
		return hotelId;
	}

	public void setHotelId(String hotelId) {
		this.hotelId = hotelId;
	}

	public String getRoomTypeID() {
		return roomTypeID;
	}

	public void setRoomTypeID(String roomTypeID) {
		this.roomTypeID = roomTypeID;
	}

	public String getStartDateStr() {
		return startDateStr;
	}

	public void setStartDateStr(String startDateStr) {
		this.startDateStr = startDateStr;
	}

	public String getEndDateStr() {
		return endDateStr;
	}

	public void setEndDateStr(String endDateStr) {
		this.endDateStr = endDateStr;
	}
	
	public Boolean getVouch() {
		return vouch;
	}

	public void setVouch(Boolean vouch) {
		this.vouch = vouch;
	}

	public Float getVouchMoney() {
		return vouchMoney;
	}

	public void setVouchMoney(Float vouchMoney) {
		this.vouchMoney = vouchMoney;
	}

	public String getVouchType() {
		return vouchType;
	}

	public void setVouchType(String vouchType) {
		this.vouchType = vouchType;
	}

	public String getBookingRuless() {
		return bookingRuless;
	}

	public void setBookingRuless(String bookingRuless) {
		this.bookingRuless = bookingRuless;
	}

	public String getStayAndLeave() {
		return stayAndLeave;
	}

	public void setStayAndLeave(String stayAndLeave) {
		this.stayAndLeave = stayAndLeave;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public String getStarCode() {
		return starCode;
	}

	public void setStarCode(String starCode) {
		this.starCode = starCode;
	}

	public String getHotelAddress() {
		return hotelAddress;
	}

	public void setHotelAddress(String hotelAddress) {
		this.hotelAddress = hotelAddress;
	}

	public String getBedType() {
		return bedType;
	}

	public void setBedType(String bedType) {
		this.bedType = bedType;
	}

	public String getHotelPhone() {
		return hotelPhone;
	}

	public void setHotelPhone(String hotelPhone) {
		this.hotelPhone = hotelPhone;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Float getSinglePrice() {
		return singlePrice;
	}

	public void setSinglePrice(Float singlePrice) {
		this.singlePrice = singlePrice;
	}

	public java.math.BigDecimal getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(java.math.BigDecimal averagePrice) {
		this.averagePrice = averagePrice;
	}

	public java.lang.String getGuestTypeCode() {
		return guestTypeCode;
	}

	public void setGuestTypeCode(java.lang.String guestTypeCode) {
		this.guestTypeCode = guestTypeCode;
	}

	public java.lang.String getRatePlanCode() {
		return ratePlanCode;
	}

	public void setRatePlanCode(java.lang.String ratePlanCode) {
		this.ratePlanCode = ratePlanCode;
	}

	public int getRatePlanID() {
		return ratePlanID;
	}

	public void setRatePlanID(int ratePlanID) {
		this.ratePlanID = ratePlanID;
	}

	public String getRatePlanName() {
		return ratePlanName;
	}

	public void setRatePlanName(String ratePlanName) {
		this.ratePlanName = ratePlanName;
	}

	public java.lang.String getReturnLcdMoney() {
		return returnLcdMoney;
	}

	public void setReturnLcdMoney(java.lang.String returnLcdMoney) {
		this.returnLcdMoney = returnLcdMoney;
	}

	public java.math.BigDecimal getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(java.math.BigDecimal totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getArrivalLateTime() {
		return arrivalLateTime;
	}

	public void setArrivalLateTime(String arrivalLateTime) {
		this.arrivalLateTime = arrivalLateTime;
	}

	public String getArrivalEarlyTime() {
		return arrivalEarlyTime;
	}

	public void setArrivalEarlyTime(String arrivalEarlyTime) {
		this.arrivalEarlyTime = arrivalEarlyTime;
	}

	public String getGuestNames() {
		return guestNames;
	}

	public void setGuestNames(String guestNames) {
		this.guestNames = guestNames;
	}

	public java.lang.String getName() {
		return name;
	}

	public void setName(java.lang.String name) {
		this.name = name;
	}

	public String getNoteElong() {
		return noteElong;
	}

	public void setNoteElong(String noteElong) {
		this.noteElong = noteElong;
	}

	public java.lang.String getGenderCode() {
		return genderCode;
	}

	public void setGenderCode(java.lang.String genderCode) {
		this.genderCode = genderCode;
	}

	public java.lang.String getEmail() {
		return email;
	}

	public void setEmail(java.lang.String email) {
		this.email = email;
	}

	public java.lang.String getMobile() {
		return mobile;
	}

	public void setMobile(java.lang.String mobile) {
		this.mobile = mobile;
	}

	public java.lang.String getIdTypeCode() {
		return idTypeCode;
	}

	public void setIdTypeCode(java.lang.String idTypeCode) {
		this.idTypeCode = idTypeCode;
	}

	public java.lang.String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(java.lang.String idNumber) {
		this.idNumber = idNumber;
	}

	public FaxForSubmitHotelOrder getFax() {
		return fax;
	}

	public void setFax(FaxForSubmitHotelOrder fax) {
		this.fax = fax;
	}

	public int getInterCode_phone() {
		return interCode_phone;
	}

	public void setInterCode_phone(int interCodePhone) {
		interCode_phone = interCodePhone;
	}

	public int getAreaCode_phone() {
		return areaCode_phone;
	}

	public void setAreaCode_phone(int areaCodePhone) {
		areaCode_phone = areaCodePhone;
	}

	public int getNmber_phone() {
		return nmber_phone;
	}

	public void setNmber_phone(int nmberPhone) {
		nmber_phone = nmberPhone;
	}

	public int getExt_phone() {
		return ext_phone;
	}

	public void setExt_phone(int extPhone) {
		ext_phone = extPhone;
	}

	public int getInterCode_fax() {
		return interCode_fax;
	}

	public void setInterCode_fax(int interCodeFax) {
		interCode_fax = interCodeFax;
	}

	public int getAreaCode_fax() {
		return areaCode_fax;
	}

	public void setAreaCode_fax(int areaCodeFax) {
		areaCode_fax = areaCodeFax;
	}

	public int getNmber_fax() {
		return nmber_fax;
	}

	public void setNmber_fax(int nmberFax) {
		nmber_fax = nmberFax;
	}

	public int getExt_fax() {
		return ext_fax;
	}

	public void setExt_fax(int extFax) {
		ext_fax = extFax;
	}

	public java.lang.String getNumber() {
		return number;
	}

	public void setNumber(java.lang.String number) {
		this.number = number;
	}

	public java.lang.String getVeryfyCode() {
		return veryfyCode;
	}

	public void setVeryfyCode(java.lang.String veryfyCode) {
		this.veryfyCode = veryfyCode;
	}

	public int getValidYear() {
		return validYear;
	}

	public void setValidYear(int validYear) {
		this.validYear = validYear;
	}

	public int getValidMonth() {
		return validMonth;
	}

	public void setValidMonth(int validMonth) {
		this.validMonth = validMonth;
	}

	public java.lang.String getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(java.lang.String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}

	public java.lang.String getIdTypeCode_card() {
		return idTypeCode_card;
	}

	public void setIdTypeCode_card(java.lang.String idTypeCodeCard) {
		idTypeCode_card = idTypeCodeCard;
	}

	public java.lang.String getIdNumber_card() {
		return idNumber_card;
	}

	public void setIdNumber_card(java.lang.String idNumberCard) {
		idNumber_card = idNumberCard;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getLcdOrderId() {
		return lcdOrderId;
	}

	public void setLcdOrderId(String lcdOrderId) {
		this.lcdOrderId = lcdOrderId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getOrderMessage() {
		return orderMessage;
	}

	public void setOrderMessage(String orderMessage) {
		this.orderMessage = orderMessage;
	}

	public int getActiveLcdfee() {
		return activeLcdfee;
	}

	public void setActiveLcdfee(int activeLcdfee) {
		this.activeLcdfee = activeLcdfee;
	}

	public double getActiveRate() {
		return activeRate;
	}

	public void setActiveRate(double activeRate) {
		this.activeRate = activeRate;
	}

	public String getReturnAvgLcdMoney() {
		return returnAvgLcdMoney;
	}

	public void setReturnAvgLcdMoney(String returnAvgLcdMoney) {
		this.returnAvgLcdMoney = returnAvgLcdMoney;
	}
    
}
