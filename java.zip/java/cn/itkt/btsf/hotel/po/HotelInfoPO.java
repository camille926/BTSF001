package cn.itkt.btsf.hotel.po;
/**
 * @version 1.0
 * @author SunLing
 * @date 2012-11-07
 * @title 订单中的酒店信息
 */
public class HotelInfoPO {
	private Long id;
	private Long resorderid;				//订单提交数据表ID
	private String hotelcode;				//酒店代码
	private String hotelname;				//酒店名称
	private String cityname;				//城市名称
	private String brandname;				//品牌名称
	private Integer quantity;				//预订的房间数量
	private String rateplanid;				//艺龙在房型基础上把产品进一个细分，细分后的每一产品称为RatePlan，简称RP
	private String bedtype;					//床型
	private String roomname;				//房间名称
	private String roomtypeid;				//房间类型编码
	private String rateplanname;			//业务名称
	private String hoteladdress;			//酒店地址
	private String notetoelong;				//特殊要求
	private String guarantee;				//预订规则
	private String star;						//星级
	private Float firstdayprice;			//第一天价格
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getResorderid() {
		return resorderid;
	}
	public void setResorderid(Long resorderid) {
		this.resorderid = resorderid;
	}
	public String getHotelcode() {
		return hotelcode;
	}
	public void setHotelcode(String hotelcode) {
		this.hotelcode = hotelcode;
	}
	public String getHotelname() {
		return hotelname;
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	public String getBrandname() {
		return brandname;
	}
	public void setBrandname(String brandname) {
		this.brandname = brandname;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getRateplanid() {
		return rateplanid;
	}
	public void setRateplanid(String rateplanid) {
		this.rateplanid = rateplanid;
	}
	public String getBedtype() {
		return bedtype;
	}
	public void setBedtype(String bedtype) {
		this.bedtype = bedtype;
	}
	public String getRoomname() {
		return roomname;
	}
	public void setRoomname(String roomname) {
		this.roomname = roomname;
	}
	public String getRoomtypeid() {
		return roomtypeid;
	}
	public void setRoomtypeid(String roomtypeid) {
		this.roomtypeid = roomtypeid;
	}
	public String getRateplanname() {
		return rateplanname;
	}
	public void setRateplanname(String rateplanname) {
		this.rateplanname = rateplanname;
	}
	public String getHoteladdress() {
		return hoteladdress;
	}
	public void setHoteladdress(String hoteladdress) {
		this.hoteladdress = hoteladdress;
	}
	public String getNotetoelong() {
		return notetoelong;
	}
	public void setNotetoelong(String notetoelong) {
		this.notetoelong = notetoelong;
	}
	public String getGuarantee() {
		return guarantee;
	}
	public void setGuarantee(String guarantee) {
		this.guarantee = guarantee;
	}
	public String getStar() {
		return star;
	}
	public void setStar(String star) {
		this.star = star;
	}
	public Float getFirstdayprice() {
		return firstdayprice;
	}
	public void setFirstdayprice(Float firstdayprice) {
		this.firstdayprice = firstdayprice;
	}
	
}
